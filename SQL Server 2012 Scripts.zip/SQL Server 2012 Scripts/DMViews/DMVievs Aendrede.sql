USE master;
GO
SELECT *
	FROM sys.dm_exec_query_stats;

SELECT *
	FROM sys.dm_os_volume_stats(DB_ID('IndexDB'), 1);

SELECT *
	FROM sys.dm_os_windows_info;

SELECT *
	FROM sys.dm_server_memory_dumps;

SELECT *
	FROM sys.dm_server_services;

SELECT *
	FROM sys.dm_server_registry;
GO
