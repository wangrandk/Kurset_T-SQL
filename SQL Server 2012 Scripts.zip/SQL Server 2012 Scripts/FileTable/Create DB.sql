USE master;
GO
DROP DATABASE FileTableDB;
GO
--Filestream skal v�re enabled
EXEC sp_configure filestream_access_level, 2;
RECONFIGURE;
GO
CREATE DATABASE FileTableDB 
ON
PRIMARY 
	(NAME = FileTableDBPrimary,
     FILENAME = 'c:\SQL Server 2012 Scripts\FileTableDBPrimary.mdf'),
FILEGROUP FileStreamGroup1 CONTAINS FILESTREAM
	(NAME = FileTableDBFS,
     FILENAME = 'c:\SQL Server 2012 Scripts\FileTableDBFS')
LOG ON  
	(NAME = FileTableDBlog,
     FILENAME = 'c:\SQL Server 2012 Scripts\FileTableDB.ldf')

	WITH FILESTREAM (NON_TRANSACTED_ACCESS = FULL, DIRECTORY_NAME = 'FileTableDir');
GO
USE FileTableDB;
SELECT *
	FROM sys.database_filestream_options;
GO
CREATE TABLE DocumentStore1 AS FileTable;
GO
CREATE TABLE DocumentStore2 AS FileTable WITH 
( 
	FileTable_Directory = 'FiletableData',
	FileTable_Collate_Filename = database_default
);
GO
