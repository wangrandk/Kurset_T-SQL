USE master;
GO
EXEC sp_configure 'show advanced options', 1;
GO
RECONFIGURE WITH OVERRIDE;
GO 
EXEC sp_configure 'contained database authentication', 1;
GO
RECONFIGURE WITH OVERRIDE;
GO 
EXEC sp_configure 'show advanced options', 0;
GO
RECONFIGURE WITH OVERRIDE;
