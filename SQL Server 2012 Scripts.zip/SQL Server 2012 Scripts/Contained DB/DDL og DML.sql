SELECT *
	FROM sys.databases;
GO
CREATE TABLE dbo.t
(
	Id		INT NOT NULL
);
GO
INSERT INTO dbo.t VALUES
	(123),
	(456),
	(789);
GO
SELECT *
	FROM dbo.t;
