USE master;
GO
DROP DATABASE ContainedDB;
GO
CREATE DATABASE ContainedDB
	CONTAINMENT = PARTIAL
	ON PRIMARY 
		(NAME = N'ContainedDB', 
		 FILENAME = N'C:\Databaser\ContainedDB.mdf', 
		 SIZE = 5120KB, 
		 FILEGROWTH = 1024KB )
	LOG ON 
		(NAME = N'ContainedDB_log', 
		 FILENAME = N'C:\Databaser\ContainedDB_log.ldf', 
		 SIZE = 1024KB, 
		 FILEGROWTH = 10%);
