USE master;
GO
DROP DATABASE BufferpoolDB;
GO
CREATE DATABASE BufferpoolDB;
GO
USE BufferpoolDB;
CREATE TABLE dbo.t
(
	ID			INT			NOT NULL PRIMARY KEY,
	Txt			CHAR(2000)	NOT NULL DEFAULT(REPLICATE('x', 2000))
);
GO
SELECT *
	from sys.dm_os_buffer_descriptors
	WHERE database_id = DB_ID()
	ORDER BY file_id, page_id
GO
SELECT *
	FROM sys.allocation_units