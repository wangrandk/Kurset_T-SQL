USE IndexDB;
GO
DECLARE		@StartingRowNumber	TINYINT = 20,
        	@FetchRows TINYINT = 20;

 SELECT *
	FROM dbo.Person
	ORDER BY	PersonID ASC 
				OFFSET @StartingRowNumber ROWS 
				FETCH NEXT @FetchRows ROWS ONLY;
GO
DECLARE		@StartingRowNumber	TINYINT = 20,
        	@FetchRows TINYINT = 20;

 SELECT *
	FROM dbo.Person
	ORDER BY	PersonID ASC 
				OFFSET @StartingRowNumber ROWS 
				FETCH FIRST @FetchRows ROWS ONLY; 
GO
DECLARE		@StartingRowNumber	INT = 2010000,
        	@FetchRows INT = 20;

 SELECT *
	FROM dbo.Person
	ORDER BY	PersonID ASC 
				OFFSET @StartingRowNumber ROWS 
				FETCH NEXT @FetchRows ROWS ONLY;
GO
DECLARE		@StartingRowNumber	INT = 6000000

 SELECT *
	FROM dbo.Person
	ORDER BY	PersonID ASC 
				OFFSET @StartingRowNumber ROWS
GO
DECLARE		@RowsPrPage INT = 20,
			@Pagenumber INT = 4;

SELECT *
	FROM dbo.Person
	ORDER BY	PersonID ASC 
				OFFSET (@Pagenumber - 1) * @RowsPrPage  ROWS 
				FETCH NEXT @RowsPrPage ROWS ONLY;
  
GO
DECLARE		@PersoniD	INT = 2000

 SELECT *
	FROM dbo.Person
	WHERE PersonId > @PersonID
	ORDER BY	PersonID ASC 
				OFFSET 0 ROWS
				FETCH NEXT 20 ROWS ONLY;
GO
