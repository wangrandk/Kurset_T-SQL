USE master;
GO
DROP DATABASE FilesDemo;
GO
CREATE DATABASE FilesDemo
ON PRIMARY 
(
	NAME = Data1, 
	FILENAME='C:\Databaser\FilesDemo_Data.mdf'
),
FILEGROUP FilestreamGroup1 CONTAINS FILESTREAM
(
	NAME=Data2, 
	FILENAME='C:\Databaser\Filestream'
)
LOG ON 
(
	NAME=Log1, 
	FILENAME='C:\Databaser\FilesDemo_Log.ldf'
)
WITH FILESTREAM 
(
	NON_TRANSACTED_ACCESS = FULL, 
	DIRECTORY_NAME=N'FilestreamData'
);
GO
-- Create filetable
USE FilesDemo;
GO
CREATE TABLE FileStore AS FileTable
WITH
(
	FileTable_Directory = 'Documents'
);
GO

-- Now copy files to \\localhost\MSSQLSERVER\FilestreamData\Documents

GO

-- Query FileTable
SELECT	[name], FileTableRootPath() + file_stream.GetFileNamespacePath() AS FullPath
	FROM FileStore;
GO
-- Create full-text catalog
CREATE FULLTEXT CATALOG documents_catalog;
GO
-- Get index ID for FileTable PK
SELECT [name] 
	FROM sys.sysindexes 
	WHERE [name] LIKE 'PK__FileStor%';
GO
-- Create full-text index
CREATE FULLTEXT INDEX ON FileStore
(
	[name]			Language 1033, 
	[file_stream]	TYPE COLUMN
	[file_type]		Language 1033
)
--	KEY INDEX PK__FileStor__xxxxxxxxxxxxx -- REPLACE WITH PK INDEX ID
	KEY INDEX PK__FileStor__5A5B77D56A214246 -- REPLACE WITH PK INDEX ID
	ON documents_catalog;
GO

-- Find documents containing "imperdiet" near "vivamus" (within 15 search terms)
SELECT	[name], 
		FileTableRootPath() + file_stream.GetFileNamespacePath() AS Fullath
	FROM FileStore
	WHERE CONTAINS(file_stream, 'NEAR((teknologisk, institut), 15)');
