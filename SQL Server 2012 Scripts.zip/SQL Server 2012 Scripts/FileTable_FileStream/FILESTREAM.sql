USE master;
GO
--SELECT * FROM sys.configurations
--ORDER BY name 
--GO
--EXEC sp_configure filestream_access_level, 1
--GO
--RECONFIGURE
--GO
--SELECT * FROM sys.configurations
--ORDER BY name 
--GO
DROP DATABASE DatatypeDB;
GO
CREATE DATABASE DatatypeDB 
ON
PRIMARY 
	(NAME = DatatypeDB_Data,
	 FILENAME = 'c:\Databaser\DatatypeDB.mdf'),
FILEGROUP FileStreamGroup CONTAINS FILESTREAM
	(NAME = DatatypeDB_FS,
     FILENAME = 'c:\Databaser\Filestream_DatatypeDB')
LOG ON  
	(NAME = DatatypeDB_Log,
     FILENAME = 'c:\Databaser\DatatypeDB.ldf');
GO
USE DatatypeDB;
GO
CREATE TABLE dbo.Tekster 
(
	Id				UNIQUEIDENTIFIER ROWGUIDCOL NOT NULL UNIQUE, 
	Serienummer		INTEGER UNIQUE,
	Tekst			VARBINARY(MAX) FILESTREAM NULL
);
GO
INSERT INTO dbo.Tekster 
	VALUES (NEWID(), 1, CAST('Dette er en tekst. ' AS VARBINARY(MAX)));
INSERT INTO dbo.Tekster 
	VALUES (NEWID(), 2, CAST(REPLICATE(CAST('Dette er en stor tekst. ' AS VARCHAR(MAX)), 1000) AS VARBINARY(MAX)));
INSERT INTO dbo.Tekster 
	VALUES (NEWID(), 3, CAST(REPLICATE(CAST('Dette er en meget stor tekst. ' AS VARCHAR(MAX)), 10000) AS VARBINARY(MAX)));
INSERT INTO dbo.Tekster 
	VALUES (NEWID(), 4, CAST(REPLICATE(CAST('Dette er en meget, meget stor tekst. ' AS VARCHAR(MAX)), 100000) AS VARBINARY(MAX)));
INSERT INTO dbo.Tekster 
	VALUES (NEWID(), 5, NULL);
GO
SELECT Id, Serienummer, CAST(Tekst AS VARCHAR(MAX)) AS Tekst
	FROM dbo.Tekster;
GO
BACKUP DATABASE DatatypeDB TO DISK = 'C:\Rod\DatatypeDB.bak' WITH INIT;
GO
USE master;
GO
DROP DATABASE DatatypeDB;
GO
RESTORE DATABASE DatatypeDB FROM DISK = 'C:\Rod\DatatypeDB.bak' WITH RECOVERY;
GO
USE DatatypeDB;
GO
SELECT	Id, 
		Serienummer, 
		LEN(Tekst) AS Length, 
		CAST(Tekst AS VARCHAR(MAX)) AS Tekst
	FROM dbo.Tekster
	WHERE Serienummer = 2;
GO
UPDATE dbo.Tekster 
	SET Tekst = CAST('nye data' AS VARBINARY(MAX))
	WHERE Serienummer = 1;
GO
SELECT	Id, 
		Serienummer, 
		Tekst.PathName(),
		Tekst.PathName(0),
		Tekst.PathName(1),
		Tekst.PathName(2)
	FROM dbo.Tekster;
GO
USE DatatypeDB;
GO
