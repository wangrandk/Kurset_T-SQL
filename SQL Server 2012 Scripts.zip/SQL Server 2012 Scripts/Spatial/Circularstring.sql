DECLARE @g	geometry = 'CIRCULARSTRING(0 2, 2 0, 4 2, 2 4, 0 2)';

SELECT @g.STIsValid(); -- valid spec?
SELECT @g.STNumPoints(); -- 5 punkter, f�rste og sidste det samme, s� en cirkel
SELECT @g;
GO
DECLARE @g	geometry = 'CIRCULARSTRING(0 2, 2 0, 4 2, 2 4, 0 2)';

SELECT	@g.STCurveToLine();
SELECT	@g.CurveToLineWithTolerance(0.01,0);
GO
DECLARE @g	geometry = 'CIRCULARSTRING(0 2, 2 0, 4 2, 2 4, 0 2)';

-- circle densification
SELECT	@g.STCurveToLine().STNumPoints(), -- 65 points,
		@g.CurveToLineWithTolerance(0.01,0).STNumPoints(); -- 33 points 
GO
DECLARE @g	geometry = 'COMPOUNDCURVE	(
										CIRCULARSTRING (-4 55, -4.5 54.5, -4 54) , 
										(-4 54, 1 55),
										CIRCULARSTRING (1 55, 1.5 54.5, 1 54)
										)';

SELECT @g;
GO
DECLARE @g	geometry = 'CURVEPOLYGON(CIRCULARSTRING(0 2, 2 0, 4 2, 2 4, 0 2))';

SELECT @g;
GO
DECLARE @jorden		geography = geography::STGeomFromText('FULLGLOBE', 4326);

SELECT @jorden;
