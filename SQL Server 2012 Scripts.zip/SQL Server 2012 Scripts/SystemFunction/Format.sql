-- Demo: FORMAT
-- Syntaks: FORMAT ( value, format [, culture ] )
-- 'format': en gyldig .NET Framework format string
USE master;
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'FunctionDB')
	DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
EXEC sp_configure 'clr_enabled', 1;	-- FORMAT foruds�tter, at .NET CLR er aktiveret
GO
RECONFIGURE;
GO
USE FunctionDB;
GO

-- Custom Numeric Format Strings: http://msdn.microsoft.com/en-us/library/0c899ak8(v=vs.110).aspx

-- Positivt, Negativt, Nul
SELECT FORMAT(1, 'YES;NO;Nul'), FORMAT(-1, 'YES;NO;Nul'), FORMAT(0, 'YES;NO;Nul');

SELECT FORMAT(27, 'YES;NO;Nul'), FORMAT(-27, 'YES;NO;Nul'), FORMAT(0, 'YES;NO;Nul');

SELECT FORMAT(1, 'True;False;Nul'), FORMAT(-1, 'True;False;Nul'), FORMAT(0, 'True;False;Nul');

SELECT FORMAT(1, 'Positiv;Negativ;Nul'), FORMAT(-1, 'Positiv;Negativ;Nul'), FORMAT(0, 'Positiv;Negativ;Nul');
GO

-- Numeric - eksempler
SELECT FORMAT(0.123, '0.00');
SELECT FORMAT(0.127, '0.00');
SELECT FORMAT(0.123, '0.00%');

SELECT FORMAT(127528.12, '###,###.##');
 
SELECT FORMAT(2109.2745, 'N', 'en-us') AS [Number Format];
SELECT FORMAT(2109.2745, 'G', 'en-us') AS [General Format];
SELECT FORMAT(2109.2745, 'C', 'en-us') AS [Currency Format];
 
SELECT FORMAT(2109.2745, 'N', 'da-DK') AS [Number Format];
SELECT FORMAT(2109.2745, 'G', 'da-DK') AS [General Format];
SELECT FORMAT(2109.2745, 'C', 'da-DK') AS [Currency Format];

-- Date - eksempler
DECLARE @d DATETIME = '2012-2-14';

SELECT	FORMAT ( @d, 'd', 'en-US' ) AS US, 
		FORMAT ( @d, 'd', 'da-DK' ) AS DK;

SELECT	FORMAT ( @d, 'D', 'en-US' ) AS US, 
		FORMAT ( @d, 'D', 'da-DK' ) AS DK;

SELECT	FORMAT ( @d, 'dd/MM/yyyy', 'en-US' ) AS US, 
		FORMAT ( @d, 'dd/MM/yyyy', 'da-DK' ) AS DK;
GO
DROP DATABASE FunctionDB;
