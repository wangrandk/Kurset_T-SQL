-- Demo:			Funktion: FORMAT
--					...
-- Filnavn:			Format.sql
-- Foruds�tninger:	Ingen
--					...
-- Rev. den/af:		25.01.2015/TR
-- ------------------------------------------------------------------
-- Etabl�r demo-milj�
-- ------------------------------------------------------------------
USE master;
-- Aktiv�r muligheden for at afvikle eksterne programmer
-- vha. af EXEC xp_cmdshell
EXEC sp_configure 'show advanced options', 1;
GO
RECONFIGURE;
GO
EXEC sp_configure 'xp_cmdshell', 1;
GO
RECONFIGURE;
GO
EXEC sp_configure 'clr_enabled', 1;	-- FORMAT foruds�tter, at .NET CLR er aktiveret
GO
RECONFIGURE;
GO
-- Opret hj�lpekatalog
EXEC xp_cmdshell 'mkdir C:\Temp_SQLDemo\';
GO
USE master
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'FormatDB')
	DROP DATABASE FormatDB;
GO
CREATE DATABASE FormatDB;
GO
USE FormatDB;
GO

-- Sprog
-- ------------------------------------------------------------------
-- Tilg�ngelige sprog
SELECT * FROM sys.syslanguages;
-- Aktuel sprog
SELECT @@language;


-- Formattering af output
-- ------------------------------------------------------------------
-- Syntaks: FORMAT ( value, format [, culture ] )
-- 'format': en gyldig .NET Framework format string
-- 'culture': https://msdn.microsoft.com/en-us/library/system.globalization.cultureinfo(vs.71).aspx

-- Positivt, Negativt, Nul
SELECT	FORMAT(1, 'YES;NO;Nul'), 
		FORMAT(-1, 'YES;NO;Nul'), 
		FORMAT(0, 'YES;NO;Nul'), 
		FORMAT(CAST(NULL AS INT), 'YES;NO;Nul');
GO
SELECT	FORMAT(27, 'YES;NO;Nul'), 
		FORMAT(-27, 'YES;NO;Nul'), 
		FORMAT(0, 'YES;NO;Nul');
GO
SELECT	FORMAT(1, 'True;False;Nul'), 
		FORMAT(-1, 'True;False;Nul'), 
		FORMAT(0, 'True;False;Nul');
GO
SELECT	FORMAT(1, 'Positiv;Negativ;Nul'), 
		FORMAT(-1, 'Positiv;Negativ;Nul'), 
		FORMAT(0, 'Positiv;Negativ;Nul');
GO

-- Numeric - eksempler
-- Custom Numeric Format Strings: http://msdn.microsoft.com/en-us/library/0c899ak8(v=vs.110).aspx
SELECT	FORMAT(2109.2745, 'N', 'en-us') AS [Number Format_en-us],
		FORMAT(2109.2745, 'G', 'en-us') AS [General Format_en-us],
		FORMAT(2109.2745, 'C', 'en-us') AS [Currency Format_en-us];
GO 
SELECT	FORMAT(2109.2745, 'N', 'da-DK') AS [Number Format_da-DK],
		FORMAT(2109.2745, 'G', 'da-DK') AS [General Format_da-DK],
		FORMAT(2109.2745, 'C', 'da-DK') AS [Currency Format_da-DK];
GO
SELECT	FORMAT(0.123, '0.00') AS [0.123-0.00],
		FORMAT(0.127, '0.00') AS [0.127-0.00],	-- bem�rk 'oprunding'
		FORMAT(0.127, '0.000') AS [0.127-0.000],
		FORMAT(0.123, '0.00%') AS [0.123-0.00%];
GO
SELECT	FORMAT(127528.12, '###,###.##') AS [127528.12-###,###.##_en-us],
		FORMAT(127528.12, '###,###.##', 'da-dk') AS [127528.12-###.###,##_da-dk],
		FORMAT(127528.127, '###,###.##', 'da-dk') AS [127528.12-###.###,##_da-dk],
		FORMAT(27528.127, '###,###.##', 'da-dk') AS [27528.12-###.###,##_da-dk],
		FORMAT(27528.127, '000,000.00', 'da-dk') AS [27528.12-000.000,00_da-dk];

-- Date - eksempler
DECLARE @d DATETIME = '2012-02-14';
SELECT	FORMAT ( @d, 'd', 'en-US' ) AS [d_en-US], 
		FORMAT ( @d, 'd', 'da-DK' ) AS [d_da-DK],
		FORMAT ( @d, 'D', 'en-US' ) AS [D_en-US], 
		FORMAT ( @d, 'D', 'da-DK' ) AS [D_da-DK],
		FORMAT ( @d, 'dd/MM/yy', 'en-US' ) AS [dd/MM/yy_en-US], 
		FORMAT ( @d, 'dd/MM/yy', 'da-DK' ) AS [dd/MM/yy_da-DK],
		FORMAT ( @d, 'dd/MM/yyyy', 'da-DK' ) AS [dd/MM/yyyy_da-DK],
		FORMAT ( @d, 'dd/M/yy', 'da-DK' ) AS [dd/M/yy_da-DK];
GO
DECLARE @d DATETIME = '2012-02-01';
SELECT	FORMAT ( @d, 'd/M/yyyy', 'da-DK' ) AS [d/M/yyyy_da-DK];
GO

-- Time - eksempler
DECLARE @t TIME(0) = '09:35:05';
SELECT @t;
SELECT	FORMAT (@t, 'hh') AS [Timer],
		FORMAT (@t, 'mm') AS [Minutter],
		FORMAT (@t, 'ss') AS [Sekunder];
GO
DECLARE @t TIME(3) = '09:35:05:257';
SELECT @t;
SELECT	FORMAT (@t, 'hh') AS [Timer],
		FORMAT (@t, 'mm') AS [Minutter],
		FORMAT (@t, 'ss') AS [Sekunder],
		FORMAT (@t, 'fff') AS [Tusindedele Sekunder];
GO
DECLARE @t TIME(3) = '09:35:05:257';
SELECT @t;
SELECT	FORMAT (@t, '"Sekunder,Minutter,Timer: "ff\*mm\*hh') AS [Mit format];
GO


-- DROP DATABASE FormatDB
-- Oprydning
-- ------------------------------------------------------------------
-- Evt. sletning af diverse demo-filer
USE master;
GO
DROP DATABASE FormatDB;
GO
