USE master;
GO
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'FunctionDB')
            DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
USE FunctionDB;

--The ";" Section Separator
----------------------------------------------------------------------------------
--The semicolon (;) is a conditional format specifier that applies different formatting to a number depending on whether its value is positive, negative, or zero. To produce this behavior, a custom format string can contain up to three sections separated by semicolons. These sections are described in the following table. 


--Description
 

--One section
 
--The format string applies to all values.
 

--Two sections
 
--The first section applies to positive values and zeros, and the second section applies to negative values. 

--If the number to be formatted is negative, but becomes zero after rounding according to the format in the second section, the resulting zero is formatted according to the first section.
 

--Three sections
 
--The first section applies to positive values, the second section applies to negative values, and the third section applies to zeros. 

--The second section can be left empty (by having nothing between the semicolons), in which case the first section applies to all nonzero values. 

--If the number to be formatted is nonzero, but becomes zero after rounding according to the format in the first or second section, the resulting zero is formatted according to the third section.
 

SELECT FORMAT(1, 'YES'), FORMAT(-1, 'YES'), FORMAT(0, 'YES');

SELECT FORMAT(1, 'YES;NO'), FORMAT(-1, 'YES;NO'), FORMAT(0, 'YES;NO');

SELECT FORMAT(1, 'YES;NO;NUL'), FORMAT(-1, 'YES;NO;NUL'), FORMAT(0, 'YES;NO;NUL');
