USE master;
DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
USE FunctionDB;
GO
-- CHOOSE
SELECT CHOOSE(2, 'en', 'to', 'tre');
GO
SELECT CHOOSE(4, 'en', 'to', 'tre');
GO
CREATE TABLE dbo.t 
(
	ID			INT NOT NULL PRIMARY KEY,
	Kode		SMALLINT NOT NULL,
	A			CHAR(1) NOT NULL,
	B			CHAR(1) NOT NULL,
	C			CHAR(1) NOT NULL,
	D			CHAR(1) NOT NULL,
	E			CHAR(1) NOT NULL
);
GO
INSERT INTO dbo.t VALUES
	(1, 5, 'A', 'B', 'C', 'D', 'E'),
	(2, 4, 'A', 'B', 'C', 'D', 'E'),
	(3, 3, 'A', 'B', 'C', 'D', 'E'),
	(4, 2, 'A', 'B', 'C', 'D', 'E'),
	(5, 1, 'A', 'B', 'C', 'D', 'E'),
	(6, 0, 'A', 'B', 'C', 'D', 'E'),
	(7, 6, 'A', 'B', 'C', 'D', 'E');
GO
SELECT	*, 
		CHOOSE(Kode, A, B, C, D, E) AS ValgtVaerdi
	FROM dbo.t;
GO
SELECT *
	FROM (VALUES (1, 'Januar'), 
				 (2, 'Februar'),
				 (3, 'Marts')) AS MdNavne(Mdnr, MdNavn);
GO
CREATE TABLE dbo.MdData
(
	ID		INT,
	Mdnr	SMALLINT
);
GO
INSERT INTO dbo.MdData VALUES
	(1, 3), (2, 2), (3, 1), (4, 3);
GO
SELECT *
	FROM dbo.MdData INNER JOIN (VALUES	(1, 'Januar', 1), 
										(2, 'Februar', 1),
										(3, 'Marts', 1)) AS MdNavne(Mdnr, MdNavn, Kvartal) 
				ON Mddata.Mdnr = MdNavne.Mdnr;
GO
SELECT	*, 
		CHOOSE(Mdnr, 'Januar', 'Februar', 'Marts')
	FROM dbo.MdData;
