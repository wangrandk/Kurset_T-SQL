USE master;
DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
USE FunctionDB;
GO
-- IIF/Case
CREATE TABLE dbo.Kunde 
(
	KundeID			INT NOT NULL PRIMARY KEY IDENTITY,
	Fornavn			VARCHAR(20) NULL, 
	Efternavn		VARCHAR(20) NULL,
	Firmanavn		VARCHAR(30) NULL,
	NavnIIF			AS IIF(Firmanavn IS NULL, Fornavn + ' ' + Efternavn, Firmanavn),
	NavnCase		AS CASE 
							WHEN Firmanavn IS NULL THEN Fornavn + ' ' + Efternavn
							ELSE Firmanavn
						END, 

	CONSTRAINT CK_Kunde__Navn CHECK (	(Fornavn IS NULL AND EfterNavn IS NULL AND Firmanavn IS NOT NULL) OR 
										(Fornavn IS NOT NULL AND EfterNavn IS NOT NULL AND Firmanavn IS NULL))
);
GO
INSERT INTO dbo.Kunde VALUES
	('Jens Peter', 'Larsen', NULL),
	(Null, NULL, 'Smeden Aps');
GO
SELECT *
	FROM dbo.Kunde;
GO
CREATE TABLE dbo.Medarbejder 
(
	MedarbId			INT NOT NULL PRIMARY KEY,
	Navn				VARCHAR(20) NOT NULL,
	Tiltraadt			DATE NOT NULL DEFAULT(SYSDATETIME()),
	Fratraadt			DATE NOT NULL DEFAULT ('2099-12-31')
);
GO
INSERT INTO dbo.Medarbejder(MedarbId, Navn) VALUES
	(1, 'Ole'),
	(2, 'Ida');
GO
INSERT INTO dbo.Medarbejder(MedarbId, Navn, Fratraadt) VALUES
	(3, 'Per', '2013-11-30');
GO
SELECT	*,
		IIF(Fratraadt = '2099-12-31', NULL, Fratraadt) AS AktuelFratraadt
	FROM dbo.Medarbejder;
GO
SELECT	*,
		ISNULL(IIF(Fratraadt = '2099-12-31', NULL, Fratraadt), SYSDATETIME()) AS AktuelFratraadt
	FROM dbo.Medarbejder;
GO
SELECT *
	FROM dbo.Medarbejder
	WHERE ISNULL(IIF(Fratraadt = '2099-12-31', NULL, Fratraadt), SYSDATETIME()) = SYSDATETIME();
