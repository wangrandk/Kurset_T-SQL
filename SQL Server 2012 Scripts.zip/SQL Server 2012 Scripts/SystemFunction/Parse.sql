USE master;
DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
USE FunctionDB;
GO
-- PARSE
SELECT	PARSE('Monday, 13 December 2010' AS DATE USING 'en-US') AS USDato,
		PARSE('Mandag, 13 December 2010' AS DATE USING 'da-DK') AS DKDato,
		PARSE('28 Februar 2010' AS DATE USING 'da-DK') AS DKDato,
		PARSE('Tirsdag, 13 December 2011 17:23:46' AS DATETIME2 USING 'da-DK') AS DKDatetime;

SELECT PARSE('Friday, 16 December 2011' AS DATETIME2 USING 'en-US') AS Resultat;

SELECT PARSE('Tirsdag, 13 December 2011' AS DATETIME2 USING 'da-DK') AS Resultat;

SELECT PARSE('Tirsdag, 13 December 2011' AS DATE USING 'da-DK') AS Resultat;

SELECT PARSE('Onsdag, 13 December 2011' AS DATETIME2 USING 'da-DK') AS Resultat; -- fejl 13 dec. er en tirsdag
SELECT PARSE('Tirsdag, 13 December 2011' AS DATETIME2 USING 'en-US') AS Resultat; -- cultur fejl
GO
SELECT PARSE('�256,75' AS MONEY USING 'de-DE') AS Resultat;
SELECT PARSE('�4256,75' AS MONEY USING 'de-DE') AS Resultat;
SELECT PARSE('�4.256,75' AS MONEY USING 'de-DE') AS Resultat;

SELECT PARSE('�2,25' AS MONEY USING 'da-DK') AS Resultat; -- Fejl, Danmark har ikke Euro
SELECT PARSE('�2,25' AS MONEY) AS Resultat; -- Fejl, da kultur ikke er angivet
SELECT PARSE('2,25' AS MONEY) AS Resultat;

SELECT PARSE('$123,23' AS MONEY USING 'en-US') AS Resultat;
SELECT PARSE('$123.23' AS MONEY USING 'en-US') AS Resultat;
SELECT PARSE('$123,456.23' AS MONEY USING 'en-US') AS Resultat;
GO
SELECT PARSE('$1,2,3,4,5,6.23' AS MONEY USING 'en-US') AS Resultat;
SELECT PARSE('$123,45.6.23' AS MONEY USING 'en-US') AS Resultat;

SELECT PARSE('1,2,3,4,5,6.23' AS MONEY USING 'da-DK') AS Resultat;
SELECT PARSE('1..2.3,45' AS MONEY USING 'da-DK') AS Resultat;
SELECT PARSE('1.2.3,4.5' AS MONEY USING 'da-DK') AS Resultat;		-- fejl
GO
DECLARE @Culture		VARCHAR(5) = 'en-US';

SELECT PARSE('$123,23' AS MONEY USING @Culture) AS Resultat;
