USE master;
DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
USE FunctionDB;
CREATE TABLE dbo.Person 
(
	PersoniD		SMALLINT	NOT NULL IDENTITY PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	Gade			VARCHAR(30) NOT NULL,
	Husnr			SMALLINT	NOT NULL,
	Etage			VARCHAR(3)	NULL,
	Side			VARCHAR(3)	NULL,
	Postnr			SMALLINT	NOT NULL
);
GO
INSERT INTO dbo.Person VALUES
	('Ole', 'Hansen', 'Vestergade', 27, NULL, NULL, 2000),
	('Ida', 'Jensen', '�stergade', 46, '1.', 'tv.', 7000),
	('Per', 'Olsen', 'S�ndergade', 5, 'st.', NULL, 8000),
	('Ane', 'Poulsen', 'Torvet', 7, NULL, 'mf.', 2000),
	('Lars', 'Karlsen', 'N�rregade', 19, 'st.', NULL, 5000),
	('Susanne', 'Didriksen', 'Torvet', 4, '1', 'th', 6000);
GO
SELECT	*,
		Fornavn + ' ' + Efternavn AS Navn,
		Gade + ' ' + CAST(Husnr AS VARCHAR(5)) + ' ' + Etage + ' ' + Side + ' ' + CAST(Postnr AS VARCHAR(5)) AS Adr
	FROM dbo.Person;

SELECT	*,
		CONCAT(Fornavn, ' ', Efternavn) AS Navn,
		CONCAT(Gade, ' ', Husnr, ' ', Etage, ' ', Side, ' ', Postnr) AS Adresse
	FROM dbo.Person;
GO
SELECT	*,
		REPLACE(CONCAT(Fornavn, ' ', Efternavn), ' ', '*') AS Navn,
		REPLACE(CONCAT(Gade, ' ', Husnr, ' ', Etage, ' ', Side, ' ', Postnr), ' ', '*') AS Adresse
	FROM dbo.Person;
GO
SELECT	PersonID,
		CONCAT(Fornavn, ' ', Efternavn) AS Navn,
		CONCAT(Gade, ' ', Husnr, ' ' + Etage + ' ' + Side + ' ', Postnr) AS Adresse
	FROM dbo.Person;
GO
SELECT	*,
		REPLACE(CONCAT(Fornavn, ' ', Efternavn), ' ', '*') AS Navn,
		REPLACE(CONCAT(Gade, ' ', Husnr, ' ' + Etage, ' ' + Side,' ', Postnr), ' ', '*') AS Adresse
	FROM dbo.Person;
GO
DECLARE @Postnr			SMALLINT = 2000;
DECLARE @Fejltext		VARCHAR(200);

SET  @Fejltext = CONCAT('Postnr ', @Postnr, ' findes allerede den ', SYSDATETIME());
THROW 54765,  @Fejltext, 2;
GO
SELECT CONCAT('kr', ' ', 123.45);