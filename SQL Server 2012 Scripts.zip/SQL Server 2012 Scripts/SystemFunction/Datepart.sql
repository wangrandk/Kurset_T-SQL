USE master;
DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
USE FunctionDB;
CREATE TABLE dbo.t 
(
	Aar				SMALLINT NOT NULL,
	Maaned			SMALLINT NOT NULL,
	Dag				SMALLINT NOT NULL,
	Time			SMALLINT NOT NULL,
	Minut			SMALLINT NOT NULL,
	Sekund			SMALLINT NOT NULL,
	Millisekund		INT NOT NULL,
	Nanosekund		INT	NOT NULL
);
GO
WITH Datoer 
AS
(
SELECT DATEADD(DAY, -60, SYSDATETIME()) AS Dato
UNION ALL
SELECT DATEADD(DAY, 1, Dato)
	FROM Datoer
	WHERE DATO < SYSDATETIME()
)
INSERT INTO dbo.t
	SELECT	YEAR(Dato), 
			MONTH(Dato), 
			DAY(Dato), 
			DATEPART(HOUR, Dato), 
			DATEPART(MINUTE, Dato), 
			DATEPART(SECOND, Dato), 
			DATEPART(MILLISECOND, Dato),
			DATEPART(NANOSECOND, Dato)
		FROM Datoer;
GO
SELECT *
	FROM dbo.t;

-- DATEFROMPARTS
-- DATETIME2FROMPARTS
-- DATETIMEFROMPARTS
-- DATETIMEOFFSETFROMPARTS
-- SMALLDATETIMEFROMPARTS


SELECT	DATEFROMPARTS(Aar, Maaned, Dag),
		DATETIME2FROMPARTS(Aar, Maaned, Dag, Time, Minut, Sekund, Nanosekund/100, 7),
		DATETIMEFROMPARTS(Aar, Maaned, Dag, Time, Minut, Sekund, Millisekund), 
		DATETIMEOFFSETFROMPARTS (Aar, Maaned, Dag, Time, Minut, Sekund, Nanosekund/100, 2, 30, 7),
		SMALLDATETIMEFROMPARTS(Aar, Maaned, Dag, Time, Minut)
	FROM dbo.t;
GO
-- TIMEFROMPARTS
SELECT	TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 100, 7),
		TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 1000, 6),
		TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 10000, 5),
		TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 100000, 4),
		TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 1000000, 3),
		TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 10000000, 2),
		TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 100000000, 1)
	FROM dbo.t;
GO
-- Fejler, da fractionsdelen er for stort et tal 
SELECT	TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 100, 7),
		TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 100, 6),
		TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 100, 5),
		TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 100, 4),
		TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 100, 3),
		TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 100, 2),
		TIMEFROMPARTS(Time, Minut, Sekund, Nanosekund / 100, 1)
	FROM dbo.t;
GO
SELECT DATEFROMPARTS(YEAR(SYSDATETIME()), MONTH(SYSDATETIME()) + 1, 1),
		DATEADD(DAY, -1, DATEFROMPARTS(YEAR(SYSDATETIME()), MONTH(SYSDATETIME()) + 1, 1));	
