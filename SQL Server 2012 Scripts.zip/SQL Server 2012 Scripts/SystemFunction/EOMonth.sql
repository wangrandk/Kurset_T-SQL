USE master;
DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
USE FunctionDB;
CREATE TABLE dbo.t 
(
	Dato			DATE NOT NULL
);
GO
WITH Datoer 
AS
(
SELECT DATEADD(DAY, -60, SYSDATETIME()) AS Dato
UNION ALL
SELECT DATEADD(DAY, 1, Dato)
	FROM Datoer
	WHERE DATO < DATEADD(DAY, 60, SYSDATETIME())
)
INSERT INTO dbo.t
	SELECT *
		FROM Datoer
		OPTION(MAXRECURSION 1000)
GO
SELECT	Dato, 
		EOMONTH(Dato) AS SidsteDagIMaaned, 
		EOMONTH(Dato, 1) AS SidsteDagNaesteMaaned,
		EOMONTH(Dato, -1) AS SidsteDagForegaaendeMaaned,
		EOMONTH(Dato, 3 - (MONTH(Dato) % 3)) AS SlutPaaKvartal
	FROM dbo.t
	ORDER BY Dato;
