USE master;
DROP DATABASE ThrowDB;
GO
CREATE DATABASE ThrowDB;
GO
USE ThrowDB;
GO
USE ThrowDB
CREATE TABLE dbo.TestRethrow
(    
	ID			INT NOT NULL
				CONSTRAINT PK_TestRethrow PRIMARY KEY
);
GO
BEGIN TRY

    PRINT 'Start TRY block.';  
	INSERT dbo.TestRethrow(ID) VALUES(1);
	PRINT 'Mellem INSERT';
    INSERT dbo.TestRethrow(ID) VALUES(1);
	PRINT 'Efter 2. INSERT';

END TRY
BEGIN CATCH

    PRINT 'In CATCH block.';
	THROW 461532, 'Der er opst�et en fejl, som er blevet behandlet', 12

END CATCH;

SELECT *
	FROM dbo.TestRethrow;
GO
BEGIN TRY

    PRINT 'Start TRY block.';  
	INSERT dbo.TestRethrow(ID) VALUES(2);
	PRINT 'Mellem INSERT';
    INSERT dbo.TestRethrow(ID) VALUES(2);
	PRINT 'Efter 2. INSERT';

END TRY
BEGIN CATCH

    PRINT 'In CATCH block.';
    THROW;
END CATCH;
GO
BEGIN TRY

    PRINT 'Start TRY block.';  
	INSERT dbo.TestRethrow(ID) VALUES(1);
	PRINT 'Mellem INSERT';
    INSERT dbo.TestRethrow(ID) VALUES(1);
	PRINT 'Efter 2. INSERT';

END TRY
BEGIN CATCH

    PRINT 'In CATCH block.';
    THROW;
END CATCH;
GO
BEGIN TRY
	BEGIN TRANSACTION;
    PRINT 'Start TRY block.';  
	INSERT dbo.TestRethrow(ID) VALUES(1);
	PRINT 'Mellem INSERT';
    INSERT dbo.TestRethrow(ID) VALUES(1);
	PRINT 'Efter 2. INSERT';
	COMMIT TRANSACTION;
END TRY
BEGIN CATCH

    PRINT 'In CATCH block.';
	ROLLBACK TRANSACTION;
  	THROW 345, 'Der er opst�et en fejl, som er ''konverteret'' til en systemfejl', 12  --fejl pga nummer, som skal v�re > 50000
END CATCH;
GO
RAISERROR ('Der er fejl', 16, 1);
RAISERROR ('Der er fejl pga %s %i', 16, 1, 'fejl ', 40);
RAISERROR ('Der er fejl pga %s %i', 16, 1);
RAISERROR ('Der er fejl pga %s %i', 16, 1, 'fejl ', 40, 45, 67);
GO
DECLARE @Message	VARCHAR(100) = 'Der er fejl pga. %s %i';
DECLARE @Errornumbr	INT = 67543;

SET @Message = FORMATMESSAGE(@Message, 'fejl', 40);
THROW @Errornumbr, @Message, 1;
GO
DECLARE @Message	VARCHAR(100) = 'Der er fejl pga. %s %i';
DECLARE @Errornumbr	INT = 67543;

SET @Message = FORMATMESSAGE(@Message, 'fejl', 40, 30, 'Dette m� man godt');
THROW @Errornumbr, @Message, 1;
GO
DECLARE @Message	VARCHAR(100) = 'Der er fejl pga. %s %i';
DECLARE @Errornumbr	INT = 67543;

SET @Message = FORMATMESSAGE(@Message, 'fejl');
THROW @Errornumbr, @Message, 1;
GO
DECLARE @Message	VARCHAR(100) = 'Der er fejl pga. %s %i';
DECLARE @Errornumbr	INT = 67543;

THROW @Errornumbr, FORMATMESSAGE(@Message, 'fejl', 40), 1;		--fejl, m� ikke v�re en funktion
GO
DECLARE @Message1	VARCHAR(100) = 'Der er fejl pga.';
DECLARE @Message2	VARCHAR(100) = 'Fejl 40';
DECLARE @Errornumbr	INT = 67543;

THROW @Errornumbr, @Message1 + @Message2, 1;					--fejl, ingen beregning
GO
