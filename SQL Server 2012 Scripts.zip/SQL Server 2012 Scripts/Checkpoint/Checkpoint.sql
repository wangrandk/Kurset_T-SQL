-- Automatic
 EXEC sp_configure 'recovery interval ','seconds';
 
 -- Issued automatically in the background to meet the upper time limit suggested by the recovery interval server configuration option. 
 -- Automatic checkpoints run to completion. Automatic checkpoints are throttled based on the number of outstanding writes 
 -- and whether the Database Engine detects an increase in write latency above 20 milliseconds. 

 
-- Indirect
 ALTER DATABASE Database SET TARGET_RECOVERY_TIME  = target_recovery_time { SECONDS | MINUTES } 
 
 USE master;
 DROP DATABASE TestDB;
 GO
 CREATE DATABASE TestDB;
 GO
 ALTER DATABASE TestDB SET TARGET_RECOVERY_TIME  = 2 MINUTES;
  
 -- Issued in the background to meet a user-specified target recovery time for a given database. 
 -- The default target recovery time is 0, which causes automatic checkpoint heuristics to be used on the database. 
 -- If you have used ALTER DATABASE to set TARGET_RECOVERY_TIME to >0, this value is used, rather than the recovery interval 
 -- specified for the server instance.
 
-- Manual
 CHECKPOINT [  checkpoint_duration ] 

 CHECKPOINT;
