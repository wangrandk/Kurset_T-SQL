USE master;
DROP DATABASE FulltextDB;
GO
CREATE DATABASE FulltextDB;
GO
USE FulltextDB;
CREATE FULLTEXT CATALOG FulltextDB_Catalog 
	WITH ACCENT_SENSITIVITY = ON
	AS DEFAULT;
GO
CREATE TABLE dbo.t_VarcharMax 
(
	ID		INT				NOT NULL 
			CONSTRAINT PK__t_VarcharMax PRIMARY KEY,
	Tekst	VARCHAR(MAX)	NOT NULL
);
GO
INSERT INTO dbo.t_VarcharMax VALUES
	(1,'TI ' +
	REPLICATE (CAST('Denne tekst gentages ' AS VARCHAR(MAX)), 2600) + 
	 REPLICATE (CAST('noget mere tekst ' AS VARCHAR(MAX)), 400)+
	 'Det vi s�ger efter : Teknologisk Institut');

INSERT INTO dbo.t_VarcharMax VALUES
	(2,'IT ' +
	REPLICATE (CAST('Denne tekst gentages igen' AS VARCHAR(MAX)), 5000) + 
	 REPLICATE (CAST('noget mere tekst igen' AS VARCHAR(MAX)), 6000)+
	 'Det vi s�ger efter (omvendt) : Institut Teknologisk ');

INSERT INTO dbo.t_VarcharMax VALUES
	(3,'T ' +
	REPLICATE (CAST('Denne tekst gentages igen igen' AS VARCHAR(MAX)), 2000) + 
	 REPLICATE (CAST('noget mere tekst ' AS VARCHAR(MAX)), 400)+
	 'Det vi s�ger efter : Teknologisk');

INSERT INTO dbo.t_VarcharMax VALUES
	(4, 'I ' +
	REPLICATE (CAST('Denne tekst gentages sikkert igen' AS VARCHAR(MAX)), 4000) + 
	 REPLICATE (CAST('noget mere tekst ' AS VARCHAR(MAX)), 3000)+
	 'Det vi s�ger efter  : Institut');

INSERT INTO dbo.t_VarcharMax VALUES
	(5, 'TI ' + 'Det vi s�ger efter  : Teknologisk Institut');

INSERT INTO dbo.t_VarcharMax VALUES
	(6, 'TI ' + 'Teknologisk Institut');

INSERT INTO dbo.t_VarcharMax VALUES
	(7, 'TI ' +'Teknologisk Institut ' + 
	 REPLICATE (CAST('Denne tekst gentages sikkert igen' AS VARCHAR(MAX)), 1000) + 
	 REPLICATE (CAST('noget mere tekst ' AS VARCHAR(MAX)), 2000));

INSERT INTO dbo.t_VarcharMax VALUES
	(8, 'TI ' +'Teknologisk ' + 
	 REPLICATE (CAST('Denne tekst gentages helt sikkert igen' AS VARCHAR(MAX)), 40000) + 
	 REPLICATE (CAST('noget mere tekst ' AS VARCHAR(MAX)), 30000)+
	 'Det vi s�ger efter  : Institut');

INSERT INTO dbo.t_VarcharMax VALUES
	(9, 'intet  ' + 
	 REPLICATE (CAST('Denne tekst gentages m�ske helt sikkert igen' AS VARCHAR(MAX)), 40000) + 
	 REPLICATE (CAST('noget mere tekst ' AS VARCHAR(MAX)), 30000)+
	 'Det vi s�ger efter er : intet');
GO
CREATE FULLTEXT INDEX ON dbo.dbo.t_VarcharMax(Tekst)
	KEY INDEX PK__t_VarcharMax;
GO
SELECT LEN(Tekst)
	FROM dbo.t_VarcharMax;
GO
SELECT * 
	FROM dbo.t_VarcharMax 
	WHERE CONTAINS(Tekst, 'NEAR((Teknologisk, Institut))');
SELECT * 
	FROM dbo.t_VarcharMax 
	WHERE CONTAINS(Tekst, 'NEAR((Teknologisk, Institut), 2)');

SELECT * 
	FROM dbo.t_VarcharMax 
	WHERE CONTAINS(Tekst, 'NEAR((Institut, Teknologisk), 2, FALSE)');
SELECT * 
	FROM dbo.t_VarcharMax 
	WHERE CONTAINS(Tekst, 'NEAR((Institut, Teknologisk), 2, TRUE)');
GO
INSERT INTO dbo.t_VarcharMax VALUES
	(110, 'Teknologisk er der var skal Institut'),
	(111, 'Teknologisk er der skal Institut'),
	(112, 'Teknologisk er der Institut');

INSERT INTO dbo.t_VarcharMax VALUES
	(210, 'Institut er der var skal  Teknologisk'),
	(211, 'Institut er der skal Teknologisk'),
	(212, 'Institut er der Teknologisk');
GO
SELECT * 
	FROM dbo.t_VarcharMax 
	WHERE	CONTAINS(Tekst, 'NEAR((Institut, Teknologisk), 3)') AND 
			ID >= 10;

SELECT * 
	FROM dbo.t_VarcharMax 
	WHERE	CONTAINS(Tekst, 'NEAR((Institut, Teknologisk), 4)') AND 
			ID >= 10;
GO
SELECT * 
	FROM dbo.t_VarcharMax 
	WHERE	CONTAINS(Tekst, 'NEAR((Institut, Teknologisk), 3, TRUE)') AND 
			ID >= 10;

SELECT * 
	FROM dbo.t_VarcharMax 
	WHERE	CONTAINS(Tekst, 'NEAR((Institut, Teknologisk), 3, FALSE)') AND 
			ID >= 10;
