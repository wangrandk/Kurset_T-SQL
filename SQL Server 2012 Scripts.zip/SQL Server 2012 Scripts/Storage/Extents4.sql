USE master;
GO
DROP DATABASE StorageDB;
GO
CREATE DATABASE StorageDB;
GO
USE StorageDB;

CREATE TABLE dbo.PageTable
(
	ID					INT NOT NULL CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt					CHAR(8000) NOT NULL DEFAULT (REPLICATE('x', 8000)),
	AntExtRead			INT DEFAULT(0)
);
GO
DECLARE @i		INT = 1;
DECLARE @j		INT = 0;

WHILE @i <= 8
BEGIN
	SET @j = 1;
	WHILE @j <= 1000
	BEGIN;
		INSERT INTO dbo.PageTable (ID) VALUES (@i + @j * 8);
		SET @j += 1;
	END;
	SET @i += 1;
END;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM dbo.PageTable;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM dbo.PageTable
	WHERE ID BETWEEN 20 AND 40;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM dbo.PageTable
	WHERE ID BETWEEN 20 AND 40
	ORDER BY ID;

--SELECT COUNT(*) 
--	FROM dbo.PageTable;

--SELECT * 
--	FROM dbo.PageTable
--	ORDER BY ID;
GO
USE StorageDB;

DECLARE @ID				INT = (SELECT MIN(ID) FROM PageTable);
DECLARE @Stop			INT = (SELECT MAX(ID) FROM PageTable);
DECLARE @ExtentInfo		TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
);
DECLARE @AntExtRead		INT;

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''StorageDB'', ''dbo.PageTable'')');

WHILE @ID <= @Stop
BEGIN

	DBCC DROPCLEANBUFFERS;

	SELECT *
		FROM PageTable
		WHERE ID = @ID;

	SET @AntExtRead = (SELECT COUNT(DISTINCT buffer.page_id/8) AS AntExtRead
							FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents 
											ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
							WHERE database_id = DB_ID('StorageDB'));

	UPDATE dbo.PageTable
		SET AntExtRead = @AntExtRead
		WHERE @ID = @ID;

	SET @ID += 1;
END;
SELECT *
	FROM dbo.PageTable
	ORDER BY AntExtRead, ID
