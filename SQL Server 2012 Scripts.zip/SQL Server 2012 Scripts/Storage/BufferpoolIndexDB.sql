USE Index4DB;

-- PK clustered
GO
CREATE NONCLUSTERED INDEX nc_Person_Persontype ON Person(Persontype)
GO
CREATE TABLE #ExtentInfo 
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO #ExtentInfo
	EXEC ('DBCC EXTENTINFO (''Index4DB'', ''Person'')');

CREATE INDEX nc_ExtentInfo__page_id ON #ExtentInfo(page_id);

CHECKPOINT;

DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON
SET STATISTICS IO ON
SELECT *
	FROM Person
	WHERE Persontype = 'D'
SET STATISTICS TIME OFF
SET STATISTICS IO OFF

SELECT	buffer.*,
		extents.page_id,
		extents.pg_alloc,
		extents.ext_size
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN #ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'Index4DB')
	ORDER BY buffer.page_level DESC, buffer.page_id;

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN #ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'Index4DB');

DROP INDEX nc_Person_Persontype ON Person;
DROP TABLE #ExtentInfo;
GO
---------------------------------------------------------------------
USE Index5DB;

-- PK nonclustered
GO
CREATE NONCLUSTERED INDEX nc_Person_Persontype ON Person(Persontype);
GO
CREATE TABLE #ExtentInfo 
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO #ExtentInfo
	EXEC ('DBCC EXTENTINFO (''Index5DB'', ''Person'')');

CREATE INDEX nc_ExtentInfo__page_id ON #ExtentInfo(page_id);

CHECKPOINT;

DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON
SET STATISTICS IO ON
SELECT *
	FROM Person
	WHERE Persontype = 'D'
SET STATISTICS TIME OFF
SET STATISTICS IO OFF

SELECT	buffer.*,
		extents.page_id,
		extents.pg_alloc,
		extents.ext_size
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN #ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'Index5DB')
	ORDER BY buffer.page_level DESC, buffer.page_id;

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN #ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'Index5DB');
GO
DROP INDEX nc_Person_Persontype ON Person;
DROP TABLE #ExtentInfo;
GO
USE Index4DB

SELECT * 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'DETAILED');
GO
USE Index5DB

SELECT * 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'DETAILED');
