-- REBUILD
USE master;
GO
DROP DATABASE StorageDB;
GO
CREATE DATABASE StorageDB;
GO
USE StorageDB;
CREATE TABLE PageTable
(
	ID		INT NOT NULL CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt		CHAR(8000) NOT NULL DEFAULT (REPLICATE('x', 8000))
);
GO
DECLARE @i		INT = 1;

WHILE @i <= 30
BEGIN;
	INSERT INTO PageTable (ID) VALUES (@i);
	SET @i += 1;
END;
GO
SELECT COUNT(*) 
	FROM PageTable;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''StorageDB'', ''PageTable'')');

SELECT *
	FROM @ExtentInfo AS extents;

SELECT COUNT(DISTINCT extents.page_id/8) AS AntalExtents
	FROM @ExtentInfo AS extents;
GO
ALTER INDEX PK_PageTable ON PageTable REBUILD;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''StorageDB'', ''PageTable'')');

SELECT *
	FROM @ExtentInfo AS extents;

SELECT COUNT(DISTINCT extents.page_id/8) AS AntalExtents
	FROM @ExtentInfo AS extents;
GO
DBCC TRACEON(3604);
DBCC PAGE('StorageDB', 1, 156, 1);
GO
-- REORGANIZE
USE master;
GO
DROP DATABASE StorageDB;
GO
CREATE DATABASE StorageDB;
GO
USE StorageDB;
CREATE TABLE PageTable
(
	ID		INT NOT NULL CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt		CHAR(8000) NOT NULL DEFAULT (REPLICATE('x', 8000))
);
GO
DECLARE @i		INT = 1;

WHILE @i <= 30
BEGIN;
	INSERT INTO PageTable (ID) VALUES (@i);
	SET @i += 1;
END
GO
SELECT COUNT(*) 
	FROM PageTable;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''StorageDB'', ''PageTable'')');

SELECT *
	FROM @ExtentInfo AS extents;

SELECT COUNT(DISTINCT extents.page_id/8) AS AntalExtents
	FROM @ExtentInfo AS extents;
GO
ALTER INDEX PK_PageTable ON PageTable REORGANIZE;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''StorageDB'', ''PageTable'')');

SELECT *
	FROM @ExtentInfo AS extents;

SELECT COUNT(DISTINCT extents.page_id/8) AS AntalExtents
	FROM @ExtentInfo AS extents;
GO
--------------------------------------------------
-- REBUILD
USE master;
GO
DROP DATABASE StorageDB;
GO
CREATE DATABASE StorageDB;
GO
USE StorageDB;
CREATE TABLE PageTable
(
	ID		INT NOT NULL CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt		CHAR(8000) NOT NULL DEFAULT (REPLICATE('x', 8000))
);
GO
DECLARE @i		INT = 1;

WHILE @i <= 30
BEGIN;
	INSERT INTO PageTable (ID) VALUES (@i);
	SET @i += 2;
END
GO
DECLARE @i		INT = 2;

WHILE @i <= 30
BEGIN;
	INSERT INTO PageTable (ID) VALUES (@i);
	SET @i += 2;
END
GO
SELECT COUNT(*) 
	FROM PageTable;
GO
DBCC EXTENTINFO ('StorageDB', 'PageTable');

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM PageTable;
GO
ALTER INDEX PK_PageTable ON PageTable REBUILD;
GO
DBCC EXTENTINFO ('StorageDB', 'PageTable');

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		*
	FROM PageTable;
GO
-- REORGANIZE
USE master;
GO
DROP DATABASE StorageDB;
GO
CREATE DATABASE StorageDB;
GO
USE StorageDB;
CREATE TABLE PageTable
(
	ID		INT NOT NULL CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt		CHAR(8000) NOT NULL DEFAULT (REPLICATE('x', 8000))
);
GO
DECLARE @i		INT = 1;

WHILE @i <= 30
BEGIN;
	INSERT INTO PageTable (ID) VALUES (@i);
	SET @i += 2;
END;
GO
DECLARE @i		INT = 2;

WHILE @i <= 30
BEGIN
	INSERT INTO PageTable (ID) VALUES (@i);
	SET @i += 2;
END;
GO
DBCC EXTENTINFO ('StorageDB', 'PageTable');

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],	
		*
	FROM PageTable;
GO
ALTER INDEX PK_PageTable ON PageTable REORGANIZE;
GO
DBCC EXTENTINFO ('StorageDB', 'PageTable');

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],	
		*
	FROM PageTable;
GO
