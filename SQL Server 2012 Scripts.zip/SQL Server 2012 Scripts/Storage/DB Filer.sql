USE master;
GO
DROP DATABASE StorageDB;
GO
CREATE DATABASE StorageDB
ON PRIMARY
	(NAME = StorageDB_sys,
	 FILENAME = 'c:\Databaser\StorageDB_sys.mdf',
     SIZE = 5MB),

FILEGROUP DataFG1
	(NAME = StorageDB_f1,
	 FILENAME = 'c:\Databaser\StorageDB_fg1.ndf',
     SIZE = 5MB),
	
	(NAME = StorageDB_f2,
	 FILENAME = 'c:\Databaser\StorageDB_fg2.ndf',
     SIZE = 5MB),
	
	(NAME = StorageDB_f3,
	 FILENAME = 'c:\Databaser\StorageDB_fg3.ndf',
     SIZE = 5MB)
LOG ON
	(NAME = StorageDB_log,
	 FILENAME = 'c:\Databaser\StorageDB.ldf',
     SIZE = 2MB);
GO
USE StorageDB;
GO
SELECT *
	FROM sys.database_files;
GO
CREATE TABLE dbo.PageTable
(
	ID		INT				NOT NULL 
							CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt		CHAR(8000)		NOT NULL DEFAULT (REPLICATE('x', 8000))
) ON DataFG1;
GO
DECLARE @i		INT = 1;

WHILE @i <= 2000
BEGIN;
	INSERT INTO dbo.PageTable (ID) VALUES (@i);
	SET @i += 1;
END;
GO
SELECT COUNT(*) 
	FROM dbo.PageTable;
GO
DBCC EXTENTINFO ('StorageDB', 'dbo.PageTable');

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM dbo.PageTable;
GO
ALTER INDEX PK_PageTable ON dbo.PageTable REBUILD;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM dbo.PageTable;
GO
USE master;
GO
DROP DATABASE StorageDB;
GO
CREATE DATABASE StorageDB
ON PRIMARY
	(NAME = StorageDB_sys,
	 FILENAME = 'c:\Databaser\StorageDB_sys.mdf',
     SIZE = 5MB),

FILEGROUP DataFG1
	(NAME = StorageDB_f1,
	 FILENAME = 'c:\Databaser\StorageDB_fg1.ndf',
     SIZE = 10MB),
	
	(NAME = StorageDB_f2,
	 FILENAME = 'c:\Databaser\StorageDB_fg2.ndf',
     SIZE = 15MB),
	
	(NAME = StorageDB_f3,
	 FILENAME = 'c:\Databaser\StorageDB_fg3.ndf',
     SIZE = 20MB)
LOG ON
	(NAME = StorageDB_log,
	 FILENAME = 'c:\Databaser\StorageDB.ldf',
     SIZE = 2MB);
GO
USE StorageDB;
GO
SELECT *
	FROM sys.database_files;
GO
CREATE TABLE dbo.PageTable
(
	ID		INT				NOT NULL 
							CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt		CHAR(8000)		NOT NULL DEFAULT (REPLICATE('x', 8000))
) ON DataFG1;
GO
SET NOCOUNT ON;
DECLARE @i		INT = 1;

WHILE @i <= 2000
BEGIN;
	INSERT INTO dbo.PageTable (ID) VALUES (@i);
	SET @i += 1;
END;
GO
SELECT COUNT(*) 
	FROM dbo.PageTable;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
);

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''StorageDB'', ''PageTable'')');

SELECT file_id, SUM(pg_alloc) AS number_of_pages
	FROM @ExtentInfo
	GROUP BY file_id;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM dbo.PageTable;
GO
ALTER INDEX PK_PageTable ON dbo.PageTable REORGANIZE;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM dbo.PageTable;
GO
DELETE 
	FROM dbo.PageTable
	WHERE ID % 5 = 2;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM dbo.PageTable;
GO
ALTER INDEX PK_PageTable ON dbo.PageTable REORGANIZE;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM dbo.PageTable;
GO