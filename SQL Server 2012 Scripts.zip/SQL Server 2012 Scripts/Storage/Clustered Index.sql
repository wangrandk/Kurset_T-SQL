USE master;
GO
DROP DATABASE StorageDB;
GO
CREATE DATABASE StorageDB;
GO
USE StorageDB;
GO
CREATE TABLE dbo.PageTable
(
	ID		INT NOT NULL CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt		VARCHAR(1996) NOT NULL DEFAULT (REPLICATE('x', 1996))
);
GO
DECLARE @i				INT = 2;
DECLARE @Maxrows		INT = 200;

WHILE @i <= @Maxrows
BEGIN;
	INSERT INTO dbo.PageTable (ID, Txt) VALUES (@i, REPLICATE('x', 1500));
	SET @i += 3;
END;

SET @i = 1;

WHILE @i <= @Maxrows
BEGIN;
		INSERT INTO dbo.PageTable (ID, Txt) VALUES (@i, REPLICATE('y', 1000));
	SET @i += 3;
END;
GO
ALTER TABLE dbo.PageTable REBUILD;
GO
DECLARE @i				INT = 2;
DECLARE @Maxrows		INT = 200;

SET @i = 0;

WHILE @i <= @Maxrows
BEGIN;
		INSERT INTO dbo.PageTable (ID, Txt) VALUES (@i, REPLICATE('z', 1900));
	SET @i += 3;
END;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		*
	FROM dbo.PageTable;
GO
