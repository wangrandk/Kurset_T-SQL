-- Med PK og FK. FK defineret, NOT NULL og med Index. Begge tabeller rebuildes
USE master;
GO
DROP DATABASE BufferpoolDB;
GO
CREATE DATABASE BufferpoolDB;
GO
USE BufferpoolDB;
CREATE TABLE dbo.PageTable
(
	ID				INT				NOT NULL 
									CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt				CHAR(8000)		NOT NULL DEFAULT (REPLICATE('x', 8000))
);

CREATE TABLE dbo.PageTableMedFK
(
	ID				INT				NOT NULL IDENTITY
									CONSTRAINT PK_PageTableMedFK PRIMARY KEY NONCLUSTERED,
	Txt				CHAR(8000) NOT NULL DEFAULT (REPLICATE('y', 8000)),
	ID_PageTable	INT				NOT NULL INDEX PageTableMedFK__Id_PageTable CLUSTERED
									CONSTRAINT FK_PageTable_PageTableMedFK 
									REFERENCES dbo.PageTable (ID)
);
GO
SET NOCOUNT ON
DECLARE @i		INT = 1;

WHILE @i <= 30
BEGIN;
	INSERT INTO dbo.PageTable (ID) VALUES (@i);
	SET @i += 1;
END
GO
DECLARE @i		INT = 1;
DECLARE @j		INT;

WHILE @i <= 30
BEGIN
	SET @j = 1;
	WHILE @j <= 50
	BEGIN
		INSERT INTO dbo.PageTableMedFK (ID_PageTable) VALUES (@i);
		SET @j += 1;
	END;
	SET @i += 1;
END;
SET NOCOUNT OFF
GO
ALTER INDEX ALL ON dbo.PageTable REBUILD;
ALTER INDEX ALL ON dbo.PageTableMedFK REBUILD;

UPDATE STATISTICS dbo.PageTable WITH FULLSCAN, ALL;
UPDATE STATISTICS dbo.PageTableMedFK WITH FULLSCAN, ALL;
GO
SELECT COUNT(*)
	FROM dbo.PageTable;

SELECT COUNT(*)
	FROM dbo.PageTableMedFK;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

DBCC DROPCLEANBUFFERS;

SELECT	PageTable.*,  PageTableMedFK.*
	FROM dbo.PageTable INNER JOIN dbo.PageTableMedFK ON PageTable.ID = PageTableMedFK.ID_PageTable
	WHERE PageTable.ID IN (1, 2);

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTableMedFK'')');

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
-- Med PK og FK. FK ikke defineret, NOT NULL og med Nonclustered Index. Begge tabeller rebuildes
USE master;
GO
DROP DATABASE BufferpoolDB;
GO
CREATE DATABASE BufferpoolDB;
GO
USE BufferpoolDB;
CREATE TABLE dbo.PageTable
(
	ID				INT NOT NULL CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt				CHAR(8000) NOT NULL DEFAULT (REPLICATE('x', 8000))
);
CREATE TABLE dbo.PageTableMedFK
(
	ID				INT NOT NULL CONSTRAINT PK_PageTableMedFK PRIMARY KEY NONCLUSTERED IDENTITY,
	Txt				CHAR(8000) NOT NULL DEFAULT (REPLICATE('y', 8000)),
	ID_PageTable	INT NOT NULL INDEX PageTableMedFK__Id_PageTable NONCLUSTERED
);

GO
SET NOCOUNT ON
DECLARE @i		INT = 1;

WHILE @i <= 30
BEGIN;
	INSERT INTO dbo.PageTable (ID) VALUES (@i);
	SET @i += 1;
END
GO
DECLARE @i		INT = 1;
DECLARE @j		INT;

WHILE @i <= 30
BEGIN
	SET @j = 1;
	WHILE @j <= 50
	BEGIN
		INSERT INTO dbo.PageTableMedFK (ID_PageTable) VALUES (@i);
		SET @j += 1;
	END;
	SET @i += 1;
END;
SET NOCOUNT OFF
GO
ALTER INDEX ALL ON dbo.PageTable REBUILD;
ALTER INDEX ALL ON dbo.PageTableMedFK REBUILD;

UPDATE STATISTICS dbo.PageTable WITH FULLSCAN, ALL;
UPDATE STATISTICS dbo.PageTableMedFK WITH FULLSCAN, ALL;
GO
SELECT COUNT(*)
	FROM dbo.PageTable;
SELECT COUNT(*)
	FROM dbo.PageTableMedFK;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

DBCC DROPCLEANBUFFERS;

SELECT	PageTable.*,  PageTableMedFK.*
	FROM dbo.PageTable INNER JOIN dbo.PageTableMedFK ON PageTable.ID = PageTableMedFK.ID_PageTable
	WHERE PageTable.ID IN (1, 2);

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTableMedFK'')');

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
-- Med PK og FK. FK ikke defineret, NULL og uden Index. Begge tabeller rebuildes
USE master;
GO
DROP DATABASE BufferpoolDB;
GO
CREATE DATABASE BufferpoolDB;
GO
USE BufferpoolDB;
CREATE TABLE dbo.PageTable
(
	ID				INT NOT NULL CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt				CHAR(8000) NOT NULL DEFAULT (REPLICATE('x', 8000))
);
CREATE TABLE dbo.PageTableMedFK
(
	ID				INT NOT NULL CONSTRAINT PK_PageTableMedFK PRIMARY KEY NONCLUSTERED IDENTITY,
	Txt				CHAR(8000) NOT NULL DEFAULT (REPLICATE('y', 8000)),
	ID_PageTable	INT NULL
);

GO
SET NOCOUNT ON
DECLARE @i		INT = 1;

WHILE @i <= 30
BEGIN;
	INSERT INTO dbo.PageTable (ID) VALUES (@i);
	SET @i += 1;
END
GO
DECLARE @i		INT = 1;
DECLARE @j		INT;

WHILE @i <= 30
BEGIN
	SET @j = 1;
	WHILE @j <= 50
	BEGIN
		INSERT INTO dbo.PageTableMedFK (ID_PageTable) VALUES (@i);
		SET @j += 1;
	END;
	SET @i += 1;
END;
SET NOCOUNT OFF
GO
ALTER INDEX ALL ON dbo.PageTable REBUILD;
ALTER INDEX ALL ON dbo.PageTableMedFK REBUILD;

UPDATE STATISTICS dbo.PageTable WITH FULLSCAN, ALL;
UPDATE STATISTICS dbo.PageTableMedFK WITH FULLSCAN, ALL;
GO
SELECT COUNT(*)
	FROM dbo.PageTable;

SELECT COUNT(*)
	FROM dbo.PageTableMedFK;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

DBCC DROPCLEANBUFFERS;

SELECT	PageTable.*,  PageTableMedFK.*
	FROM dbo.PageTable INNER JOIN dbo.PageTableMedFK ON PageTable.ID = PageTableMedFK.ID_PageTable
	WHERE PageTable.ID IN (1, 2);

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTableMedFK'')');

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
-- Med PK og FK. FK ikke defineret, NULL og nonclustered Index. Begge tabeller rebuildes
USE master;
GO
DROP DATABASE BufferpoolDB;
GO
CREATE DATABASE BufferpoolDB;
GO
USE BufferpoolDB;
CREATE TABLE dbo.PageTable
(
	ID				INT NOT NULL CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt				CHAR(8000) NOT NULL DEFAULT (REPLICATE('x', 8000))
);
CREATE TABLE dbo.PageTableMedFK
(
	ID				INT NOT NULL CONSTRAINT PK_PageTableMedFK PRIMARY KEY NONCLUSTERED IDENTITY,
	Txt				CHAR(8000) NOT NULL DEFAULT (REPLICATE('y', 8000)),
	ID_PageTable	INT NULL INDEX  nc_PageTableMedFK__ID_PageTable NONCLUSTERED
);

GO
SET NOCOUNT ON
DECLARE @i		INT = 1;

WHILE @i <= 30
BEGIN;
	INSERT INTO dbo.PageTable (ID) VALUES (@i);
	SET @i += 1;
END
GO
DECLARE @i		INT = 1;
DECLARE @j		INT;

WHILE @i <= 30
BEGIN
	SET @j = 1;
	WHILE @j <= 50
	BEGIN
		INSERT INTO dbo.PageTableMedFK (ID_PageTable) VALUES (@i);
		SET @j += 1;
	END;
	SET @i += 1;
END;
SET NOCOUNT OFF
GO
ALTER INDEX ALL ON dbo.PageTable REBUILD;
ALTER INDEX ALL ON dbo.PageTableMedFK REBUILD;

UPDATE STATISTICS dbo.PageTable WITH FULLSCAN, ALL;
UPDATE STATISTICS dbo.PageTableMedFK WITH FULLSCAN, ALL;
GO
SELECT COUNT(*)
	FROM dbo.PageTable;

SELECT COUNT(*)
	FROM dbo.PageTableMedFK;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

DBCC DROPCLEANBUFFERS;

SELECT	PageTable.*,  PageTableMedFK.*
	FROM dbo.PageTable INNER JOIN dbo.PageTableMedFK ON PageTable.ID = PageTableMedFK.ID_PageTable
	WHERE PageTable.ID IN (1, 2);

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTableMedFK'')');

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
