--------------------------------------------------
-- REBUILD
USE master;
GO
DROP DATABASE StorageDB;
GO
CREATE DATABASE StorageDB;
GO
USE StorageDB;
CREATE TABLE PageTable
(
	ID		INT NOT NULL CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt		CHAR(8000) NOT NULL DEFAULT (REPLICATE('x', 8000))
);
GO
DECLARE @i		INT = 1;

WHILE @i <= 30
BEGIN;
	INSERT INTO PageTable (ID) VALUES (@i);
	SET @i += 2;
END
GO
DECLARE @i		INT = 2;

WHILE @i <= 30
BEGIN;
	INSERT INTO PageTable (ID) VALUES (@i);
	SET @i += 2;
END
GO
SELECT COUNT(*) 
	FROM PageTable;
GO
DBCC EXTENTINFO ('StorageDB', 'PageTable');

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM PageTable;
GO
ALTER INDEX PK_PageTable ON PageTable REBUILD;
GO
DBCC EXTENTINFO ('StorageDB', 'PageTable');

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM PageTable;
GO
DBCC EXTENTINFO ('StorageDB', 'PageTable');

SELECT *
	FROM
		(SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],	*
			FROM PageTable) AS RidResult
			WHERE [Physical RID] IN ('(1:89:0)', '(1:118:0)', '(1:218:0)','(1:3304:0)');

GO
DBCC IND ('StorageDB', 'PageTable', 1)

 --1 � data page. This holds data records in a heap or clustered index leaf-level. 
 --2 � index page. This holds index records in the upper levels of a clustered index and all levels of non-clustered indexes. 
 --3 � text mix page. A text page that holds small chunks of LOB values plus internal parts of text tree. These can be shared between LOB values in the same partition of an index or heap. 
 --4 � text tree page. A text page that holds large chunks of LOB values from a single column value. 
 --7 � sort page. A page that stores intermediate results during a sort operation. 
 --8 � GAM page. Holds global allocation information about extents in a GAM interval (every data file is split into 4GB chunks � the number of extents that can be represented in a bitmap on a single database page). Basically whether an extent is allocated or not. GAM = Global Allocation Map. The first one is page 2 in each file. More on these in a later post. 
 --9 � SGAM page. Holds global allocation information about extents in a GAM interval. Basically whether an extent is available for allocating mixed-pages. SGAM = Shared GAM. the first one is page 3 in each file. More on these in a later post. 
 --10 � IAM page. Holds allocation information about which extents within a GAM interval are allocated to an index or allocation unit, in SQL Server 2000 and 2005 respectively. IAM = Index Allocation Map. More on these in a later post. 
 --11 � PFS page. Holds allocation and free space information about pages within a PFS interval (every data file is also split into approx 64MB chunks � the number of pages that can be represented in a byte-map on a single database page. PFS = Page Free Space. The first one is page 1 in each file. More on these in a later post. 
 --13 � boot page. Holds information about the database. There's only one of these in the database. It's page 9 in file 1. 
 --15 � file header page. Holds information about the file. There's one per file and it's page 0 in the file. 
 --16 � diff map page. Holds information about which extents in a GAM interval have changed since the last full or differential backup. The first one is page 6 in each file. 
 --17 � ML map page. Holds information about which extents in a GAM interval have changed while in bulk-logged mode since the last backup. This is what allows you to switch to bulk-logged mode for bulk-loads and index rebuilds without worrying about breaking a backup chain. The first one is page 7 in each file. 
GO
DBCC TRACEON (3604); 
GO
DBCC EXTENTINFO ('StorageDB', 'PageTable'); 

DBCC PAGE ('StorageDB', 1, 121, 3); 
