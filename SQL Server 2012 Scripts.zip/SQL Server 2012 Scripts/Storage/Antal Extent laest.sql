-- Med PK og tabellen rebuildes
USE master;
GO
DROP DATABASE BufferpoolDB;
GO
CREATE DATABASE BufferpoolDB;
GO
USE BufferpoolDB;
CREATE TABLE dbo.PageTable
(
	ID		INT			NOT NULL 
						CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
--						UNIQUE CLUSTERED,
--						INDEX IX_PageTable CLUSTERED,
	Txt		CHAR(8000)	NOT NULL 
						CONSTRAINT DF_PageTable_Txt DEFAULT (REPLICATE('x', 8000))
);
GO
SET NOCOUNT ON;
WITH 
Id_Data 
AS
(
SELECT 1 AS ID
UNION ALL
SELECT ID + 1
	FROM Id_Data
	WHERE ID < 500
)
SELECT	ID, 
		NEWID() AS Sortkol
	INTO Data
	FROM ID_Data
	OPTION (MAXRECURSION 0);
GO
DECLARE @Sortkol	UNIQUEIDENTIFIER = (SELECT MIN(Sortkol) 
											FROM Data);
DECLARE @ID			INT = (SELECT ID 
							FROM Data 
							WHERE Sortkol = @Sortkol);

WHILE EXISTS (SELECT * FROM Data WHERE Sortkol > @Sortkol)
BEGIN
	INSERT INTO dbo.PageTable (ID) VALUES (@ID);

	SELECT @Sortkol = MIN(Sortkol) 
		FROM Data
		WHERE Sortkol > @Sortkol;

	SELECT @ID = ID 
		FROM Data 
		WHERE Sortkol = @Sortkol;
END;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	ORDER BY ID;
GO

ALTER INDEX PK_PageTable ON dbo.PageTable REBUILD;

CHECKPOINT;
GO
-----------------------------------
CREATE TABLE dbo.AntalExtLaest
(
	ID			INT,
	AntalExt	INT
);


DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
);

DECLARE @ID			INT = 1;

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

SELECT *
	FROM @ExtentInfo;

WHILE @ID <= 500
BEGIN

	DBCC DROPCLEANBUFFERS;

	--SELECT	*
	--	FROM dbo.PageTable
	--	WHERE ID = @ID;

	SELECT	*
		FROM dbo.PageTable
		WHERE ID BETWEEN @ID AND @ID + 7;

	INSERT INTO dbo.AntalExtLaest (ID, AntalExt)
		SELECT @ID, COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
			FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
			WHERE database_id = DB_ID(N'BufferpoolDB');

	SET @ID += 1;
END;
GO
SELECT	AntalExt,
		COUNT(*)
	FROM dbo.AntalExtLaest
	GROUP BY AntalExt;
