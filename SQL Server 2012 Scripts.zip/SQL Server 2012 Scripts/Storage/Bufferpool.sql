-- Med PK og tabellen rebuildes
USE master;
GO
DROP DATABASE BufferpoolDB;
GO
CREATE DATABASE BufferpoolDB;
GO
USE BufferpoolDB;
CREATE TABLE dbo.PageTable
(
	ID		INT			NOT NULL 
						CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt		CHAR(8000)	NOT NULL 
						CONSTRAINT DF_PageTable_Txt DEFAULT (REPLICATE('x', 8000))
);
GO
SET NOCOUNT ON;
WITH 
Id_Data 
AS
(
SELECT 1 AS ID
UNION ALL
SELECT ID + 1
	FROM Id_Data
	WHERE ID < 500
)
SELECT	ID, 
		NEWID() AS Sortkol
	INTO Data
	FROM ID_Data
	OPTION (MAXRECURSION 0);
GO
DECLARE @Sortkol	UNIQUEIDENTIFIER = (SELECT MIN(Sortkol) 
											FROM Data);
DECLARE @ID			INT = (SELECT ID 
							FROM Data 
							WHERE Sortkol = @Sortkol);

WHILE EXISTS (SELECT * FROM Data WHERE Sortkol > @Sortkol)
BEGIN
	INSERT INTO dbo.PageTable (ID) VALUES (@ID);

	SELECT @Sortkol = MIN(Sortkol) 
		FROM Data
		WHERE Sortkol > @Sortkol;

	SELECT @ID = ID 
		FROM Data 
		WHERE Sortkol = @Sortkol;
END;
SET NOCOUNT OFF;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	ORDER BY ID;

SELECT *
	FROM dbo.PageTable WITH(TABLOCK);
GO
ALTER INDEX PK_PageTable ON dbo.PageTable REBUILD;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	ORDER BY ID;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	ORDER BY PhysicalRID;

SELECT *
	FROM dbo.PageTable WITH(TABLOCK);
GO
SELECT *
	FROM sys.dm_os_buffer_descriptors
	WHERE database_id = DB_ID(N'BufferpoolDB')
	ORDER BY page_id;

CHECKPOINT;
DBCC DROPCLEANBUFFERS;

SELECT *
	FROM sys.dm_os_buffer_descriptors
	WHERE database_id = DB_ID(N'BufferpoolDB')
	ORDER BY page_id;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
);

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

CHECKPOINT;
DBCC DROPCLEANBUFFERS;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	WHERE ID IN (1, 2, 3, 4);

SELECT	buffer.*,
		extents.page_id,
		extents.pg_alloc,
		extents.ext_size
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB')
	ORDER BY buffer.page_id;

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
);

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

CHECKPOINT;
DBCC DROPCLEANBUFFERS;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	WHERE ID = 9;

SELECT	buffer.*,
		extents.page_id,
		extents.pg_alloc,
		extents.ext_size
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB')
	ORDER BY buffer.page_id;

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

CHECKPOINT;
DBCC DROPCLEANBUFFERS;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	WHERE ID = 16;

SELECT	buffer.*,
		extents.page_id,
		extents.pg_alloc,
		extents.ext_size
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB')
	ORDER BY buffer.page_id;

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
-- Uden PK men med clustered index p� Id. Tabel rebuildes
USE master;
GO
DROP DATABASE BufferpoolDB;
GO
CREATE DATABASE BufferpoolDB;
GO
USE BufferpoolDB;
CREATE TABLE dbo.PageTable
(
	ID		INT			NOT NULL,
	Txt		CHAR(8000)	NOT NULL 
						CONSTRAINT DF_PageTable_Txt DEFAULT (REPLICATE('x', 8000))
);
GO
CREATE CLUSTERED INDEX CL_PageTable_ID ON PageTable(ID);
GO
SET NOCOUNT ON;
WITH 
Id_Data 
AS
(
SELECT 1 AS ID
UNION ALL
SELECT ID + 1
	FROM Id_Data
	WHERE ID < 500
)
SELECT	ID, 
		NEWID() AS Sortkol
	INTO Data
	FROM ID_Data
	OPTION (MAXRECURSION 0);
GO
DECLARE @Sortkol		UNIQUEIDENTIFIER = (SELECT MIN(Sortkol) 
												FROM Data);
DECLARE @ID				INT = (SELECT ID 
								FROM Data 
								WHERE Sortkol = @Sortkol);

WHILE EXISTS (SELECT * FROM Data WHERE Sortkol > @Sortkol)
BEGIN
	INSERT INTO dbo.PageTable (ID) VALUES (@ID);

	SELECT @Sortkol = MIN(Sortkol) 
		FROM Data
		WHERE Sortkol > @Sortkol;

	SELECT @ID = ID 
		FROM Data 
		WHERE Sortkol = @Sortkol
END;
SET NOCOUNT OFF;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	ORDER BY ID;
GO
ALTER INDEX CL_PageTable_ID ON dbo.PageTable REBUILD;
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	ORDER BY ID;
GO
CHECKPOINT;
GO
SELECT *
	FROM dbo.PageTable;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

CHECKPOINT;
DBCC DROPCLEANBUFFERS;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	WHERE ID IN (1, 2, 3, 4);

SELECT	buffer.*,
		extents.page_id,
		extents.pg_alloc,
		extents.ext_size
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB')
	ORDER BY buffer.page_id;

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

CHECKPOINT;
DBCC DROPCLEANBUFFERS;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	WHERE ID = 9;

SELECT	buffer.*,
		extents.page_id,
		extents.pg_alloc,
		extents.ext_size
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB')
	ORDER BY buffer.page_id;

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

CHECKPOINT;
DBCC DROPCLEANBUFFERS;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	WHERE ID = 16;

SELECT	buffer.*,
		extents.page_id,
		extents.pg_alloc,
		extents.ext_size
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB')
	ORDER BY buffer.page_id;

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
-- Uden PK men med clustered index p� Id og tabel rebuildes IKKE
USE master;
GO
DROP DATABASE BufferpoolDB;
GO
CREATE DATABASE BufferpoolDB;
GO
USE BufferpoolDB;
CREATE TABLE dbo.PageTable
(
	ID		INT			NOT NULL,
	Txt		CHAR(8000)	NOT NULL 
						CONSTRAINT DF_PageTable_Txt DEFAULT (REPLICATE('x', 8000))
);
GO
CREATE CLUSTERED INDEX CL_PageTable_ID ON PageTable(ID)
GO
SET NOCOUNT ON;
WITH 
Id_Data 
AS
(
SELECT 1 AS ID
UNION ALL
SELECT ID + 1
	FROM Id_Data
	WHERE ID < 500
)
SELECT	ID, 
		NEWID() AS Sortkol
	INTO Data
	FROM ID_Data
	OPTION (MAXRECURSION 0);
GO
DECLARE @Sortkol		UNIQUEIDENTIFIER = (SELECT MIN(Sortkol) 
												FROM Data);
DECLARE @ID				INT = (SELECT ID 
									FROM Data 
									WHERE Sortkol = @Sortkol);

WHILE EXISTS (SELECT * FROM Data WHERE Sortkol > @Sortkol)
BEGIN
	INSERT INTO dbo.PageTable (ID) VALUES (@ID);

	SELECT @Sortkol = MIN(Sortkol) 
		FROM Data
		WHERE Sortkol > @Sortkol;

	SELECT @ID = ID 
		FROM Data 
		WHERE Sortkol = @Sortkol
END;
SET NOCOUNT OFF;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	ORDER BY ID;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

CHECKPOINT;
DBCC DROPCLEANBUFFERS;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	WHERE ID IN (1, 2, 3, 4);

SELECT	buffer.*,
		extents.page_id,
		extents.pg_alloc,
		extents.ext_size
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB')
	ORDER BY buffer.page_id;

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

CHECKPOINT;
DBCC DROPCLEANBUFFERS;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	WHERE ID = 9;

SELECT	buffer.*,
		extents.page_id,
		extents.pg_alloc,
		extents.ext_size
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB')
	ORDER BY buffer.page_id;

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

CHECKPOINT;
DBCC DROPCLEANBUFFERS;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	WHERE ID = 16;

SELECT	buffer.*,
		extents.page_id,
		extents.pg_alloc,
		extents.ext_size
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB')
	ORDER BY buffer.page_id;

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
-- uden index
USE master;
GO
DROP DATABASE BufferpoolDB;
GO
CREATE DATABASE BufferpoolDB;
GO
USE BufferpoolDB;
CREATE TABLE dbo.PageTable
(
	ID		INT			NOT NULL,
	Txt		CHAR(8000)	NOT NULL 
						CONSTRAINT DF_PageTable_Txt DEFAULT (REPLICATE('x', 8000))
);
GO
SET NOCOUNT ON;
WITH 
Id_Data 
AS
(
SELECT 1 AS ID
UNION ALL
SELECT ID + 1
	FROM Id_Data
	WHERE ID < 500
)
SELECT ID, NEWID() AS Sortkol
	INTO Data
	FROM ID_Data
	OPTION (MAXRECURSION 0);
GO
DECLARE @Sortkol		UNIQUEIDENTIFIER = (SELECT MIN(Sortkol) 
												FROM Data);
DECLARE @ID				INT = (SELECT ID 
								FROM Data 
								WHERE Sortkol = @Sortkol);

WHILE EXISTS (SELECT * FROM Data WHERE Sortkol > @Sortkol)
BEGIN
	INSERT INTO dbo.PageTable (ID) VALUES (@ID);

	SELECT @Sortkol = MIN(Sortkol) 
		FROM Data
		WHERE Sortkol > @Sortkol;

	SELECT @ID = ID 
		FROM Data 
		WHERE Sortkol = @Sortkol
END;
SET NOCOUNT OFF
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	ORDER BY ID;
GO
DECLARE @ExtentInfo TABLE
(
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	object_id			BIGINT,
	index_id			SMALLINT,
	partition_number	INT,
	partition_id		BIGINT,
	iam_chain_type		VARCHAR(250),
	pfs_bytes			BINARY(8)
)

INSERT INTO @ExtentInfo
	EXEC ('DBCC EXTENTINFO (''BufferpoolDB'', ''PageTable'')');

CHECKPOINT;
DBCC DROPCLEANBUFFERS;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalRID,
		*
	FROM dbo.PageTable
	WHERE ID IN (1, 2, 3, 4);

SELECT	buffer.*,
		extents.page_id,
		extents.pg_alloc,
		extents.ext_size
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB')
	ORDER BY buffer.page_id;

SELECT COUNT(DISTINCT buffer.page_id/8) AS AntalExtents
	FROM sys.dm_os_buffer_descriptors AS buffer INNER JOIN @ExtentInfo AS extents ON buffer.page_id BETWEEN extents.page_id AND extents.page_id + extents.pg_alloc - 1
	WHERE database_id = DB_ID(N'BufferpoolDB');
GO
