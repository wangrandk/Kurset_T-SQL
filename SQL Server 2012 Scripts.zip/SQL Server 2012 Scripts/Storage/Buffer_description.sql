SELECT *
	FROM sys.dm_os_buffer_descriptors;