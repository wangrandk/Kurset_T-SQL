USE master;
DROP DATABASE PPDB;
GO
CREATE DATABASE PPDB;
GO
USE PPDB;
CREATE TABLE dbo.t1_1
(
	ID			INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(20) NOT NULL
);
CREATE TABLE dbo.t2_1
(
	ID			INT NOT NULL PRIMARY KEY,
	Beloeb		INT NOT NULL,
	t1ID		INT NOT NULL REFERENCES dbo.t1_1(ID)
);
GO
INSERT INTO dbo.t1_1 VALUES
	(1, 'Hanne'),
	(2, 'Ida'),
	(3, 'Ane');
	
INSERT INTO dbo.t2_1 VALUES
	(1, 25, 1),
	(2, 75, 1),
	(3, 10, 2),
	(4, 20, 2),
	(5, 20, 2),
	(6, 50, 3),
	(7, 50, 3);
GO
CREATE TABLE dbo.t1_2
(
	ID			INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(20) NOT NULL
);
CREATE TABLE dbo.t2_2
(
	ID			INT NOT NULL PRIMARY KEY,
	Beloeb		INT NOT NULL,
	t1ID		INT NOT NULL REFERENCES t1_2(ID)
);
GO
INSERT INTO dbo.t1_2 VALUES
	(1, 'Per'),
	(2, 'Bo'),
	(3, 'Hans');
	
INSERT INTO dbo.t2_2 VALUES
	(1, 25, 1),
	(2, 75, 1),
	(3, 10, 2),
	(4, 20, 2),
	(5, 20, 2);
GO
CREATE TABLE dbo.t1_3
(
	ID			INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(20) NOT NULL
);
CREATE TABLE dbo.t2_3
(
	ID			INT NOT NULL PRIMARY KEY,
	Beloeb		INT NOT NULL,
	t1ID		INT NULL REFERENCES t1_3(ID)
);
GO
INSERT INTO dbo.t1_3 VALUES
	(1, 'Hansen'),
	(2, 'Jensen'),
	(3, 'Olsen');
	
INSERT INTO dbo.t2_3 VALUES
	(1, 25, 1),
	(2, 75, 1),
	(3, 10, 2),
	(4, 20, 2),
	(5, 20, 2),
	(6, 20, NULL),
	(7, 20, NULL);
GO
CREATE TABLE dbo.t1_4
(
	ID			INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(20) NOT NULL
);
CREATE TABLE dbo.t2_4
(
	ID			INT NOT NULL PRIMARY KEY,
	Beloeb		INT NOT NULL,
	t1ID		INT NULL
);
GO
INSERT INTO dbo.t1_4 VALUES
	(1, 'Hans Hansen'),
	(2, 'Jens Jensen'),
	(3, 'Ole Olsen');
	
INSERT INTO dbo.t2_4 VALUES
	(1, 25, 1),
	(2, 75, 1),
	(3, 10, 2),
	(4, 20, 2),
	(5, 20, 2),
	(6, 20, NULL),
	(7, 20, 4);
GO