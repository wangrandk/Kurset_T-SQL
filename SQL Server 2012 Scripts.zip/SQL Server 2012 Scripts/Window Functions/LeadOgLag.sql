USE master;
GO
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
CREATE TABLE dbo.Events
(
	GruppeId		INT NOT NULL,
	EventTid		DATE
);
GO
INSERT INTO dbo.Events VALUES
	(1, DATEADD(DAY, -23, SYSDATETIME())),
	(1, DATEADD(DAY, -12, SYSDATETIME())),
	(1, DATEADD(DAY, -5, SYSDATETIME())),
	(2, DATEADD(DAY, -26, SYSDATETIME())),
	(2, DATEADD(DAY, -25, SYSDATETIME())),
	(2, DATEADD(DAY, -11, SYSDATETIME())),
	(2, DATEADD(DAY, -8, SYSDATETIME())),
	(2, DATEADD(DAY, -8, SYSDATETIME())),
	(2, DATEADD(DAY, -1, SYSDATETIME()));
GO 
SELECT	GruppeId, 
		EventTid, 
		DATEDIFF(DAY, EventTid, LEAD(EventTid, 1) OVER (ORDER BY EventTid))
	FROM dbo.Events
	ORDER BY EventTid;

SELECT	GruppeId, 
		EventTid, 
		DATEDIFF(DAY, LAG(EventTid, 1) OVER (ORDER BY EventTid), EventTid)
	FROM dbo.Events
	ORDER BY EventTid;
GO
SELECT	GruppeId, 
		EventTid, 
		DATEDIFF(DAY, EventTid, LEAD(EventTid, 1) OVER (PARTITION BY GruppeId ORDER BY EventTid))
	FROM dbo.Events
	ORDER BY GruppeId, EventTid;

SELECT	GruppeId, 
		EventTid, 
		DATEDIFF(DAY, LAG(EventTid, 1) OVER (PARTITION BY GruppeId ORDER BY EventTid), EventTid)
	FROM dbo.Events
	ORDER BY GruppeId,EventTid;
