DECLARE @Gaps TABLE 
	(
	Vaerdi		INT		 NOT NULL
	);

INSERT INTO @Gaps (Vaerdi) VALUES 
	(1), (2), (3),
	(50), (51), (52), (53), (54), (55),
	(100), (101), (102),
	(500),
	(502), (503), (504),
	(506),
	(950), (951), (952);

WITH NaesteVaerdi AS
(
SELECT Vaerdi AS Aktuel,
       LEAD(Vaerdi, 1) OVER (ORDER BY Vaerdi) AS Naeste
	FROM @Gaps
)
SELECT	
		NaesteVaerdi.Aktuel,
		NaesteVaerdi.Naeste,
		NaesteVaerdi.Aktuel + 1 AS StartPaaGab,
		NaesteVaerdi.Naeste - 1 AS SlutPaaGab
	FROM NaesteVaerdi
	WHERE NaesteVaerdi.Naeste - NaesteVaerdi.Aktuel > 1;

WITH NaesteVaerdi AS
(
SELECT Vaerdi AS Aktuel,
       LAG(Vaerdi, 1) OVER (ORDER BY Vaerdi) AS Naeste
	FROM @Gaps
)
SELECT	
		NaesteVaerdi.Naeste,
		NaesteVaerdi.Aktuel,
		NaesteVaerdi.Naeste + 1 AS StartPaaGab,
		NaesteVaerdi.Aktuel - 1 AS SlutPaaGab
	FROM NaesteVaerdi
	WHERE NaesteVaerdi.Aktuel - NaesteVaerdi.Naeste > 1;
