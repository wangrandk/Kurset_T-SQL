USE master
DROP DATABASE OverDB;
GO
CREATE DATABASE OverDB;
GO
USE OverDB;
CREATE TABLE dbo.KundeKoeb 
(
	KundeId			INT NOT NULL,
	Dato			DATE NOT NULL,
	Beloeb			DECIMAL(9,2) NOT NULL,
	CONSTRAINT PK_KundeKoeb PRIMARY KEY (KundeId, Dato)
);
GO
INSERT INTO dbo.KundeKoeb VALUES
	(1, DATEADD(DAY, -933, SYSDATETIME()), 200),
	(1, DATEADD(DAY, -756, SYSDATETIME()), 300),
	(1, DATEADD(DAY, -456, SYSDATETIME()), 300),
	(1, DATEADD(DAY, -300, SYSDATETIME()), 100),
	(1, DATEADD(DAY, -200, SYSDATETIME()), 100),
	(2, DATEADD(DAY, -678, SYSDATETIME()), 400),
	(2, DATEADD(DAY, -413, SYSDATETIME()), 300),
	(2, DATEADD(DAY, -198, SYSDATETIME()), 600),
	(2, DATEADD(DAY, -23,  SYSDATETIME()), 500),
	(3, DATEADD(DAY, -112, SYSDATETIME()), 500);
GO
SELECT *
	FROM dbo.KundeKoeb
	ORDER BY KundeId, Dato;
GO
SELECT	KundeId,
		FIRST_VALUE(Dato) OVER (PARTITION BY KundeId ORDER BY Dato)  AS FoersteKoeb,
		LAST_VALUE(Dato) OVER (PARTITION BY KundeId ORDER BY Dato)  AS SidsteKoeb
	FROM dbo.KundeKoeb
	ORDER BY KundeId, Dato;
GO
SELECT KundeID, FoersteKoeb, MAX(SidsteKoeb) AS SidsteKoeb
FROM 
	(
	SELECT	KundeId,
			FIRST_VALUE(Dato) OVER (PARTITION BY KundeId ORDER BY Dato)  AS FoersteKoeb,
			LAST_VALUE(Dato) OVER (PARTITION BY KundeId ORDER BY Dato)  AS SidsteKoeb
		FROM dbo.KundeKoeb) AS KoebMinMax
	GROUP BY KundeId, FoersteKoeb
	ORDER BY KundeId;
GO
SELECT	KundeId,
		Dato,
		LAG(Dato, 1) OVER (PARTITION BY KundeId ORDER BY Dato)  AS DatoFoer,
		LEAD(Dato, 1) OVER (PARTITION BY KundeId ORDER BY Dato)  AS DatoEfter
	FROM dbo.KundeKoeb
	ORDER BY KundeId, Dato;
GO
SELECT	KundeId,
		Dato,
		DATEDIFF(DAY, LAG(Dato, 1) OVER (PARTITION BY KundeId ORDER BY Dato), Dato)  AS DageImellemKoeb
	FROM dbo.KundeKoeb
	ORDER BY KundeId, Dato;
GO
SELECT	KundeId,
		Dato,
		Beloeb,
		PERCENT_RANK() OVER (PARTITION BY KundeId ORDER BY Beloeb)  AS PercentRank,
		CUME_DIST() OVER (PARTITION BY KundeId ORDER BY Beloeb)  AS CumeDest
	FROM dbo.KundeKoeb
	ORDER BY KundeId, Beloeb;
GO
