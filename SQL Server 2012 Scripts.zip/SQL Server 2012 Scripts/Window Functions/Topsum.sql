USE master;
DROP DATABASE TopsumDB;
GO
CREATE DATABASE TopsumDB
ON PRIMARY
	( NAME = TopsumDB_file_1,
	  FILENAME = 'C:\Databaser\TopsumDB_p.mdf',
      SIZE = 5MB,
      MAXSIZE = 6MB,
      FILEGROWTH = 10%),
	
FILEGROUP TopsumDB_group_1 DEFAULT
	( NAME = TopsumDB_file_2,
	  FILENAME = 'C:\Databaser\TopsumDB_1.ndf',
      SIZE = 200MB,
      MAXSIZE = 400MB,
      FILEGROWTH = 10%),
	
	( NAME = TopsumDB_file_3,
	  FILENAME = 'C:\Databaser\TopsumDB_2.ndf',
      SIZE = 200MB,
      MAXSIZE = 400MB,
      FILEGROWTH = 10%)

LOG ON
	( NAME = TopsumDB_log_file_1,
	  FILENAME = 'C:\Databaser\TopsumDB_log_1.ldf',
      SIZE = 800MB,
      MAXSIZE = 1500MB,
      FILEGROWTH = 10%);
GO
USE master;
GO
ALTER DATABASE TopsumDB SET RECOVERY SIMPLE WITH NO_WAIT;
GO
USE TopsumDB;
CREATE TABLE dbo.Salg
(
	ID			INT NOT NULL PRIMARY KEY IDENTITY,
	SaelgerID	INT NOT NULL,
	KundeID		INT NOT NULL,
	Beloeb		INT NOT NULL
);
GO
INSERT INTO dbo.Salg (SaelgerID, KundeID, Beloeb) VALUES
	(1, 20, 200),
	(1, 23, 300),
	(1, 17, 900),
	(1, 11, 100),
	(1, 56, 800),
	(1, 44, 400),
	(1, 35, 700),
	(1, 77, 700),
	(1, 13, 150),
	(1, 45, 180),
	(1, 67, 110),
	(1, 57, 700),

	(2, 12, 100),
	(2, 57, 800),
	(2, 15, 400),
	(2, 49, 600),
	(2, 19, 700),
	(2, 44, 100),
	(2, 14, 120),
	(2, 13, 190),
	(2, 88, 100),
	(2, 99, 200),
		
	(3, 23, 900),
	(3, 57, 100),
	(3, 02, 100);
GO
INSERT INTO dbo.Salg (SaelgerID, KundeID, Beloeb)
	SELECT	SaelgerID + (SELECT MAX(SaelgerID) FROM dbo.Salg), 
			KundeID, 
			Beloeb
		FROM dbo.Salg;
GO 15
SELECT COUNT(*)
	FROM dbo.Salg;

UPDATE dbo.Salg	
	SET Beloeb = ABS(Beloeb + (ID % 754) - (SaelgerID % 234));

DELETE
	FROM dbo.Salg
	WHERE	Beloeb % 47 = 5 OR
			Beloeb = 0;

SELECT TOP 100 *
	FROM dbo.Salg;

SELECT COUNT(*)
	FROM dbo.Salg;
GO
DECLARE @TopPct			SMALLINT = 75;

WITH Saelgerdata
AS
(
SELECT	*,
		ROW_NUMBER() OVER (PARTITION BY SaelgerID ORDER BY Beloeb DESC) AS RkNummer,
		SUM(Beloeb) OVER (PARTITION BY SaelgerID ORDER BY Beloeb DESC 
				ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS LoebendeSum,
		SUM(Beloeb) OVER (PARTITION BY SaelgerID ORDER BY Beloeb DESC 
				ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS SaelgerSum
	FROM dbo.Salg
)
SELECT *
	FROM Saelgerdata AS SaelgerRes
	WHERE RkNummer <= 1 + ISNULL((SELECT MAX(RkNummer)
									FROM SaelgerData AS SD
									WHERE	SaelgerSum / 100 * @TopPct > LoebendeSum AND
										SD.SaelgerID = SaelgerRes.SaelgerID), 0)
	ORDER BY SaelgerID ASC, Beloeb DESC;
GO
DECLARE @TopPct			SMALLINT = 50;

WITH Saelgerdata
AS
(
SELECT	*,
		ROW_NUMBER() OVER (PARTITION BY SaelgerID ORDER BY Beloeb DESC) AS RkNummer,
		SUM(Beloeb) OVER (PARTITION BY SaelgerID ORDER BY Beloeb DESC 
				ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS LoebendeSum,
		SUM(Beloeb) OVER (PARTITION BY SaelgerID ORDER BY Beloeb DESC 
				ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS SaelgerSum
	FROM dbo.Salg
),
Topsalg
AS
(
SELECT	ID,
		SaelgerID,
		KundeID,
		Beloeb,
		CONCAT('Blandt TOP', @TopPct, ' procent') AS Topangivelse
	FROM Saelgerdata AS SaelgerRes
	WHERE RkNummer <= 1 + ISNULL((SELECT MAX(RkNummer)
								FROM SaelgerData AS SD
								WHERE	SaelgerSum / 100 * @TopPct > LoebendeSum AND
										SD.SaelgerID = SaelgerRes.SaelgerID), 0)
)
SELECT *, NULL AS Antal
	FROM Topsalg
UNION ALL
SELECT	999,
		SaelgerID,
		NULL,
		SUM(Beloeb),
		CONCAT('Udenfor TOP', @TopPct, ' procent') AS Topangivelse,
		COUNT(*) AS Antal
	FROM dbo.Salg
	WHERE ID NOT IN 
			(SELECT ID 
				FROM Topsalg)
	GROUP BY SaelgerID
ORDER BY SaelgerID ASC, ID;

SELECT *
	FROM dbo.Salg
	WHERE SaelgerID = 1;
GO
DECLARE @BottomPct			SMALLINT = 50;

WITH Saelgerdata
AS
(
SELECT	*,
		ROW_NUMBER() OVER (PARTITION BY SaelgerID ORDER BY Beloeb ASC) AS RkNummer,
		SUM(Beloeb) OVER (PARTITION BY SaelgerID ORDER BY Beloeb ASC 
				ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS LoebendeSum,
		SUM(Beloeb) OVER (PARTITION BY SaelgerID ORDER BY Beloeb ASC 
				ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS SaelgerSum
	FROM dbo.Salg
),
Topsalg
AS
(
SELECT	ID,
		SaelgerID,
		KundeID,
		Beloeb,
		CONCAT('Blandt Bottom', @BottomPct, ' procent') AS Topangivelse
	FROM Saelgerdata AS SaelgerRes
	WHERE RkNummer <= 1 + ISNULL((SELECT MAX(RkNummer)
								FROM SaelgerData AS SD
								WHERE	SaelgerSum / 100 * @BottomPct > LoebendeSum AND
										SD.SaelgerID = SaelgerRes.SaelgerID), 0)
)
SELECT *, NULL AS Antal
	FROM Topsalg
UNION ALL
SELECT	999,
		SaelgerID,
		NULL,
		SUM(Beloeb),
		CONCAT('Udenfor Bottom', @BottomPct, ' procent') AS Topangivelse,
		COUNT(*) AS Antal
	FROM dbo.Salg
	WHERE ID NOT IN 
			(SELECT ID 
				FROM Topsalg)
	GROUP BY SaelgerID
ORDER BY SaelgerID ASC, ID;

SELECT *
	FROM dbo.Salg
	WHERE SaelgerID = 1;
