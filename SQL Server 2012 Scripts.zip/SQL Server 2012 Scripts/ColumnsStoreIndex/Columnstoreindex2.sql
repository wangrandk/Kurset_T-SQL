USE IndexDB;
GO
CREATE NONCLUSTERED COLUMNSTORE INDEX cs_dbo_Person
	ON dbo.Person
	( 
	 Fornavn,
	 Efternavn,
	 Gade,
	 Postnr,
	 Landekode,
	 Tlfnr,
	 Persontype,
	 Koenkode
	);
GO
SELECT *
	FROM sys.column_store_segments;

SELECT *
	FROM sys.column_store_dictionaries;
GO
SELECT
		COUNT(DISTINCT Fornavn) AS Fornavn,
		COUNT(DISTINCT Efternavn) AS Efternavn,
		COUNT(DISTINCT Gade) AS Gade,
		COUNT(DISTINCT Postnr) AS Postnr,
		COUNT(DISTINCT Landekode) AS Landekode,
		COUNT(DISTINCT Tlfnr) AS Tlfnr,
		COUNT(DISTINCT Persontype) AS Persontype,
		COUNT(DISTINCT Koenkode) AS Koenkode
	FROM dbo.Person;
GO
DROP INDEX cs_dbo_Person ON Person;
