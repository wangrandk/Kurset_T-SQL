 USE IndexDB;
 GO
 SET STATISTICS TIME ON;
 SELECT		Fornavn, 
			Efternavn, 
			Gade
	FROM dbo.Person;
SET STATISTICS TIME OFF;
--  (5155601 row(s) affected)

-- SQL Server Execution Times:
--   CPU time = 4587 ms,  elapsed time = 58182 ms.
GO
CREATE NONCLUSTERED COLUMNSTORE INDEX cs_dbo_Person
	ON dbo.Person
	( 
	 Fornavn,
	 Efternavn,
	 Gade,
	 Postnr,
	 Landekode,
	 Tlfnr,
	 Persontype,
	 Koenkode
	);
GO
 SET STATISTICS TIME ON;
 SELECT		Fornavn, 
			Efternavn, 
			Gade
	FROM dbo.Person;
SET STATISTICS TIME OFF;
-- (5155601 row(s) affected)

-- SQL Server Execution Times:
--   CPU time = 6209 ms,  elapsed time = 65367 ms.
GO
SELECT SUM(on_disk_size_MB) AS TotalSizeInMB
  FROM
  (
     (SELECT SUM(css.on_disk_size)/(1024.0*1024.0) on_disk_size_MB
      FROM sys.indexes AS i
      JOIN sys.partitions AS p
          ON i.object_id = p.object_id 
      JOIN sys.column_store_segments AS css
          ON css.hobt_id = p.hobt_id
      WHERE i.object_id = object_id('dbo.Person') 
      AND i.type_desc = 'NONCLUSTERED COLUMNSTORE') 
    UNION ALL
     (SELECT SUM(csd.on_disk_size)/(1024.0*1024.0) on_disk_size_MB
      FROM sys.indexes AS i
      JOIN sys.partitions AS p
          ON i.object_id = p.object_id 
      JOIN sys.column_store_dictionaries AS csd
          ON csd.hobt_id = p.hobt_id
      WHERE i.object_id = object_id('dbo.Person') 
      AND i.type_desc = 'NONCLUSTERED COLUMNSTORE') 
  ) AS SegmentsPlusDictionary;
GO
SET STATISTICS TIME ON;
SELECT		Fornavn, 
			Efternavn, 
			COUNT(*)
	FROM dbo.Person
	GROUP BY Fornavn, Efternavn;
SET STATISTICS TIME OFF;
-- (5960 row(s) affected)

-- SQL Server Execution Times:
--   CPU time = 392 ms,  elapsed time = 233 ms.
GO
DROP INDEX cs_dbo_Person ON dbo.Person;
GO
SET STATISTICS TIME ON;
SELECT		Fornavn, 
			Efternavn, 
			COUNT(*)
	FROM dbo.Person
	GROUP BY Fornavn, Efternavn;
SET STATISTICS TIME OFF;
-- (5960 row(s) affected)

-- SQL Server Execution Times:
--   CPU time = 19110 ms,  elapsed time = 2757 ms.
GO
CREATE NONCLUSTERED INDEX nc_dbo_Person_Fornavn_Efternavn ON dbo.Person(Fornavn, Efternavn);
GO
SET STATISTICS TIME ON;
SELECT		Fornavn, 
			Efternavn, 
			COUNT(*)
	FROM dbo.Person
	GROUP BY Fornavn, Efternavn;
SET STATISTICS TIME OFF;
GO
-- (5960 row(s) affected)

-- SQL Server Execution Times:
--   CPU time = 10449 ms,  elapsed time = 1812 ms.