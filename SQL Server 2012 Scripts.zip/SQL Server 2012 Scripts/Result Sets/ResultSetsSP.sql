USE master;
GO
DROP DATABASE SPDB;
GO
CREATE DATABASE SPDB;
GO
USE SPDB;
CREATE TABLE Postopl 
(
	Postnr		SMALLINT	NOT NULL PRIMARY KEY,
	Bynavn		VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Person 
(
	PersonId	INT			NOT NULL PRIMARY KEY,
	Navn		VARCHAR(30) NOT NULL,
	Gade		VARCHAR(30) NOT NULL,
	Postnr		SMALLINT	NOT NULL REFERENCES Postopl (Postnr)	
);
GO
INSERT INTO dbo.Postopl VALUES
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C');

INSERT INTO dbo.Person VALUES
	(1, 'Ida Jensen', 'Vestergade 73', 2000),
	(2, 'Bo larsen', 'Torvet 31', 2000),
	(3, 'Knud Olsen', '�stergade 16', 8000),
	(4, 'Maren Poulsen', 'N�rregade 27', 8000),
	(5, 'Per Andersen', 'Strandvejen 54', 8000),
	(6, 'Lars S�rensen', 'Poulsgade 4', 8000);
GO
CREATE PROCEDURE dbo.usp_Person
	@PersonId		INT
AS
SELECT *
	FROM dbo.Person
	WHERE PersonId = @PersonId;
GO
EXEC dbo.usp_Person 3;
GO
EXEC dbo.usp_Person 4
	WITH RESULT SETS
	(
		( 
		ID					INT,
		Personnavn			VARCHAR(40),
		Personadr			VARCHAR(40),
		Personpostnr		INT
		) 
	);
GO
CREATE PROCEDURE dbo.usp_PersonPostnr
	@Postnr			SMALLINT
AS
SELECT *
	FROM dbo.Postopl
	WHERE Postnr = @Postnr

SELECT *
	FROM dbo.Person
	WHERE Postnr = @Postnr
GO
EXEC dbo.usp_PersonPostnr 2000;
GO
EXEC dbo.usp_PersonPostnr 8000
	WITH RESULT SETS
	(
		(
		Postnummer			SMALLINT,
		Bynavn				VARCHAR(20)
		),
		( 
		ID					INT,
		Personnavn			VARCHAR(40),
		Personadr			VARCHAR(40),
		Personpostnr		INT
		) 
	);
GO
EXEC dbo.usp_PersonPostnr 8000
	WITH RESULT SETS
	(
		(
		Postnummer			SMALLINT,
		Bynavn				VARCHAR(20)
		),
		( 
		ID					VARCHAR(10),
		Personnavn			VARCHAR(40),
		Personadr			VARCHAR(40),
		Personpostnr		INT
		) 
	);
GO
EXEC dbo.usp_PersonPostnr 8000 --Fejl, kolonne mangler
	WITH RESULT SETS
	(
		(
		Postnummer			SMALLINT,
		Bynavn				VARCHAR(20)
		),
		( 
		ID					VARCHAR(10),
		Personnavn			VARCHAR(40),
		Personpostnr		INT
		) 
	);