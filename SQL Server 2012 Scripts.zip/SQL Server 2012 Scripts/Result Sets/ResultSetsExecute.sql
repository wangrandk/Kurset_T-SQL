USE IndexDB;
GO
EXECUTE ('SELECT * FROM Postopl')
WITH RESULT SETS 
(
	(
	Zipcode		INT			NOT NULL,
	Cityname	VARCHAR(30) NOT NULL
	)
);
GO
EXECUTE ('SELECT * FROM dbo.Postopl; SELECT * FROM dbo.Persontype')
WITH RESULT SETS 
(
	(
	Zipcode			INT			NOT NULL,
	Cityname		VARCHAR(30) NOT NULL
	),
	(
	Persontype		CHAR(1)		NOT NULL,
	PersontypeTxt	VARCHAR(20) NOT NULL
	)
);
GO
SELECT DISTINCT Koenkode	
	FROM dbo.Person;
GO
SELECT DISTINCT Koenkode	
	FROM dbo.Person;
GO
EXECUTE ('SELECT DISTINCT Koenkode FROM dbo.Person')
WITH RESULT SETS
(
	(
	Koenkode		CHAR(1) NULL
	)
);
GO
EXECUTE ('SELECT DISTINCT Koenkode FROM dbo.Person')
WITH RESULT SETS
(
	(
	Koenkode		CHAR(1) NOT NULL
	)
);
GO
