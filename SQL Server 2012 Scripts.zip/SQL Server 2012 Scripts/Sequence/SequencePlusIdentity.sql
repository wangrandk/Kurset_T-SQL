USE master;
DROP DATABASE SequenceDB;
GO
CREATE DATABASE SequenceDB;
GO
USE SequenceDB;
CREATE SEQUENCE PersonSeq
    AS INT
    START WITH 1
    INCREMENT BY 1;
GO
CREATE TABLE dbo.Kunde 
(
	KundeID					INT NOT NULL PRIMARY KEY DEFAULT (NEXT VALUE FOR PersonSeq),
	KundeIdentity			INT NOT NULL IDENTITY,
	Navn					VARCHAR(30) NOT NULL
);

CREATE TABLE dbo.Leverandoer 
(
	LeverandoerID			INT NOT NULL PRIMARY KEY DEFAULT (NEXT VALUE FOR PersonSeq),
	LeverandoerIdentity		INT NOT NULL IDENTITY,
	Navn					VARCHAR(30) NOT NULL
);

CREATE TABLE dbo.Medarbejder 
(
	MedarbejderID			INT NOT NULL PRIMARY KEY DEFAULT (NEXT VALUE FOR PersonSeq),
	MedarbejderIdentity		INT NOT NULL IDENTITY,
	Navn					VARCHAR(30) NOT NULL
);
GO
INSERT INTO dbo.Kunde(Navn) VALUES
	('Kunde 1'),
	('Kunde 2'),
	('Kunde 3');

INSERT INTO dbo.Medarbejder(Navn) VALUES
	('Medarbejder 1'),
	('Medarbejder 2')

INSERT INTO dbo.Kunde(Navn) VALUES
	('Kunde 4'),
	('Kunde 5');

INSERT INTO dbo.Leverandoer(Navn) VALUES
	('Leverandoer 1'),
	('Leverandoer 2'),
	('Leverandoer 3');

INSERT INTO dbo.Medarbejder(Navn) VALUES
	('Medarbejder 3');

INSERT INTO dbo.Leverandoer(Navn) VALUES
	('Leverandoer 4');
GO
SELECT	KundeID AS ID, 
		KundeIdentity AS PersonIdentity, 
		Navn
	FROM dbo.Kunde
UNION ALL
SELECT	LeverandoerID AS ID,
		LeverandoerIdentity, 
		Navn
	FROM dbo.Leverandoer
UNION ALL
SELECT	MedarbejderID AS ID, 
		MedarbejderIdentity,
		Navn
	FROM dbo.Medarbejder
ORDER BY ID
GO
SELECT	KundeID AS ID, 
		KundeIdentity, 
		Navn
	FROM dbo.Kunde

SELECT	LeverandoerID AS ID,
		LeverandoerIdentity, 
		Navn
	FROM dbo.Leverandoer

SELECT	MedarbejderID AS ID, 
		MedarbejderIdentity,
		Navn
	FROM dbo.Medarbejder
GO
