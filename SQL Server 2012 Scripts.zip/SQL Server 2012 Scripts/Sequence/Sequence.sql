USE master;
DROP DATABASE SequenceDB;
GO
CREATE DATABASE SequenceDB;
GO
USE SequenceDB;
CREATE SEQUENCE PersonSeq
    AS INT
    START WITH 1
    INCREMENT BY 1;
GO
CREATE TABLE dbo.Kunde 
(
	KundeId			INT			NOT NULL 
					PRIMARY KEY DEFAULT (NEXT VALUE FOR PersonSeq),
	Navn			VARCHAR(30) NOT NULL
);

CREATE TABLE dbo.Leverandoer 
(
	LeverandoerId	INT			NOT NULL 
					PRIMARY KEY DEFAULT (NEXT VALUE FOR PersonSeq),
	Navn			VARCHAR(30) NOT NULL
);

CREATE TABLE dbo.Medarbejder 
(
	MedarbejderId	INT			NOT NULL 
					PRIMARY KEY DEFAULT (NEXT VALUE FOR PersonSeq),
	Navn			VARCHAR(30) NOT NULL
);
GO
SELECT * 
	FROM sys.sequences 
	WHERE name = 'PersonSeq';
GO
INSERT INTO dbo.Kunde(Navn) VALUES
	('Kunde 1'),
	('Kunde 2'),
	('Kunde 3');

INSERT INTO dbo.Medarbejder(Navn) VALUES
	('Medarbejder 1'),
	('Medarbejder 2');

INSERT INTO dbo.Kunde(Navn) VALUES
	('Kunde 4'),
	('Kunde 5');

INSERT INTO dbo.Leverandoer(Navn) VALUES
	('Leverandoer 1'),
	('Leverandoer 2'),
	('Leverandoer 3');

INSERT INTO dbo.Medarbejder(Navn) VALUES
	('Medarbejder 3');

INSERT INTO dbo.Leverandoer(Navn) VALUES
	('Leverandoer 4');
GO
SELECT	KundeId AS ID, 
		Navn, 'K' AS Type
	FROM dbo.Kunde
UNION ALL
SELECT	LeverandoerId AS ID, 
		Navn, 'L'
	FROM dbo.Leverandoer
UNION ALL
SELECT	MedarbejderId AS ID, 
		Navn, 'M'
	FROM dbo.Medarbejder
ORDER BY ID;
GO
SELECT NEXT VALUE FOR PersonSeq;
SELECT NEXT VALUE FOR PersonSeq;
SELECT NEXT VALUE FOR PersonSeq;
SELECT NEXT VALUE FOR PersonSeq;
GO
SELECT	NEXT VALUE FOR PersonSeq,
		NEXT VALUE FOR PersonSeq,
		NEXT VALUE FOR PersonSeq,
		NEXT VALUE FOR PersonSeq;
GO
INSERT INTO dbo.Kunde(Navn) VALUES
	('Kunde 18');
GO
SELECT	KundeId AS ID, 
		Navn
	FROM dbo.Kunde
UNION ALL
SELECT	LeverandoerId AS ID, 
		Navn
	FROM dbo.Leverandoer
UNION ALL
SELECT	MedarbejderId AS ID, 
		Navn
	FROM dbo.Medarbejder
ORDER BY ID;
GO
CREATE SEQUENCE MinMaxSeq
	AS TINYINT
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 5;
GO
SELECT NEXT VALUE FOR MinMaxSeq;
SELECT NEXT VALUE FOR MinMaxSeq;
SELECT NEXT VALUE FOR MinMaxSeq;
SELECT NEXT VALUE FOR MinMaxSeq;
SELECT NEXT VALUE FOR MinMaxSeq;

SELECT NEXT VALUE FOR MinMaxSeq;
GO
ALTER SEQUENCE MinMaxSeq
	RESTART WITH 3 ;
GO
SELECT NEXT VALUE FOR MinMaxSeq;
GO
-- Fejler - uden for Min/Max gr�nserne
ALTER SEQUENCE MinMaxSeq
	RESTART WITH 100;
GO
DROP SEQUENCE MinMaxSeq;
GO
CREATE SEQUENCE MinMaxSeq
	AS TINYINT
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 5
	CYCLE;
GO
SELECT NEXT VALUE FOR MinMaxSeq;
SELECT NEXT VALUE FOR MinMaxSeq;
SELECT NEXT VALUE FOR MinMaxSeq;
SELECT NEXT VALUE FOR MinMaxSeq;
SELECT NEXT VALUE FOR MinMaxSeq;

SELECT NEXT VALUE FOR MinMaxSeq;
SELECT NEXT VALUE FOR MinMaxSeq;
SELECT NEXT VALUE FOR MinMaxSeq;
SELECT NEXT VALUE FOR MinMaxSeq;
GO
CREATE TABLE dbo.Medarbejder 
(
	MedarbejderId		INT			NOT NULL PRIMARY KEY,
	Navn				VARCHAR(20) NOT NULL,
	AfdelingsId			CHAR(1)		NOT NULL, 
	ChefId				INT			NULL 
						REFERENCES dbo.Medarbejder (MedarbejderId)
);
GO
INSERT INTO dbo.Medarbejder  VALUES
	(1345,  'Anne',  'A', NULL),
	(265,  'Ole',   'B', 1345),
	(39,  'Per',   'C', 1345),
	(54,  'Sanne', 'D', 1345),
	(25,  'Kurt',  'B', 265),
	(673,  'Poul',  'B', 265),
	(17,  'Kamma', 'B', 25),
	(5238,  'Hans',  'B', 25),
	(999,  'Irene', 'B', 25),
	(1960, 'Lotte', 'D', 54),
	(181, 'Lars',  'D', 54),
	(112, 'Vivi',  'D', 54),
	(313, 'Sofus', 'E', 112),
	(214, 'Lilly',  'E', 112),
	(915, 'Johanne',  'E', 112);
GO
CREATE SEQUENCE MedarbejderSeq
	AS INT
	START WITH 1
	INCREMENT BY 1;
GO
SELECT	*,
		NEXT VALUE FOR MedarbejderSeq 
				OVER (ORDER BY AfdelingsId, MedarbejderId) AS NextValue
	FROM dbo.Medarbejder 
	ORDER BY NextValue;

SELECT	*,				-- Fejl, m� ikke anvende PARTITION BY 
		NEXT VALUE FOR MedarbejderSeq 
				OVER (PARTITION BY AfdelingsId ORDER BY MedarbejderId) AS NextValue
	FROM dbo.Medarbejder 
	ORDER BY NextValue;
