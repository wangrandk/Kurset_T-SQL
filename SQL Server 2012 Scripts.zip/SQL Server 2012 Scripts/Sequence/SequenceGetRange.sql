USE master;
DROP DATABASE SequenceDB;
GO
CREATE DATABASE SequenceDB;
GO
USE SequenceDB;
CREATE SEQUENCE dbo.PersonSeq
    AS INT
    START WITH 1
    INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 100
	CYCLE;
GO
CREATE TABLE dbo.Kunde 
(
	KundeID					INT			NOT NULL 
							PRIMARY KEY DEFAULT (NEXT VALUE FOR PersonSeq),
	KundeIdentity			INT			NOT NULL IDENTITY,
	Navn					VARCHAR(30) NOT NULL
);
GO
INSERT INTO dbo.Kunde(Navn) VALUES
	('Kunde 1'),
	('Kunde 2'),
	('Kunde 3');
GO
SELECT	KundeID AS ID, 
		KundeIdentity AS PersonIdentity, 
		Navn
	FROM dbo.Kunde
GO
DECLARE	@FirstSeqNum		SQL_VARIANT;
DECLARE	@LastSeqNum			SQL_VARIANT;
DECLARE @CycleCount			INT;
DECLARE @SeqIncr			SQL_VARIANT;
DECLARE @SeqMinVal			SQL_VARIANT;
DECLARE @SeqMaxVal			SQL_VARIANT;

EXEC sys.sp_sequence_get_range	@sequence_name = N'dbo.PersonSeq',
								@range_size = 10,
								@range_first_value = @FirstSeqNum OUTPUT,
								@range_last_value = @LastSeqNum OUTPUT,
								@range_cycle_count = @CycleCount OUTPUT,
								@sequence_increment = @SeqIncr OUTPUT,
								@sequence_min_value = @SeqMinVal OUTPUT,
								@sequence_max_value = @SeqMaxVal OUTPUT;


SELECT
		@FirstSeqNum AS FirstVal,
		@LastSeqNum AS LastVal,
		@CycleCount AS CycleCount,
		@SeqIncr AS SeqIncrement,
		@SeqMinVal AS MinSeq,
		@SeqMaxVal AS MaxSeq;
