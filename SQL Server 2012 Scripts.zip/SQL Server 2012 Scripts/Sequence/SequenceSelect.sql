USE IndexDB;
GO
CREATE SEQUENCE dbo.Seq
    AS INT
    START WITH 1
    INCREMENT BY 1;
GO
SELECT	*, 
		(NEXT VALUE FOR dbo.Seq) AS SqkNumber
	FROM dbo.Postopl;
GO
SELECT	*, 
		(NEXT VALUE FOR dbo.Seq) AS SqkNumber		-- fejl
	FROM dbo.Postopl
	ORDER BY Postnr;
GO
SELECT *											-- fejl
	FROM (SELECT	*,	
					(NEXT VALUE FOR dbo.Seq) AS SqkNumber 
			FROM dbo.Postopl) AS p
	ORDER BY Postnr;
GO
