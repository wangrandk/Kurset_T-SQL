USE master
GO
DROP DATABASE SynonymDB
DROP DATABASE Synonym1DB
DROP DATABASE Synonym2DB
DROP DATABASE Synonym3DB
GO
CREATE DATABASE SynonymDB
CREATE DATABASE Synonym1DB
CREATE DATABASE Synonym2DB
CREATE DATABASE Synonym3DB
GO
USE SynonymDB
CREATE TABLE dbo.t1
(
	id			INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(20) NOT NULL
)
GO
INSERT INTO dbo.t1 VALUES
	(1, 'Ole'),
	(2, 'Per')
GO
USE Synonym1DB
CREATE SYNONYM t1
	FOR SynonymDB.dbo.t1
GO
USE Synonym1DB
SELECT *
	FROM dbo.t1
GO
USE Synonym2DB;
GO
CREATE SCHEMA brugerdata;
GO
CREATE SYNONYM brugerdata.t1
	FOR SynonymDB.dbo.t1
GO
USE Synonym2DB
SELECT *
	FROM brugerdata.t1
GO
USE Synonym3DB;
GO
CREATE SYNONYM t2
	FOR SynonymDB.dbo.t1
GO
CREATE TABLE dbo.t1
(
	id			INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(20) NOT NULL
)
GO
INSERT INTO dbo.t1 VALUES
	(1, 'Ida'),
	(2, 'Ane'),
	(3, 'Sanne'),
	(4, 'marem')
GO

USE Synonym3DB
SELECT *
	FROM dbo.t1
SELECT *
	FROM dbo.t2
