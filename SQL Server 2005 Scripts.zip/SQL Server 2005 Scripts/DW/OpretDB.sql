USE master
DROP DATABASE DWDB
GO
CREATE DATABASE DWDB  
ON PRIMARY
 (NAME = N'DWDB_Sys', 
  FILENAME = N'C:\Databaser\DWDB_Data.MDF', 
  SIZE = 4, 
  FILEGROWTH = 10%) ,
FILEGROUP DataFG
 (NAME = N'DWDB_Data', 
  FILENAME = N'C:\Databaser\DWDB_DataFG_Fil1.NDF', 
  SIZE = 4000, 
  FILEGROWTH = 10%) 
LOG ON 
 (NAME = N'DWDB_Log',
  FILENAME = N'C:\Databaser\DWDB_Log.LDF', 
  SIZE = 1000,
  FILEGROWTH = 50)
GO
USE DWDB
ALTER DATABASE DWDB MODIFY FILEGROUP DataFG DEFAULT
GO
ALTER DATABASE DWDB SET RECOVERY SIMPLE
GO
CREATE TABLE ENavn (
	ENavn 			VARCHAR (20)  NOT NULL)

CREATE TABLE Fnavn (
	FNavn 			VARCHAR (50)  NOT NULL) 

CREATE TABLE Gade (
	Gade 			VARCHAR (30)  NOT NULL)
GO
CREATE TABLE Kunde (
	KundeID 		INT IDENTITY NOT NULL 
					CONSTRAINT PK_Kunde PRIMARY KEY,
	FNavn 			VARCHAR (20)  NOT NULL ,
	ENavn 			VARCHAR (20)  NOT NULL ,
	Gade 			VARCHAR (30)  NOT NULL ,
	Postnr 			SMALLINT NOT NULL ,
	KundeType		CHAR(1) NOT NULL,
	Navn 			AS (FNavn + ' ' + ENavn))

CREATE TABLE Postopl (
	PostNr 			SMALLINT NOT NULL 
					CONSTRAINT PK_Postopl PRIMARY KEY,
	Bynavn 			VARCHAR (20)  NOT NULL)

CREATE TABLE KundeType (
	KundeType		char(1) NOT NULL CONSTRAINT PK_KundeType PRIMARY KEY,
	KundeTypeTxt	char(30) NOT NULL)

CREATE TABLE KateGOri (
	KateGOriID		SMALLINT NOT NULL CONSTRAINT PK_KateGOri PRIMARY KEY,
	KateGOriNavn	VARCHAR(30) NOT NULL)

CREATE TABLE SubKateGOri (
	SubKateGOriID	SMALLINT NOT NULL CONSTRAINT PK_SubKateGOri PRIMARY KEY,
	SubKateGOriNavn	VARCHAR(30) NOT NULL,
	KateGOriID		SMALLINT NOT NULL
					CONSTRAINT FK_KateGOri__SubKateGOri FOREIGN KEY REFERENCES KateGOri(KateGOriID))

CREATE TABLE Vare (
	VareID			INT IDENTITY NOT NULL 
					CONSTRAINT PK_Vare PRIMARY KEY,
	Varenavn		VARCHAR(30) NOT NULL,
	AntalPaaLager	SMALLINT NOT NULL default 0,
	VejlPris		decimal(9,2) NOT NULL,
	SubKateGOriID	SMALLINT NOT NULL 
					CONSTRAINT FK_Vare__SubKateGOri FOREIGN KEY REFERENCES SubKateGOri(SubKateGOriID))
GO
SET NOCOUNT ON
INSERT INTO FNavn VALUES ('Anne')
INSERT INTO FNavn VALUES ('Ane')
INSERT INTO FNavn VALUES ('Annemette')
INSERT INTO FNavn VALUES ('Anne Mette')
INSERT INTO FNavn VALUES ('Anne Marie')
INSERT INTO FNavn VALUES ('Anders')
INSERT INTO FNavn VALUES ('Arne')
INSERT INTO FNavn VALUES ('Arvid')
INSERT INTO FNavn VALUES ('Allan')
INSERT INTO FNavn VALUES ('Birte')
INSERT INTO FNavn VALUES ('Birthe')
INSERT INTO FNavn VALUES ('Bente')
INSERT INTO FNavn VALUES ('Bent')
INSERT INTO FNavn VALUES ('B�rge')
INSERT INTO FNavn VALUES ('Bruno')
INSERT INTO FNavn VALUES ('Carl')
INSERT INTO FNavn VALUES ('Carina')
INSERT INTO FNavn VALUES ('Christian')
INSERT INTO FNavn VALUES ('Christina')
INSERT INTO FNavn VALUES ('Dorte')
INSERT INTO FNavn VALUES ('Dorthe')
INSERT INTO FNavn VALUES ('David')
INSERT INTO FNavn VALUES ('Daniel')
INSERT INTO FNavn VALUES ('Erik')
INSERT INTO FNavn VALUES ('Eva')
INSERT INTO FNavn VALUES ('Ellen')
INSERT INTO FNavn VALUES ('Edward')
INSERT INTO FNavn VALUES ('EGOn')
INSERT INTO FNavn VALUES ('Esther')
INSERT INTO FNavn VALUES ('Ester')
INSERT INTO FNavn VALUES ('Frank')
INSERT INTO FNavn VALUES ('Frederikke')
INSERT INTO FNavn VALUES ('Frede')
INSERT INTO FNavn VALUES ('Grete')
INSERT INTO FNavn VALUES ('Grethe')
INSERT INTO FNavn VALUES ('Gert')
INSERT INTO FNavn VALUES ('Gerd')
INSERT INTO FNavn VALUES ('Gunnar')
INSERT INTO FNavn VALUES ('Gustav')
INSERT INTO FNavn VALUES ('Gudrun')
INSERT INTO FNavn VALUES ('Henrik')
INSERT INTO FNavn VALUES ('Hans')
INSERT INTO FNavn VALUES ('Hanne')
INSERT INTO FNavn VALUES ('Henriette')
INSERT INTO FNavn VALUES ('HuGO')
INSERT INTO FNavn VALUES ('Heidi')
INSERT INTO FNavn VALUES ('Helga')
INSERT INTO FNavn VALUES ('Hedvig')
INSERT INTO FNavn VALUES ('Ib')
INSERT INTO FNavn VALUES ('Ida')
INSERT INTO FNavn VALUES ('Ilse')
INSERT INTO FNavn VALUES ('Ivar')
INSERT INTO FNavn VALUES ('Ivan')
INSERT INTO FNavn VALUES ('Inger')
INSERT INTO FNavn VALUES ('Inge')
INSERT INTO FNavn VALUES ('Inga')
INSERT INTO FNavn VALUES ('Jens')
INSERT INTO FNavn VALUES ('Jakob')
INSERT INTO FNavn VALUES ('Jacob')
INSERT INTO FNavn VALUES ('Jette')
INSERT INTO FNavn VALUES ('Julie')
INSERT INTO FNavn VALUES ('Josefine')
INSERT INTO FNavn VALUES ('J�rn')
INSERT INTO FNavn VALUES ('J�rgen')
INSERT INTO FNavn VALUES ('Jane')
INSERT INTO FNavn VALUES ('Jesper')
INSERT INTO FNavn VALUES ('Karl')
INSERT INTO FNavn VALUES ('Karen')
INSERT INTO FNavn VALUES ('Karin')
INSERT INTO FNavn VALUES ('Karina')
INSERT INTO FNavn VALUES ('Kurt')
INSERT INTO FNavn VALUES ('Knud')
INSERT INTO FNavn VALUES ('Kenneth')
INSERT INTO FNavn VALUES ('Klara')
INSERT INTO FNavn VALUES ('Lars')
INSERT INTO FNavn VALUES ('Ludvig')
INSERT INTO FNavn VALUES ('Line')
INSERT INTO FNavn VALUES ('Lise')
INSERT INTO FNavn VALUES ('Lisette')
INSERT INTO FNavn VALUES ('Lene')
INSERT INTO FNavn VALUES ('Lisbeth')
INSERT INTO FNavn VALUES ('Lena')
INSERT INTO FNavn VALUES ('Morten')
INSERT INTO FNavn VALUES ('Marie')
INSERT INTO FNavn VALUES ('Mads')
INSERT INTO FNavn VALUES ('Maren')
INSERT INTO FNavn VALUES ('Malene')
INSERT INTO FNavn VALUES ('Michael')
INSERT INTO FNavn VALUES ('Mikael')
INSERT INTO FNavn VALUES ('Mikkel')
INSERT INTO FNavn VALUES ('Morten')
INSERT INTO FNavn VALUES ('Niels')
INSERT INTO FNavn VALUES ('Nette')
INSERT INTO FNavn VALUES ('Nanna')
INSERT INTO FNavn VALUES ('Ninna')
INSERT INTO FNavn VALUES ('Nora')
INSERT INTO FNavn VALUES ('Nicky')
INSERT INTO FNavn VALUES ('Ole')
INSERT INTO FNavn VALUES ('Oda')
INSERT INTO FNavn VALUES ('Olivia')
INSERT INTO FNavn VALUES ('Oskar')
INSERT INTO FNavn VALUES ('Ove')
INSERT INTO FNavn VALUES ('Oline')
INSERT INTO FNavn VALUES ('Peter')
INSERT INTO FNavn VALUES ('Per')
INSERT INTO FNavn VALUES ('Petrea')
INSERT INTO FNavn VALUES ('Peder')
INSERT INTO FNavn VALUES ('Palle')
INSERT INTO FNavn VALUES ('Poul')
INSERT INTO FNavn VALUES ('Paul')
INSERT INTO FNavn VALUES ('Poula')
INSERT INTO FNavn VALUES ('Rasmus')
INSERT INTO FNavn VALUES ('Rie')
INSERT INTO FNavn VALUES ('Rikke')
INSERT INTO FNavn VALUES ('Richard')
INSERT INTO FNavn VALUES ('Rune')
INSERT INTO FNavn VALUES ('Ruth')
INSERT INTO FNavn VALUES ('Rosa')
INSERT INTO FNavn VALUES ('Robert')
INSERT INTO FNavn VALUES ('Rositta')
INSERT INTO FNavn VALUES ('S�ren')
INSERT INTO FNavn VALUES ('Sara')
INSERT INTO FNavn VALUES ('Susanne')
INSERT INTO FNavn VALUES ('Sanne')
INSERT INTO FNavn VALUES ('Sofus')
INSERT INTO FNavn VALUES ('Solvej')
INSERT INTO FNavn VALUES ('Signe')
INSERT INTO FNavn VALUES ('Thomas')
INSERT INTO FNavn VALUES ('Tove')
INSERT INTO FNavn VALUES ('Tommy')
INSERT INTO FNavn VALUES ('Tone')
INSERT INTO FNavn VALUES ('Trine')
INSERT INTO FNavn VALUES ('Tobias')
INSERT INTO FNavn VALUES ('Uffe')
INSERT INTO FNavn VALUES ('Ulla')
INSERT INTO FNavn VALUES ('Ulrik')
INSERT INTO FNavn VALUES ('Vera')
INSERT INTO FNavn VALUES ('Villy')
INSERT INTO FNavn VALUES ('Vagn')
INSERT INTO FNavn VALUES ('Willy')
INSERT INTO FNavn VALUES ('Wagn')
INSERT INTO FNavn VALUES ('Yrsa')
INSERT INTO FNavn VALUES ('�jvind')
INSERT INTO FNavn VALUES ('�ge')
INSERT INTO FNavn VALUES ('�se')
GO
INSERT INTO ENavn VALUES ('Andersen')
INSERT INTO ENavn VALUES ('Arnesen')
INSERT INTO ENavn VALUES ('Andreasen')
INSERT INTO ENavn VALUES ('B�rgesen')
INSERT INTO ENavn VALUES ('Bentsen')
INSERT INTO ENavn VALUES ('Christensen')
INSERT INTO ENavn VALUES ('Christiansen')
INSERT INTO ENavn VALUES ('Carlsen')
INSERT INTO ENavn VALUES ('Davidsen')
INSERT INTO ENavn VALUES ('Danielsen')
INSERT INTO ENavn VALUES ('Eriksen')
INSERT INTO ENavn VALUES ('Eskildsen')
INSERT INTO ENavn VALUES ('Frandsen')
INSERT INTO ENavn VALUES ('Frederiksen')
INSERT INTO ENavn VALUES ('Gertsen')
INSERT INTO ENavn VALUES ('Henriksen')
INSERT INTO ENavn VALUES ('Hansen')
INSERT INTO ENavn VALUES ('Hansen')
INSERT INTO ENavn VALUES ('Iversen')
INSERT INTO ENavn VALUES ('Ibsen')
INSERT INTO ENavn VALUES ('Jensen')
INSERT INTO ENavn VALUES ('Jensen')
INSERT INTO ENavn VALUES ('Jensen')
INSERT INTO ENavn VALUES ('Jakobsen')
INSERT INTO ENavn VALUES ('Jacobsen')
INSERT INTO ENavn VALUES ('Karlsen')
INSERT INTO ENavn VALUES ('Knudsen')
INSERT INTO ENavn VALUES ('Kristensen')
INSERT INTO ENavn VALUES ('Larsen')
INSERT INTO ENavn VALUES ('Lassen')
INSERT INTO ENavn VALUES ('Mortensen')
INSERT INTO ENavn VALUES ('Madsen')
INSERT INTO ENavn VALUES ('Mikkelsen')
INSERT INTO ENavn VALUES ('Nielsen')
INSERT INTO ENavn VALUES ('Nielsen')
INSERT INTO ENavn VALUES ('Olsen')
INSERT INTO ENavn VALUES ('Olesen')
INSERT INTO ENavn VALUES ('Pedersen')
INSERT INTO ENavn VALUES ('Petersen')
INSERT INTO ENavn VALUES ('Petersen')
INSERT INTO ENavn VALUES ('Rasmussen')
INSERT INTO ENavn VALUES ('S�rensen')
INSERT INTO ENavn VALUES ('Thomsen')
INSERT INTO ENavn VALUES ('�vlisen')
INSERT INTO ENavn VALUES ('�gesen')
GO
INSERT INTO Gade VALUES ('N�rregade 2')
INSERT INTO Gade VALUES ('N�rregade 34')
INSERT INTO Gade VALUES ('N�rregade 27')
INSERT INTO Gade VALUES ('Vestergade 3')
INSERT INTO Gade VALUES ('Norgesgade 38')
INSERT INTO Gade VALUES ('Ungarnsgade 7')
INSERT INTO Gade VALUES ('Italiensvej 21')
INSERT INTO Gade VALUES ('Italiensvej 4')
INSERT INTO Gade VALUES ('Bragesgade 1')
INSERT INTO Gade VALUES ('Bragesgade 12')
INSERT INTO Gade VALUES ('Dortesvej 4')
INSERT INTO Gade VALUES ('Dortesvej 3')
INSERT INTO Gade VALUES ('Ellebjergvej 114')
INSERT INTO Gade VALUES ('Ellebjergvej 98')
INSERT INTO Gade VALUES ('Frankrigsgade 14')
INSERT INTO Gade VALUES ('Frankrigsgade 6')
INSERT INTO Gade VALUES ('HelGOlandsgade 54')
INSERT INTO Gade VALUES ('HelGOlandsgade 8')
INSERT INTO Gade VALUES ('K�gevej 4')
INSERT INTO Gade VALUES ('K�gevej 48')
INSERT INTO Gade VALUES ('M�llegade 3')
INSERT INTO Gade VALUES ('M�llegade 34')
INSERT INTO Gade VALUES ('Ollerupvej 3')
INSERT INTO Gade VALUES ('Sct. Pouls Gade 3')
INSERT INTO Gade VALUES ('Sct. Pouls Gade 25')
INSERT INTO Gade VALUES ('Willemoesgade 2')
INSERT INTO Gade VALUES ('Willemoesgade 23')
INSERT INTO Gade VALUES ('N�rregade 11')
INSERT INTO Gade VALUES ('N�rregade 36')
INSERT INTO Gade VALUES ('N�rregade 72')
INSERT INTO Gade VALUES ('Vesterbro 3')
INSERT INTO Gade VALUES ('Vesterbrogade 23')
INSERT INTO Gade VALUES ('Vesterbrogade 1')
INSERT INTO Gade VALUES ('M�llevej 78')
INSERT INTO Gade VALUES ('M�llevej 2')
INSERT INTO Gade VALUES ('M�llevej 4')
INSERT INTO Gade VALUES ('M�llevej 3')
INSERT INTO Gade VALUES ('Adelgade 3')
INSERT INTO Gade VALUES ('Adelgade 12')
INSERT INTO Gade VALUES ('�gade 38')
INSERT INTO Gade VALUES ('�gade 7')
INSERT INTO Gade VALUES ('�boulevarden 21')
INSERT INTO Gade VALUES ('�boulevarden 4')
INSERT INTO Gade VALUES ('�sterbro 1')
INSERT INTO Gade VALUES ('�sterbro 12')
INSERT INTO Gade VALUES ('�sterbro 4')
INSERT INTO Gade VALUES ('Horsensgade 3')
INSERT INTO Gade VALUES ('Roskildevej 114')
INSERT INTO Gade VALUES ('K�gevej 98')
INSERT INTO Gade VALUES ('Nyborgvej 14')
INSERT INTO Gade VALUES ('Nyborgvej 16')
INSERT INTO Gade VALUES ('T�ndergade 34')
INSERT INTO Gade VALUES ('T�ndergade 18')
INSERT INTO Gade VALUES ('Ribevej 14')
INSERT INTO Gade VALUES ('Thistedvej 8')
INSERT INTO Gade VALUES ('Herningvej 2')
INSERT INTO Gade VALUES ('Svendborgvej 34')
INSERT INTO Gade VALUES ('�benr�vej 4')
INSERT INTO Gade VALUES ('Vordingborgvej 13')
GO
INSERT INTO PostOpl VALUES (1127, 'K�benhavn K')
INSERT INTO PostOpl VALUES (1001, 'K�benhavn K')
INSERT INTO PostOpl VALUES (2000, 'Frederiksberg')
INSERT INTO PostOpl VALUES (8000, '�rhus C')
INSERT INTO PostOpl VALUES (8210, '�rhus V')
INSERT INTO PostOpl VALUES (8240, 'Risskov')
INSERT INTO PostOpl VALUES (8270, 'H�jbjerg')
INSERT INTO PostOpl VALUES (8310, 'Tranbjerg J')
INSERT INTO PostOpl VALUES (9000, '�lborg')
INSERT INTO PostOpl VALUES (9400, 'N�rresundby')
INSERT INTO PostOpl VALUES (9600, 'Br�nderslev')
INSERT INTO PostOpl VALUES (9800, 'Hj�rring')
INSERT INTO PostOpl VALUES (9990, 'Skagen')
INSERT INTO PostOpl VALUES (2600, 'Glostrup')
INSERT INTO PostOpl VALUES (2605, 'Br�ndby')
INSERT INTO PostOpl VALUES (2610, 'R�dovre')
INSERT INTO PostOpl VALUES (2620, 'Albertslund')
INSERT INTO PostOpl VALUES (2625, 'Vallensb�k')
INSERT INTO PostOpl VALUES (2630, 'Taastrup')
INSERT INTO PostOpl VALUES (2635, 'Ish�j')
GO
INSERT INTO Kunde (FNavn, ENavn, Gade, Postnr, KundeType)
   SELECT  FNavn, ENavn, Gade, Postnr, 'A'
      FROM FNavn INNER JOIN ENavn	ON FNavn.FNavn > ENavn.ENavn
                 INNER JOIN Gade	ON ENavn.ENavn < Gade.Gade
                 INNER JOIN Postopl ON Gade.Gade > Postopl.Bynavn
      WHERE len (Gade) < len (ENavn) + len(FNavn)

INSERT INTO Kunde (FNavn, ENavn, Gade, Postnr, KundeType)
   SELECT  FNavn, ENavn, Gade, Postnr, 'A'
      FROM FNavn INNER JOIN ENavn	ON FNavn.FNavn < ENavn.ENavn
                 INNER JOIN Gade	ON ENavn.ENavn > Gade.Gade
                 INNER JOIN Postopl ON Gade.Gade < Postopl.Bynavn
      WHERE len (Gade) > len (ENavn) + len(FNavn)

DELETE FROM kunde WHERE kundeid % 15 iN (2,4,5,7,9,11, 12, 13)
DELETE FROM kunde WHERE kundeid % 7 IN (3,5,6)
GO
INSERT INTO KundeType VALUES('A', 'Privat')
INSERT INTO KundeType VALUES('B', 'Erhverv')
INSERT INTO KundeType VALUES('C', 'Offentlig institution')
INSERT INTO KundeType VALUES('D', 'Ukendt')
GO
UPDATE Kunde
  SET KundeType = 'B'
  WHERE KundeID % 100 = 1

UPDATE Kunde
  SET KundeType = 'C'
  WHERE KundeID % 1000 = 1

UPDATE Kunde
  SET KundeType = 'D'
  WHERE KundeID % 10000 = 1
GO
DROP TABLE FNavn
DROP TABLE ENavn
DROP TABLE Gade
GO
INSERT INTO KateGOri VALUES (1, 'KateGOri 1')
INSERT INTO KateGOri VALUES (2, 'KateGOri 2')
INSERT INTO KateGOri VALUES (3, 'KateGOri 3')
INSERT INTO KateGOri VALUES (4, 'KateGOri 4')

INSERT INTO SubKateGOri VALUES (1, 'SubkateGOri 1', 1)
INSERT INTO SubKateGOri VALUES (2, 'SubkateGOri 2', 1)
INSERT INTO SubKateGOri VALUES (3, 'SubkateGOri 3', 2)
INSERT INTO SubKateGOri VALUES (4, 'SubkateGOri 4', 2)
INSERT INTO SubKateGOri VALUES (5, 'SubkateGOri 5', 2)
INSERT INTO SubKateGOri VALUES (6, 'SubkateGOri 6', 2)
INSERT INTO SubKateGOri VALUES (7, 'SubkateGOri 7', 3)
INSERT INTO SubKateGOri VALUES (8, 'SubkateGOri 8', 3)
INSERT INTO SubKateGOri VALUES (9, 'SubkateGOri 9', 4)
INSERT INTO SubKateGOri VALUES (10, 'SubkateGOri 10', 4)
INSERT INTO SubKateGOri VALUES (11, 'SubkateGOri 11', 4)
GO
INSERT INTO Vare VALUES('Vare', 234, 112.00, 1)
INSERT INTO Vare VALUES('Vare', 11, 1250.00, 2)
INSERT INTO Vare VALUES('Vare', 118, 6.00, 3)
INSERT INTO Vare VALUES('Vare', 1432, 8.25, 4)
INSERT INTO Vare VALUES('Vare', 8, 1998.00, 5)
INSERT INTO Vare VALUES('Vare', 46, 4.75, 6)
INSERT INTO Vare VALUES('Vare', 13, 9.95, 7)
INSERT INTO Vare VALUES('Vare', 98, 8.75, 8)
INSERT INTO Vare VALUES('Vare', 482, 15.00, 9)
INSERT INTO Vare VALUES('Vare', 33, 225.00, 10)
INSERT INTO Vare VALUES('Vare', 286, 2.50, 11)

DECLARE @i	INT
SET @i = 1
WHILE @i < 200
BEGIN
	INSERT INTO Vare (Varenavn, AntalPaaLager, VejlPris, SubKateGOriID)
		SELECT TOP ((SELECT COUNT(*) FROM Vare) % 34)	Varenavn, (AntalPaaLager * VareID) % 2007, 
														(VejlPris * VareID) % 426.25, SubKateGOriID
			FROM Vare
			ORDER BY NEWID()
	SET @i = @i + 1
END
UPDATE vare 
	SET Varenavn = Varenavn + ' ' + cast(VareID AS VARCHAR(10))
GO
SELECT top 27 IDENTITY(INT, 1, 1) AS MedarbejderID, FNavn, ENavn
	INTO Medarbejder
	FROM Kunde TABLESAMPLE (7 PERCENT)
	ORDER BY NEWID()
GO
SELECT	KundeID, 
		MedarbejderID, 
		VareID, 
		GETDATE() - MedarbejderID % 24 AS SalgsDato, 
		MedarbejderID % 3 + 1 AS Antal, 
		VejlPris AS Salgspris
	INTO Salg
	FROM kunde INNER JOIN medarbejder ON kundeid % 27 = medarbejderid
			   INNER JOIN vare ON vareid % medarbejderid + 3 = medarbejderid
GO
SET NOCOUNT OFF
