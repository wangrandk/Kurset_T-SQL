use master
drop database RankDb
go
create database RankDb
go
use RankDb
create table ordrelinie (
	ordreid		int not null,
	vareid		int not null,
	antal		smallint not null)
go
set nocount on
insert into ordrelinie values (1,10, 2)
insert into ordrelinie values (1,12, 1)
insert into ordrelinie values (1,12, 4)   --samme vareid flere gange inden for samme ordre
insert into ordrelinie values (1,17, 2)
insert into ordrelinie values (2,11, 5)
insert into ordrelinie values (2,11, 6)   --samme vareid flere gange inden for samme ordre
insert into ordrelinie values (2,19, 1)
insert into ordrelinie values (3,15, 2)
insert into ordrelinie values (4,12, 1)
insert into ordrelinie values (4,13, 4)
insert into ordrelinie values (4,14, 5)
insert into ordrelinie values (4,17, 3)
set nocount off
go
-- dense rank
select	*, 
		(select count(distinct vareid) 
			from ordrelinie as o2  
			where o1.ordreid = o2.ordreid and o1.vareid >= o2.vareid)  as rank 
	from ordrelinie as o1