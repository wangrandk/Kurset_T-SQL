use master
drop database ApplyDB
go
create database ApplyDB
go
use ApplyDB
create table saelger (
	saelgerid		int not null primary key identity,
	navn			varchar(30) not null)
create table salg (
	salgid			int not null primary key identity,
	kundeid			int	not null,
	salgsbeloeb		int not null,
	saelgerid		int not null foreign key references saelger(saelgerid))
go
set nocount on
insert into saelger values ('ole')
insert into saelger values ('ida')
insert into saelger values ('ane')
insert into saelger values ('per')

insert into salg values (23, 100, 1)
insert into salg values (63, 200, 1)
insert into salg values (13, 400, 1)
insert into salg values (56, 700, 1)
insert into salg values (78, 200, 1)

insert into salg values (18, 300, 2)
insert into salg values (53, 500, 2)
insert into salg values (17, 500, 2)

insert into salg values (49, 200, 4)
set nocount off
go
select saelger.*, top3kunder.kundeid, top3kunder.salgsbeloeb
	from saelger inner join
		 (select saelgerid, kundeid, salgsbeloeb
				from salg as salg_outer
				where kundeid in (select top 3 kundeid 
										from salg as salg_inner 
										where salg_inner.saelgerid = salg_outer.saelgerid 
										order by salgsbeloeb desc)) as top3kunder
		on saelger.saelgerid = top3kunder.saelgerid
go
select saelger.*, top3kunder.kundeid, top3kunder.salgsbeloeb 
	from saelger left join
		 (select saelgerid, kundeid, salgsbeloeb
				from salg as salg_outer
				where kundeid in (select top 3 kundeid 
										from salg as salg_inner 
										where salg_inner.saelgerid = salg_outer.saelgerid 
										order by salgsbeloeb desc)) as top3kunder
		on saelger.saelgerid = top3kunder.saelgerid