use master
drop database AlgebraDB
go
create database AlgebraDB
go
use AlgebraDB
create table t1 (i	int, navn	varchar(30))
create table t2 (i	int, navn	varchar(30))
go
insert into t1 values (1, 'ole')
insert into t1 values (2, 'ida')
insert into t1 values (2, 'ida')
insert into t1 values (3, 'ane')
insert into t1 values (3, 'ane')
go
insert into t2 values (3, 'ane')
insert into t2 values (3, 'ane')
insert into t2 values (4, 'per') 
go
select distinct *
	from t1
	where exists (
		select *
			from t2
			where t1.i = t2.i and t1.navn = t2.navn)
go
select distinct *
	from t1
	where not exists (
		select *
			from t2
			where t1.i = t2.i and t1.navn = t2.navn)