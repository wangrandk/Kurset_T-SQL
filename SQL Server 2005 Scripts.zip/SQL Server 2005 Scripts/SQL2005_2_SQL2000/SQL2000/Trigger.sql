use master
drop database DataManipulationsDB
go
create database DataManipulationsDB
go
use DataManipulationsDB
create table person (
	personid	int not null primary key identity,
	navn		varchar(50) not null,
	adresse		varchar(50) not null,
	postnr		smallint not null,
	initialer	varchar (3) not null
 )
go
create trigger ins_person on person
after insert
as
update person 
	set initialer = upper(initialer) 
	where personid in (select personid from inserted)
select * from inserted
go
insert into person (navn, adresse, postnr, initialer)
values('ole olsen', 'nygade', 2000, 'oo')
go
alter trigger ins_person on person
after insert
as
update person 
	set initialer = upper(initialer) 
	where personid in (select personid from inserted)
go
create trigger ins_person_output on person
after insert
as
select * 
	from person 
	where personid in (select personid from inserted)
go
exec sp_settriggerorder @triggername = 'ins_person_output', @order = 'last', @stmttype = 'INSERT'
go
insert into person (navn, adresse, postnr, initialer)
values('ane jensen', 'torvet', 2000, 'aje')


