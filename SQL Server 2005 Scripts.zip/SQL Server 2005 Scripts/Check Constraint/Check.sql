USE master
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'TestDB')
	DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
GO
USE TestDB;
CREATE TABLE Varekategori 
(
	KategoriID		INT				NOT NULL
					CONSTRAINT PK_Varekategori PRIMARY KEY,
	Kategorinavn	VARCHAR(30)		NOT NULL
);

CREATE TABLE dbo.Vare 
(
	VareID			INT				NOT NULL 
					CONSTRAINT PK_Vare PRIMARY KEY,
	Varenavn		VARCHAR(30)		NOT NULL,
	AntalPaaLager	SMALLINT		NOT NULL DEFAULT (0) 
					CONSTRAINT CK_Vare_AntalPaaLager CHECK (AntalPaaLager >= 0),
	Genbestilling	SMALLINT		NULL 
					CONSTRAINT CK_Vare_Genbestilling CHECK (Genbestilling >= 0),
	VejledendePris	DECIMAL (9,2)	NOT NULL
					CONSTRAINT CK_Vare_VejledendePris CHECK(VejledendePris >= 0),
	KategoriID		INT				NOT NULL
					CONSTRAINT FK_Vare_VareKategori FOREIGN KEY REFERENCES Varekategori(KategoriID),
	Varebeskrivelse	VARCHAR(8000)	NULL,
	VareOprettet	DATE			NOT NULL DEFAULT(SYSDATETIME()),
	VareRettet		DATE			NULL
);