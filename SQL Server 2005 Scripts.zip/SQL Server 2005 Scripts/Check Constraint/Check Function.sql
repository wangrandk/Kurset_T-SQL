USE master;
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'TestDB')
	DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
GO
USE TestDB;
GO
CREATE TABLE dbo.KategoriGraenser
(
	Kategori		CHAR(1)		NOT NULL PRIMARY KEY,
	MinVaerdi		INT			NOT NULL,
	MaxVaerdi		INT			NOT NULL,
	CONSTRAINT CK_MinVaerdi_MaxVaerdi CHECK (MinVaerdi < MaxVaerdi)
);
GO
INSERT INTO dbo.KategoriGraenser VALUES
	(1, 100, 200),
	(2, 150, 400);
GO
CREATE FUNCTION dbo.ufn_KategoriGraenser 
(
	@Kategori	CHAR(1),
	@Vaerdi		INT	
)
RETURNS SMALLINT
AS
BEGIN
	DECLARE @ReturnValue	INT;

	IF @Vaerdi BETWEEN	(SELECT MinVaerdi 
							FROM dbo.KategoriGraenser 
							WHERE Kategori = @Kategori) AND
						(SELECT MaxVaerdi 
							FROM dbo.KategoriGraenser 
							WHERE Kategori = @Kategori)
		SET @ReturnValue = 0;
	ELSE 
		SET @ReturnValue = 1;

	RETURN @ReturnValue;
END;
GO
CREATE TABLE dbo.Data
(
	Id				INT				NOT NULL PRIMARY KEY,
	Kategori		CHAR(1)			NOT NULL REFERENCES KategoriGraenser(Kategori),
	Vaerdi			INT				NOT NULL,
	CONSTRAINT CK_Vaerdi CHECK(dbo.ufn_KategoriGraenser(Kategori, Vaerdi) = 0)
);
GO
INSERT INTO dbo.Data VALUES
	(1, 1, 133),
	(2, 1, 250);
GO
DROP TABLE dbo.Data;
GO
DROP FUNCTION  dbo.ufn_KategoriGraenser ;
GO
ALTER FUNCTION dbo.ufn_KategoriGraenser 
(
	@Kategori	CHAR(1),
	@Vaerdi		INT	
)
RETURNS SMALLINT
AS
BEGIN
	DECLARE @ReturnValue	INT;

	IF @Vaerdi BETWEEN	(SELECT MinVaerdi 
							FROM dbo.KategoriGraenser 
							WHERE Kategori = @Kategori) AND
						(SELECT MaxVaerdi 
							FROM dbo.KategoriGraenser 
							WHERE Kategori = @Kategori)
		SET @ReturnValue = 0;
	ELSE 
		SET @ReturnValue = 1;

	RETURN @ReturnValue;
END;
GO
CREATE TABLE dbo.Data
(
	Id				INT				NOT NULL PRIMARY KEY,
	Kategori		CHAR(1)			NOT NULL REFERENCES KategoriGraenser(Kategori),
	Vaerdi			INT				NOT NULL
);
GO
ALTER TABLE dbo.Data
	WITH NOCHECK
	ADD CONSTRAINT CK_Vaerdi CHECK(dbo.ufn_KategoriGraenser(Kategori, Vaerdi) = 0);
GO
SELECT *
	FROM sys.objects
	WHERE type = 'FN';
