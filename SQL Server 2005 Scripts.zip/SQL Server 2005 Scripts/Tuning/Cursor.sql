use master
drop database CursorDB
go
create database CursorDB
go
use CursorDB
create table Kontering (
	Kontoid		int not null,
	Type		int not null,
	Dato		smalldatetime not null default getdate(),
	Beloeb		decimal (9,2) not null)
go
set nocount on
declare @kontoid			int
declare @type				int
declare @kontering			int
declare @antal_kontering	int

set @kontoid = 1

while @kontoid <= 10
begin
	set @type = 1
	while @type <= 5
	begin
		set @antal_kontering = datepart(ms, getdate())
		set @kontering = 0
		while @kontering <= @antal_kontering
		begin
			insert into Kontering(Kontoid, Type, Beloeb) 
					values (@kontoid, @type, @kontering)
			set @kontering = @kontering + 1 
		end
		set @type = @type + 1
	end
	set @kontoid = @kontoid + 1
end
set nocount off
go
select top 100 * from Kontering
go
select count(*), max(kontoid) 
from Kontering
go
select Kontoid, Type, count(*) 
from Kontering
group by Kontoid, Type
order by 1, 2
go
create table SumData1(
	Kontoid			int, 
	Type			int, 
	beloeb_ialt		decimal(9,2))
go
insert into SumData1
	select distinct Kontoid, Type, 0
		from Kontering
go
create proc usp_update1
@kontoid	int,
@type		int
as
update Sumdata1
	set beloeb_ialt = (select sum(beloeb)
							from Kontering
							where kontoid = @kontoid and
								  type = @type)
	where kontoid = @kontoid and
		  type = @type
go
create proc usp_cursor1
@kontoid	int,
@type		int
as
declare @beloeb_ialt    decimal(9,2)
declare @beloeb			decimal(9,2)

set @beloeb_ialt = 0

declare konteringsdata cursor
for
select beloeb
	from Kontering
	where kontoid = @kontoid and
		  type = @kontoid

open konteringsdata

fetch next from konteringsdata into @beloeb
while @@fetch_status = 0
begin
	set @beloeb_ialt = @beloeb_ialt + @beloeb
	fetch next from konteringsdata into @beloeb
end
close konteringsdata
deallocate konteringsdata

update SumData1
	set beloeb_ialt = @beloeb_ialt
	where kontoid = @kontoid and
		  type = @type
go
dbcc dropcleanbuffers
go
exec usp_update1 4,2
go
select * from sumdata1
go
dbcc dropcleanbuffers
go
exec usp_cursor1 4,2
go
select * from sumdata1
go

-------------------------------------------------------------------
create index nc_kontering_kontoid_type on kontering(kontoid, type)
go
dbcc dropcleanbuffers
go
exec usp_update1 4,2
go
select * from sumdata1
go
dbcc dropcleanbuffers
go
exec usp_cursor1 4,2
go
select * from sumdata1
go
------------------------------------------------------------------
create table SumData2(
	Kontoid			int, 
	beloeb_ialt1	decimal(9,2),
	beloeb_ialt2	decimal(9,2),
	beloeb_ialt3	decimal(9,2),
	beloeb_ialt4	decimal(9,2),
	beloeb_ialt5	decimal(9,2))

insert into SumData2
	select distinct Kontoid, 0, 0, 0, 0, 0
		from Kontering
go
create proc usp_update2
@kontoid	int
as
update Sumdata2
	set beloeb_ialt1 = (select sum(beloeb)
							from Kontering
							where kontoid = @kontoid and
								  type = 1),
		beloeb_ialt2 = (select sum(beloeb)
							from Kontering
							where kontoid = @kontoid and
								  type = 2), 
		beloeb_ialt3 = (select sum(beloeb)
							from Kontering
							where kontoid = @kontoid and
								  type = 3), 
		beloeb_ialt4 = (select sum(beloeb)
							from Kontering
							where kontoid = @kontoid and
								  type = 4), 
		beloeb_ialt5 = (select sum(beloeb)
							from Kontering
							where kontoid = @kontoid and
								  type = 5)
	where kontoid = @kontoid 
go
create proc usp_cursor2
@kontoid	int
as
declare @beloeb_ialt1   decimal(9,2)
declare @beloeb_ialt2   decimal(9,2)
declare @beloeb_ialt3   decimal(9,2)
declare @beloeb_ialt4   decimal(9,2)
declare @beloeb_ialt5   decimal(9,2)

declare @beloeb			decimal(9,2)
declare @type			int

set @beloeb_ialt1 = 0
set @beloeb_ialt2 = 0
set @beloeb_ialt3 = 0
set @beloeb_ialt4 = 0
set @beloeb_ialt5 = 0

declare konteringsdata cursor
for
select type, beloeb
	from Kontering
	where kontoid = @kontoid

open konteringsdata

fetch next from konteringsdata into @type, @beloeb
while @@fetch_status = 0
begin
	if @type = 1
		set @beloeb_ialt1 = @beloeb_ialt1 + @beloeb
	if @type = 2
		set @beloeb_ialt2 = @beloeb_ialt2 + @beloeb
	if @type = 3
		set @beloeb_ialt3 = @beloeb_ialt3 + @beloeb
	if @type = 4
		set @beloeb_ialt4 = @beloeb_ialt4 + @beloeb
	if @type = 5
		set @beloeb_ialt5 = @beloeb_ialt5 + @beloeb

	fetch next from konteringsdata into @type, @beloeb
end
close konteringsdata
deallocate konteringsdata

update SumData2
	set beloeb_ialt1 = @beloeb_ialt1,
	    beloeb_ialt2 = @beloeb_ialt2,
		beloeb_ialt3 = @beloeb_ialt3,
		beloeb_ialt4 = @beloeb_ialt4,
		beloeb_ialt5 = @beloeb_ialt5
	where kontoid = @kontoid
go
set statistics time on
dbcc dropcleanbuffers
go
exec usp_update2 4
go
select * from sumdata2
go
dbcc dropcleanbuffers
go
exec usp_cursor2 4
go
select * from sumdata2
go
set statistics time off
go
