USE master;
DROP DATABASE DMDB;
GO
CREATE DATABASE DMDB;
GO
USE DMDB;
CREATE TABLE dbo.t 
(
	i	INT
);
GO
INSERT INTO dbo.t VALUES
	(1),
	(2),
	(3),
	(4),
	(5);
GO
CREATE PROCEDURE dbo.usp_t 
AS 
SELECT * 
	FROM dbo.t;
GO
EXEC dbo.usp_t;
GO
SELECT * 
	FROM sys.dm_exec_cached_plans;
GO
DBCC FREEPROCCACHE;
GO
SELECT * 
	FROM sys.dm_exec_cached_plans
