SELECT db.name, dm.*
	FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS dm INNER JOIN master.sys.databases AS db
						ON dm.database_id = db.database_id
	ORDER BY name
