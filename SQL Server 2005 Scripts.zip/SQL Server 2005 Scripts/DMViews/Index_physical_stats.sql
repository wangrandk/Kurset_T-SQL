USE IndexDB;
GO
CREATE NONCLUSTERED INDEX nc_person_navn
		ON dbo.Person (Navn);
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL , NULL);
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , NULL);
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'DETAILED');
GO
SELECT i.name,  ps.* 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id

SELECT * 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'LIMITED');

SELECT * 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'SAMPLED');
GO
DROP INDEX person.nc_person_navn;
GO
SELECT ps.object_id, so.name, record_count, SUM(page_count) AS pagCount
	FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL ,  'DETAILED') AS ps 
    INNER JOIN sys.objects AS so on ps.object_id = so.object_id
	WHERE index_level = 0
	GROUP BY ps.object_id, so.name, record_count;
GO
CREATE INDEX nc_Person_Persontype ON dbo.Person(Persontype);

CREATE INDEX nc_Person_Persontype_Filter ON dbo.Person(Persontype)
	WHERE Persontype <> 'A';
GO
INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr,Koenkode,Landekode,Tlfnr,Persontype)
	SELECT	Fornavn,	
			Efternavn,
			Gade,
			Postnr,
			Koenkode,
			Landekode,
			Tlfnr,
			Persontype
		FROM dbo.Person
		WHERE Efternavn = 'Jensen';
