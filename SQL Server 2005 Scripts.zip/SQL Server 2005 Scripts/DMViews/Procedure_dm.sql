SELECT *
	FROM sys.procedures;

SELECT *
	FROM sys.dm_sql_referenced_entities('dbo.usp_Kunde', 'OBJECT');

SELECT *	
	FROM sys.dm_sql_referencing_entities('dbo.Kunde', 'OBJECT');

