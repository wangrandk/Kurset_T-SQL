USE IndexDB;
GO
WITH cte_tablestats 
AS
(
SELECT 
		object_id,
		SUM(CASE 
				WHEN (index_id < 2) THEN row_count 
				ELSE 0 
			END) AS Rows, -- index_id 0 = heap, 1 = clustered index
		SUM(reserved_page_count) AS Reserved,
		SUM(CASE 
				WHEN (index_id < 2) THEN (in_row_data_page_count + lob_used_page_count + row_overflow_used_page_count)
				ELSE (lob_used_page_count + row_overflow_used_page_count)
			END) AS Data,
		SUM(used_page_count) AS Used
	FROM sys.dm_db_partition_stats
	GROUP BY object_id
),
cte_internal 
AS -- numbers for XML and full text indexes
(
SELECT 
		it.parent_id,
		SUM(ps.reserved_page_count) AS Reserved,
		SUM(ps.used_page_count) AS Used
	FROM sys.dm_db_partition_stats AS ps INNER JOIN sys.internal_tables AS it ON it.object_id = ps.object_id
	WHERE it.internal_type IN (202,204) -- 202 = xml_index_nodes, 204 = fulltext_catalog_map
	GROUP BY it.parent_id
),
cte_heaps 
AS
(
SELECT	
		object_id, 
		1 AS IsHeap
	FROM sys.dm_db_partition_stats
	WHERE index_id = 0
),
cte_spacecalc 
AS
(
-- sizes are retrieved in number of pages, so they should be multiplied by 8 to get the number of kilobytes
SELECT
		a3.name AS Schemaname,
		a2.name AS Tablename,
		a1.[rows] AS Row_count,
		(a1.reserved + ISNULL(a4.reserved,0)) * 8 AS Reserved,
		a1.data * 8 AS Data,
-- index = total pages used - pages used for actual data storage
		(CASE 
			WHEN (a1.used + ISNULL(a4.used,0)) > a1.data THEN (a1.used + ISNULL(a4.used,0)) - a1.data
			ELSE 0
		END) * 8 AS index_size,

-- unused = pages reserved - total pages used

		(CASE 
			WHEN (a1.reserved + ISNULL(a4.reserved,0)) > a1.used THEN (a1.reserved + ISNULL(a4.reserved,0)) - a1.used
			ELSE 0
		END) * 8 AS Unused,
		ISNULL([IsHeap],0) AS IsHeap
	FROM  cte_tablestats AS a1	LEFT JOIN cte_internal AS a4 ON a4.parent_id = a1.object_id
								INNER JOIN sys.all_objects AS a2 ON a1.object_id = a2.object_id
								INNER JOIN sys.schemas AS a3 ON a2.schema_id = a3.schema_id
								LEFT JOIN cte_heaps AS h ON a1.object_id = h.object_id
	WHERE	a2.[type] <> N'S' AND
			a2.[type] <> N'IT'
)
SELECT
		Schemaname,
		Tablename,
		Row_count,
		Reserved,
		Data,
		Index_size,
		Unused,
		IsHeap,
		PercentageOfTotal = CONVERT(NUMERIC(15,2), Reserved/ (SELECT totalReserved = CONVERT(NUMERIC(15,2),SUM(Reserved)) 
																FROM cte_spacecalc))
	FROM cte_spacecalc
	ORDER BY Reserved DESC;
