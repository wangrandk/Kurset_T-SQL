--database_id				int				ID of database associated with the page in the buffer pool. Is nullable.
--file_id					int				ID of the file that stores the persisted image of the page. Is nullable
--page_id					int				ID of the page within the file. Is nullable.
--page_level				int				Index level of the page. Is nullable
--allocation_unit_id		bigint			ID of the allocation unit of the page. This value can be used to join sys.allocation_units. Is nullable.
--											Note   sys.dm_os_buffer_descriptors might show nonexistent values in allocation_unit_id for clustered indexes that are created in versions of SQL Server earlier than SQL Server 2005. 
--page_type					nvarchar(60)	Type of the page, such as: Data page or Index page. Is nullable. For more information, see Understanding Pages and Extents.
--row_count					int				Number of rows on the page. Is nullable.
--free_space_in_bytes		int				Amount of available free space, in bytes, on the page. Is nullable.
--is_modified				bit				1 = Page has been modified after it was read FROM the disk. Is nullable.
--numa_mode					int				Nonuniform Memory Access node for the buffer.

USE IndexDB;
GO
SELECT *
	FROM sys.dm_os_buffer_descriptors
	WHERE database_id = DB_ID()
	ORDER BY page_type;
GO
SELECT *
	FROM sys.allocation_units;
GO
SELECT *
	FROM sys.dm_os_buffer_descriptors AS bd INNER JOIN sys.allocation_units AS au ON bd.allocation_unit_id = au.allocation_unit_id
	WHERE database_id = DB_ID()
	ORDER BY page_type;
