USE IndexDB;
GO
SELECT *
	FROM sys.dm_db_file_space_usage;
