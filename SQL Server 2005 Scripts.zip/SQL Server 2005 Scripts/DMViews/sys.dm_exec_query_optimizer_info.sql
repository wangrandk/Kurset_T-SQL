SELECT *
	FROM sys.dm_exec_query_optimizer_info;