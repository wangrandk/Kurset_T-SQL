USE IndexDB;
GO
CREATE NONCLUSTERED INDEX nc_Person_Fornavn
		ON dbo.Person (Fornavn);
GO
SELECT * 
	FROM sys.dm_db_index_usage_stats;
GO
SELECT db_name() AS  database_name, object_name(object_id) AS object_name,  * 
	FROM sys.dm_db_index_usage_stats
	WHERE database_id = db_id() and object_id = object_id('Person');

SELECT * 
	FROM dbo.Person  
	WHERE Fornavn = 'fff';
SELECT * 
	FROM dbo.Person  
	WHERE Fornavn = 'kkk';
SELECT * 
	FROM dbo.Person 
	WHERE Fornavn = 'rrr';
SELECT * 
	FROM dbo.Person  
	WHERE Fornavn = 'ppp';
GO
SELECT db_name() AS database_name, OBJECT_NAME(object_id) AS object_name,  * 
	FROM sys.dm_db_index_usage_stats
	WHERE	database_id = DB_ID() AND 
			object_id = OBJECT_ID('Person');

SELECT Fornavn, COUNT(*) 
	FROM dbo.Person
	GROUP BY Fornavn;

SELECT db_name() AS  database_name, OBJECT_NAME(object_id) AS object_name,  * 
	FROM sys.dm_db_index_usage_stats
	WHERE	database_id = db_id() AND 
			object_id = OBJECT_ID('Person');
GO
UPDATE dbo.Person 
	SET Fornavn = 'Oliver' 
	WHERE Personid BETWEEN 10 AND 200;
GO
SELECT *
	FROM dbo.Person 
	WHERE Efternavn = 'Jensen Olsen';
	
SELECT db_name() AS  database_name, OBJECT_NAME(object_id) AS object_name,  * 
	FROM sys.dm_db_index_usage_stats
	WHERE	database_id = DB_ID() AND 
			object_id = OBJECT_ID('Person');
GO
--DROP INDEX Person.nc_Person_Fornavn
GO
SELECT * 
	FROM sys.indexes AS i
	WHERE NOT EXISTS (SELECT * 
						FROM sys.dm_db_index_usage_stats
						WHERE database_id = DB_ID() AND 
							  object_id = i.object_id AND 
							  index_id = i.index_id ) AND
		object_id > 100;
