SELECT *
	FROM sys.dm_os_performance_counters;
