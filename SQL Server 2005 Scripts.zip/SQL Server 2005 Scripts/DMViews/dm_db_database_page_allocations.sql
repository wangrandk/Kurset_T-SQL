USE master;
GO
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'DmvDB')
	DROP DATABASE DmvDB;
GO
CREATE DATABASE DmvDB;
GO
USE DmvDB;
GO
CREATE TABLE dbo.t 
(
	Id		INT			NOT NULL PRIMARY KEY,
	Navn	CHAR(6000)	NOT NULL
);
GO
-- Inds�t nogle r�kker i tabellen
SET NOCOUNT ON;

INSERT INTO dbo.t VALUES
	(1, 'Ole'),
	(2, 'Anders'),
	(3, 'Per'),
	(4, 'Ib'),
	(5, 'Carl'),
	(6, 'Knud'),
	(7, 'Poul'),
	(8, 'Lars'),
	(9, 'S�ren'),
	(10, 'Hans'),
	(11, 'Peter'),
	(12, 'Poul'),
	(13, 'Tom'),
	(14, 'Ludvig'),
	(15, 'Mads'),
	(16, '�ge');

SET NOCOUNT OFF;
GO
SELECT *
	FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID('dbo.t'), NULL, NULL, 'DETAILED');

SELECT *
	FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID('dbo.t'), NULL, NULL, 'LIMITED');

SELECT *
	FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID('dbo.t'), NULL, NULL, 'DETAILED')
	WHERE page_type_desc = 'DATA_PAGE';
GO
