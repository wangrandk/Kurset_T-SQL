USE IndexDB;
GO
SELECT	DB_NAME(op.database_id) AS DBName, 
		OBJECT_NAME(op.object_id) AS TableName, 
		ix.name AS IndexName, 
		op.partition_number, 

 /*Capturing page io latch*/ 
		op.page_io_latch_wait_count, 
		op.page_io_latch_wait_in_ms, 
		op.page_io_latch_wait_in_ms, 

/*Indexes associated with contention*/ 
		op.page_lock_count, 
		op.page_lock_wait_count, 
		op.page_lock_wait_in_ms, 

/*Row locks*/ 
		op.row_lock_count, 
		op.row_lock_wait_count, 
		op.row_lock_wait_in_ms, 

/*Index lock escalation*/ 
		op.index_lock_promotion_attempt_count, 
		op.index_lock_promotion_count, 
		op.leaf_allocation_count, 
		op.nonleaf_allocation_count 
	FROM sys.dm_db_index_operational_stats(DB_ID(), NULL, NULL, NULL) AS op 
							INNER JOIN sys.indexes AS ix ON ix.object_id = op.object_id AND 
															ix.index_id = op.index_id 
	ORDER BY page_lock_wait_count DESC;
