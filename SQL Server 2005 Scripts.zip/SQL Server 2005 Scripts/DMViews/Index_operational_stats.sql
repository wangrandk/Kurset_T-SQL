USE IndexDB;
GO
CREATE NONCLUSTERED INDEX nc_Person_Fornavn
		ON dbo.Person (Fornavn);

CREATE NONCLUSTERED INDEX nc_Person_Postnr
		ON dbo.Person (Postnr);

CREATE NONCLUSTERED INDEX nc_Person_Persontype
		ON dbo.Person (Persontype);
GO
SELECT * 
	FROM sys.dm_db_index_operational_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL);
GO
SELECT * 
	FROM sys.dm_db_index_operational_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL);

INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, PersonType) 
	SELECT TOP 20000 Fornavn, Efternavn, Gade, Postnr, PersonType 
		FROM dbo.Person;

UPDATE dbo.Person
	SET Fornavn = LEFT(Fornavn, 1)
	WHERE PersonID > (SELECT MAX(PersonID) FROM dbo.Person) - 20000;

UPDATE dbo.Person
	SET Persontype = 'C'
	WHERE PersonID > (SELECT MAX(PersonID) FROM dbo.Person) - 10000;

UPDATE dbo.Person
	SET Persontype = 'D',
		Postnr = Postnr
	WHERE PersonID > (SELECT MAX(PersonID) FROM dbo.Person) - 10000;

UPDATE dbo.Person
	SET Postnr = Postnr
	WHERE PersonID > (SELECT MAX(PersonID) FROM dbo.Person) - 10000;

SELECT * 
	FROM sys.dm_db_index_operational_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL );
GO
SELECT	OBJECT_NAME(op.object_id) AS ObjectName,
		i.name,
		op.leaf_insert_count,
		op.leaf_update_count,
		op.leaf_delete_count
	FROM sys.dm_db_index_operational_stats(DB_ID(), NULL, NULL, NULL) AS op INNER JOIN sys.indexes AS i
				ON op.object_id = i.object_id AND op.index_id = i.index_id
	WHERE OBJECTPROPERTYEX(op.object_id, 'IsUserTable') = 1;
GO
SELECT *
	FROM sys.indexes
	WHERE OBJECT_ID = OBJECT_ID('Person');
GO
DROP INDEX nc_person_Fornavn ON dbo.Person;
DROP INDEX nc_person_Postnr ON dbo.Person;
DROP INDEX nc_person_Persontype ON dbo.Person;	
