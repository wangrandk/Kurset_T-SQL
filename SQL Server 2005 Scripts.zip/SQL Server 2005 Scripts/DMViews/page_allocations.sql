USE master;
GO
DROP DATABASE PageDB;
GO
CREATE DATABASE PageDB;
GO
USE PageDB;
CREATE TABLE dbo.Person
(
	ID			INT				NOT NULL 
				CONSTRAINT PK_t PRIMARY KEY CLUSTERED,
	Navn		VARCHAR(30)		NOT NULL,
	Adresse		VARCHAR(30)		NOT NULL,
	Postnr		SMALLINT		NOT NULL,
	Cprnr		CHAR(10)		NOT NULL
				CONSTRAINT UQ_Person_Cprnr UNIQUE,
	Fyld		CHAR(1800)		NOT NULL DEFAULT (REPLICATE('x', 1800))
);
GO
CREATE NONCLUSTERED INDEX nc_Person__Navn ON dbo.Person(Navn) WITH FILLFACTOR = 40;
CREATE NONCLUSTERED INDEX nc_Person__Adresse ON dbo.Person(Adresse) WITH FILLFACTOR = 40;
CREATE NONCLUSTERED INDEX nc_Person__Postnr ON dbo.Person(Postnr) WITH FILLFACTOR = 40;
CREATE NONCLUSTERED INDEX nc_Person__Postnr_Adresse ON dbo.Person(Postnr, Adresse) WITH FILLFACTOR = 40;
GO
SET NOCOUNT ON;
DECLARE @i		INT = 1;

WHILE @i <= 2000
BEGIN
	INSERT INTO dbo.Person (ID, Navn, Adresse, Postnr, Cprnr) VALUES
		(	@i, 
			'Jens Olsen - ' + CAST(@i AS VARCHAR(10)),

			'Vestergade ' + CAST(@i % 18 AS VARCHAR(10)),

			100000 % DATEPART(MILLISECOND, SYSDATETIME()) + 1500,

			RIGHT('0' + CAST((DAY(SYSDATETIME()) * DATEPART(SECOND, SYSDATETIME()) % 26) + 1 AS VARCHAR(2)), 2) + 
			RIGHT('0' + CAST((MONTH(SYSDATETIME()) * DATEPART(SECOND, SYSDATETIME()) % 11) + 1 AS VARCHAR(2)), 2) +
			SUBSTRING('0' + CAST(YEAR(SYSDATETIME()) - DATEPART(SECOND, SYSDATETIME()) AS VARCHAR(4)), 3, 2) + 
			RIGHT('0000' + DATEPART(NANOSECOND, SYSDATETIME()) % 49999, 4)
		);
	
	WAITFOR DELAY '00:00:00.008';
 
	SET @i += 1;
END;

SELECT COUNT(*)
	FROM dbo.Person;
GO
SELECT	indexes.name, 
		indexes.index_id, 
		indexes.type_desc, 
		Pages.allocated_page_file_id, 
		Pages.allocated_page_page_id, 
		Pages.is_iam_page
	FROM sys.indexes INNER JOIN sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID('Person'), NULL, NULL, NULL) AS Pages
				ON	indexes.object_id = Pages.object_id AND
					indexes.index_id = Pages.index_id
	WHERE indexes.index_id = 2;
GO
DECLARE @DBID	INT = DB_ID();

DBCC PAGE(@DBID, 1, 89, 2);
DBCC PAGE(@DBID, 1, 80, 3);
DBCC PAGE(@DBID, 1, 181, 3);
GO
SELECT i.name,  ps.* 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
GO
DELETE
	FROM dbo.Person
	WHERE ID = 554
GO
INSERT INTO dbo.Person(ID, Navn, Adresse, Postnr, Cprnr)
	SELECT	554, 
			Navn,
			Adresse, 
			Postnr,
			'2704281235'
		FROM dbo.Person
		WHERE ID = 2626;

INSERT INTO dbo.Person(ID, Navn, Adresse, Postnr, Cprnr)
	SELECT	8554, 
			Navn,
			Adresse, 
			Postnr,
			'0304244332'
		FROM dbo.Person
		WHERE ID = 2626;
GO
DECLARE @DBID	INT = DB_ID();

DBCC IND (@DBID, Person, -1);
