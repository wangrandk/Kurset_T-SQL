USE IndexDB;
GO
SELECT *
	FROM sys.dm_db_missing_index_details;
GO
SELECT *
	FROM sys.dm_db_missing_index_group_stats;
GO
SELECT *
	FROM sys.dm_db_missing_index_groups;
GO
SELECT i_details.database_id, i_details.index_handle, i_details.object_id, i_col.*
	FROM sys.dm_db_missing_index_details AS i_details CROSS APPLY
		 sys.dm_db_missing_index_columns(i_details.index_handle) AS i_col;
GO
SELECT COUNT(*)
	FROM dbo.Person
	WHERE Fornavn = 'Ole';

SELECT COUNT(*)
	FROM dbo.Person
	WHERE Efternavn = 'Olsen';

SELECT COUNT(*)
	FROM dbo.Person
	WHERE	Fornavn = 'Ole' AND 
			Efternavn = 'Olsen';

SELECT  Persontype, Gade
	FROM dbo.Person
	WHERE	Fornavn = 'Ole' AND 
			Efternavn = 'Olsen';
GO
SELECT *
	FROM sys.dm_db_missing_index_details;
GO
SELECT *
	FROM sys.dm_db_missing_index_group_stats;
GO
SELECT *
	FROM sys.dm_db_missing_index_groups;
GO
SELECT db_name(i_details.database_id), i_details.index_handle, 
	   object_name(i_details.object_id), i_col.*
	FROM sys.dm_db_missing_index_details AS i_details CROSS APPLY
		 sys.dm_db_missing_index_columns(i_details.index_handle) AS i_col
	ORDER BY 1, 3, 2;
GO
SELECT	mid.index_handle,
		mid.database_id,
		mid.statement,
		mid.equality_columns,
		mid.inequality_columns,
		mid.included_columns,
		migs.user_seeks,
		migs.user_scans,
		migs.avg_total_user_cost,
		migs.avg_user_impact,
		migs.avg_total_user_cost * migs.avg_user_impact *
		(migs.user_seeks + migs.user_scans) AS potential_user_benefit
	FROM sys.dm_db_missing_index_details AS mid INNER JOIN sys.dm_db_missing_index_groups AS mig
															ON mid.index_handle = mig.index_handle
												INNER JOIN sys.dm_db_missing_index_group_stats AS migs
															ON mig.index_group_handle = migs.group_handle
	WHERE (mid.database_id = DB_ID())
GO
CREATE INDEX nc_Fornavn_Efternavn 
	ON dbo.Person(Fornavn, Efternavn);
GO
SELECT db_name(i_details.database_id), i_details.index_handle, 
	   object_name(i_details.object_id), i_col.*
	FROM sys.dm_db_missing_index_details AS i_details CROSS APPLY
		 sys.dm_db_missing_index_columns(i_details.index_handle) AS i_col
	ORDER BY 1, 3, 2;
GO
DROP INDEX nc_Fornavn_Efternavn ON dbo.Person;
GO
CREATE INDEX nc_Fornavn_Efternavn_4_8 
	ON dbo.Person(Fornavn, Efternavn) INCLUDE (Navn, Gade);
GO