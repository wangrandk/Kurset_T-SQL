USE master
DROP DATABASE MaalerDB
GO
CREATE DATABASE MaalerDB
GO
USE MaalerDB
CREATE TABLE Maalinger (
		Tid			INT IDENTITY NOT NULL,
		MaalerNr	INT NOT NULL,
		Status		INT NOT NULL)
GO
INSERT INTO Maalinger VALUES (1, 77)
INSERT INTO Maalinger VALUES (1, 77)
INSERT INTO Maalinger VALUES (1, 77)
INSERT INTO Maalinger VALUES (1, 77)
INSERT INTO Maalinger VALUES (1, 77)

INSERT INTO Maalinger VALUES (2, 83)
INSERT INTO Maalinger VALUES (2, 98)
INSERT INTO Maalinger VALUES (2, 83)
INSERT INTO Maalinger VALUES (2, 34)
INSERT INTO Maalinger VALUES (2, 56)

INSERT INTO Maalinger VALUES (3, 83)
INSERT INTO Maalinger VALUES (3, 77)
INSERT INTO Maalinger VALUES (3, 83)
INSERT INTO Maalinger VALUES (3, 34)
INSERT INTO Maalinger VALUES (3, 77)
GO
SELECT DISTINCT MaalerNr 
	FROM Maalinger
EXCEPT
SELECT Maalernr
	FROM	(SELECT DISTINCT MaalerNr 
					FROM Maalinger) AS Maaler
			CROSS APPLY 
			(SELECT *
				FROM (
				SELECT TOP 3 Status 
					FROM Maalinger 
					WHERE	Maaler.MaalerNr = Maalinger.MaalerNr
					ORDER BY Tid DESC) AS Top3Maaleinger
				GROUP BY Status
				HAVING COUNT(*) >= 1 AND Status = 77) AS t
GO
use MASTER
DROP DATABASE MaalerDB
GO
CREATE DATABASE MaalerDB
GO
USE MaalerDB
CREATE TABLE Maalinger (
		Tid			INT IDENTITY NOT NULL,
		MaalerNr	INT NOT NULL,
		Status		INT NOT NULL)
GO
INSERT INTO Maalinger VALUES (1, 77)
INSERT INTO Maalinger VALUES (1, 77)
INSERT INTO Maalinger VALUES (1, 77)
INSERT INTO Maalinger VALUES (1, 77)
INSERT INTO Maalinger VALUES (1, 77)

INSERT INTO Maalinger VALUES (2, 83)
INSERT INTO Maalinger VALUES (2, 98)
INSERT INTO Maalinger VALUES (2, 83)
INSERT INTO Maalinger VALUES (2, 83)
INSERT INTO Maalinger VALUES (2, 83)

INSERT INTO Maalinger VALUES (3, 83)
INSERT INTO Maalinger VALUES (3, 77)
INSERT INTO Maalinger VALUES (3, 83)
INSERT INTO Maalinger VALUES (3, 34)
INSERT INTO Maalinger VALUES (3, 77)
GO
SELECT Maalernr
	FROM	(SELECT DISTINCT MaalerNr 
					FROM Maalinger) AS Maaler
			CROSS APPLY 
			(SELECT *
				FROM (
				SELECT TOP 3 Status 
					FROM Maalinger 
					WHERE	Maaler.MaalerNr = Maalinger.MaalerNr
					ORDER BY Tid DESC) AS Top3Maaleinger
				GROUP BY Status
				HAVING COUNT(*) = 3 AND Status <> 77) AS t
