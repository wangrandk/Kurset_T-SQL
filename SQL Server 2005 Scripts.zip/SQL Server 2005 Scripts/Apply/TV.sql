USE master 
DROP DATABASE ApplyDB
GO
CREATE DATABASE ApplyDB
GO
USE ApplyDB
CREATE TABLE Channels (
	ChanID			INT NOT NULL PRIMARY KEY,
	ChanName		VARCHAR(10) NOT NULL)
GO
CREATE TABLE TVInfo (
	Id				INT NOT NULL PRIMARY KEY IDENTITY,
	ChanId			INT NOT NULL REFERENCES Channels (ChanID),
	StartTime		DATETIME NOT NULL,
	StopTime		DATETIME NOT NULL,
	Title			VARCHAR(50) NOT NULL)
GO
INSERT INTO Channels VALUES (1, 'DR1')
INSERT INTO Channels VALUES (2, 'DR2')
INSERT INTO Channels VALUES (3, 'TV2')

INSERT INTO TVInfo VALUES (1, '2011-11-12 18:30', '2011-11-12 19:00', 'TV Avisen')
INSERT INTO TVInfo VALUES (1, '2011-11-12 19:00', '2011-11-12 19:30', 'Aftenshowet')
INSERT INTO TVInfo VALUES (1, '2011-11-12 19:30', '2011-11-12 20:00', 'En eller anden film')
INSERT INTO TVInfo VALUES (1, '2011-11-12 20:30', '2011-11-12 21:00', 'En anden film')

INSERT INTO TVInfo VALUES (2, '2011-11-12 18:00', '2011-11-12 19:00', 'Kultur 1')
INSERT INTO TVInfo VALUES (2, '2011-11-12 19:00', '2011-11-12 20:00', 'Kultur 2')
INSERT INTO TVInfo VALUES (2, '2011-11-12 20:00', '2011-11-12 22:00', 'Valg')

INSERT INTO TVInfo VALUES (3, '2011-11-12 18:00', '2011-11-12 19:00', 'Baneg�rden')
INSERT INTO TVInfo VALUES (3, '2011-11-12 19:00', '2011-11-12 19:30', 'Nyheder p� TV2')
INSERT INTO TVInfo VALUES (3, '2011-11-12 19:30', '2011-11-12 20:00', 'Regional nyheder')
INSERT INTO TVInfo VALUES (3, '2011-11-12 20:00', '2011-11-12 21:00', 'TV Avisen')
INSERT INTO TVInfo VALUES (3, '2011-11-12 21:00', '2011-11-12 22:00', 'Nyheder med sport')
GO
SELECT * 
	FROM dbo.Channels CROSS APPLY 
			(SELECT TOP 2 * 
				FROM dbo.TVInfo
				WHERE Channels.ChanID = TVInfo.ChanID AND
					  Starttime >= '2011-11-12 19:22'  -- getdate()
				ORDER BY Starttime) AS TVInfo_Top1
GO
CREATE PROC usp_TVKig
@Top		SMALLINT = 1,
@StartTime	DATETIME = NULL
AS
IF @StartTime IS NULL
	SET @StartTime = GETDATE()
SELECT * 
FROM dbo.Channels CROSS APPLY 
			(SELECT TOP (@Top) * 
				FROM dbo.TVInfo
				WHERE Channels.ChanID = TVInfo.ChanID and
					  Starttime >= @StartTime
				ORDER BY Starttime) AS TVInfo_Top1
ORDER BY ChanName, StartTime
GO
EXEC usp_TVKig 
GO
EXEC usp_TVKig 2
GO
EXEC usp_TVKig @StartTime = '2011-11-12 19:59'
GO
EXEC usp_TVKig 2, '2011-11-12 19:59'
GO
SELECT * 
FROM dbo.Channels inner join 
		(SELECT * 
			FROM TVInfo AS TVInfo1
			WHERE Id IN (
				SELECT TOP 1 Id
					FROM TVInfo AS TVInfo2
					WHERE TVInfo1.ChanId = TVInfo2.ChanID and
							Starttime >= '2011-11-12 19:22'  -- getdate()
					ORDER BY Starttime)) AS TVInfo
	ON Channels.ChanId = TvInfo.ChanId
GO
