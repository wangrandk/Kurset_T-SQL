USE master
DROP DATABASE ApplyDB;
GO
CREATE DATABASE ApplyDB;
GO
USE ApplyDB
CREATE TABLE dbo.Saelger 
(
	Saelgerid		INT			NOT NULL 
								CONSTRAINT PK_Saelger PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	AntalTop		INT			NOT NULL
);

CREATE TABLE dbo.Salg 
(
	Salgid			INT			NOT NULL IDENTITY
								CONSTRAINT PK_Salg PRIMARY KEY,
	Kundeid			INT			NOT NULL,
	Salgsbeloeb		INT			NOT NULL,
	Saelgerid		INT			NOT NULL 
								CONSTRAINT FK_Salg_Saelger 
								FOREIGN KEY REFERENCES Saelger(Saelgerid)
);
GO
SET NOCOUNT ON;
INSERT INTO dbo.Saelger VALUES 
	(1, 'Ole Jensen', 4),
	(2, 'Ida Hansen', 3),
	(3, 'Ane S�rensen', 2),
	(4, 'Per Olsen', 2),
	(5, 'Lars Hansen', 4);

INSERT INTO dbo.Salg VALUES 
	(23, 100, 1),
	(63, 200, 1),
	(13, 400, 1),
	(56, 700, 1),
	(78, 200, 1),
	(113, 10, 1),
	(256, 70, 1),
	(378, 20, 1);

INSERT INTO dbo.Salg VALUES 
	(18, 300, 2),
	(53, 500, 2),
	(17, 500, 2),
	(14, 700, 2),
	(34, 100, 2),
	(76, 100, 2),
	(36, 100, 2),
	(59, 100, 2),
	(46, 100, 2),
	(99, 100, 2),
	(98, 100, 2);

INSERT INTO dbo.Salg VALUES 
	(49, 200, 4);

INSERT INTO dbo.Salg VALUES 
	(46, 200, 5),
	(76, 300, 5),
	(23, 800, 5);

SET NOCOUNT OFF;
GO
WITH Top3Data
AS
(
SELECT	Saelger.SaelgerId,
		Salg.KundeId,
		Salg.Salgsbeloeb 
	FROM dbo.Saelger CROSS APPLY 
						(SELECT TOP 3 kundeid, Salgsbeloeb 
							FROM dbo.Salg
							WHERE Salg.Saelgerid = Saelger.Saelgerid
							ORDER BY Salgsbeloeb DESC) AS Salg
),
IkkeTop3Data
AS
(
SELECT	Salg.SaelgerId,
		Salg.KundeId,
		Salg.Salgsbeloeb 
	FROM dbo.Salg
EXCEPT
SELECT	Top3Data.SaelgerId,
		Top3Data.KundeId,
		Top3Data.Salgsbeloeb 
	FROM Top3Data
),
Resultat
AS
(
SELECT *, 'Top3Data' AS Type
	FROM Top3Data
UNION ALL
SELECT	SaelgerID,
		(SELECT MAX(KundeID) FROM dbo.Salg) + 1 AS KundeID,
		SUM(SalgsBeloeb) AS SalgsBeloeb,
		'Sum af de ' + CAST(COUNT(*) AS VARCHAR(5)) + ' Ikke Top 3 salg'
	FROM IkkeTop3Data
	GROUP BY SaelgerID
)
SELECT	Saelger.SaelgerID,
		ISNULL(Saelger.Navn, '�vrige') AS Navn,
		Resultat.Salgsbeloeb,
		Type
	FROM Resultat LEFT JOIN dbo.Saelger ON Resultat.Saelgerid = Saelger.Saelgerid
	ORDER BY Saelger.SaelgerID, Resultat.KundeID;
