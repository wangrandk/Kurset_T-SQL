USE master
DROP DATABASE TestDB
GO
CREATE DATABASE TestDB
GO
USE TestDB
CREATE TABLE Person
(
	ID			INT NOT NULL PRIMARY KEY IDENTITY,
	Cprnr		INT NOT NULL,
	Navn		VARCHAR(20) NOT NULL
)
GO
INSERT INTO Person VALUES
	(10, 'Ole Olsen'), 
	(10, 'Ole H Olsen'),
	(10, 'Ole R Olsen'),
	(11, 'Ida Hansen'),
	(12, 'Bo'),
	(12, 'Anne'),
	(12, 'Hans'),
	(12, 'Per'),
	(12, 'Maren')
GO
SELECT *
	FROM Person
GO
SELECT Res.*
	FROM 
		(SELECT DISTINCT Cprnr	
			FROM Person
		) AS PersonCpr
		CROSS APPLY
		(SELECT TOP 1 *
			FROM Person
			WHERE Person.Cprnr = PersonCpr.Cprnr
			ORDER BY ID DESC
		) AS Res
GO
DELETE 
	FROM Person
	WHERE ID IN
		(SELECT papply.ID
			FROM
				(SELECT DISTINCT Cprnr
						FROM Person) AS pdist CROSS APPLY 
								(SELECT TOP ((SELECT COUNT(*) 
												FROM Person 
												WHERE pdist.Cprnr = Person.Cprnr) - 1) *
									FROM Person 
									WHERE pdist.Cprnr = Person.cprnr
									ORDER BY ID ASC) AS Papply)
DELETE
	FROM Person
	WHERE ID IN (
	SELECT ID
		FROM Person
	EXCEPT
	SELECT papply.ID
			FROM
				(SELECT DISTINCT Cprnr
						FROM Person) AS pdist CROSS APPLY 
								(SELECT TOP 1 *
									FROM Person 
									WHERE pdist.Cprnr = Person.cprnr
									ORDER BY ID DESC) AS Papply)

DELETE
	FROM Person
	WHERE ID NOT IN (
		SELECT papply.ID
			FROM
				(SELECT DISTINCT Cprnr
						FROM Person) AS pdist CROSS APPLY 
								(SELECT TOP 1 *
									FROM Person 
									WHERE pdist.Cprnr = Person.cprnr
									ORDER BY ID DESC) AS Papply)
				
SELECT *
	FROM Person

SELECT *
	FROM
(SELECT DISTINCT Cprnr
		FROM Person) AS pdist CROSS APPLY 
								(SELECT TOP (1) *
									FROM Person 
									WHERE pdist.Cprnr = Person.Cprnr
									ORDER BY ID DESC) AS s