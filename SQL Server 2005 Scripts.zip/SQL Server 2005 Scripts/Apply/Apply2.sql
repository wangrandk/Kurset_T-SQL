USE master;
DROP DATABASE ApplyDB;
GO
CREATE DATABASE ApplyDB;
GO
USE ApplyDB
CREATE TABLE dbo.Saelger 
(
	Saelgerid		INT NOT NULL PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	AntalTop		INT NOT NULL
);

CREATE TABLE dbo.Salg 
(
	Salgid			INT NOT NULL PRIMARY KEY IDENTITY,
	Kundeid			INT	NOT NULL,
	Salgsbeloeb		INT NOT NULL,
	Aar				SMALLINT,
	Saelgerid		INT NOT NULL FOREIGN KEY REFERENCES Saelger(Saelgerid)
);
GO
SET NOCOUNT ON
INSERT INTO dbo.Saelger VALUES 
	(1, 'Ole Jensen', 2),
	(2, 'Ida Larsen', 3),
	(3, 'Ane Hansen', 2),
	(4, 'Per Thomsen', 4),
	(5, 'Hanne Knudsen', 3);

INSERT INTO dbo.Salg VALUES 
	(23, 100, 2012, 1),
	(63, 200, 2012, 1),
	(13, 400, 2012, 1),
	(56, 700, 2012, 1),
	(78, 200, 2012, 1);

INSERT INTO dbo.Salg VALUES 
	(18, 300, 2012, 2),
	(53, 500, 2012, 2),
	(17, 500, 2012, 2),
	(14, 700, 2012, 2);

INSERT INTO dbo.Salg VALUES 
	(49, 200, 2012, 4);

INSERT INTO dbo.Salg VALUES 
	(23, 100, 2013, 1),
	(65, 700, 2013, 1),
	(13, 400, 2013, 1),
	(56, 700, 2013, 1);

INSERT INTO dbo.Salg VALUES 
	(18, 300, 2013, 2),
	(53, 500, 2013, 2),
	(19, 800, 2013, 2),
	(14, 700, 2013, 2);

INSERT INTO dbo.Salg VALUES 
	(49, 200, 2013, 4),
	(54, 300, 2013, 4);

INSERT INTO dbo.Salg VALUES 
	(12, 400, 2013, 5),
	(17, 300, 2013, 5),
	(19, 500, 2013, 5),
	(20, 100, 2013, 5);

SET NOCOUNT OFF
GO
CREATE FUNCTION dbo.ufn_top3kunder (@Saelgerid INT)
RETURNS TABLE 
AS
	RETURN SELECT	Applydata.Saelgerid,
					Applydata.Kundeid,
					Applydata.Salgsbeloeb,
					AarData.Aar
				FROM 
					(SELECT DISTINCT Aar 
							FROM dbo.Salg) AS AarData
						CROSS APPLY
							(SELECT TOP 3 *
								FROM dbo.Salg
								WHERE	Salg.Saelgerid = @Saelgerid AND
										Salg.Aar = Aardata.Aar
								ORDER BY  Salgsbeloeb DESC)  AS Applydata;
GO
SELECT * 
	FROM dbo.ufn_top3kunder(1);
GO
SELECT	Saelger.Navn, 
		Topsalg.* 
	FROM dbo.Saelger CROSS APPLY dbo.ufn_top3kunder (Saelger.Saelgerid) AS topSalg
	ORDER BY Saelgerid, Aar, Salgsbeloeb;
GO
SELECT	Saelger.Navn, 
		Topsalg.* 
	FROM dbo.Saelger OUTER APPLY dbo.ufn_top3kunder (Saelger.Saelgerid) AS topSalg
	ORDER BY Saelgerid, Aar, Salgsbeloeb;
GO
GO
SELECT	Saelger.Navn, 
		Topsalg.* 
	FROM dbo.Saelger OUTER APPLY (SELECT	Applydata.Saelgerid,
											Applydata.Kundeid,
											Applydata.Salgsbeloeb,
											AarData.Aar
									FROM 
										(SELECT DISTINCT Aar 
												FROM dbo.Salg) AS AarData
											CROSS APPLY
												(SELECT TOP 3 *
													FROM dbo.Salg
													WHERE	Salg.Saelgerid = Saelger.Saelgerid AND
															Salg.Aar = Aardata.Aar
													ORDER BY  Salgsbeloeb DESC) AS Applydata) AS topSalg
	ORDER BY Saelgerid, Aar, Salgsbeloeb;