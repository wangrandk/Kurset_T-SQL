USE master;
DROP DATABASE DistinctDB;
GO
CREATE DATABASE DistinctDB;
GO
USE DistinctDB;
CREATE TABLE dbo.Person 
(
	PersonID		INT NOT NULL PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	Gade			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL
);
GO
INSERT INTO dbo.Person VALUES 
	(1, 'Jens', 'Olsen', 'Nygade 3', 8000),
	(2, 'Jens', 'Olsen', 'Nygade 3 2. tv.', 8000),
	(3, 'Ida', 'Larsen', 'Vestergade 6', 2000),
	(4, 'Lars', 'Knudsen', 'Torvet 13', 9000),
	(5, 'Hanne', 'Carlsen', 'S�ndergade 7', 2000),
	(6, 'Hanne', 'Carlsen', 'S�ndergade 7 1. th', 2000),
	(7, 'Hanne', 'Carlsen', 'S�ndergade 7', 2000),
	(8, 'Tina', 'Knudsen', 'Torvet 13', 9000);
GO
SELECT DISTINCT *
	FROM dbo.Person;
GO
CREATE INDEX nc_Person__Postnr_Fornavn_Efternavn ON Person(Postnr, Fornavn, Efternavn);
GO
SELECT DISTINCT Fornavn,
				Efternavn,
				Gade,
				Postnr
	FROM dbo.Person;
GO
SELECT Data.*
	FROM (
		SELECT DISTINCT Postnr, Fornavn, Efternavn
			FROM dbo.Person) AS DistinctData CROSS APPLY 
					(SELECT TOP 1 *
						FROM dbo.Person
						WHERE Person.Postnr = DistinctData.Postnr AND
							  Person.Fornavn = DistinctData.Fornavn AND
							  Person.Efternavn = DistinctData.Efternavn
						ORDER BY PersonID DESC) AS Data
	ORDER BY Postnr, Fornavn, Efternavn;
GO
SELECT *
	FROM dbo.Person 
EXCEPT 
SELECT Data.*
	FROM (
		SELECT DISTINCT Postnr, Fornavn, Efternavn
			FROM dbo.Person) AS DistinctData CROSS APPLY 
					(SELECT TOP 1 *
						FROM dbo.Person
						WHERE Person.Postnr = DistinctData.Postnr AND
							  Person.Fornavn = DistinctData.Fornavn AND
							  Person.Efternavn = DistinctData.Efternavn
							  ORDER BY PersonID DESC) AS Data;
