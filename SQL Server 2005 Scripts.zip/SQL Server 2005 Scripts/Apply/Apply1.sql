USE master;
GO
DROP DATABASE ApplyDB;
GO
CREATE DATABASE ApplyDB;
GO
USE ApplyDB;
CREATE TABLE dbo.Salgsdata 
(
	ID				INT NOT NULL PRIMARY KEY IDENTITY,
	Dato			DATE NOT NULL,
	Totalsalg		INT	NOT NULL
);
CREATE TABLE dbo.Maaneder
(
	Maanedsnr		SMALLINT NOT NULL PRIMARY KEY,
	Maanedsnavn		VARCHAR(20) NOT NULL UNIQUE
);
CREATE TABLE dbo.Perioder
(
	Periodenr		SMALLINT NOT NULL PRIMARY KEY,
	Periodenavn		VARCHAR(20) NOT NULL UNIQUE
);
CREATE TABLE dbo.PeriodeMaaned
(
	Periodenr		SMALLINT NOT NULL,
	Maanedsnr		SMALLINT NOT NULL,
	CONSTRAINT pk_PeriodeMaaned PRIMARY KEY (Periodenr, Maanedsnr)
);
GO
DECLARE @Aar		SMALLINT;
DECLARE @Startdato	DATE;
DECLARE @Slutdato	DATE;

SET @Aar = YEAR(SYSDATETIME()) - 1;
SET @Startdato  = DATEFROMPARTS(@Aar, 1, 1);
SET @Slutdato  = DATEFROMPARTS(@Aar, 12, 31);

WITH DanSalgsdata (Dato, Salgsbeloeb)
AS
(
SELECT	@Startdato AS Dato,
		(DATEPART(MICROSECOND, SYSDATETIME())) % 213
UNION ALL
SELECT	DATEADD(DAY, 1, Dato),
		(DATEPART(MICROSECOND, SYSDATETIME())) % (DAY(Dato) * MONTH(Dato))
	FROM DanSalgsdata
	WHERE Dato < @Slutdato
)
INSERT INTO dbo.Salgsdata
	SELECT *
		FROM DanSalgsdata
		OPTION(MAXRECURSION 400);

INSERT INTO dbo.Maaneder VALUES
	(1, 'Januar'),
	(2, 'Februar'),
	(3, 'Marts'),
	(4, 'April'),
	(5 , 'Maj'),
	(6, 'Juni'),
	(7, 'Juli'),
	(8, 'August'),
	(9, 'September'),
	(10 , 'Oktober'),
	(11 , 'November'),
	(12 , 'December')
GO
INSERT INTO dbo.Perioder VALUES 
	(1, 'Vinter incl. jul'),
	(2, 'Vinter excl. jul'),
	(3, 'Jul'),
	(4,	'For�r'),
	(5, 'Efter�r'),
	(6, 'For�r og efter�r'),
	(7, 'Sommer'),
	(8, 'Hele �ret')

INSERT INTO dbo.PeriodeMaaned VALUES 
	(1, 11), (1, 12), (1, 1), (1, 2),
	(2, 11), (2, 1), (2, 2),
	(3, 12),
	(4, 3), (4, 4), (4, 5),
	(5, 9), (5, 10),
	(6, 3), (6, 4), (6, 5), (6, 9), (6, 10),
	(7, 6), (7, 7), (7, 8),
	(8, 1), (8, 2), (8, 3), (8, 4), (8, 5), (8, 6),
	(8, 7), (8, 8), (8, 9), (8, 10), (8, 11), (8, 12);
GO
SELECT *
	FROM dbo.Perioder CROSS APPLY
			(SELECT TOP 3 *
				FROM dbo.Salgsdata INNER JOIN dbo.PeriodeMaaned 
						ON	MONTH(Salgsdata.Dato) = PeriodeMaaned.Maanedsnr AND
							Perioder.Periodenr = PeriodeMaaned.Periodenr
				ORDER BY Totalsalg DESC) AS Top3Periodesalg
	ORDER BY Perioder.Periodenr, Top3Periodesalg.Totalsalg DESC;
