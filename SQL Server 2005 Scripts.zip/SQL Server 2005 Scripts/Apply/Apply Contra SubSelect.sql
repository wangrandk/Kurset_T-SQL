USE master
DROP DATABASE ApplyDB
GO
CREATE DATABASE ApplyDB
GO
USE ApplyDB
CREATE TABLE Kunde (
	KundeID		INT NOT NULL PRIMARY KEY)
	
CREATE TABLE KundeKoeb (
	ID			INT NOT NULL PRIMARY KEY IDENTITY,
	KundeID		INT NOT NULL REFERENCES Kunde,
	OrdreID		INT NOT NULL UNIQUE,
	Dato		DATE NOT NULL,
	Beloeb		INT NOT NULL)
GO
INSERT INTO Kunde VALUES
	(1),
	(2),
	(3)

INSERT INTO KundeKoeb(KundeID, OrdreID, Dato, Beloeb) VALUES
	(1, 234, '2009-5-7', 200),
	(1, 217, '2009-5-7', 300),
	(1, 114, '2009-5-6', 400),
	(1, 789, '2009-5-7', 250),
	(2, 433, '2009-5-6', 200),
	(2, 123, '2009-5-7', 500),
	(2, 765, '2009-5-8', 300),
	(3, 211, '2009-5-8', 100),
	(3, 198, '2009-5-7', 400),
	(3, 139, '2009-5-6', 200)
GO
SELECT Kunde.KundeID,
	(SELECT TOP 1 OrdreID
		FROM KundeKoeb
		WHERE Kunde.KundeID = KundeKoeb.KundeID
		ORDER BY Dato DESC) AS OrdreID,
	(SELECT TOP 1 Beloeb
		FROM KundeKoeb
		WHERE Kunde.KundeID = KundeKoeb.KundeID
		ORDER BY Dato DESC) AS Beloeb,
	(SELECT MAX(Dato)
		FROM KundeKoeb
		WHERE Kunde.KundeID = KundeKoeb.KundeID) AS Dato
	FROM Kunde
GO
CREATE INDEX IX_KundeKoeb__Dato_OrdreID ON KundeKoeb(Dato, OrdreID)
CREATE INDEX IX_KundeKoeb__Dato_Beloeb ON KundeKoeb(Dato, Beloeb)
GO
SELECT Kunde.KundeID,
	(SELECT TOP 1 OrdreID
		FROM KundeKoeb
		WHERE Kunde.KundeID = KundeKoeb.KundeID
		ORDER BY Dato DESC) AS OrdreID,
	(SELECT TOP 1 Beloeb
		FROM KundeKoeb
		WHERE Kunde.KundeID = KundeKoeb.KundeID
		ORDER BY Dato DESC) AS Beloeb,
	(SELECT MAX(Dato)
		FROM KundeKoeb
		WHERE Kunde.KundeID = KundeKoeb.KundeID) AS Dato
	FROM Kunde
GO
SELECT *
	FROM Kunde CROSS APPLY (SELECT TOP 1 OrdreID, Beloeb, Dato
								FROM KundeKoeb
								WHERE Kunde.KundeID = KundeKoeb.KundeID
								ORDER BY Dato DESC) AS KundeKoeb
GO
