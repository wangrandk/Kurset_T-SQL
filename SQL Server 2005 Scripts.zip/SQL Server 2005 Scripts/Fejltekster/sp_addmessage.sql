USE master;
GO
EXEC sp_addmessage 
	@msgnum = 60010, 
	@severity = 16, 
	@msgtext = N'xxxxxxxxxx %s yyyyyyy %i zzzzzzz', 
	@lang = 'us_english',
	@replace =  'replace';

EXEC sp_addmessage 
	@msgnum = 60010, 
	@severity = 16, 
	@msgtext = N'aaaaaaaaaaaaaaaa %2! bbbbbbbbbb %1!', 
	@lang = 'danish',
	@replace =  'replace';
GO
SET LANGUAGE 'us_english';
RAISERROR (60010, 16, 1, 'Error', 247);
GO
SET LANGUAGE 'danish';
RAISERROR (60010, 16, 1, 'fejl', 247);
GO
EXEC sp_dropmessage @msgnum = 60010, @lang = 'danish';
EXEC sp_dropmessage @msgnum = 60010, @lang = 'us_english';
GO
EXEC sp_addmessage 
	@msgnum = 60000, 
	@severity = 16, 
	@msgtext = N'Zipcode %s already exists', 
	@lang = 'us_english',
	@replace =  'replace';

EXEC sp_addmessage 
	@msgnum = 60000, 
	@severity = 16, 
	@msgtext = N'Postnr %1! forekommer allerede', 
	@lang = 'danish',
	@replace =  'replace';
GO
SET LANGUAGE 'us_english';
RAISERROR (60000, 16, 1, '90210');
GO
SET LANGUAGE 'danish';
RAISERROR (60000, 16, 1, '90210');
GO
SET LANGUAGE 'swedish';
RAISERROR (60000, 16, 1, '90210');
GO
RAISERROR (60000, 16, 1, '3000') WITH LOG;
GO
SET LANGUAGE 'us_english'; 
RAISERROR (60000, 16, 1);
GO
USE master;
GO
EXEC sp_addmessage 
	@msgnum = 60001, 
	@severity = 16, 
	@msgtext = N'Zipcode %s already exists', 
	@with_log = 'true',
	@lang = 'us_english',
	@replace =  'replace';
GO
RAISERROR (60001, 16, 1, '44800');
RAISERROR (60001, 16, 3, '44800');
GO
RAISERROR (60001);					-- fejl, severity og state skal angives
RAISERROR (60001,,2);				-- fejl, severity skal angives
RAISERROR (60001, -1, 3, '44800');	-- den definerede severity returneres
RAISERROR (60001, -1, 289, '44800'); -- n� (289 - 256 = 33)
RAISERROR (60001, 10, 3, '44800');
RAISERROR (60001, 10, 3, '44800', 23, 45, 56);
GO
RAISERROR ('Der er fejl', 16, 1);
RAISERROR ('Der er fejl pga. %s', 16, 1, 'forkert parameter');
GO
DECLARE @Fejltxt  VARCHAR(255) = 'Der er fejl pga. %s';

RAISERROR (@Fejltxt, 16, 1, 'forkert parameter');
GO
SELECT  TOP 20 * 
	FROM sys.messages 
	ORDER BY 1 DESC;
GO
SELECT * 
	FROM sys.messages 
	WHERE message_id = 1205; -- deadlock
GO
EXEC sp_dropmessage @msgnum = 60000, @lang = 'danish';
EXEC sp_dropmessage @msgnum = 60000, @lang = 'us_english';
EXEC sp_dropmessage @msgnum = 60001, @lang = 'us_english';
GO
RAISERROR ('Der er  fejl', 16, 1);
