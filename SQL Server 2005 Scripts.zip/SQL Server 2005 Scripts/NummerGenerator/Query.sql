use master
drop database NumDB
go
create database NumDB
go
use NumDB
go
create function ufn_nums (@ant int)
returns table
as
return
	with 
	l0 as (select 1 as c union all select 1),
	l1 as (select 1 as c from l0 as t1, l0 as t2),
	l2 as (select 1 as c from l1 as t1, l1 as t2),
	l3 as (select 1 as c from l2 as t1, l2 as t2),
	l4 as (select 1 as c from l3 as t1, l3 as t2),
	l5 as (select 1 as c from l4 as t1, l4 as t2),
		
	nums as (select row_number() over(order by c) as n from l5)
	select * from nums where n <= @ant
go
create function ufn_nums2 (@ant	int)
returns @t table (i	int)
as
begin
declare @i	int
set @i = 1
while @i <= @ant
begin
	insert into @t values (@i)
	set @i = @i + 1
end
return
end
go
set statistics time on
select * from ufn_nums(20000)

select * from ufn_nums2(20000)
set statistics time off
