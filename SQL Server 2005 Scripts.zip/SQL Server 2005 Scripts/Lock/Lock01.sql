USE master
DROP DATABASE LockDB
GO
CREATE DATABASE LockDB
ON PRIMARY 
	(NAME = LockDB_file_1,
	 FILENAME = N'c:\databaser\LockDB.mdf',
	 SIZE = 100MB,
	 MAXSIZE = 600MB,
	 FILEGROWTH = 10%)

LOG ON 
	(NAME = LockDB_log_file_1,
	 FILENAME = N'c:\databaser\LockDB_log.ldf',
	 SIZE = 100MB,
	 MAXSIZE = 400MB,
	 FILEGROWTH = 10%)
GO
USE LockDB
CREATE TABLE t (
	id		INT NOT NULL PRIMARY KEY NONCLUSTERED WITH ( ALLOW_PAGE_LOCKS = OFF),
	data	CHAR(790) NOT NULL DEFAULT (REPLICATE('x', 790)))
GO
SET NOCOUNT ON
DECLARE @i INT
SET @i = 1
WHILE @i <= 10000
BEGIN 
	INSERT INTO t (id) VALUES(@i)
	SET @i = @i + 1
END
SET NOCOUNT OFF
GO
SELECT * 
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('t'), NULL, NULL , 'DETAILED');
GO
SELECT * 
	FROM sys.dm_tran_locks 
	WHERE resource_database_id = DB_ID()
GO
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRANSACTION

SELECT  * 
	FROM t 
	WHERE id % 10 = 1

SELECT * 
	FROM sys.dm_tran_locks 
	WHERE resource_database_id = DB_ID()
	ORDER BY 4

SELECT  * 
	FROM t 
	WHERE id % 10 = 3

SELECT * 
	FROM sys.dm_tran_locks WHERE resource_database_id = DB_ID()
	ORDER BY 4


SELECT  * 
	FROM t 
	WHERE id % 10 = 5

SELECT * 
	FROM sys.dm_tran_locks 
	WHERE resource_database_id = DB_ID()
	ORDER BY 4

SELECT  * 
	FROM t 
	WHERE id % 10 = 7

SELECT * 
	FROM sys.dm_tran_locks 
	WHERE resource_database_id = DB_ID()
	ORDER BY 4

SELECT  * 
	FROM t 
	WHERE id % 10 = 9

SELECT * 
	FROM sys.dm_tran_locks 
	WHERE resource_database_id = DB_ID()
	ORDER BY 4
--------------------------------------------------------------

SELECT * 
	FROM t 
	WHERE id % 10 in (2,4,6,8,0)

SELECT * 
	FROM sys.dm_tran_locks 
	WHERE resource_database_id = DB_ID()
	ORDER BY 4

COMMIT TRANSACTION
GO
--------------------------------------------------------------
BEGIN TRANSACTION

SELECT  * 
	FROM t 
	WHERE id % 10 in (1,3,5,7,9)

SELECT * 
	FROM t 
	WHERE id % 10 = 0

SELECT * 
	FROM sys.dm_tran_locks 
	WHERE resource_database_id = DB_ID()
	ORDER BY 4

SELECT  * 
	FROM t 
	WHERE id % 10 in (2,4)

SELECT * 
	FROM sys.dm_tran_locks 
	WHERE resource_database_id = DB_ID()
	ORDER BY 4

COMMIT TRANSACTION
---------------------------------------------------------------
BEGIN TRANSACTION

SELECT  * 
	FROM t 
	WHERE id % 10 in (1,3,5,7,9) and id <= 4000

SELECT  * 
	FROM t 
	WHERE id % 10 in (2,4) and id <= 4000

SELECT  * 
	FROM t 
	WHERE id % 10 in (6,8,0) and id <= 4000

SELECT * 
	FROM sys.dm_tran_locks 
	WHERE resource_database_id = DB_ID()
	ORDER BY 4

SELECT * 
	FROM t 
	WHERE id <= 4000

SELECT * 
	FROM sys.dm_tran_locks 
	WHERE resource_database_id = DB_ID()
	ORDER BY 4

SELECT COUNT(*) 
	FROM sys.dm_tran_locks 
	WHERE resource_database_id = DB_ID() and
      resource_type = 'PAGE' and request_mode = 'IS'

COMMIT TRANSACTION
GO
