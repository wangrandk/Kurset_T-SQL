USE master
DROP DATABASE FraktilDB
GO
CREATE DATABASE FraktilDB
GO
USE FraktilDB
CREATE TABLE t (
	ID			INT NOT NULL PRIMARY KEY IDENTITY,
	v			INT NOT NULL)
GO
DELETE FROM t
INSERT INTO t(v) VALUES
	(1),(2),(3),(4),(5),(6),(7),(8),(9)
GO
--test2
DELETE FROM t
INSERT INTO t(v) VALUES
	(1),(1),(1),(1),(1),(1),(1),(1),(1), (1) -- 10 r�kker
GO
--test 3 
DELETE FROM t
DECLARE @i		INT = 1
WHILE @i <= 10000
BEGIN
	INSERT INTO t VALUES (DATEPART(mcs, SYSDATETIME())/100)
	SET @i += 1
END
CREATE INDEX nc_t_v ON t(v)
GO
SELECT TOP 100 *
	FROM t
GO
--SELECT v, RANK() OVER(PARTITION BY (SELECT 0) ORDER BY v) AS v_Rank
--	FROM t
--GO
--WITH 
--t_Rank
--AS
--(SELECT v,
--		ROW_NUMBER() OVER(PARTITION BY (SELECT 0) ORDER BY v) AS v_RowNumber,
--		RANK() OVER(PARTITION BY (SELECT 0) ORDER BY v) AS v_Rank
--	FROM t),
--t_Rank_SUM
--AS
--(SELECT SUM(v_Rank) AS Rank_Sum
--	FROM t_Rank)
--SELECT v, CAST((SELECT SUM(v_Rank)
--					FROM t_Rank 
--					WHERE v_RowNumber <= t_Ydre.v_RowNumber) AS DECIMAL(19, 15)) /
--		(SELECT Rank_Sum FROM t_Rank_Sum) AS v_Procent
--	FROM t_Rank AS t_Ydre
--GO
--DECLARE @Fraktil DECIMAL(5,2) = 50.0;
--WITH 
--t_Rank
--AS
--(SELECT v,
--		ROW_NUMBER() OVER(PARTITION BY (SELECT 0) ORDER BY v) AS v_RowNumber,
--		RANK() OVER(PARTITION BY (SELECT 0) ORDER BY v) AS v_Rank
--	FROM t),
--t_Rank_SUM
--AS
--(SELECT SUM(v_Rank) AS Rank_Sum
--	FROM t_Rank),
--t_Procent
--AS
--(SELECT v, (CAST((SELECT SUM(v_Rank)
--					FROM t_Rank 
--					WHERE v_RowNumber <= t_Ydre.v_RowNumber) AS DECIMAL(19, 15)) /
--		(SELECT Rank_Sum FROM t_Rank_Sum)) * 100 AS v_Procent
--	FROM t_Rank AS t_Ydre)

--SELECT (SELECT v 
--			FROM t_Procent
--			WHERE v_Procent = (SELECT MAX(v_Procent) 
--									FROM t_Procent
--									WHERE v_Procent <= @Fraktil)) AS v_Min,
--		(SELECT v 
--			FROM t_Procent
--			WHERE v_Procent = (SELECT MIN(v_Procent) 
--									FROM t_Procent
--									WHERE v_Procent >= @Fraktil)) AS v_Max,
--		(SELECT MAX(v_Procent) 
--			FROM t_Procent
--			WHERE v_Procent <= @Fraktil),
		
--		(SELECT MIN(v_Procent) 
--			FROM t_Procent
--			WHERE v_Procent >= @Fraktil)	
--GO
DECLARE @Fraktil DECIMAL(19,9) = 50.0;
WITH 
t_Rank
AS
(SELECT v,
		ROW_NUMBER() OVER(PARTITION BY (SELECT 0) ORDER BY v) AS v_RowNumber
	FROM t),
t_Rank_SUM
AS
(SELECT SUM(v) AS Rank_Sum
	FROM t_Rank),
t_Procent
AS
(SELECT v, (CAST((SELECT SUM(v)
					FROM t_Rank 
					WHERE v_RowNumber <= t_Ydre.v_RowNumber) AS DECIMAL(19, 9)) /
		   (SELECT Rank_Sum FROM t_Rank_Sum)) * 100 AS v_Procent
	FROM t_Rank AS t_Ydre)

SELECT (SELECT v 
			FROM t_Procent
			WHERE v_Procent = (SELECT MAX(v_Procent) 
									FROM t_Procent
									WHERE v_Procent <= @Fraktil)) +
		(
		(SELECT v 
			FROM t_Procent
			WHERE v_Procent = (SELECT MIN(v_Procent) 
									FROM t_Procent
									WHERE v_Procent >= @Fraktil)) -
		(SELECT v 
			FROM t_Procent
			WHERE v_Procent = (SELECT MAX(v_Procent) 
									FROM t_Procent
									WHERE v_Procent <= @Fraktil))
		)
		/
		(
		CASE				-- Hvis nedre v�rdi rammer fraktil
		WHEN @Fraktil <> (SELECT MAX(v_Procent) 
							FROM t_Procent
							WHERE v_Procent <= @Fraktil)
		THEN
			((SELECT MIN(v_Procent) 
				FROM t_Procent
				WHERE v_Procent >= @Fraktil) -
			(SELECT MAX(v_Procent) 
				FROM t_Procent
				WHERE v_Procent <= @Fraktil)) /
			(@Fraktil -
			(SELECT MAX(v_Procent) 
				FROM t_Procent
				WHERE v_Procent <= @Fraktil))
		ELSE 
			1
		END
		)
