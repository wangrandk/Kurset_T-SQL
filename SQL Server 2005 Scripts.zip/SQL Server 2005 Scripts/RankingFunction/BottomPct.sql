USE FraktilDB
GO
DECLARE @BottomPct DECIMAL(19,9) = 50.0;
WITH 
t_rownumber
AS
(SELECT v,
		ROW_NUMBER() OVER(ORDER BY v) AS v_RowNumber
	FROM t),
t_Pct
AS
(SELECT	t1.v, t1.v_RowNumber,  
		(CAST(SUM(t2.v) AS DECIMAL(19, 9))/(SELECT SUM(v) FROM t_rownumber)) * 100 AS v_Pct
	FROM t_rownumber AS t1 INNER JOIN t_rownumber AS t2 ON t1.v_RowNumber >= t2.v_RowNumber	
	GROUP BY t1.v, t1.v_RowNumber),
BottomRows
AS
(SELECT *
	FROM t_Pct
	WHERE v_RowNumber <= (SELECT MIN(v_RowNumber) FROM t_Pct WHERE v_Pct >= @BottomPct))
SELECT v
	FROM BottomRows
