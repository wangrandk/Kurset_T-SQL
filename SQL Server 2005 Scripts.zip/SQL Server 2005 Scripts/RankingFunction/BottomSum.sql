USE FraktilDB
GO
DECLARE @BottomSum DECIMAL(19,9) = 8;
WITH 
t_rownumber
AS
(SELECT v,
		ROW_NUMBER() OVER(ORDER BY v) AS v_RowNumber
	FROM t),
t_RunningValue
AS
(SELECT	t1.v, t1.v_RowNumber,  
		CAST(SUM(t2.v) AS DECIMAL(19, 9)) AS v_RunningValue
	FROM t_rownumber AS t1 INNER JOIN t_rownumber AS t2 ON t1.v_RowNumber >= t2.v_RowNumber	
	GROUP BY t1.v, t1.v_RowNumber),
BottomRows
AS
(SELECT *
	FROM t_RunningValue
	WHERE v_RowNumber <= (SELECT MIN(v_RowNumber) FROM t_RunningValue WHERE v_RunningValue >= @BottomSum))
SELECT *
	FROM BottomRows
