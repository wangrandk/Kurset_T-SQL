USE TransaktionDB;

-- REPEATABLE READ
SET TRANSACTION ISOLATION LEVEL 
	READ COMMITTED;

SELECT * 
	FROM dbo.Person

SET IDENTITY_INSERT dbo.Person ON;

INSERT INTO dbo.Person (id,Navn) 
	VALUES (12,'ib')

UPDATE dbo.Person 
	SET Navn = Navn + Navn 
	WHERE Id = 17;
