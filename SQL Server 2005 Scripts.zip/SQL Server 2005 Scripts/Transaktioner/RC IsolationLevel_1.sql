USE master
GO
DROP DATABASE TransaktionDB
GO
CREATE DATABASE TransaktionDB
GO
use TransaktionDB
GO
CREATE TABLE Person(
	Id		INT NOT NULL IDENTITY (1,2) PRIMARY KEY, 
	Navn	VARCHAR(30)  NOT NULL, 
	Bem		CHAR(1000) NOT NULL DEFAULT 'Bem�rkning')
GO
SET NOCOUNT ON
INSERT INTO Person (Navn) VALUES ('per')
INSERT INTO Person (Navn) VALUES ('ole')
INSERT INTO Person (Navn) VALUES ('ane')
INSERT INTO Person (Navn) VALUES ('ib')
INSERT INTO Person (Navn) VALUES ('louise')
INSERT INTO Person (Navn) VALUES ('hanne')
INSERT INTO Person (Navn) VALUES ('s�ren')
INSERT INTO Person (Navn) VALUES ('sanne')
INSERT INTO Person (Navn) VALUES ('bo')
INSERT INTO Person (Navn) VALUES ('carina')
INSERT INTO Person (Navn) VALUES ('dorthe')
INSERT INTO Person (Navn) VALUES ('tom')
INSERT INTO Person (Navn) VALUES ('tine')
INSERT INTO Person (Navn) VALUES ('maren')
INSERT INTO Person (Navn) VALUES ('karen')
SET NOCOUNT OFF
SELECT * 
	FROM Person
GO
-- READ COMMITTED
SET TRANSACTION ISOLATION LEVEL READ COMMITTED

UPDATE Person 
	SET Navn = Navn + Navn 
	WHERE Id = 7


BEGIN TRANSACTION
UPDATE Person 
	SET Navn = Navn + ' l ' 
	WHERE Id = 7

COMMIT TRANSACTION
