USE master
GO
DROP DATABASE TransaktionDB
GO
CREATE DATABASE TransaktionDB
GO
USE TransaktionDB
GO
CREATE TABLE dbo.Person
(
	Id 		INT				NOT NULL IDENTITY (1, 2), 
	Navn	VARCHAR(30)		NOT NULL, 
	Bem 	CHAR(1000)		NOT NULL DEFAULT ('Bem�rkning')
)
GO
SET NOCOUNT ON
INSERT INTO dbo.Person (Navn) VALUES 
	('Per'),
	('Ole'),
	('Ane'),
	('Ib'),
	('Louise'),
	('Hanne'),
	('S�ren'),
	('Sanne'),
	('Bo'),
	('Carina'),
	('Dorthe'),
	('Tom'),
	('Tine'),
	('Maren'),
	('Karen');

SET NOCOUNT OFF;

SELECT * 
	FROM dbo.Person
GO
-- READ UNCOMMITTED 1

BEGIN TRANSACTION;

UPDATE dbo.Person 
	SET Navn = Navn + Navn
	WHERE Id = 7;

ROLLBACK TRANSACTION;
COMMIT TRANSACTION;

-- READ UNCOMMITTED 2
SET TRANSACTION ISOLATION LEVEL 
	READ UNCOMMITTED;

BEGIN TRANSACTION;

UPDATE dbo.Person 
	SET Navn = Navn 
	WHERE Id = 7;

COMMIT TRANSACTION;

-- READ UNCOMMITTED 3
SET TRANSACTION ISOLATION LEVEL 
	READ UNCOMMITTED;

BEGIN TRANSACTION;

UPDATE dbo.Person 
	SET Navn = Navn + Navn 
	WHERE Id = 7;

COMMIT TRANSACTION;
