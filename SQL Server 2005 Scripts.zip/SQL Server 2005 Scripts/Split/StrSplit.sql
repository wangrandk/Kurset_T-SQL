use master
drop database SplitDB
go
create database SplitDB
go
use SplitDb
go
create function ufn_split
(@stringarr varchar(20), @separator char(1) = ',') 
returns table
as
return
	select
		s,n,
		n - len(replace(left(s, n), @separator, '')) + 1 as pos,
		substring(s, n, charindex(@separator, s + @separator, n) - n) as element
	from	(select @stringarr as s) as d
			inner join (	select 1 as n 
							union all 
							select 2 
							union all
							select 3 
							union all 
							select 4 
							union all 
							select 5
							union all
							select 6
							union all
							select 7
							union all 
							select 8
							union all
							select 9
							union all
							select 10) as num
			on n <= len(s) and substring(@separator + s, n, 1) = @separator
go
select * from ufn_split('a,bd,c, d', ',')
