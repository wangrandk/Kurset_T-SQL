USE master
DROP DATABASE HashDB
GO
CREATE DATABASE HashDB
GO
USE HashDB
GO
DECLARE @i				INT = 33

DECLARE @Char			TABLE (
	Tegn		CHAR(1))
	
CREATE TABLE PasswordData (
	Password	VARCHAR(10) NOT NULL, 
	HashMD2		VARBINARY(100) NULL,
	HashMD4		VARBINARY(100) NULL,
	HashMD5		VARBINARY(100) NULL,
	HashSHA		VARBINARY(100) NULL,
	HashSHA1	VARBINARY(100) NULL)

WHILE @i <= 156
BEGIN
	INSERT INTO @Char
		VALUES (CHAR(@i))
	SET @i += 1
END
DELETE 
	FROM @Char
	WHERE Tegn = ' '

DELETE
	FROM @Char
	WHERE Tegn IN (SELECT Tegn FROM @Char GROUP BY Tegn HAVING COUNT(*) > 1) 
	 
SELECT * 
	FROM @Char
	
INSERT INTO PasswordData (Password)
	SELECT Tegn
		FROM @Char

INSERT INTO PasswordData (Password)
	SELECT c1.Tegn + c2.Tegn
		FROM @Char AS c1	CROSS JOIN @Char AS c2	

INSERT INTO PasswordData (Password)
	SELECT c1.Tegn + c2.Tegn + c3.Tegn
		FROM @Char AS c1	CROSS JOIN @Char AS c2	
							CROSS JOIN @Char AS c3

--INSERT INTO PasswordData (Password)
--	SELECT c1.Tegn + c2.Tegn + c3.Tegn + + c4.Tegn
--		FROM @Char AS c1	CROSS JOIN @Char AS c2
--							CROSS JOIN @Char AS c3 
--							CROSS JOIN @Char AS c4

SELECT COUNT(*), COUNT(DISTINCT Password)
	FROM PasswordData

UPDATE PasswordData
	SET HashMD2 = HASHBYTES('MD2', Password),
		HashMD4 = HASHBYTES('MD4', Password),
		HashMD5 = HASHBYTES('MD5', Password),
		HashSHA = HASHBYTES('SHA', Password),
		HashSHA1 = HASHBYTES('SHA1', Password)

SELECT	COUNT(*),
		COUNT(DISTINCT HashMD2), 
		COUNT(DISTINCT HashMD4), 
		COUNT(DISTINCT HashMD5),
		COUNT(DISTINCT HashSHA), 
		COUNT(DISTINCT HashSHA1)
	FROM PasswordData

SELECT COUNT(*), COUNT(DISTINCT Password)
	FROM PasswordData
