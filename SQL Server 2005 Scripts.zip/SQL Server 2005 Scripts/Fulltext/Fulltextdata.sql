USE master;
GO
DROP DATABASE IF EXISTS TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
CREATE FULLTEXT CATALOG TestDB_Catalog 
	WITH ACCENT_SENSITIVITY = ON
	AS DEFAULT;
GO
CREATE TABLE dbo.Beskrivelser
(
	ID				INT NOT NULL IDENTITY
					CONSTRAINT PK_Beskrivelser PRIMARY KEY,
	Type			VARCHAR(20) NOT NULL,
	Overskrift		VARCHAR(100) NOT NULL,
	Beskrivelse		VARCHAR(8000) NOT NULL
);
GO
INSERT INTO dbo.Beskrivelser(Type, Overskrift, Beskrivelse) VALUES
	('Azure', 'Microsoft Azure - Enterprise Application Integration Using Azure Logic Apps', 'With Azure Logic Apps, developers can visually compose integration flow and easily handle scenarios that involve long-running transactions, handling condition-based routing of workflows, retry logic to handle transient failures, and more. The suite of Standard and Enterprise Connectors provided by Azure Logic Apps can be leveraged to implement an end-to-end enterprise application integration scenario.'),
	('Visual Studio', 'Visual Studio - Nurturing Lean UX Practices ', 'When Microsoft developed the new debugging and diagnostic features in Visual Studio 2015, it employed an iterative, "Lean UX" approach to inform the design. This article goes behind the scenes to explore the making of the PerfTips feature in Visual Studio 2015.'),
	('Power Shell', 'Windows PowerShell - Writing Windows Services in PowerShell ', 'This article presents a novel and easy way to create Windows services, by writing them in the PowerShell scripting language rather than C# or C++. No more compilation, just a quick edit/test cycle that can be done on any system.'),
	('.Net', 'NET Compiler Platform - Maximize your Model-View-ViewModel Experience with Roslyn ', 'Learn how to simplify the implementation of the Model-View-ViewModel pattern with custom Roslyn refactorings. Del Sole shows you how to take advantage of the Roslyn APIs to automate the generation of common objects in MVVM, starting with plain text analysis and moving on to creating new syntax nodes.'),
	('.Net', 'ASP.NET - Writing Clean Code in ASP.NET Core with Dependency Injection ', 'Dependency Injection (DI) is a technique that allows applications to be constructed from loosely coupled modules. ASP.NET Core has built-in support for DI and uses it to provide services to applications built on it. Learn how to use DI to access ASP.NET services as well as your own application services.'),
	('SQL Server', 'Database Engine', 'The Database Engine is the core service for storing, processing, and securing data. The Database Engine provides controlled access and rapid transaction processing to meet the requirements of the most demanding data consuming applications within your enterprise. The Database Engine also provides rich support for sustaining high availability.'),
	('SQL Server', 'R Services', 'Microsoft R Services provides multiple ways to incorporate the popular R language into enterprise workflows. R Services (In-database) integrates the R language with SQL Server, making it easy to build, retrain, and score models by calling Transact-SQL stored procedures. Microsoft R Server provides multi-platform, scalable support for R in the enterprise, and supports data sources such as Hadoop and Teradata.'),
	('SQL Server', 'Data Quality Services', 'SQL Server Data Quality Services (DQS) provides you with a knowledge-driven data cleansing solution. DQS enables you to build a knowledge base, and then use that knowledge base to perform data correction and deduplication on your data, using both computer-assisted and interactive means. You can use cloud-based reference data services, and you can build a data management solution that integrates DQS with SQL Server Integration Services and Master Data Services.'),
	('SQL Server', 'Integration Services', '�Integration Services is a platform for building high performance data integration solutions, including packages that provide extract, transform, and load (ETL) processing for data warehousing.'),
	('SQL Server', 'Master Data Services', 'Master Data Services is the SQL Server solution for master data management. A solution built on Master Data Services helps ensure that reporting and analysis is based on the right information. Using Master Data Services, you create a central repository for your master data and maintain an auditable, securable record of that data as it changes over time.'),
	('SQL Server', 'Analysis Services', '�Analysis Services is an analytical data platform and toolset for personal, team, and corporate business intelligence. Servers and client designers support traditional OLAP solutions, new tabular modeling solutions, as well as self-service analytics and collaboration using Power Pivot, Excel, and a SharePoint Server environment. Analysis Services also includes Data Mining so that you can uncover the patterns and relationships hidden inside large volumes of data.'),
	('SQL Server', 'Replication', 'Replication is a set of technologies for copying and distributing data and database objects from one database to another, and then synchronizing between databases to maintain consistency. By using replication, you can distribute data to different locations and to remote or mobile users by means of local and wide area networks, dial-up connections, wireless connections, and the Internet.'),
	('SQL Server', 'Reporting Services', 'Reporting Services delivers enterprise, Web-enabled reporting functionality so you can create reports that draw content from a variety of data sources, publish reports in various formats, and centrally manage security and subscriptions.');
GO
INSERT INTO dbo.Beskrivelser (Type, Overskrift, Beskrivelse)
	SELECT Type, Overskrift, Beskrivelse 
		FROM dbo.Beskrivelser;
GO 6
SELECT *
	FROM dbo.Beskrivelser;
GO
CREATE FULLTEXT INDEX ON dbo.Beskrivelser (Type, Overskrift, Beskrivelse) 
	KEY INDEX PK_Beskrivelser;
GO
SET STATISTICS TIME ON;
SELECT *
	FROM dbo.Beskrivelser
	WHERE Beskrivelse LIKE '%DQS%';

SELECT * 
	FROM dbo.Beskrivelser 
	WHERE CONTAINS (Beskrivelse, 'DQS');
SET STATISTICS TIME OFF;
GO
SELECT * 
	FROM sys.dm_fts_index_keywords_position_by_document  
			(DB_ID(), OBJECT_ID('dbo.Beskrivelser'));   
