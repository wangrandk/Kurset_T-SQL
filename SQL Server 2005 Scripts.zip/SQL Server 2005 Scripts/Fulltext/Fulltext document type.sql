SELECT *
	FROM sys.fulltext_document_types
