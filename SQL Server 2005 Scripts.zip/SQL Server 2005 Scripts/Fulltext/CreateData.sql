USE master;
DROP DATABASE FulltextDB;
GO
CREATE DATABASE FulltextDB;
GO
USE FulltextDB;
CREATE FULLTEXT CATALOG FulltextDB_Catalog 
	WITH ACCENT_SENSITIVITY = ON
	AS DEFAULT;
GO
CREATE TABLE dbo.t 
(
	id	INT				NOT NULL CONSTRAINT PK_t PRIMARY KEY,
	a	VARCHAR(2000)	NOT NULL,
	b	VARCHAR(2000)	NOT NULL,
	c	VARCHAR(2000)	NOT NULL,
	d	VARCHAR(2000)	NOT NULL
);
GO
INSERT INTO dbo.t VALUES
	(1, 'this is a test', 'this is a test', 'this is a test', 'this is a test'),
	(2, 'this is a test on bottle', 'this is a test', 'this is a test', 'this is a test'),
	(3, 'this is a test on bottles', 'this is a test', 'this is a test', 'this is a test'),
	(4, 'this is a test', 'this is a test', 'this is a test', 'this is a test on bottle'),
	(5, 'this is a test', 'this is a test', 'this is a test', 'this is a test on bottles'),
	(6, 'this is a test on bottle', 'this is a test', 'this is a test', 'this is a test on bottle'),
	(7, 'this is a test on bottle', 'this is a test', 'this is a test', 'this is a test on bottles'),
	(8, 'this is a test on bottles', 'this is a test', 'this is a test', 'this is a test on bottle'),
	(9, 'this is a test', 'this is a test on bottle', 'this is a test', 'this is a test'),
	(10, 'this is a test', 'this is a test ', 'this is a test on bottle', 'this is a test'),
	(11, 'this is a test on bottles', 'this is a test', 'this is a test', 'this is a test on bottles'),
	(12, 'this is a test', 'this is a test', 'this is a test on bottle', 'this is a test'),
	(13, 'this is a test on bottle', 'this is a test', 'this is a test', 'this is a test on BOTTLE'),
	(14, 'this is a test', 'this is a test on bottle', 'this is a test on BOTTLES', 'this is a test');
GO
CREATE FULLTEXT INDEX ON dbo.t(a, b, c, d) 
	KEY INDEX PK_t;
GO
SELECT * FROM t WHERE CONTAINS (a, 'bottle');
SELECT * FROM t WHERE CONTAINS (a, 'bottle') AND  CONTAINS (d, 'bottle');
SELECT * FROM t WHERE CONTAINS (a, 'bottle') OR  CONTAINS (d, 'bottle');
SELECT * FROM t WHERE CONTAINS ((a, d), 'bottle');
SELECT * FROM t WHERE CONTAINS (*, 'bottles');
SELECT * FROM t WHERE CONTAINS (*, 'BOTTLES');
SELECT * FROM t WHERE CONTAINS (a,  ' FORMSOF (INFLECTIONAL, BOTTLE )');
GO
DROP FULLTEXT INDEX ON dbo.t;
GO
CREATE FULLTEXT STOPLIST FTStoplist;
GO
ALTER FULLTEXT STOPLIST FTStoplist ADD 'bottles' LANGUAGE 'English';
GO
SELECT *
	FROM sys.fulltext_stopwords;
	 
SELECT *
	FROM sys.fulltext_system_stopwords
	WHERE language_id IN (1030);		-- Dansk
GO
ALTER FULLTEXT STOPLIST FTStoplist DROP 'bottles' LANGUAGE 'English';
GO
SELECT *
	FROM sys.fulltext_stopwords;
GO
CREATE FULLTEXT INDEX ON dbo.t(a, b, c, d) 
	KEY INDEX PK_t
	WITH STOPLIST FTStoplist;
GO
SELECT * 
	FROM dbo.t 
	WHERE CONTAINS (*, 'bottles');

SELECT * 
	FROM dbo.t 
	WHERE CONTAINS (*, 'bottle');

SELECT * 
	FROM dbo.t 
	WHERE CONTAINS (a,  ' FORMSOF (INFLECTIONAL, BOTTLE )');
GO
SELECT * 
	FROM dbo.t 
	WHERE CONTAINS (a, 'bottle');

SELECT * 
	FROM dbo.t 
	WHERE a LIKE '%bottle%';
GO
CREATE TABLE dbo.t_VarcharMax 
(
	ID		INT NOT NULL CONSTRAINT PK__t_VarcharMax PRIMARY KEY IDENTITY,
	Tekst	VARCHAR(MAX) NOT NULL
);
GO
INSERT INTO dbo.t_VarcharMax VALUES
	('TI ' +
	REPLICATE (CAST('Denne tekst gentages ' AS VARCHAR(MAX)), 2600) + 
	 REPLICATE (CAST('noget mere tekst ' AS VARCHAR(MAX)), 400)+
	 'Det vi s�ger efter : Teknologisk Institut');

INSERT INTO dbo.t_VarcharMax VALUES
	('IT ' +
	REPLICATE (CAST('Denne tekst gentages igen' AS VARCHAR(MAX)), 5000) + 
	 REPLICATE (CAST('noget mere tekst igen' AS VARCHAR(MAX)), 6000)+
	 'Det vi s�ger efter (omvendt) : Institut Teknologisk ');

INSERT INTO dbo.t_VarcharMax VALUES
	('T ' +
	REPLICATE (CAST('Denne tekst gentages igen igen' AS VARCHAR(MAX)), 2000) + 
	 REPLICATE (CAST('noget mere tekst ' AS VARCHAR(MAX)), 400)+
	 'Det vi s�ger efter : Teknologisk');

INSERT INTO dbo.t_VarcharMax VALUES
	('I ' +
	REPLICATE (CAST('Denne tekst gentages sikkert igen' AS VARCHAR(MAX)), 4000) + 
	 REPLICATE (CAST('noget mere tekst ' AS VARCHAR(MAX)), 3000)+
	 'Det vi s�ger efter  : Institut');

INSERT INTO dbo.t_VarcharMax VALUES
	('TI ' + 'Det vi s�ger efter  : Teknologisk Institut');

INSERT INTO dbo.t_VarcharMax VALUES
	('TI ' + 'Teknologisk Institut');

INSERT INTO dbo.t_VarcharMax VALUES
	('TI ' +'Teknologisk Institut ' + 
	 REPLICATE (CAST('Denne tekst gentages sikkert igen' AS VARCHAR(MAX)), 1000) + 
	 REPLICATE (CAST('noget mere tekst ' AS VARCHAR(MAX)), 2000));

INSERT INTO dbo.t_VarcharMax VALUES
	('T  I ' +'Teknologisk ' + 
	 REPLICATE (CAST('Denne tekst gentages sikkert igen' AS VARCHAR(MAX)), 40000) + 
	 REPLICATE (CAST('noget mere tekst ' AS VARCHAR(MAX)), 30000)+
	 'Det vi s�ger efter  : Institut');

INSERT INTO dbo.t_VarcharMax VALUES
	('intet  ' + 
	 REPLICATE (CAST('Denne tekst gentages sikkert igen' AS VARCHAR(MAX)), 40000) + 
	 REPLICATE (CAST('noget mere tekst ' AS VARCHAR(MAX)), 30000)+
	 'Det vi s�ger efter intet');
GO
CREATE FULLTEXT INDEX ON dbo.t_VarcharMax(Tekst)
	KEY INDEX PK__t_VarcharMax;
GO
SELECT LEN(Tekst)
	FROM dbo.t_VarcharMax;
GO
SET STATISTICS TIME ON;
SELECT * FROM dbo.t_VarcharMax WHERE CONTAINS (Tekst, 'Teknologisk');
SELECT * FROM dbo.t_VarcharMax WHERE Tekst LIKE '%Teknologisk%';
SET STATISTICS TIME OFF;
GO
SET STATISTICS TIME ON;
SELECT * FROM dbo.t_VarcharMax WHERE CONTAINS(Tekst, ' "Teknologisk" NEAR "Institut" ');
SELECT * FROM dbo.t_VarcharMax WHERE Tekst LIKE '%Teknologisk%Institut%' OR 
									 Tekst LIKE '%Institut%Teknologisk%';
SET STATISTICS TIME OFF;
GO
SELECT * FROM dbo.t_VarcharMax WHERE CONTAINS(Tekst, ' "Teknologisk" OR "Institut" ');
SELECT * FROM dbo.t_VarcharMax WHERE CONTAINS(Tekst, ' "Tekno*" ');
SELECT * FROM dbo.t_VarcharMax WHERE CONTAINS(Tekst, ' "Teknologisk" NEAR "Institut" ');
SELECT * FROM dbo.t_VarcharMax WHERE CONTAINS(Tekst, ' "Institut" NEAR "Teknologisk"');
SELECT * FROM CONTAINSTABLE (dbo.t_VarcharMax, Tekst, '"Teknologisk" NEAR "Institut"', 20) AS t;
GO
CREATE TABLE dbo.t_Blob 
(
	ID			INT NOT NULL CONSTRAINT PK__t_Blob PRIMARY KEY IDENTITY,
	Blob		VARBINARY(MAX),
	BlobType	VARCHAR(10) NOT NULL
);
GO
INSERT INTO dbo.t_Blob (Blob, BlobType)
	SELECT d.blob, '.doc' 
		FROM OPENROWSET( BULK 'c:\SQL Server 2005 Scripts\Fulltext\FulltextDok\Word1.doc', SINGLE_BLOB) AS d(blob);

INSERT INTO dbo.t_Blob (Blob, BlobType)
	SELECT d.blob, '.xls' 
		FROM OPENROWSET( BULK 'c:\SQL Server 2005 Scripts\Fulltext\FulltextDok\Book1.xls', SINGLE_BLOB) AS d(blob);

INSERT INTO dbo.t_Blob (Blob, BlobType)
	SELECT d.blob, '.ppt' 
		FROM OPENROWSET( BULK 'c:\SQL Server 2005 Scripts\Fulltext\FulltextDok\Ppt1.ppt', SINGLE_BLOB) AS d(blob);

INSERT INTO dbo.t_Blob (Blob, BlobType)
	SELECT d.blob, '.doc' 
		FROM OPENROWSET( BULK 'c:\SQL Server 2005 Scripts\Fulltext\FulltextDok\Uden1.doc', SINGLE_BLOB) AS d(blob);
GO
CREATE FULLTEXT INDEX ON dbo.t_Blob(Blob TYPE COLUMN BlobType)
	KEY INDEX PK__t_Blob;
GO
SELECT ID 
	FROM dbo.t_Blob 
	WHERE CONTAINS (Blob, 'Teknologisk');
GO
SELECT * 
	FROM CONTAINSTABLE(dbo.t_Blob, blob, 'Teknologisk') AS X;
GO
SELECT * 
	FROM dbo.t_Blob;
