USE master
DROP DATABASE FulltextDB
GO
CREATE DATABASE FulltextDB
GO
USE FulltextDB
CREATE FULLTEXT CATALOG FulltextDB_Catalog 
	WITH ACCENT_SENSITIVITY = ON
	AS DEFAULT
GO
CREATE TABLE t_xml (
	id	INT NOT NULL CONSTRAINT PK_t PRIMARY KEY,
	a	XML NOT NULL
)
GO
INSERT INTO t_xml VALUES
	(1, '<kunder>
				<kunde kundeid="6" navn="jensen og andersen" adresse="nygade 2" postnr="2000" tlfnr="22113344">
					<kundekontakt navn="jens jensen" tlfnr="22113345" titel="direkt�r" />
					<kundekontakt navn="hans andersen" tlfnr="22113345" titel="direkt�r" />
				</kunde>
				<kunde kundeid="9" navn="bygmesteren" adresse="vestergade 67" postnr="9000" tlfnr="98225633">
					<kundekontakt navn="hanne larsen" tlfnr="2207" titel="�konomichef" />
					<kundekontakt navn="lene hansen" tlfnr="2231" titel="arkitekt" />
					<kundekontakt navn="lars petersen" tlfnr="2227" />
				</kunde>
				<kunde kundeid="2" navn="smedemesteren" adresse="torvet 5" postnr="8000" tlfnr="44213755">
					<kundekontakt navn="claus davidsen" tlfnr="20214587" />
				</kunde>
			</kunder>'),
	(2, '<kunder>
				<kunde kundeid="3" navn="larsen og co" adresse="�stergadegade 2" postnr="4000" tlfnr="12343344">
					<kundekontakt navn="sanne jensen" tlfnr="12343344" titel="�konomidirekt�r" />
				</kunde>
				<kunde kundeid="4" navn="t�mmerhandelen a/s" adresse="industrivej 7" postnr="9400" tlfnr="98225432">
					<kundekontakt navn="arne petersen" tlfnr="98225432" titel="direkt�r" />
					<kundekontakt navn="ludvig petersen" tlfnr="98225433" titel="�konomichef" />
				</kunde>
			</kunder>'),
	(3, '<kunder>
				<kunde kundeid="12" navn="larsen og co" adresse="�stergadegade 2" postnr="4000" tlfnr="12343344">
					<kundekontakt navn="sanne jensen" tlfnr="12343344" />
				</kunde>
				<kunde kundeid="1" navn="t�mmerhandelen a/s" adresse="industrivej 7" postnr="9400" tlfnr="98225432">
					<kundekontakt navn="arne petersen" tlfnr="98225432" />
					<kundekontakt navn="ludvig petersen" tlfnr="98225433" />
				</kunde>
			</kunder>')
GO
CREATE FULLTEXT INDEX ON dbo.t_xml(a) 
	KEY INDEX PK_t
GO
SELECT * FROM t_xml WHERE CONTAINS (a, '"jensen og andersen"') 
GO
SELECT  *
	FROM sys.dm_fts_index_keywords_by_document(DB_ID('FulltextDB'), Object_ID('dbo.t_xml'));
