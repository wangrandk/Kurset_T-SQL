USE master
GO
DROP DATABASE FulltextDB
GO
CREATE DATABASE FulltextDB 
ON
PRIMARY 
	(NAME = FulltextDB_Data,
	 FILENAME = 'c:\Databaser\FulltextDB.mdf'),

FILEGROUP FileStreamGroup CONTAINS FILESTREAM
	(NAME = FulltextDB_FS,
     FILENAME = 'c:\Databaser\Filestream_FulltextDB')

LOG ON  
	(NAME = FulltextDB_Log,
     FILENAME = 'c:\Databaser\FulltextDB.ldf')
GO
USE FulltextDB
GO
CREATE FULLTEXT CATALOG FulltextDB_Catalog 
	WITH ACCENT_SENSITIVITY = ON
	AS DEFAULT
GO
CREATE TABLE t_Blob (
	ID			INT NOT NULL CONSTRAINT PK__t_Blob PRIMARY KEY IDENTITY,
	IDUQ		UNIQUEIDENTIFIER ROWGUIDCOL NOT NULL UNIQUE DEFAULT(NEWID()),
	Blob		VARBINARY(MAX) FILESTREAM,
	BlobType	VARCHAR(10) NOT NULL)
GO
INSERT INTO t_Blob (Blob, BlobType)
	SELECT d.blob, '.doc' 
		FROM OPENROWSET( BULK 'c:\SQL Server 2005 Scripts\Fulltext\FulltextDok\Word1.doc', SINGLE_BLOB) AS d(blob)

INSERT INTO t_Blob (Blob, BlobType)
	SELECT d.blob, '.xls' 
		FROM OPENROWSET( BULK 'c:\SQL Server 2005 Scripts\Fulltext\FulltextDok\Book1.xls', SINGLE_BLOB) AS d(blob)

INSERT INTO t_Blob (Blob, BlobType)
	SELECT d.blob, '.ppt' 
		FROM OPENROWSET( BULK 'c:\SQL Server 2005 Scripts\Fulltext\FulltextDok\Ppt1.ppt', SINGLE_BLOB) AS d(blob)

INSERT INTO t_Blob (Blob, BlobType)
	SELECT d.blob, '.doc' 
		FROM OPENROWSET( BULK 'c:\SQL Server 2005 Scripts\Fulltext\FulltextDok\Uden1.doc', SINGLE_BLOB) AS d(blob)

INSERT INTO t_Blob (Blob, BlobType)
	SELECT d.blob, '.xml' 
		FROM OPENROWSET( BULK 'c:\SQL Server 2005 Scripts\Fulltext\FulltextDok\KundeOrdre.xml', SINGLE_BLOB) AS d(blob)
GO
CREATE FULLTEXT INDEX ON dbo.t_Blob(Blob TYPE COLUMN BlobType)
	KEY INDEX PK__t_Blob
GO
SELECT ID 
	FROM t_Blob 
	WHERE CONTAINS (Blob, 'Teknologisk')
GO
SELECT ID 
	FROM t_Blob 
	WHERE CONTAINS (Blob, 'end')
GO
SELECT  *
	FROM sys.dm_fts_index_keywords_by_document(DB_ID('FulltextDB'), Object_ID('dbo.t_Blob'))
