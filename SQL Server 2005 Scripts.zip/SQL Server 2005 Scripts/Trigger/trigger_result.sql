USE master
DROP DATABASE TriggerDB
GO
CREATE DATABASE TriggerDB
GO
USE TriggerDB
GO
CREATE TABLE t (
	id		INT NOT NULL IDENTITY PRIMARY KEY,
	navn	VARCHAR(20) NOT NULL)
GO
CREATE TRIGGER ins_t ON t AFTER INSERT
AS
SELECT * FROM inserted
GO
INSERT INTO t VALUES ('ole')
INSERT INTO t VALUES ('ida')
GO
INSERT INTO t
	SELECT navn FROM t
GO
USE master;
GO
EXEC sp_configure 'show advanced option', '1';
GO
EXEC sp_configure 'disallow results from triggers', 1
GO
RECONFIGURE
GO
USE TriggerDB;
GO
INSERT INTO t VALUES ('bo')
GO
CREATE TRIGGER upd_t ON t AFTER UPDATE
AS
SELECT *
	FROM inserted
GO
UPDATE t SET navn = navn + navn WHERE id = 2
GO
UPDATE t SET navn = navn + navn WHERE id = 3
GO
EXEC sp_configure 'disallow results from triggers', 0	-- ikke tilladt
GO
RECONFIGURE
GO
