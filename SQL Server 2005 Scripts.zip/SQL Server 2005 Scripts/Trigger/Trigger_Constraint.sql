USE master;
DROP DATABASE TriggerDB;
GO
CREATE DATABASE TriggerDB;
GO
USE TriggerDB
CREATE TABLE dbo.LovligeSkift 
(
	StatusFra		CHAR(1) NOT NULL,
	StatusTil		CHAR(1) NOT NULL,
	CONSTRAINT PK_LovligeSkift PRIMARY KEY (StatusFra, StatusTil)
);
GO
INSERT INTO dbo.LovligeSkift VALUES
	('U','G'),
	('G','S'),
	('G','F'),
	('G','E'),
	('S','F'),
	('S','G'),
	('S','E'),
	('F','G'),
	('E','G');
GO
CREATE TABLE dbo.Person 
(
	PersonID				INT NOT NULL PRIMARY KEY IDENTITY,
	AegteskabeligStatus		CHAR(1) NOT NULL
);	
GO 
CREATE TRIGGER INS_Person ON dbo.Person
AFTER INSERT
AS
BEGIN
	IF EXISTS (SELECT *
				FROM INSERTED
				WHERE AegteskabeligStatus NOT IN (SELECT StatusFra
													FROM LovligeSkift))
	BEGIN
		ROLLBACK TRANSACTION;
		THROW 89234, '�gteskabelig status ikke lovlig', 1;
	END
END;
GO
CREATE TRIGGER UPD_Person ON dbo.Person
AFTER UPDATE
AS
BEGIN
	IF EXISTS (SELECT *
				FROM INSERTED INNER JOIN DELETED
								ON INSERTED.PersonID = DELETED.PersonID
				WHERE DELETED.AegteskabeligStatus + INSERTED.AegteskabeligStatus NOT IN (
									SELECT StatusFra + StatusTil
											FROM LovligeSkift))
	BEGIN
		ROLLBACK TRANSACTION;
		THROW 89237, 'Tilstandsskift ikke lovlig', 1;
	END;
END;
GO
INSERT INTO dbo.Person VALUES ('G');
INSERT INTO dbo.Person VALUES ('U');

SELECT *
	FROM dbo.Person;
GO
UPDATE dbo.Person
	SET AegteskabeligStatus = 'E'
	WHERE PersonID = 1;
GO
UPDATE dbo.Person
	SET AegteskabeligStatus = 'E'
	WHERE PersonID = 2;
GO
SELECT *
	FROM dbo.Person;

UPDATE dbo.Person
	SET AegteskabeligStatus = 'G'
	WHERE PersonID IN (1, 2);

SELECT *
	FROM dbo.Person;
