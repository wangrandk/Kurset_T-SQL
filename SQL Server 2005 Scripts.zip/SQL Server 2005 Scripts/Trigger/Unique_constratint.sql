USE master
DROP DATABASE TriggerDB
GO
CREATE DATABASE TriggerDB
GO
USE TriggerDB
CREATE TABLE Person 
(
	id		INT  NOT NULL PRIMARY KEY IDENTITY,
	cprnr	CHAR(10) NULL
)
GO
CREATE TRIGGER ins_upd_Person ON Person
AFTER INSERT, UPDATE
AS
IF  EXISTS (SELECT inserted.id 
				FROM inserted INNER JOIN Person
						ON inserted.cprnr = person.cprnr
				GROUP BY inserted.id
				HAVING COUNT(*) >= 2)
BEGIN	
	ROLLBACK TRANSACTION;
	THROW 76234, 'Cprnr findes i forvejen', 1;	
END
GO
INSERT INTO person (cprnr) VALUES ('123')
INSERT INTO person (cprnr) VALUES ('456')
INSERT INTO person (cprnr) VALUES (NULL)
GO
SELECT *
	FROM person
GO
INSERT INTO person (cprnr) VALUES ('123')
INSERT INTO person (cprnr) VALUES (NULL)
GO
UPDATE person 
	SET cprnr = '789' 
	WHERE id = 1
GO
UPDATE person 
	SET cprnr = '789' 
	WHERE id = 2
GO
GO
UPDATE person 
	SET cprnr = NULL 
	WHERE id = 2
GO
SELECT * 
	FROM person
GO
UPDATE person 
	SET cprnr = '987'
GO
