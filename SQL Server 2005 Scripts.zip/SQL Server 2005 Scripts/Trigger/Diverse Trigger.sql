USE master
DROP DATABASE TestDB
GO
CREATE DATABASE TestDB
GO
USE TestDB
GO
CREATE TABLE Medarbejder
(
	Medarbejderid			INT NOT NULL PRIMARY KEY,
	Navn					VARCHAR(30) NOT NULL,
	Cprnr					CHAR(10) NULL,
	Oprettetaf				VARCHAR(200) NOT NULL DEFAULT(SUSER_SNAME()),
	�ndretAF				VARCHAR(200) NULL,
	Slettet					VARCHAR(1) DEFAULT('A')
)
CREATE TABLE MedarbejderHist
(	
	HistID					INT NOT NULL PRIMARY KEY IDENTITY,
	Operation				VARCHAR(10) NOT NULL,
	Medarbejderid			INT NOT NULL,
	Navn					VARCHAR(30) NOT NULL,
	Cprnr					CHAR(10) NULL,
	Oprettetaf				VARCHAR(200) NOT NULL DEFAULT(SUSER_SNAME()),
	�ndretAf				VARCHAR(200) NULL
)
GO
CREATE TRIGGER ins_Medarbejder ON Medarbejder
AFTER INSERT
AS
BEGIN
INSERT INTO MedarbejderHist(Medarbejderid
							,Navn
							,Cprnr
							,Oprettetaf
							,�ndretAF,
							Operation)
	SELECT	Medarbejderid
			,Navn
			,Cprnr
			,Oprettetaf
			,�ndretAF, 
			'Insert'
		FROM INSERTED
END
GO
CREATE TRIGGER iodel_Medarbejder ON Medarbejder
INSTEAD OF DELETE
AS
BEGIN
UPDATE Medarbejder
	SET Slettet = 'P'
	WHERE Medarbejderid IN (SELECT Medarbejderid FROM DELETED)
END
GO
CREATE TRIGGER del_Medarbejder ON Medarbejder
AFTER DELETE
AS
BEGIN
INSERT INTO MedarbejderHist(Medarbejderid
							,Navn
							,Cprnr
							,Oprettetaf
							,�ndretAF,
							Operation)
	SELECT	Medarbejderid
			,Navn
			,Cprnr
			,Oprettetaf
			,�ndretAF, 
			'Delete'
		FROM DELETED
END
GO
CREATE TRIGGER upd_Medarbejder ON Medarbejder
AFTER UPDATE
AS
BEGIN
UPDATE Medarbejder	
	SET �ndretAf = SUSER_SNAME()
	WHERE Medarbejderid IN (SELECT Medarbejderid FROM INSERTED)
	
INSERT INTO MedarbejderHist(Medarbejderid
							,Navn
							,Cprnr
							,Oprettetaf
							,�ndretAF,
							Operation)
	SELECT	Medarbejderid
			,Navn
			,Cprnr
			,Oprettetaf
			,�ndretAF, 
			'Upd gl'
		FROM DELETED
	
INSERT INTO MedarbejderHist(Medarbejderid
							,Navn
							,Cprnr
							,Oprettetaf
							,�ndretAF,
							Operation)
	SELECT	m.Medarbejderid
			,m.Navn
			,m.Cprnr
			,m.Oprettetaf
			,m.�ndretAf, 
			'Upd ny'
		FROM INSERTED AS i INNER JOIN Medarbejder AS m  ON i.Medarbejderid = m.Medarbejderid
END
GO
INSERT INTO Medarbejder(Medarbejderid, Navn, Cprnr)  VALUES(1, 'Ole Olsen', '1234')

UPDATE Medarbejder	
	SET Cprnr = '4321'
	WHERE Medarbejderid = 1
	
SELECT *
	FROM Medarbejder
	
SELECT *
	FROM MedarbejderHist
GO
CREATE TRIGGER ins_upd_Medarbejder ON Medarbejder
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS (SELECT Cprnr, COUNT(*)
				FROM Medarbejder
				WHERE Cprnr IN (SELECT Cprnr FROM inserted)
				GROUP BY Cprnr
				HAVING COUNT(*) > 1)
BEGIN
	RAISERROR('Ingen dublerede cprnr tilladt', 16, 1)
	ROLLBACK TRANSACTION
END
 
END
GO
INSERT INTO Medarbejder(Medarbejderid, Navn, Cprnr)  VALUES(2, 'Ole Olsen', '1234')
INSERT INTO Medarbejder(Medarbejderid, Navn, Cprnr)  VALUES(3, 'Ole Olsen', '1234')
GO
DELETE FROM Medarbejder
	WHERE MedarbejderId  IN (2, 3)
	
SELECT *
	FROM Medarbejder
	
SELECT *
	FROM MedarbejderHist
GO
USE AdventureWorks2008R2;
GO
sp_settriggerorder	@triggername= 'iodel_Medarbejder', 
					@order='Last', 
					@stmttype = 'DELETE';