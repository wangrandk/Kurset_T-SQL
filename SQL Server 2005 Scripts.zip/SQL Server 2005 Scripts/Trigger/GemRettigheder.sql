USE master
DROP DATABASE TriggerDB
GO
CREATE DATABASE TriggerDB
GO
USE TriggerDB
CREATE TABLE DDL_resultat (
	id			INT NOT NULL PRIMARY KEY IDENTITY,
	eventdata	XML NOT NULL)
GO
CREATE TRIGGER create_table_triggerdb 
ON DATABASE 
AFTER ddl_database_security_events
AS 
   INSERT INTO DDL_resultat VALUES(eventdata())
GO
CREATE LOGIN LarsK WITH PASSWORD = '3khj6dhx(0xvysdf'
GO
SELECT * FROM DDL_resultat
GO
CREATE USER LarsK
GO
SELECT * FROM DDL_resultat
GO
CREATE TABLE t (i int)
GO
GRANT SELECT, UPDATE ON t TO LarsK
GO
SELECT * FROM DDL_resultat
GO
CREATE PROC usp_t
AS
SELECT * 
	FROM t
GO
GRANT EXEC ON usp_t TO LarsK
GO
DROP USER LarsK
GO
DROP LOGIN LarsK
GO
SELECT * FROM DDL_resultat
GO