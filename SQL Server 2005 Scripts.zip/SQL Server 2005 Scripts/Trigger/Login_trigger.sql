USE master;
DROP DATABASE TriggerDB;
GO
CREATE DATABASE TriggerDB;
GO
USE TriggerDB;
CREATE TABLE Login_resultat 
(
	id			INT NOT NULL PRIMARY KEY IDENTITY,
	Afvist		VARCHAR(11) DEFAULT ('ikke afvist'),
	eventdata	XML NOT NULL
);
GO
CREATE LOGIN login_test WITH PASSWORD = 'abcd!1234';
GO
USE master;
GRANT VIEW SERVER STATE TO login_test;
GO
CREATE TRIGGER connection_limit_trigger
ON ALL SERVER 
WITH EXECUTE AS 'sa'
FOR LOGON
AS
BEGIN
	IF (SELECT COUNT(*) FROM sys.dm_exec_sessions
				WHERE is_user_process = 1 and
					original_login_name = ORIGINAL_LOGIN()) > 2
		ROLLBACK TRANSACTION
	ELSE
		INSERT INTO TriggerDB..Login_resultat VALUES('ikke afvist', eventdata());
END;
GO
USE TriggerDB;
SELECT * 
	FROM login_resultat;
GO
DROP TRIGGER connection_limit_trigger ON ALL SERVER;
GO
DROP LOGIN login_test;
GO
