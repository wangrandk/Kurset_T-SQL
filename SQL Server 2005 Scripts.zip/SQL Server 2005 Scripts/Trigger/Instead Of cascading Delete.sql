USE master
GO
DROP DATABASE TestDB
GO
CREATE DATABASE TestDB;
GO
USE testDB
CREATE TABLE Ordre
(
	OrdreID		INT NOT NULL PRIMARY KEY,
	Dato		DATE NOT NULL DEFAULT(SYSDATETIME())
);
CREATE TABLE OrdreLinie
(
	OrdreID		INT NOT NULL REFERENCES Ordre,
	VareID		INT NOT NULL,
	Leveret		SMALLINT NOT NULL,
	CONSTRAINT pk_OrdreLinie PRIMARY KEY (OrdreId, VareId)
);
GO
INSERT INTO Ordre (OrdreId) VALUES (1), (2), (3);
INSERT INTO OrdreLinie (OrdreId, VareId, Leveret)  VALUES (1, 34, 1), (2, 56, 0), (3, 11, 0);
GO
SELECT *
	FROM Ordre
SELECT *
	FROM OrdreLinie
GO
CREATE TRIGGER del_Ordre ON Ordre
INSTEAD OF DELETE
AS
BEGIN
	DELETE
		FROM OrdreLinie
		WHERE	Ordreid IN (SELECT OrdreId FROM DELETED) AND 
				Leveret = 0

	IF EXISTS (SELECT *
				FROM OrdreLinie
				WHERE Ordreid IN (SELECT OrdreId FROM DELETED))
	BEGIN
		ROLLBACK TRANSACTION;
		THROW 67894, 'Du kan ikke slette leverede Ordrer', 1;
	END;

	DELETE
		FROM Ordre
		WHERE Ordreid IN (SELECT OrdreId FROM DELETED)

END;
GO
DELETE 
	FROM Ordre	
	WHERE OrdreId IN (1, 3);

DELETE 
	FROM Ordre	
	WHERE OrdreId IN (2);