USE master;
GO
DROP DATABASE TriggerDB;
GO
CREATE DATABASE TriggerDB;
GO
USE TriggerDB;
CREATE TABLE dbo.Person
(
	ID			INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(20) NOT NULL,
	Timestamp	DATETIME2 NOT NULL DEFAULT(SYSDATETIME()),
	Bruger		VARCHAR(255) NOT NULL DEFAULT (USER_NAME())
);
GO
CREATE TRIGGER upd_Person ON dbo.Person AFTER UPDATE
AS
BEGIN
	UPDATE dbo.Person	
		SET Timestamp = SYSDATETIME(),
			Bruger = USER_NAME()
		WHERE ID IN (SELECT ID FROM INSERTED);
END;
GO
CREATE TRIGGER del_Person ON dbo.Person INSTEAD OF DELETE
AS
BEGIN
	UPDATE dbo.Person	
		SET Timestamp = SYSDATETIME(),
			Bruger = USER_NAME()
		WHERE ID IN (SELECT ID FROM DELETED);

	DELETE 
		FROM dbo.Person	
		WHERE ID IN (SELECT ID FROM DELETED);
END;
GO
INSERT INTO dbo.Person (ID, Navn) VALUES 
	(1, 'Ole'),
	(2, 'Ida'),
	(3, 'Hans'),
	(4, 'Maren');
GO
SELECT *
	FROM dbo.Person;
GO
CREATE USER Anders WITHOUT LOGIN;
GO
GRANT INSERT, UPDATE, DELETE, SELECT TO Anders;
GO
EXECUTE AS USER = 'Anders';

UPDATE dbo.Person
	SET Navn = 'Ole Erik'
	WHERE ID = 1;

SELECT *
	FROM dbo.Person;
GO
REVERT;
SELECT SUSER_SNAME(), USER_NAME();
GO
USE TriggerDB
EXEC sys.sp_cdc_enable_db;

EXEC sys.sp_cdc_enable_table 
	@source_schema = N'dbo',
	@source_name = N'Person',
	@role_name = NULL,
	@supports_net_changes = 1;
GO
SELECT *
	FROM cdc.dbo_Person_CT;
GO
CREATE USER Anne WITHOUT LOGIN;
GO
GRANT INSERT, UPDATE, DELETE, SELECT TO Anne;
GO
EXECUTE AS USER = 'Anne';

DELETE
	FROM dbo.Person
	WHERE ID = 3;
GO
REVERT;
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM cdc.dbo_Person_ct;
GO
DECLARE @From	BINARY(10) = sys.fn_cdc_get_min_lsn ('dbo_Person'),
		@To		BINARY(10) = sys.fn_cdc_get_max_lsn ();

SELECT *
	FROM cdc.fn_cdc_get_net_changes_dbo_Person (@From, @To, N'all with merge') AS r;
GO
USE TriggerDB;
GO
EXEC sys.sp_cdc_disable_table
	@source_schema = N'dbo',
	@source_name = N'Person',
	@capture_instance = 'all';
GO
EXEC sys.sp_cdc_disable_db;
