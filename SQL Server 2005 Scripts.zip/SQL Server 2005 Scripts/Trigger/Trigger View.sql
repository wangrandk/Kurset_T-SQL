USE master;
GO
DROP DATABASE TriggerDB;
GO
CREATE DATABASE TriggerDB;
GO
USE TriggerDB;
CREATE TABLE dbo.Kunde1
(
	KundeId			INT			NOT NULL
					CONSTRAINT PK_Kunde1 PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT	NOT NULL
);

CREATE TABLE dbo.Kunde2
(
	KundeId			INT			NOT NULL
					CONSTRAINT PK_Kunde2 PRIMARY KEY
					CONSTRAINT FK_Kunde2_Kunde1
					FOREIGN KEY REFERENCES dbo.Kunde1(Kundeid),
	Bemaerk			VARCHAR(8000) NULL
);
GO
CREATE VIEW dbo.Kunde
AS
SELECT	Kunde1.Kundeid,
		Kunde1.Navn,
		Kunde1.Adresse,
		Kunde1.Postnr,
		Kunde2.Bemaerk
	FROM dbo.Kunde1 LEFT JOIN dbo.Kunde2 ON Kunde1.KundeId = Kunde2.KundeId;
GO
CREATE TRIGGER ins_Kunde ON dbo.Kunde
INSTEAD OF INSERT
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
		BEGIN TRANSACTION;
		INSERT INTO dbo.Kunde1 (Kundeid, Navn, Adresse, Postnr)	
			SELECT	Kundeid,
					Navn,
					Adresse,
					Postnr
				FROM INSERTED;
	
		INSERT INTO dbo.Kunde2 (Kundeid, Bemaerk)
			SELECT	Kundeid,
					Bemaerk
				FROM INSERTED
				WHERE Bemaerk IS NOT NULL;

		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		THROW 65871, 'Kundeinfo kunne ikke inds�ttes', 1;
	END CATCH;
END;
GO
INSERT INTO dbo.Kunde (Kundeid, Navn, Adresse, Postnr, Bemaerk) VALUES
	(1, 'Carl Ottesen', 'S�ndergade 44', 2000, 'Mulig storkunde'),
	(2, 'Ane Hansen', 'Vestergade 23', 9000, NULL);
GO
SELECT *
	FROM dbo.Kunde1;

SELECT *
	FROM dbo.Kunde2;

SELECT *
	FROM dbo.Kunde;
GO
CREATE TRIGGER upd_Kunde ON dbo.Kunde
INSTEAD OF UPDATE
AS
BEGIN
	SET NOCOUNT ON;

	IF UPDATE(Kundeid)
		THROW 65873, 'Kundeid m� ikke �ndres', 1;

	BEGIN TRY
		BEGIN TRANSACTION;

		WITH UpdKunde1
		AS
		(SELECT INSERTED.Kundeid,
				INSERTED.Navn,
				INSERTED.Adresse,
				INSERTED.Postnr
			FROM INSERTED INNER JOIN DELETED ON INSERTED.KundeId = DELETED.KundeId
			WHERE	INSERTED.Navn <> DELETED.Navn OR
					INSERTED.Adresse <> DELETED.Adresse OR
					INSERTED.Postnr <> DELETED.Postnr
		)
		UPDATE dbo.Kunde1
			SET Navn = UpdKunde1.Navn,
				Adresse = UpdKunde1.Adresse,
				Postnr = UpdKunde1.Postnr
			FROM dbo.Kunde1 INNER JOIN UpdKunde1 ON Kunde1.KundeId = UpdKunde1.KundeId; 
		
		WITH UpdKunde2
		AS
		(SELECT INSERTED.Kundeid,
				INSERTED.Bemaerk
			FROM INSERTED INNER JOIN DELETED ON INSERTED.KundeId = DELETED.KundeId
			WHERE ISNULL(INSERTED.Bemaerk, '') <> ISNULL(DELETED.Bemaerk, '')
		)
		MERGE dbo.Kunde2
			USING UpdKunde2
			ON Kunde2.Kundeid = UpdKunde2.KundeID
			WHEN MATCHED AND UpdKunde2.Bemaerk IS NULL
				THEN DELETE
			WHEN MATCHED
				THEN UPDATE SET Bemaerk = UpdKunde2.Bemaerk
			WHEN NOT MATCHED
				THEN INSERT (Kundeid, Bemaerk) VALUES (UpdKunde2.Kundeid, UpdKunde2.Bemaerk);

		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		THROW 65872, 'Kundeinfo kunne ikke opdateres', 1;
	END CATCH;
END;
GO
UPDATE dbo.Kunde	
	SET Adresse = 'Torvet 21',
		Postnr = 2200
	WHERE KundeId = 2;
GO
SELECT *
	FROM dbo.Kunde1;

SELECT *
	FROM dbo.Kunde2;

SELECT *
	FROM dbo.Kunde;
GO
UPDATE dbo.Kunde	
	SET Adresse = '�stergade 6',
		Postnr = 4400,
		Bemaerk = 'Flyttet til anden region'
	WHERE KundeId = 2;
GO
SELECT *
	FROM dbo.Kunde1;

SELECT *
	FROM dbo.Kunde2;

SELECT *
	FROM dbo.Kunde;
GO
UPDATE dbo.Kunde	
	SET Bemaerk = 'Klage'
	WHERE KundeId = 1;
GO
SELECT *
	FROM dbo.Kunde1;

SELECT *
	FROM dbo.Kunde2;

SELECT *
	FROM dbo.Kunde;
GO
UPDATE dbo.Kunde	
	SET Bemaerk = NULL
	WHERE KundeId = 1;
GO
SELECT *
	FROM dbo.Kunde1;

SELECT *
	FROM dbo.Kunde2;

SELECT *
	FROM dbo.Kunde;
GO
CREATE TRIGGER del_Kunde ON dbo.Kunde
INSTEAD OF DELETE
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
		BEGIN TRANSACTION;

		DELETE
			FROM dbo.Kunde2
			WHERE Kundeid IN
				(SELECT Kundeid 
					FROM DELETED);
	
		DELETE
			FROM dbo.Kunde1
			WHERE Kundeid IN
				(SELECT Kundeid 
					FROM DELETED);

		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		THROW 65874, 'Kundeinfo kunne ikke slettes', 1;
	END CATCH;
END;
GO
DELETE dbo.Kunde	
	WHERE KundeId = 1;
GO
SELECT *
	FROM dbo.Kunde1;

SELECT *
	FROM dbo.Kunde2;

SELECT *
	FROM dbo.Kunde;
GO
DELETE dbo.Kunde	
	WHERE KundeId = 111;
GO
SELECT *
	FROM dbo.Kunde1;

SELECT *
	FROM dbo.Kunde2;
GO
UPDATE dbo.Kunde	
	SET Bemaerk = NULL
	WHERE KundeId = 2;
GO
DELETE dbo.Kunde	
	WHERE KundeId = 2;
GO
SELECT *
	FROM dbo.Kunde1;

SELECT *
	FROM dbo.Kunde2;
GO
