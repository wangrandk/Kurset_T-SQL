USE master;
-- Aktiv�r muligheden for at afvikle eksterne programmer
-- vha. af EXEC xp_cmdshell
EXEC sp_configure 'show advanced options', 1;
GO
RECONFIGURE;
GO
EXEC sp_configure 'xp_cmdshell', 1;
GO
RECONFIGURE;
GO
-- Opret hj�lpekatalog
EXEC xp_cmdshell 'mkdir C:\Rod\';
GO
