USE master;
GO
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB;
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	i		INT IDENTITY, 
	txt		CHAR(8000) DEFAULT 'xxxx'
);

BACKUP DATABASE BackupDB TO DISK = 'c:/rod/BackupDb.Bak' WITH FORMAT;
BACKUP LOG BackupDB TO DISK = 'c:/rod/BackupDb.Log' WITH FORMAT;

CREATE TABLE dbo.SqlperfLogspace 
(
	DbName		SYSNAME,
	Logsize		FLOAT,
	Logpct		FLOAT,
	Status		SMALLINT,
	Time		DATETIME2 DEFAULT(SYSDATETIME())
)
GO
--USE master;
--EXEC sp_dropdevice 'Backupdev', 'DELFILE'
--EXEC sp_addumpdevice 'DISK', 'Backupdev', 'c:\rod\Backupdev.bak'
--GO
--BACKUP DATABASE BackupDB TO Backupdev
--GO
USE BackupDB;
DECLARE @i		INT = 1;

INSERT INTO dbo.t DEFAULT VALUES;

WHILE @i <= 12
BEGIN
	INSERT INTO dbo.t
		SELECT txt 
			FROM dbo.t;
		
	SET @i += 1;

	BACKUP DATABASE BackupDB TO DISK = 'c:/Rod/BackupDB.bak' WITH FORMAT;

	INSERT INTO dbo.SqlperfLogspace (DbName, Logsize, Logpct, Status)
		EXEC ('DBCC SQLPERF(LOGSPACE)');
END;

SELECT	*,
		CAST(Logsize / 100.0 * Logpct AS DECIMAL(9,3)) AS LogdataInMB
	FROM dbo.SqlperfLogspace 
	WHERE DbName = 'BackupDB' 
	ORDER BY Time;
GO
