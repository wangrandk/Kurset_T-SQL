USE master;
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY
	(NAME = BackupDB_sys,
	 FILENAME = 'c:\Databaser\BackupDB_sys.mdf',
     SIZE = 5MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%),

FILEGROUP BackupDB_FILEGROUP_1
	(NAME = BackupDB_fg1_1,
	 FILENAME = 'c:\Databaser\BackupDB_fg1_1.ndf',
     SIZE = 2MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%),
	
FILEGROUP BackupDB_FILEGROUP_2
	(NAME = BackupDB_fg2_1,
	 FILENAME = 'c:\Databaser\BackupDB_fg2_1.ndf',
     SIZE = 2MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%),
	
FILEGROUP BackupDB_FILEGROUP_3
	(NAME = BackupDB_fg3_1,
	 FILENAME = 'c:\Databaser\BackupDB_fg3_1.ndf',
     SIZE = 2MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%)

LOG ON
	(NAME = BackupDB_log,
	 FILENAME = 'c:\Databaser\BackupDB.ldf',
     SIZE = 2MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%);
GO
USE BackupDB;;
CREATE TABLE dbo.t1 
(
	i		INT
) ON BackupDB_FILEGROUP_1;
CREATE TABLE dbo.t2 
(
	i		INT
) ON BackupDB_FILEGROUP_2;
CREATE TABLE dbo.t3 
(
	i		INT
) ON BackupDB_FILEGROUP_3;
GO
SET NOCOUNT ON;
INSERT INTO dbo.t1 VALUES
	(11),
	(12),
	(13);

INSERT INTO dbo.t2 VALUES
	(21),
	(22),
	(23);

INSERT INTO dbo.t3 VALUES
	(31),
	(32),
	(33);
SET NOCOUNT OFF;
GO
ALTER DATABASE BackupDB  MODIFY FILEGROUP  BackupDB_FILEGROUP_3 READ_ONLY;
GO
BACKUP DATABASE BackupDB  READ_WRITE_FILEGROUPS 
	TO DISK = 'c:\rod\Full.bak'
	WITH FORMAT;
GO
BACKUP LOG BackupDB TO DISK = 'c:\rod\BackupDB_log1.bak' WITH FORMAT;
GO
