USE master;
GO
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB;
GO
BACKUP DATABASE BackupDB 
	TO DISK='C:\Rod\BackupDB.bak' WITH INIT;
GO
USE BackupDB;
GO
CREATE TABLE dbo.Person
(
	ID			INT NOT NULL IDENTITY,
	Dato		DATETIME2 NOT NULL DEFAULT(SYSDATETIME()),
	Navn		VARCHAR(20) NOT NULL
); 
GO
INSERT INTO dbo.Person(Navn) VALUES
	('Ole'),
	('Ane'),
	('Per'),
	('Ida'),
	('Vivi'),
	('Tina');
GO
SELECT *
	FROM dbo.Person;
GO
BACKUP DATABASE BackupDB 
	TO DISK='C:\Rod\BackupDB.bak' WITH INIT;
GO
SELECT	*
	FROM fn_dblog(NULL, NULL);
GO
BACKUP LOG BackupDB 
	TO DISK='C:\Rod\BackupDB.log' WITH INIT;
GO
SELECT	*
	FROM fn_dblog(NULL, NULL);
GO
INSERT INTO dbo.Person(Navn) VALUES
	('Ole')
GO
SELECT	*
	FROM fn_dblog(NULL, NULL);
GO
BACKUP DATABASE BackupDB 
	TO DISK='C:\Rod\BackupDB.bak';
GO
SELECT	*
	FROM fn_dblog(NULL, NULL);
GO
BACKUP LOG BackupDB 
	TO DISK='C:\Rod\BackupDB.log' WITH INIT;