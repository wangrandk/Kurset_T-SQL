USE master;
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDb;
GO
DROP TABLE #tid;
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	i			INT
);
CREATE TABLE #tid 
(
	stoptid		DATETIME)
;
GO
USE master;
EXEC sp_addumpdevice 'DISK', 'Backupdev', 'c:\rod\Backupdev.bak';
GO
BACKUP DATABASE BackupDB TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;

BEGIN TRANSACTION;
INSERT INTO dbo.t VALUES
	(1),
	(2),
	(3),
	(4);
COMMIT TRANSACTION;
GO
BEGIN TRANSACTION xx WITH MARK 'dette er mark xx';
UPDATE dbo.t 
	SET i = i + 10;
COMMIT TRANSACTION xx;
GO
BEGIN TRANSACTION xx WITH MARK 'dette er mark xx';
UPDATE dbo.t 
	SET i = i + 10;
COMMIT TRANSACTION xx;
GO
BEGIN TRANSACTION xx WITH MARK 'dette er mark xx';
UPDATE dbo.t 
	SET i = i + 10;
COMMIT TRANSACTION xx;

WAITFOR DELAY '00:00:00:10';
INSERT INTO #tid VALUES(GETDATE());
WAITFOR DELAY '00:00:00:10';
GO
BEGIN TRANSACTION xx WITH marK 'dette er mark xx';
UPDATE dbo.t 
	SET i = i + 10;
COMMIT TRANSACTION xx;
GO
BEGIN TRANSACTION xx WITH mark 'dette er mark xx';
UPDATE dbo.t 
	SET i = i + 10;
COMMIT TRANSACTION xx;
SET NOCOUNT OFF;
GO
SELECT * FROM t
GO
BACKUP LOG BackupDB TO Backupdev;
GO
USE msdb;
SELECT *
	FROM logmarkhistory;
GO
USE master;
RESTORE DATABASE BackupDB FROM Backupdev WITH FILE= 1, NORECOVERY;
GO
DECLARE @tid	DATETIME;

SELECT @tid = stoptid 
	FROM #tid;

--RESTORE LOG BackupDB FROM Backupdev WITH FILE=2, RECOVERY, 
--STOPATMARK='xx' AFTER @tid;

RESTORE LOG BackupDB FROM Backupdev WITH FILE=2, RECOVERY , 
	STOPBEFOREMARK='xx' AFTER @tid;
GO
EXEC sp_dropdevice 'Backupdev', 'DELFILE';
GO
USE BackupDB;
SELECT * 
	FROM dbo.t;
					 