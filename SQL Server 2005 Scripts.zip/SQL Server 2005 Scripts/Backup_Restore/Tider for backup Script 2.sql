USE BackupDB
GO
UPDATE dbo.Person
	SET Fornavn = 'Olfert', Efternavn = 'Olsen'
	WHERE Personid = (SELECT MIN(PersonId) 
							FROM dbo.Person
							WHERE Navn = 'Vagn Jensen');
GO 20
USE master;
