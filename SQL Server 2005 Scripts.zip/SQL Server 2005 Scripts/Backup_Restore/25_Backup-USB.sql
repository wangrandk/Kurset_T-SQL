USE master;
GO
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY
	( NAME = BackupDB_file_sys,
	  FILENAME = 'E:\BackupDB_sys.mdf',
      SIZE = 5MB,
      MAXSIZE = 10MB,
      FILEGROWTH = 10%),
	
FILEGROUP BackupDB_group_1
	( NAME = BackupDB_file_1,
	  FILENAME = 'F:\BackupDB_1.ndf',
      SIZE = 10MB,
      MAXSIZE = 20MB,
      FILEGROWTH = 10%),
	
FILEGROUP BackupDB_group_2
	( NAME = BackupDB_file_2,
	  FILENAME = 'G:\BackupDB_2.ndf',
      SIZE = 10MB,
      MAXSIZE = 20MB,
      FILEGROWTH = 10%),

FILEGROUP BackupDB_group_3
	( NAME = BackupDB_file_3,
	  FILENAME = 'H:\BackupDB_3.ndf',
      SIZE = 10MB,
      MAXSIZE = 20MB,
      FILEGROWTH = 10%)

LOG ON
	( NAME = BackupDB_log_file_1,
	  FILENAME = 'I:\BackupDB_log_1.ldf',
      SIZE = 10MB,
      MAXSIZE = 20MB,
      FILEGROWTH = 10%);
GO
USE BackupDB;
CREATE TABLE dbo.t1 
(
	c1		INT NOT NULL, 
	c2		INT 
) ON BackupDB_group_1;

CREATE TABLE dbo.t2 
(
	c1		INT NOT NULL, 
	c2		INT 
) ON BackupDB_group_2;
GO
CREATE TABLE dbo.t3 
(
	c1		INT NOT NULL, 
	c2		INT 
) ON BackupDB_group_3;
GO
EXEC sp_dropdevice 'Backupdev', 'DELFILE';
EXEC sp_addumpdevice 'DISK', 'Backupdev', 'c:\rod\Backupdev.bak';
GO
BACKUP DATABASE BackupDB TO Backupdev WITH FORMAT;
GO
SET NOCOUNT ON;
INSERT INTO dbo.t1 VALUES
	(1, 1),
	(2, 2),
	(3, 3),
	(4, 4);
SET NOCOUNT OFF;
GO
SET NOCOUNT ON;
INSERT INTO dbo.t2 VALUES
	(1, 1),
	(2, 2),
	(3, 3),
	(4, 4);
SET NOCOUNT OFF;
GO
SET NOCOUNT ON;
INSERT INTO dbo.t3 VALUES
	(1, 1),
	(2, 2),
	(3, 3),
	(4, 4);
SET NOCOUNT OFF;
GO
BACKUP LOG BackupDB TO Backupdev;
GO
BACKUP DATABASE BackupDB FILEGROUP='BackupDB_group_1' TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;
INSERT INTO dbo.t1 VALUES
	(5, 5),
	(6, 6);
SET NOCOUNT OFF;
GO
BACKUP DATABASE BackupDB FILEGROUP='BackupDB_group_2' TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;
INSERT INTO dbo.t2 VALUES
	(5, 5),
	(6, 6);
SET NOCOUNT OFF;
GO
USE master;
--fil  C:\Databaser\BackupDB_2.ndf �delagt
BACKUP LOG BackupDB TO Backupdev WITH NO_TRUNCATE;
GO
RESTORE DATABASE BackupDB FILEGROUP='BackupDB_group_2' FROM Backupdev WITH FILE = 4, NORECOVERY;
GO
RESTORE LOG BackupDB FROM Backupdev WITH FILE = 5, RECOVERY; 
GO
USE BackupDB;
SELECT * 
	FROM dbo.t1;
SELECT * 
	FROM dbo.t2;
GO
