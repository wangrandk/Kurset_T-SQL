USE master;
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY 
	( NAME = BackupDB_file_1,
      FILENAME = N'c:\databaser\BackupDB.mdf',
      SIZE = 5MB,
      MAXSIZE = 5MB,
      FILEGROWTH = 10%)

LOG ON 
	( NAME = BackupDB_log_file_1,
	  FILENAME = N'c:\databaser\BackupDB_log.ldf',
      SIZE = 1MB,
      MAXSIZE = 2MB,
      FILEGROWTH = 10%);
GO
USE BackupDB;
CREATE TABLE dbo.t
(
	i		INT
);
GO
USE master;
EXEC sp_dropdevice 'Backupdev', 'DELFILE';
EXEC sp_addumpdevice 'DISK', 'Backupdev', 'c:\rod\Backupdev.bak';
GO
BACKUP DATABASE BackupDB TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;
INSERT INTO dbo.t VALUES
	(1),
	(2),
	(3),
	(4);
SET NOCOUNT OFF;
GO
BACKUP LOG BackupDB TO Backupdev;
GO
USE BackupDB;
CREATE TABLE dbo.tNy
(
	i		INT,
	j		INT,
	k		INT
);
GO
ALTER TABLE dbo.t ADD j	INT NOT NULL DEFAULT (7);
GO
SET NOCOUNT ON;
INSERT INTO t VALUES
	(5, 8),
	(6, 8);
GO
--�delagt datafil
USE master;
ALTER DATABASE BackupDB SET OFFLINE;
EXEC master..xp_cmdshell 'del c:\databaser\BackupDB.mdf';
ALTER DATABASE BackupDB SET ONLINE;
--backup af log
-- BACKUP LOG BackupDB TO Backupdev WITH NO_TRUNCATE;						- gl udgave
-- eller
BACKUP LOG BackupDB TO Backupdev WITH  COPY_ONLY, CONTINUE_AFTER_ERROR;		-- ny udgave
GO
USE master;
DROP DATABASE BackupDB;
RESTORE DATABASE BackupDB FROM Backupdev WITH FILE = 1, NORECOVERY, REPLACE;
GO
RESTORE LOG BackupDB FROM Backupdev WITH FILE = 2, NORECOVERY;
GO
RESTORE LOG BackupDB FROM Backupdev WITH FILE = 3, RECOVERY;
GO
USE BackupDB;
SELECT * 
	FROM dbo.t;

SELECT * 
	FROM dbo.tNy;
