USE master;
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB;
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	i		INT
);
GO
USE master;
EXEC sp_dropdevice 'Backupdev', 'DELFILE'
EXEC sp_addumpdevice 'DISK', 'Backupdev', 'c:\rod\Backupdev.bak'
GO
BACKUP DATABASE BackupDB TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;

BEGIN TRANSACTION;
INSERT INTO dbo.t VALUES
	(1),
	(2),
	(3),
	(4);
COMMIT TRANSACTION;
GO
BEGIN TRANSACTION xx WITH MARK 'dette er mark xx';
UPDATE dbo.t 
	SET i = i + 10 
	WHERE i IN (1, 2);
COMMIT TRANSACTION xx;
GO
BEGIN TRANSACTION;
INSERT INTO dbo.t VALUES
	(5),
	(6);
COMMIT TRANSACTION;
SET NOCOUNT OFF;
GO
BACKUP LOG BackupDB TO Backupdev;
GO
USE master;
DROP DATABASE BackupDB;
GO
USE master;
RESTORE DATABASE BackupDB FROM Backupdev WITH FILE= 1, NORECOVERY;
GO
RESTORE LOG BackupDB FROM Backupdev WITH FILE=2, NORECOVERY, STOPATMARK='xx';
RESTORE LOG BackupDB  WITH RECOVERY;

--RESTORE LOG BackupDB FROM Backupdev WITH FILE=2, RECOVERY , STOPBEFOREMARK='xx';

GO
USE BackupDB;
SELECT * 
	FROM dbo.t
					 