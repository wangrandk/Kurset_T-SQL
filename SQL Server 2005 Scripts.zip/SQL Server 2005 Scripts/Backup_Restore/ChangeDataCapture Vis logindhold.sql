USE master
GO
DROP DATABASE TrackingDB;
GO
CREATE DATABASE TrackingDB;
GO
USE TrackingDB;
GO
CREATE TABLE dbo.Person (
	ID			INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(30) NOT NULL,
	Gade		VARCHAR(30) NOT NULL,
	Postnr		SMALLINT NOT NULL,
	Koen		CHAR(1) NOT  NULL);
GO
INSERT INTO Person VALUES
	(1, 'Ole Jensen', 'Vestergade 11', 8000, 'M'),
	(2, 'Ida Hansen', '�stergade 3', 1129, 'K'),
	(3, 'Carl Larsen', 'Torvet 1', 9400, 'M'),
	(4, 'Sofie Petersen', 'S�ndergade 123', 3000, 'M');
GO
USE TrackingDB;
EXEC sys.sp_cdc_enable_db;
GO
EXEC sys.sp_cdc_enable_table 
	@source_schema = N'dbo',
	@source_name = N'Person',
	@role_name = NULL,
	@supports_net_changes = 1;
GO
UPDATE Person
	SET Navn = 'Jens Ole Jensen'
	WHERE ID = 1;
	
UPDATE Person
	SET Gade = 'S�ndergade 2'
	WHERE ID = 1;

UPDATE Person
	SET Postnr = 2000
	WHERE ID = 1;

UPDATE Person
	SET Koen = 'K'
	WHERE ID = 4;

DELETE FROM Person
	WHERE ID = 2;
	
INSERT INTO Person VALUES
	(5, 'Hans Jensen', 'Knudsgade 21', 8000, 'M'),
	(6, 'Ida Hansen', '�stergade 3', 1129, 'K'),
	(7, 'Carl Larsen', 'Torvet 1', 9400, 'M'),
	(8, 'Sofie Petersen', 'S�ndergade 123', 3000, 'K');

BEGIN TRANSACTION
INSERT INTO Person VALUES
	(9, 'Knud Olsen', 'S�ndergade 121', 8000, 'M');

UPDATE Person
	SET Postnr = 2000
	WHERE ID = 9;

COMMIT TRANSACTION

SELECT *
	FROM Person;
GO
DECLARE @From	BINARY(10) = sys.fn_cdc_get_min_lsn ('dbo_Person'),
		@To		BINARY(10) = sys.fn_cdc_get_max_lsn ();

SELECT *
	FROM cdc.fn_cdc_get_all_changes_dbo_Person (@From, @To, N'all update old') AS r;
GO
EXEC sys.sp_cdc_disable_table
	@source_schema = N'dbo',
	@source_name = N'Person',
	@capture_instance = 'all';
GO
EXEC sys.sp_cdc_disable_db;
