USE master;
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDb;
GO
USE BackupDB;
CREATE TABLE dbo.t
(
	i		INT
);
GO
USE master;
GO
EXEC sp_dropdevice 'Backupdev', 'DELFILE';
EXEC sp_addumpdevice 'DISK', 'Backupdev', 'c:\rod\Backupdev.bak';
GO
BACKUP DATABASE BackupDB TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;
INSERT INTO dbo.t VALUES
	(1),
	(2),
	(3),
	(4);
SET NOCOUNT OFF;
GO
BACKUP DATABASE BackupDB TO Backupdev WITH DIFFERENTIAL;
GO
BACKUP LOG BackupDB TO Backupdev WITH COPY_ONLY;
GO
BACKUP LOG BackupDB TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;
INSERT INTO dbo.t VALUES
	(5),
	(6),
	(7),
	(8);
SET NOCOUNT OFF;
GO
BACKUP LOG BackupDB TO Backupdev;
GO
RESTORE HEADERONLY FROM Backupdev;
RESTORE FILELISTONLY FROM Backupdev;
RESTORE VERIFYONLY FROM Backupdev;
RESTORE LABELONLY FROM Backupdev;
