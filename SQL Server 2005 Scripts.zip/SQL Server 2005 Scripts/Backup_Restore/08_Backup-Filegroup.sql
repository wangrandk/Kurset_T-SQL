USE master;
GO
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY
	( NAME = BackupDB_file_1,
	  FILENAME = 'C:\Databaser\BackupDB_p.mdf',
      SIZE = 5MB,
      MAXSIZE = 6MB,
      FILEGROWTH = 10%),
	
FILEGROUP BackupDB_group_1
	( NAME = BackupDB_file_2,
	  FILENAME = 'C:\Databaser\BackupDB_1.ndf',
      SIZE = 2MB,
      MAXSIZE = 2MB,
      FILEGROWTH = 10%),
	
FILEGROUP BackupDB_group_2
	( NAME = BackupDB_file_4,
	  FILENAME = 'C:\Databaser\BackupDB_2.ndf',
      SIZE = 2MB,
      MAXSIZE = 2MB,
      FILEGROWTH = 10%)

LOG ON
	( NAME = BackupDB_log_file_1,
	  FILENAME = 'C:\Databaser\BackupDB_log_1.ldf',
      SIZE = 1MB,
      MAXSIZE = 2MB,
      FILEGROWTH = 10%);
GO
USE Backupdb;
CREATE TABLE dbo.t1 
(
	c1 INT NOT NULL, 
	c2 INT 
) 
ON BackupDB_group_1;

CREATE TABLE dbo.t2 
(
	c1 INT NOT NULL, 
	c2 INT 
) 
ON BackupDB_group_2;
GO
EXEC sp_dropdevice 'Backupdev', 'DELFILE';
EXEC sp_addumpdevice 'DISK', 'Backupdev', 'c:\rod\Backupdev.bak';
GO
BACKUP DATABASE BackupDB TO Backupdev WITH FORMAT;
GO
SET NOCOUNT ON;

INSERT INTO dbo.t1 VALUES
	(1,1),
	(2,2),
	(3,3),
	(4,4);

SET NOCOUNT OFF;
GO
SET NOCOUNT ON;

INSERT INTO dbo.t2 VALUES
	(1,1),
	(2,2),
	(3,3),
	(4,4);

SET NOCOUNT OFF;
GO
BACKUP LOG BackupDB TO Backupdev;
GO
BACKUP DATABASE BackupDB FILEGROUP='BackupDB_group_1' TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;

INSERT INTO dbo.t1 VALUES
	(5,5),
	(6,6);

SET NOCOUNT OFF;
GO
BACKUP DATABASE BackupDB FILEGROUP='BackupDB_group_2' TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;

INSERT INTO dbo.t2 VALUES
	(5,5),
	(6,6);

SET NOCOUNT OFF;
GO
USE master;
--fil  c:\Databaser\BackupDB_2.ndf �delagt
ALTER DATABASE BackupDB SET OFFLINE;
EXEC master..xp_cmdshell 'del c:\Databaser\BackupDB_2.ndf';
ALTER DATABASE BackupDB SET ONLINE;
--backup af log
BACKUP LOG BackupDB TO Backupdev WITH COPY_ONLY, CONTINUE_AFTER_ERROR;
GO
RESTORE DATABASE BackupDB FILEGROUP='BackupDB_group_2' FROM Backupdev WITH FILE = 4, NORECOVERY;
GO
RESTORE LOG BackupDB FROM Backupdev WITH FILE = 5, RECOVERY;
GO
USE BackupDB;

SELECT * 
	FROM dbo.t1;

SELECT * 
	FROM dbo.t2;
GO
