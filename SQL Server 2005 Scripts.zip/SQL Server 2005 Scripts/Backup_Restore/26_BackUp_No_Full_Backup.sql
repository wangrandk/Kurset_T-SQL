USE master;
GO
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB;
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	i		INT IDENTITY, 
	txt		CHAR(8000) DEFAULT 'xxxx'
);

-- BACKUP DATABASE BackupDB TO DISK = 'c:/rod/BackupDb.Bak' WITH FORMAT

CREATE TABLE dbo.SqlperfLogspace 
(
	DbName		SYSNAME,
	Logsize		FLOAT,
	Logpct		FLOAT,
	Status		SMALLINT,
	Time		DATETIME2 DEFAULT(SYSDATETIME())
)
GO
--USE master;
--EXEC sp_dropdevice 'Backupdev', 'DELFILE'
--EXEC sp_addumpdevice 'DISK', 'Backupdev', 'c:\rod\Backupdev.bak'
--GO
--BACKUP DATABASE BackupDB TO Backupdev
--GO
USE BackupDB;
DECLARE @i		INT = 1;

INSERT INTO dbo.t DEFAULT VALUES;

WHILE @i < 14
BEGIN
	INSERT INTO dbo.t
		SELECT txt 
			FROM dbo.t;
		
	SET @i = @i + 1;

	INSERT INTO dbo.SqlperfLogspace (DbName, Logsize, Logpct, Status)
		EXEC ('DBCC SQLPERF(LOGSPACE)');
END;

SELECT * 
	FROM dbo.SqlperfLogspace 
	WHERE DbName = 'BackupDB' 
	ORDER BY Time;
GO
-- efter 1 min ser vi igen p� log-st�rrelsen
INSERT INTO dbo.SqlperfLogspace (DbName, Logsize, Logpct, Status)
	EXEC ('DBCC SQLPERF(LOGSPACE)');

SELECT * 
	FROM dbo.SqlperfLogspace 
	WHERE DbName = 'BackupDB' 
	ORDER BY Time;

-- CHECKPOINT

SELECT COUNT(*)
	FROM dbo.t;

DBCC LOGINFO;

BACKUP LOG BackupDB TO Backupdev;

DBCC SHRINKFILE (BackupDb_log, 1);
