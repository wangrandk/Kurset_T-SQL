USE BIDB
GO
--FileID			Physical log file identifier FROM sysfiles 
--FileSize			Virtual log file size 
--StartOffSET		Beginning poINT of the virtual log file 
--FSeqNo			Virtual log file's sequence number 
--Status			Whether the virtual file contains the active part of the log (logical log).
--					0 means that virtual file does not contain the active portion of the log; 2 means that it does 
--Parity			Parity information for virtual log file 
--CreateLSN			Log sequence number that began the virtual log file 

BEGIN TRANSACTION
UPDATE DataWarehoUSE.Kunde
	SET Efternavn = 'Jensen'
	WHERE KundeID = (SELECT MIN(KundeID) FROM DataWarehoUSE.Kunde)

DBCC OPENTRAN

ROLLBACK TRANSACTION
