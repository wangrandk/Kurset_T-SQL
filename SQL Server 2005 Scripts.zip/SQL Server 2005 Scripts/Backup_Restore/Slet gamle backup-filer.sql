-- Slet all .bak filer i C:\Backup og under-kataloger, hvor 'file modified date' er �ldre en  18. oktober 2010.

EXEC xp_cmdshell 'FORFILES /p c:\BACKUP /s /m *.bak /d 10/18/2010 /c "CMD /C del /Q /F @FILE"' 

-- Slet all .bak filer i C:\Backup og under-kataloger, hvor 'file modified date' er mere END 30 dage gammel

EXEC xp_cmdshell 'FORFILES /p c:\BACKUP /s /m *.bak /d -30 /c "CMD /C del /Q /F @FILE"' 

-- Slet all .bak filer i C:\Backup og under-kataloger, hvor 'file modified date' er mere END 30 dage gammel og filnavn starter med "F_".

EXEC xp_cmdshell 'FORFILES /p c:\BACKUP /s /m F_*.bak /d -30 /c "CMD /C del /Q /F @FILE"' 

