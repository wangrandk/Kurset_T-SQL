USE master;
GO
DROP DATABASE ReadinglogDB;
GO
CREATE DATABASE ReadinglogDB;
GO
BACKUP DATABASE ReadinglogDB 
	TO DISK='C:\Rod\ReadinglogDB.bak' WITH INIT;
GO
USE ReadinglogDB;
GO
CREATE TABLE dbo.Person
(
	ID			INT NOT NULL IDENTITY,
	Dato		DATETIME2 NOT NULL DEFAULT(SYSDATETIME()),
	Navn		VARCHAR(20) NOT NULL
); 
GO
INSERT INTO dbo.Person(Navn) VALUES
	('Ole'),
	('Ane'),
	('Per'),
	('Ida'),
	('Lars'),
	('Maren'),
	('Anne'),
	('Sanne'),
	('�ge'),
	('�se'),
	('Knud'),
	('Dorte'),
	('Erik'),
	('Vivi'),
	('Tina');
GO
SELECT *
	FROM dbo.Person;
GO
DELETE
	FROM dbo.Person	
	WHERE ID <= 5;
GO
BACKUP LOG ReadinglogDB 
	TO DISK='C:\Rod\ReadinglogDB.log' WITH INIT;
GO
SELECT *
	FROM dbo.Person;
GO
SELECT	*,[Current LSN],    
		[Transaction ID],
		Operation,
		Context,
		AllocUnitName
	FROM fn_dblog(NULL, NULL)	
	WHERE	Operation = 'LOP_DELETE_ROWS' AND
			AllocUnitName = 'dbo.Person';
GO
SELECT	[Current LSN],    
		[Transaction ID],
		Operation,
		Context,
		AllocUnitName
	FROM fn_dblog(NULL, NULL)
	WHERE	[Transaction ID] = '0000:000002ff' AND
			[Operation] = 'LOP_BEGIN_XACT';
GO
USE master;
RESTORE DATABASE ReadinglogDB_COPY
		FROM DISK = 'C:\Rod\ReadinglogDB.bak'
	WITH
		MOVE 'ReadinglogDB' TO 'C:\Rod\ReadinglogDB.mdf',
		MOVE 'ReadinglogDB_log' TO 'C:\Rod\ReadinglogDB_log.ldf', REPLACE, NORECOVERY;
GO
-- konverter lsn 00000028:0000009a:0001 til numerisk : l�ngde for de 3 dele skal v�re 10 10 5 
-- konverteringen giver de nummereiske v�rdier : 40 154 1, s� lsn bliver  0000000040000000015400001
-- fjern foranstillede 0'er

--Restore Log backup with STOPBEFOREMARK option to recover exact LSN.
RESTORE LOG ReadinglogDB_COPY
	FROM DISK = 'C:\Rod\ReadinglogDB.log'
	WITH STOPBEFOREMARK = 'lsn:330000000015400002', NORECOVERY

RESTORE LOG ReadinglogDB_COPY WITH RECOVERY
GO
USE ReadinglogDB_COPY
GO
SELECT * 
	FROM dbo.Person;
GO
USE ReadinglogDB
GO
DROP TABLE dbo.Person;
GO
SELECT 
		[Current LSN],
		Operation,
		[Transaction Id],
		[Transaction SID],
		[Transaction Name],
		[Begin Time],
		[SPID],
		Description
	FROM fn_dblog (NULL, NULL)
	WHERE [Transaction Name] = 'DROPOBJ'
GO
