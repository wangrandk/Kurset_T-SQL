USE master;
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY 
	( NAME = BackupDB_file_1,
      FILENAME = N'c:\databaser\BackupDB.mdf',
      SIZE = 5MB,
      MAXSIZE = 5MB,
      FILEGROWTH = 10%)

LOG ON 
	( NAME = BackupDB_log_file_1,
	  FILENAME = N'c:\databaser\BackupDB_log.ldf',
      SIZE = 1MB,
      MAXSIZE = 2MB,
      FILEGROWTH = 10%);
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	i		INT
);
GO
USE master;
EXEC sp_dropdevice 'Backupdev', 'DELFILE';
EXEC sp_addumpdevice 'DISK', 'Backupdev', 'c:\rod\Backupdev.bak';
GO
BACKUP DATABASE BackupDB TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;
INSERT INTO dbo.t VALUES
	(1),
	(2),
	(3),
	(4);
SET NOCOUNT OFF;
GO
BACKUP LOG BackupDB TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;
INSERT INTO dbo.t VALUES
	(5),
	(6);
GO
--�delagt datafil
USE master;
ALTER DATABASE BackupDB SET OFFLINE;
EXEC master..xp_cmdshell 'del c:\databaser\BackupDB_log.ldf';
ALTER DATABASE BackupDB SET ONLINE;
GO
-- backup af data
USE master;
GO
BACKUP DATABASE BackupDB TO Backupdev;	  -- fejler
--detach
GO
EXEC master.dbo.sp_detach_db @dbNAME = N'BackupDB';    -- fejler
GO
-- stop service
USE master;
ALTER DATABASE BackupDB SET OFFLINE;
EXEC master..xp_cmdshell 'rename c:\databaser\BackupDB.mdf BackupDB1.mdf';
ALTER DATABASE BackupDB SET ONLINE;
-- start service
-- attach
