USE master;
DROP DATABASE BackupDb
GO
CREATE DATABASE BackupDB
ON PRIMARY 
	( NAME = BackupDB_file_1,
      FILENAME = N'c:\databaser\BackupDB.mdf',
      SIZE = 3MB,
      FILEGROWTH = 10%)

LOG ON 
	( NAME = BackupDB_log_file_1,
	  FILENAME = N'c:\databaser\BackupDB_log1.ldf',
      SIZE = 1MB,
      MAXSIZE = 1MB),
      
      ( NAME = BackupDB_log_file_2,
	  FILENAME = N'c:\databaser\BackupDB_log2.ldf',
      SIZE = 1MB,
      MAXSIZE = 1MB),
      
      ( NAME = BackupDB_log_file_3,
	  FILENAME = N'c:\databaser\BackupDB_log3.ldf',
      SIZE = 1MB,
      FILEGROWTH = 10%)
GO
BACKUP DATABASE BackupDB TO DISK = 'c:\rod\Backup.BAK' WITH FORMAT;
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	i			INT IDENTITY,
	txt			CHAR(8000) DEFAULT('xxxx')
);
GO
DECLARE @i		INT = 0;

INSERT INTO t DEFAULT VALUES;

WHILE @i < 10
BEGIN
	INSERT INTO dbo.t (txt)
		SELECT txt
			FROM dbo.t;
	SET @i += 1;
END 
GO
DBCC SHRINKFILE (BackupDB_log_file_2, EMPTYFILE);
GO
ALTER DATABASE BackupDB
	REMOVE FILE BackupDB_log_file_2;
GO
BACKUP LOG BackupDB TO DISK = 'BackupDB.log' WITH FORMAT;
GO
DECLARE @i		INT = 0;

INSERT INTO t DEFAULT VALUES;

WHILE @i < 3
BEGIN
	INSERT INTO dbo.t (txt)
		SELECT txt
			FROM dbo.t;
	SET @i += 1;
END 
GO
ALTER DATABASE BackupDB
	REMOVE FILE BackupDB_log_file_2;
