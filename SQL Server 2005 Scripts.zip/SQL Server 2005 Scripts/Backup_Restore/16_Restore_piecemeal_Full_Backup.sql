USE master;
DROP DATABASE BackupDB
GO
CREATE DATABASE BackupDB
ON PRIMARY
	(NAME = BackupDB_sys,
	 FILENAME = 'c:\Databaser\BackupDB_sys.mdf',
     SIZE = 5MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%),

FILEGROUP BackupDB_FILEGROUP_1
	(NAME = BackupDB_fg1_1,
	 FILENAME = 'c:\Databaser\BackupDB_fg1_1.ndf',
     SIZE = 2MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%),
	
FILEGROUP BackupDB_FILEGROUP_2
	(NAME = BackupDB_fg2_1,
	 FILENAME = 'c:\Databaser\BackupDB_fg2_1.ndf',
     SIZE = 2MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%),
	
FILEGROUP BackupDB_FILEGROUP_3
	(NAME = BackupDB_fg3_1,
	 FILENAME = 'c:\Databaser\BackupDB_fg3_1.ndf',
     SIZE = 2MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%)

LOG ON
	(NAME = BackupDB_log,
	 FILENAME = 'c:\Databaser\BackupDB.ldf',
     SIZE = 2MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%);
GO
USE BackupDB;
CREATE TABLE dbo.t1 
(
	i		INT
) ON BackupDB_FILEGROUP_1;
CREATE TABLE dbo.t2 
(
	i		INT
) ON BackupDB_FILEGROUP_2;
CREATE TABLE dbo.t3 
(	i		INT
) ON BackupDB_FILEGROUP_3;
GO
SET NOCOUNT ON
INSERT INTO dbo.t1 VALUES
	(11),
	(12),
	(13);

INSERT INTO dbo.t2 VALUES
	(21),
	(22),
	(23);

INSERT INTO dbo.t3 VALUES
	(31),
	(32),
	(33);
SET NOCOUNT OFF;
GO
ALTER DATABASE BackupDB  MODIFY FILEGROUP  BackupDB_FILEGROUP_3 READ_ONLY;
GO
BACKUP DATABASE BackupDB  TO DISK = 'c:\rod\full.bak' WITH FORMAT;
GO
BACKUP LOG BackupDB TO DISK = 'c:\rod\BackupDB_log1.bak' WITH FORMAT;
GO
SET NOCOUNT ON;
INSERT INTO dbo.t1 VALUES
	(14),
	(15),
	(16);

INSERT INTO dbo.t2 VALUES
	(24),
	(25),
	(26);
SET NOCOUNT OFF;
GO
BACKUP LOG BackupDB TO DISK = 'c:\rod\BackupDB_log2.bak' WITH FORMAT;
GO
USE master;
DROP DATABASE BackupDB;
GO
RESTORE DATABASE BackupDB 
	FILEGROUP='primary',
	FILEGROUP='BackupDB_FILEGROUP_1' FROM DISK = 'c:\rod\full.bak' 
	WITH PARTIAL, NORECOVERY;
RESTORE LOG BackupDB FROM DISK = 'c:\rod\BackupDB_log1.bak' WITH NORECOVERY;
RESTORE LOG BackupDB FROM DISK = 'c:\rod\BackupDB_log2.bak' WITH RECOVERY;
GO
USE BackupDB;
SELECT * 
	FROM dbo.t1;
GO
SELECT * 
	FROM dbo.t2;   -- fejl da kun FILEGROUP_1 er restored - t2 er i FILEGROUP_2
SELECT * 
	FROM dbo.t3;   -- fejl da kun FILEGROUP_1 er restored - t3 er i FILEGROUP_3
GO
USE master;
RESTORE DATABASE BackupDB FILEGROUP='BackupDB;_FILEGROUP_2' FROM DISK = 'c:\rod\full.bak' WITH NORECOVERY;
RESTORE LOG BackupDB FROM DISK = 'c:\rod\BackupDB_log1.bak' WITH NORECOVERY;
RESTORE LOG BackupDB FROM DISK = 'c:\rod\BackupDB_log2.bak' WITH RECOVERY;
GO
USE BackupDB;
SELECT * 
	FROM dbo.t1;
SELECT * 
	FROM dbo.t2;
GO
SELECT * 
	FROM dbo.t3;   -- fejl da kun FILEGROUP_1 + _2 er restored - t3 er i FILEGROUP_3
GO
USE master;
RESTORE DATABASE BackupDB FILEGROUP='BackupDB_FILEGROUP_3' FROM DISK = 'c:\rod\full.bak' WITH RECOVERY;
GO
USE BackupDB;
SELECT * 
	FROM dbo.t1;
SELECT * 
	FROM dbo.t2;
SELECT * 
	FROM dbo.t3; 
