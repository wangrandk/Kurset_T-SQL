USE master;
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY
	(NAME = BackupDB_sys,
	 FILENAME = 'e:\BackupDB_sys.mdf',
     SIZE = 5MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%),

FILEGROUP BackupDB_FILEGROUP_1
	(NAME = BackupDB_fg1_1,
	 FILENAME = 'f:\BackupDB_fg1_1.ndf',
     SIZE = 2MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%),
	
FILEGROUP BackupDB_FILEGROUP_2
	(NAME = BackupDB_fg2_1,
	 FILENAME = 'g:\BackupDB_fg2_1.ndf',
     SIZE = 2MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%),
	
FILEGROUP BackupDB_FILEGROUP_3
	(NAME = BackupDB_fg3_1,
	 FILENAME = 'h:\BackupDB_fg3_1.ndf',
     SIZE = 2MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%)

LOG ON
	(NAME = BackupDB_log,
	 FILENAME = 'i:\BackupDB.ldf',
     SIZE = 2MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%);
GO
USE BackupDB;
CREATE PARTITION FUNCTION PartitionFunction (INT)
	AS RANGE LEFT FOR VALUES (10, 30);
GO
CREATE PARTITION SCHEME PartitionSchema
	AS PARTITION PartitionFunction TO (BackupDB_FILEGROUP_1, BackupDB_FILEGROUP_2, BackupDB_FILEGROUP_3);
GO
CREATE TABLE dbo.PartitionTable 
(
	ID			INT NOT NULL IDENTITY, 
	Navn		CHAR(10) NOT NULL,
	Lokation	INT NOT NULL CHECK (Lokation > 0)
) ON PartitionSchema (Lokation);
GO
SET NOCOUNT ON;
INSERT INTO dbo.PartitionTable VALUES
	('Ole', 2),
	('Per', 3),
	('Ane', 5),
	('Hanne', 12),
	('Ida', 17),
	('Inga', 21),
	('Bo', 22),
	('Ib', 25),
	('Emma', 26);
SET NOCOUNT ON;
SELECT * 
	FROM dbo.PartitionTable;
GO
BACKUP DATABASE BackupDB TO DISK = 'c:\rod\backupdb.bak' WITH FORMAT;
GO
-- diskcrash
SELECT * 
	FROM dbo.PartitionTable 
	WHERE Lokation between 2 and 20;
GO
SELECT * 
	FROM dbo.PartitionTable 
	WHERE Lokation between 1 and 10;
GO
CHECKPOINT;
BACKUP LOG BackupDB TO DISK = 'c:\rod\BackupDB_log.bak' WITH NO_TRUNCATE;
GO
USE master
RESTORE DATABASE BackupDB FILEGROUP='BackupDB_FILEGROUP_2' FROM  DISK = 'c:\rod\backupdb.bak' WITH NORECOVERY;
RESTORE LOG BackupDB FROM DISK = 'c:\rod\BackupDB_log.bak' WITH RECOVERY;
