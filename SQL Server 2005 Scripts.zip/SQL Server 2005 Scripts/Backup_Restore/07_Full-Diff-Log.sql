USE master;
GO
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY 
	( NAME = BackupDB_file_1,
	FILENAME = N'c:\databaser\BackupDB.mdf',
	SIZE = 400MB,
	MAXSIZE = 600MB,
	FILEGROWTH = 10%)

LOG ON 
	( NAME = BackupDB_log_file_1,
	  FILENAME = N'c:\databaser\BackupDB_log.ldf',
	  SIZE = 50MB,
	  MAXSIZE = 400MB,
	  FILEGROWTH = 10%);
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	id		INT NOT NULL IDENTITY (1,1) PRIMARY KEY CLUSTERED, 
	c		CHAR(1996) NOT NULL
);
GO
SET NOCOUNT ON;
DECLARE @i	INT;

INSERT INTO dbo.t VALUES('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');

SET @i = 1;

WHILE @i <= 17
BEGIN
	INSERT INTO t 
	    SELECT c FROM dbo.t;

	SET @i += 1;
END;

SELECT COUNT(*) 
	FROM dbo.t;

SET NOCOUNT OFF;
GO
BACKUP DATABASE BackupDB TO DISK = 'c:\rod\fullbackup.bak' WITH FORMAT;
GO
SET NOCOUNT ON;

DECLARE @i		INT;

SET @i = 1;

WHILE @i <= 100
BEGIN
	INSERT INTO t VALUES('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');

	SET @i += 1;
END;
SET NOCOUNT ON;
GO
BACKUP DATABASE BackupDB TO DISK = 'c:\rod\diff1.bak' WITH FORMAT, DIFFERENTIAL;
GO
SET NOCOUNT ON;
INSERT INTO dbo.t VALUES
	('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'),
	('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');

BACKUP LOG BackupDB TO DISK = 'c:\rod\log1.bak' WITH FORMAT;

SET NOCOUNT OFF;
GO
SET NOCOUNT ON;
INSERT INTO dbo.t VALUES
	('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'),
	('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');

UPDATE dbo.t 
	SET c = 'yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy' 
	WHERE ID < 20000;
UPDATE dbo.t 
	SET c = 'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz' 
	WHERE ID < 20000;
UPDATE dbo.t
	SET c = 'uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu' 
	WHERE ID < 20000;
UPDATE dbo.t 
	SET c = 'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv' 
	WHERE ID < 20000;

BACKUP LOG BackupDB TO DISK = 'c:\rod\log2.bak' WITH FORMAT;
SET NOCOUNT OFF;
GO
SET NOCOUNT ON;
DECLARE @i		INT;

SET @i = 1;

WHILE @i <= 500
BEGIN
	INSERT INTO t VALUES('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
	SET @i += 1
END
SET NOCOUNT OFF;
GO
BACKUP DATABASE BackupDB TO DISK = 'c:\rod\diff2.bak' WITH FORMAT, DIFFERENTIAL;
GO
SET NOCOUNT ON;

INSERT INTO dbo.t VALUES
	('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'),
	('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');

BACKUP LOG BackupDB TO DISK = 'c:\rod\log3.bak' WITH FORMAT;
SET NOCOUNT OFF;
GO
USE BackupDB;
SELECT COUNT(*) 
	FROM dbo.t;
SELECT MAX(id) 
	FROM dbo.t;
GO
USE master;
DROP DATABASE BackupDB;
RESTORE DATABASE BackupDB FROM DISK = 'c:\rod\fullbackup.bak' WITH NORECOVERY;
GO
RESTORE DATABASE BackupDB FROM DISK = 'c:\rod\diff2.bak' WITH NORECOVERY;
GO
RESTORE LOG BackupDB FROM DISK = 'c:\rod\log3.bak' WITH RECOVERY;
GO
USE BackupDB;
SELECT COUNT(*) 
	FROM dbo.t;
SELECT MAX(id) 
	FROM dbo.t;
GO
USE master;
DROP DATABASE BackupDB;
RESTORE DATABASE BackupDB FROM DISK = 'c:\rod\fullbackup.bak' WITH NORECOVERY;
GO
RESTORE LOG BackupDB FROM DISK = 'c:\rod\log1.bak' WITH NORECOVERY;
RESTORE LOG BackupDB FROM DISK = 'c:\rod\log2.bak' WITH NORECOVERY;
RESTORE LOG BackupDB FROM DISK = 'c:\rod\log3.bak' WITH RECOVERY;
GO
------------------------------------------------------------
USE master;
GO
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY 
	( NAME = BackupDB_file_1,
	FILENAME = N'c:\databaser\BackupDB.mdf',
	SIZE = 10MB,
	MAXSIZE = 600MB,
	FILEGROWTH = 10%)

LOG ON 
	( NAME = BackupDB_log_file_1,
	  FILENAME = N'c:\databaser\BackupDB_log.ldf',
	  SIZE = 5MB,
	  MAXSIZE = 400MB,
	  FILEGROWTH = 10%);
GO
USE BackupDB;
GO
CREATE TABLE dbo.t
(
	ID		INT				NOT NULL IDENTITY
			CONSTRAINT PK_t PRIMARY KEY,
	Txt		VARCHAR(2000)	NOT NULL
			CONSTRAINT DF_t_Txt DEFAULT(REPLICATE('x', 1000))
);
GO
INSERT INTO dbo.t DEFAULT VALUES;
GO 1000
BACKUP DATABASE BackupDB TO DISK = 'c:\rod\Backupdb.bak' WITH FORMAT;
BACKUP LOG BackupDB TO DISK = 'c:\rod\Backupdb.log' WITH FORMAT;
GO
DBCC TRACEON (3604);
GO
DECLARE @DBID		INT = DB_ID();

DBCC PAGE (@DBID, 1, 6, 3);
GO
UPDATE dbo.t	
	SET Txt = REPLICATE('y', 1000)
	WHERE ID % 10 = 4;
GO
DECLARE @DBID		INT = DB_ID();

DBCC PAGE (@DBID, 1, 6, 3);
GO
BACKUP DATABASE BackupDB TO DISK = 'c:\rod\Backupdb.bak' WITH FORMAT, COPY_ONLY;
BACKUP LOG BackupDB TO DISK = 'c:\rod\Backupdb.log' WITH FORMAT;
GO
DECLARE @DBID		INT = DB_ID();

DBCC PAGE (@DBID, 1, 6, 3);
GO
BACKUP DATABASE BackupDB TO DISK = 'c:\rod\Backupdb.bak' WITH FORMAT;
BACKUP LOG BackupDB TO DISK = 'c:\rod\Backupdb.log' WITH FORMAT;
GO
DECLARE @DBID		INT = DB_ID();

DBCC PAGE (@DBID, 1, 6, 3);
GO
UPDATE dbo.t	
	SET Txt = REPLICATE ('z', 2000);
GO
DECLARE @DBID		INT = DB_ID();

DBCC PAGE (@DBID, 1, 6, 3);
GO
BACKUP DATABASE BackupDB TO DISK = 'c:\rod\Backupdb.bak' WITH FORMAT;
BACKUP LOG BackupDB TO DISK = 'c:\rod\Backupdb.log' WITH FORMAT;
GO
DECLARE @DBID		INT = DB_ID();

DBCC PAGE (@DBID, 1, 6, 3);
GO
