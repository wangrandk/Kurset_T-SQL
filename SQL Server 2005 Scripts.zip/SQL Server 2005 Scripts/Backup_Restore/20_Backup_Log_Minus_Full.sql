USE master;
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY
	(NAME = BackupDB_data,
	  FILENAME = 'C:\Databaser\BackupDB.mdf',
      SIZE = 10MB)
LOG ON
	(NAME = BackupDB_log,
	 FILENAME = 'C:\Databaser\BackupDB.ldf',
     SIZE = 1MB,
	 MAXSIZE = 1MB);
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	id		INT NOT NULL IDENTITY PRIMARY KEY,
	txt		CHAR(1000) NOT NULL
);
GO
SET NOCOUNT ON;
DECLARE @txt		CHAR(1000) = REPLICATE('x', 1000);
DECLARE @i			INT = 1;

SELECT num_of_bytes_written AS ant_byte
	INTO #t
	FROM sys.dm_io_virtual_file_stats(db_id(), 2);

WHILE @i < 9000
BEGIN
	INSERT INTO dbo.t VALUES (@txt);
	SET @i = @i + 1;

	IF @i % 500 = 0
	BEGIN
		WAITFOR DELAY '00:00:01';
		PRINT @i;
		INSERT INTO #t
			SELECT num_of_bytes_written
			    FROM sys.dm_io_virtual_file_stats(db_id(), 2);
	END;
END;
SET NOCOUNT OFF;

SELECT	ant_byte AS byte, 
		ant_byte / 1024 AS kb, 
		ant_byte /1024/1024 AS mb 
	FROM #t;

DROP TABLE #t;
DBCC SQLPERF(logspace);
GO
USE master;
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY
	(NAME = BackupDB_data,
	  FILENAME = 'C:\Databaser\BackupDB.mdf',
      SIZE = 10MB)
LOG ON
	(NAME = BackupDB_log,
	 FILENAME = 'C:\Databaser\BackupDB.ldf',
     SIZE = 1MB,
     MAXSIZE=1MB);
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	id		INT NOT NULL IDENTITY PRIMARY KEY,
	txt		CHAR(1000) NOT NULL
);
GO
--BACKUP DATABASE BackupDB TO DISK = 'c:\rod\BackupDB;.bal' with init
SET NOCOUNT ON;
DECLARE @txt	CHAR(1000) = REPLICATE('x', 1000);
DECLARE @i		INT = 1;

SELECT num_of_bytes_written AS ant_byte
	INTO #t
	FROM sys.dm_io_virtual_file_stats(db_id(), 2);

WHILE @i < 9000
BEGIN
	INSERT INTO dbo.t VALUES (@txt);
	SET @i = @i + 1;
	IF @i % 500 = 0
	BEGIN
		WAITFOR DELAY '00:00:01';
		PRINT @i;
		INSERT INTO #t
			SELECT num_of_bytes_written
			    FROM sys.dm_io_virtual_file_stats(db_id(), 2);
	END;
END;
SET NOCOUNT OFF;

SELECT	ant_byte AS byte, 
		ant_byte / 1024 AS kb, 
		ant_byte /1024/1024 AS mb 
	FROM #t;

DROP TABLE #t;
DBCC SQLPERF (logspace);
