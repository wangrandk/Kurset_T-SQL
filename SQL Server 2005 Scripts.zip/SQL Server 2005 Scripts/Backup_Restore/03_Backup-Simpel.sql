USE master;
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB;
GO
ALTER DATABASE Backupdb SET RECOVERY SIMPLE; 
GO
USE BackupDB;
CREATE TABLE dbo.t (i INT)
GO
USE master;
EXEC sp_dropdevice 'Backupdev', 'DELFILE';
EXEC sp_addumpdevice 'DISK', 'Backupdev', 'c:\rod\Backupdev.bak';
GO
BACKUP DATABASE BackupDB TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;
INSERT INTO dbo.t VALUES
	(1),
	(2),
	(3),
	(4);

SET NOCOUNT OFF;
GO
CHECKPOINT;
GO
BACKUP LOG BackupDB TO Backupdev;			-- fejler, da RECOVERY model er simpel
GO
ALTER DATABASE backupdb SET RECOVERY FULL;
GO
BACKUP LOG BackupDB TO Backupdev;			-- fejler, da der ikke er en full backup siden �ndring af recovery model
GO
 