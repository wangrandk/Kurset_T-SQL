--Table Has Existing Data		Has Clustered Index		Has Non-Clustered Index		Data Page UPDATEs		Index Page UPDATEs
------------------------------------------------------------------------------------------------------------------------------
--No							No						No							minimally logged		n/a
--No							No						Yes							minimally logged		minimally logged
--No							Yes						doesn't matter				minimally logged		minimally logged
--Yes							No						No							minimally logged		n/a
--Yes							No						Yes							minimally logged		fully logged
--Yes							Yes						doesn't matter				fully logged			fully logged
------------------------------------------------------------------------------------------------------------------------------
USE master;
GO
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY 
	( NAME = BackupDB_file_1,
	FILENAME = N'c:\databaser\BackupDB.mdf',
	SIZE = 400MB,
	MAXSIZE = 600MB,
	FILEGROWTH = 10%)

LOG ON 
	( NAME = BackupDB_log_file_1,
	FILENAME = N'c:\databaser\BackupDB_log.ldf',
	SIZE = 50MB,
	MAXSIZE = 400MB,
	FILEGROWTH = 10%);
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	i	INT NOT NULL PRIMARY KEY CLUSTERED ,
	c	CHAR(1000) NOT NULL
);
GO
SET NOCOUNT ON;

DECLARE @i	INT;

SET @i = 1;

WHILE @i <= 50000
BEGIN
	INSERT INTO dbo.t VALUES(@i, 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
	SET @i += 1
END;
INSERT INTO dbo.t VALUES(100001, 'yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy');
SET NOCOUNT OFF;
GO
DBCC SQLPERF ( logspace );
BACKUP DATABASE BackupDB TO DISK = 'c:\rod\fullbackup.bak' WITH FORMAT;
BACKUP LOG BackupDB TO DISK = 'c:\rod\log1.bak' WITH FORMAT;
GO
ALTER DATABASE BackupDB SET RECOVERY BULK_LOGGED;
GO
INSERT INTO dbo.t VALUES
	(100002, 'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz'),
	(100003, 'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
GO
USE BackupDB;

SELECT * 
	INTO t1 
	FROM dbo.t;
GO
USE master; 
GO
ALTER DATABASE BackupDB SET OFFLINE;
EXEC master..xp_cmdshell 'del c:\databaser\BackupDB.mdf';
ALTER DATABASE BackupDB SET ONLINE;

--oprydning
--ALTER DATABASE BackupDB SET OFFLINE
--EXEC master..xp_cmdshell 'del c:\databaser\BackupDB_log.ldf'
-- hvis datafil er v�k, kan der ikke tages backup af log

DBCC SQLPERF ( logspace );
BACKUP LOG BackupDB TO DISK = 'c:\rod\bulklog.bak' WITH FORMAT, NO_TRUNCATE;
DBCC SQLPERF (logspace);
GO
ALTER DATABASE BackupDB SET RECOVERY FULL;
GO
USE BackupDB;

SELECT * 
	INTO t2 
	FROM dbo.t;
GO
DBCC SQLPERF (logspace);
BACKUP LOG BackupDB TO DISK = 'c:\rod\log2.bak' WITH FORMAT;
DBCC SQLPERF (logspace);
GO
USE master;
DROP DATABASE BackupDB;
RESTORE DATABASE BackupDB FROM DISK = 'c:\rod\fullbackup.bak' WITH NORECOVERY, REPLACE;
GO
RESTORE LOG BackupDB FROM DISK = 'c:\rod\log1.bak' WITH NORECOVERY;
GO
--RESTORE LOG BackupDB FROM DISK = 'c:\rod\bulklog.bak' WITH NORECOVERY;
RESTORE LOG BackupDB FROM DISK = 'c:\rod\bulklog.bak' WITH NORECOVERY,  CONTINUE_AFTER_ERROR;
GO
RESTORE LOG BackupDB WITH RECOVERY;
GO
USE BackupDB;
SELECT TOP 5 * 
	FROM dbo.t 
	ORDER BY 1 DESC;

SELECT TOP 5 * 
	FROM t1 
	ORDER BY 1 DESC;

SELECT TOP 5 * 
	FROM t2 
	ORDER BY 1 DESC;
GO
-- ingen BULK operationer, men i BULK_LOGGED mode
GO
USE master;
GO
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY 
	( NAME = BackupDB_file_1,
	FILENAME = N'c:\databaser\BackupDB.mdf',
	SIZE = 400MB,
	MAXSIZE = 600MB,
	FILEGROWTH = 10%)

LOG ON 
	( NAME = BackupDB_log_file_1,
	FILENAME = N'c:\databaser\BackupDB_log.ldf',
	SIZE = 50MB,
	MAXSIZE = 400MB,
	FILEGROWTH = 10%);
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	i	INT NOT NULL PRIMARY KEY CLUSTERED ,
	c	CHAR(1000) NOT NULL
);
GO
SET NOCOUNT ON;

DECLARE @i	INT;

SET @i = 1;

WHILE @i <= 500
BEGIN
	INSERT INTO dbo.t VALUES(@i, 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
	SET @i = @i + 1;
END
SET NOCOUNT OFF;
GO
BACKUP DATABASE BackupDB TO DISK = 'c:\rod\fullbackup.bak' WITH FORMAT;
BACKUP LOG BackupDB TO DISK = 'c:\rod\log1.bak' WITH FORMAT;
GO
ALTER DATABASE BackupDB SET RECOVERY BULK_LOGGED;
GO
INSERT INTO dbo.t VALUES(100002, 'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO dbo.t VALUES(100003, 'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
GO
USE master; 
GO
ALTER DATABASE BackupDB SET OFFLINE;
EXEC master..xp_cmdshell 'del c:\databaser\BackupDB.mdf';
ALTER DATABASE BackupDB SET ONLINE;
GO
-- kan godt tage tail-backup, da der ikke har v�ret bulk operationer
BACKUP LOG BackupDB TO DISK = 'c:\rod\bulklog.bak' WITH FORMAT, CONTINUE_AFTER_ERROR;
GO
DROP DATABASE BackupDB;
GO
EXEC master..xp_cmdshell 'del c:\databaser\BackupDB_log.ldf';
GO
RESTORE DATABASE BackupDB FROM DISK = 'c:\rod\fullbackup.bak' WITH NORECOVERY;
RESTORE LOG BackupDB FROM DISK = 'c:\rod\log1.bak' WITH NORECOVERY;
RESTORE LOG BackupDB FROM DISK = 'c:\rod\bulklog.bak' WITH RECOVERY, CONTINUE_AFTER_ERROR;
GO
USE BackupDB;
GO
SELECT *
	FROM dbo.t;
GO
-- med BULK operationog  i BULK_LOGGED mode
GO
USE master;
GO
EXEC master..xp_cmdshell 'del c:\databaser\BackupDB_log.ldf';
GO
USE master;
GO
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY 
	( NAME = BackupDB_file_1,
	FILENAME = N'c:\databaser\BackupDB.mdf',
	SIZE = 400MB,
	MAXSIZE = 600MB,
	FILEGROWTH = 10%)

LOG ON 
	( NAME = BackupDB_log_file_1,
	FILENAME = N'c:\databaser\BackupDB_log.ldf',
	SIZE = 50MB,
	MAXSIZE = 400MB,
	FILEGROWTH = 10%);
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	i	INT NOT NULL PRIMARY KEY CLUSTERED ,
	c	CHAR(1000) NOT NULL
);
GO
SET NOCOUNT ON;

DECLARE @i	INT;

SET @i = 1;

WHILE @i <= 500
BEGIN
	INSERT INTO dbo.t VALUES(@i, 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
	SET @i = @i + 1;
END
SET NOCOUNT OFF;
GO
BACKUP DATABASE BackupDB TO DISK = 'c:\rod\fullbackup.bak' WITH FORMAT;
BACKUP LOG BackupDB TO DISK = 'c:\rod\log1.bak' WITH FORMAT;
GO
ALTER DATABASE BackupDB SET RECOVERY BULK_LOGGED;
GO
SELECT *
	INTO dbo.t1
	FROM dbo.t;
GO
USE master; 
GO
ALTER DATABASE BackupDB SET OFFLINE;
EXEC master..xp_cmdshell 'del c:\databaser\BackupDB.mdf';
ALTER DATABASE BackupDB SET ONLINE;
GO
-- kan ikke tage tail-backup, da der har v�ret en bulk operationer
BACKUP LOG BackupDB TO DISK = 'c:\rod\bulklog.bak' WITH FORMAT, CONTINUE_AFTER_ERROR;
GO
RESTORE DATABASE BackupDB FROM DISK = 'c:\rod\fullbackup.bak' WITH NORECOVERY;
RESTORE LOG BackupDB FROM DISK = 'c:\rod\log1.bak' WITH NORECOVERY;
RESTORE LOG BackupDB FROM DISK = 'c:\rod\bulklog.bak' WITH RECOVERY, CONTINUE_AFTER_ERROR;
GO
USE BackupDB;
GO
SELECT *
	FROM dbo.t;
SELECT *
	FROM dbo.t1;
