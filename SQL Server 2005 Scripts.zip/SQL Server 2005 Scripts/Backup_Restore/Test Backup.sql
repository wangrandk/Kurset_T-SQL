--FULL database backups
 
SELECT database_name, backup_start_date, type, * 
	FROM msdb.dbo.backupSET
	WHERE	backup_start_date BETWEEN DATEADD(hh, -24, GETDATE()) AND GETDATE() AND 
			TYPE = 'd'
	ORDER BY backup_SET_id DESC
GO
--TRANSACTION log backups
 
SELECT database_name, backup_start_date, type, * 
	FROM msdb.dbo.backupSET
	WHERE	backup_start_date BETWEEN DATEADD(hh, -24, GETDATE()) AND GETDATE() 
			AND TYPE = 'l'
	ORDER BY backup_SET_id DESC
GO
--differential backups
 
SELECT database_name, backup_start_date, type, * 
	FROM msdb.dbo.backupSET
	WHERE	backup_start_date BETWEEN DATEADD(hh, -24, GETDATE()) AND GETDATE() 
			AND TYPE = 'i'
ORDER BY backup_SET_id DESC
GO 
--file\file group backups
 
SELECT database_name, backup_start_date, type, * 
	FROM msdb.dbo.backupSET
	WHERE	backup_start_date BETWEEN DATEADD(hh, -24, GETDATE()) AND GETDATE() 
			AND TYPE = 'f'
	ORDER BY backup_SET_id DESC
GO
