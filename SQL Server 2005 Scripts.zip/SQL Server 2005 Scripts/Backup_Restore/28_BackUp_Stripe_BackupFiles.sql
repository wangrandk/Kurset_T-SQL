USE master;
GO
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDB
ON PRIMARY
	( NAME = BackupDB_file_1,
	  FILENAME = 'C:\Databaser\BackupDB.mdf',
      SIZE = 1000MB,
      MAXSIZE = 2000MB,
      FILEGROWTH = 10%)

LOG ON
	( NAME = BackupDB_log_file_1,
	  FILENAME = 'C:\Databaser\BackupDB.ldf',
      SIZE = 1000MB,
      MAXSIZE = 2000MB,
      FILEGROWTH = 10%);
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	i		INT IDENTITY, txt CHAR(8000) DEFAULT 'xxxx'
);
GO
DECLARE @i		INT = 1;

INSERT INTO dbo.t DEFAULT VALUES;

WHILE @i < 18
begin
	INSERT INTO dbo.t
		SELECT txt 
			FROM dbo.t;

	SET @i += 1;
END;
SELECT COUNT(*)
	FROM dbo.t;
GO
BACKUP DATABASE BackupDB 
	TO	DISK='c:\rod\Backupdb_full.bak' 
	WITH FORMAT;
GO
BACKUP DATABASE BackupDB 
	TO	DISK='c:\rod\Backupdb_full1.bak',
		DISK='c:\rod\Backupdb_full2.bak',
		DISK='c:\rod\Backupdb_full3.bak',
		DISK='c:\rod\Backupdb_full4.bak' 
	WITH FORMAT;
