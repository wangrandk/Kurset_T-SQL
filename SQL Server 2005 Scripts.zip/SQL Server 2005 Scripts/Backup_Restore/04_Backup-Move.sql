USE master;
DROP DATABASE BackupDB;
GO
CREATE DATABASE BackupDb;
GO
EXEC sp_helpdb BackupDB;
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	i		INT
);
GO
USE master;
BACKUP DATABASE BackupDB TO DISK='c:\rod\Backupdb_full.bak' WITH FORMAT;
GO
USE BackupDB;
SET NOCOUNT ON;
INSERT INTO dbo.t VALUES
	(1),
	(2),
	(3),
	(4);

SET NOCOUNT OFF;
GO
BACKUP LOG BackupDB TO DISK='c:\rod\BackupDB_log' WITH FORMAT;
GO
USE master;
DROP DATABASE BackupDB;
RESTORE DATABASE BackupDB FROM DISK='c:\rod\Backupdb_full.bak'  WITH NORECOVERY, 
      	MOVE 'BackupDB' TO 'c:\rod\BackupDB_Move.mdf', 
      	MOVE 'BackupDB_log' TO 'c:\rod\BackupDB_Move.ldf';
GO
RESTORE LOG BackupDB FROM DISK='c:\rod\BackupDB_log'  WITH RECOVERY;
GO
EXEC sp_helpdb BackupDB;
GO
USE master;
RESTORE DATABASE BackupDB_Copy FROM DISK='c:\rod\Backupdb_full.bak'  WITH RECOVERY, 
      	MOVE 'BackupDB' TO 'c:\rod\BackupDB_Copy.mdf', 
      	MOVE 'BackupDB_log' TO 'c:\rod\BackupDB_Copy.ldf';
GO
DROP DATABASE BackupDB_Copy;
GO
