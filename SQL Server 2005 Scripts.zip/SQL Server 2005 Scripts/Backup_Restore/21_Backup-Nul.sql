USE master;
DROP DATABASE BackupDB
GO
CREATE DATABASE BackupDB
GO
USE BackupDB;
CREATE TABLE dbo.t 
(
	i			INT
);
GO
USE master;
EXEC sp_dropdevice 'Backupdev', 'DELFILE';
EXEC sp_addumpdevice 'DISK', 'Backupdev', 'c:\rod\Backupdev.bak';
GO
BACKUP DATABASE BackupDB TO Backupdev;
GO
USE BackupDB;
SET NOCOUNT ON;
INSERT INTO dbo.t VALUES
	(1),
	(2),
	(3),
	(4);
SET NOCOUNT OFF;
GO
BACKUP LOG BackupDB TO DISK = 'nul';
GO
USE BackupDB;
SET NOCOUNT ON;
INSERT INTO dbo.t VALUES
	(5),
	(6);
SET NOCOUNT OFF;
GO
BACKUP LOG BackupDB TO DISK = 'nul';
GO
USE master;
DROP DATABASE BackupDB;
RESTORE DATABASE BackupDB FROM Backupdev WITH FILE = 1, NORECOVERY;
GO
RESTORE LOG BackupDB FROM Backupdev WITH FILE = 2, RECOVERY;
GO
USE BackupDB;
SELECT * 
	FROM dbo.t;
