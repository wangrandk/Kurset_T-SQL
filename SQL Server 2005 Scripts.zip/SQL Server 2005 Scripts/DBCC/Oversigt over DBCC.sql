USE master
GO
DBCC TRACEON(2588)
DBCC HELP('?')  -- viser udokumenterede DBCC kommandoer
GO
DBCC HELP('WRITEPAGE')
