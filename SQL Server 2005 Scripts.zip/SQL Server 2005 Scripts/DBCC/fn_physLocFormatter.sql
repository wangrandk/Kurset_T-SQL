USE master
DROP DATABASE FnDB
GO
CREATE DATABASE FnDB
GO
USE FnDB
GO
CREATE TABLE dbo.t(
	ID			INT		IDENTITY,
	Felt1		CHAR(500),
	Felt2		CHAR(500))
GO
INSERT INTO t VALUES 
	('Felt1-1','Felt2-1'),
	('Felt1-2','Felt2-2'),
	('Felt1-3','Felt2-3'),
	('Felt1-4','Felt2-4'),
	('Felt1-5','Felt2-5'),
	('Felt1-6','Felt2-6'),
	('Felt1-7','Felt2-7'),
	('Felt1-8','Felt2-8'),
	('Felt1-9','Felt2-9');
GO
SELECT sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID], *		-- udokumenteret
	FROM t
GO
EXEC sp_helptext 'sys.fn_physLocFormatter'

Text
-------------------------------------------------------------------------------
-- Name: sys.fn_PhysLocFormatter 
--
-- Description:
--	Formats the output of %%physloc%% virtual column
--
-- Notes:
-------------------------------------------------------------------------------
CREATE FUNCTION sys.fn_PhysLocFormatter (@physical_locator BINARY (8))
RETURNS VARCHAR (128)
AS
BEGIN

	DECLARE @page_id	BINARY (4)
	DECLARE @file_id	BINARY (2)
	DECLARE @slot_id	BINARY (2)

	-- Page ID is the first four bytes, then 2 bytes of page ID, then 2 bytes of slot
	--
	SELECT @page_id = CONVERT (BINARY (4), REVERSE (SUBSTRING (@physical_locator, 1, 4)))
	SELECT @file_id = CONVERT (BINARY (2), REVERSE (SUBSTRING (@physical_locator, 5, 2)))
	SELECT @slot_id = CONVERT (BINARY (2), REVERSE (SUBSTRING (@physical_locator, 7, 2)))
	
	RETURN '(' + CAST (CAST (@file_id as int) as varchar) + ':' + 
				 CAST (CAST (@page_id as int) as varchar) + ':' + 
				 CAST (CAST (@slot_id as int) as varchar) + ')'
END


GO
DBCC TRACEON(3604)
DBCC PAGE (FnDB,1,78,1)
GO
