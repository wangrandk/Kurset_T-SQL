USE master
DROP DATABASE CheckDB
GO
CREATE DATABASE CheckDB
GO
USE CheckDB
CREATE TABLE t (
	id		INT NOT NULL,
	type	CHAR(1) CONSTRAINT ck_type CHECK (type IN ('a', 'b', 'c')))
GO
INSERT INTO t VALUES (1, 'a')
INSERT INTO t VALUES (2, 'a')
INSERT INTO t VALUES (3, 'b')
INSERT INTO t VALUES (4, 'c')
GO
ALTER TABLE t 
	DROP CONSTRAINT ck_type 
GO
ALTER TABLE t
	WITH NOCHECK ADD CONSTRAINT ck_type 
	CHECK (type IN ('a', 'b')) 
GO
DBCC CHECKCONSTRAINTS ('t')
GO
SELECT * 
	FROM t
GO
UPDATE t
	SET ID = ID + 5
	WHERE Id = 4;

UPDATE t
	SET Type = 'D'
	WHERE Id = 9;

UPDATE t
	SET Type = 'A'
	WHERE Id = 9;

UPDATE t
	SET Type = 'A'
	WHERE type = 'c';
