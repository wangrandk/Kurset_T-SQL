USE master
DROP DATABASE FileDB
GO
CREATE DATABASE FileDB
ON PRIMARY
	( NAME = FileDB_file_1,
	  FILENAME = 'C:\Databaser\FileDB.mdf',
      SIZE = 200MB,
      MAXSIZE = 300MB,
      FILEGROWTH = 10%)

LOG ON
	( NAME = FileDB_log_file_1,
	  FILENAME = 'C:\Databaser\FileDB_log.ldf',
      SIZE = 10MB,
      MAXSIZE = 200MB,
      FILEGROWTH = 10%)
GO
USE FileDB
CREATE TABLE t (
	id		INT NOT NULL,
	txt		CHAR(796) NOT NULL)
GO
SET NOCOUNT ON
DECLARE @i	INT
SET @i = 1
WHILE @i <= 10000
BEGIN
	INSERT INTO t VALUES (@i, right('000000' + CAST(@i as VARCHAR(6)), 6) + 
								REPLICATE('XXXXXXXXXX', 79))
	SET @i = @i + 1
END
SET NOCOUNT OFF
GO
SELECT * FROM t
GO
DBCC ind(FileDB, t, 0)
GO
CREATE CLUSTERED INDEX cl_t ON t(id)
GO
DBCC ind(FileDB, t, 0)
GO
ALTER INDEX cl_t ON t REORGANIZE
GO
DBCC ind(FileDB, t, 0)
GO
ALTER INDEX cl_t ON t REBUILD
GO
DBCC ind(FileDB, t, 0)
