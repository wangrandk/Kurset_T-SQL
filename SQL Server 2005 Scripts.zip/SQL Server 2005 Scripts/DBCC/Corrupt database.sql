-- efterf�lgende eksempel, kun for at vise en �delagt database - KUN TIL DEMO
USE master
GO
DBCC TRACEON(2588);
GO
DBCC HELP('WRITEPAGE');
GO
USE master;
DROP DATABASE CorruptDB;
GO
CREATE DATABASE CorruptDB;
GO
USE CorruptDB;
CREATE TABLE dbo.t
(
	ID		INT NOT NULL IDENTITY,
	Txt		CHAR(8000) NOT NULL DEFAULT(REPLICATE('x', 8000))
);
GO
INSERT INTO dbo.t DEFAULT VALUES
GO 5
SELECT *	
	FROM dbo.t;
GO
DBCC IND(N'CorruptDB', N'dbo.t', -1);
GO
ALTER DATABASE CorruptDB SET SINGLE_USER;
GO
DBCC WRITEPAGE(N'CorruptDB', 1, 78, 200, 5, 0x4546474849, 1);
GO
SELECT *
	FROM dbo.t;
GO
EXEC xp_readerrorlog;
GO
SELECT *
	FROM msdb.dbo.suspect_pages;
GO
DBCC CHECKDB(N'CorruptDB')

