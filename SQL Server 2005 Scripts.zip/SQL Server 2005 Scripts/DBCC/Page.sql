USE master;
DROP DATABASE FileDB;
GO
CREATE DATABASE FileDB
ON PRIMARY
	( NAME = FileDB_file_1,
	  FILENAME = 'C:\Databaser\FileDB.mdf',
      SIZE = 150MB,
      MAXSIZE = 300MB,
      FILEGROWTH = 10%)

LOG ON
	( NAME = FileDB_log_file_1,
	  FILENAME = 'C:\Databaser\FileDB_log.ldf',
      SIZE = 100MB,
      MAXSIZE = 200MB,
      FILEGROWTH = 10%);
GO
ALTER DATABASE FileDB SET RECOVERY SIMPLE;
GO
USE FileDB;
CREATE TABLE dbo.t 
(
	id		INT NOT NULL IDENTITY PRIMARY KEY CLUSTERED,
	txt		CHAR(796) NOT NULL
);
GO
SET NOCOUNT ON;
DECLARE @i		INT

INSERT INTO dbo.t VALUES (REPLICATE('XXXXXXXXXX', 79))

SET @i = 1;

WHILE @i <= 17
BEGIN
	INSERT INTO dbo.t (txt)
		SELECT txt 
			FROM dbo.t;
	SET @i += 1;
END
SET NOCOUNT OFF;
SELECT COUNT(*) 
	FROM dbo.t;
GO
SELECT TOP 10 * 
	FROM dbo.t;
GO
DBCC TRACEON (3604);
-- file header
DBCC PAGE (FileDB, 1, 0, 3);
GO
-- PFS
DBCC SHOWCONTIG(t);
DBCC PAGE (FileDB, 1, 1, 2);
GO
-- GAM
DBCC PAGE (FileDB, 1, 2, 2);
GO
-- SGAM
DBCC PAGE (FileDB, 1, 3, 2);
GO
-- DCM
DBCC PAGE (FileDB, 1, 6, 2);
GO
-- BCM
DBCC PAGE (FileDB, 1, 7, 2);
GO
------ diff ---------------------------------------------------------------------------------------------
BACKUP DATABASE FileDB TO DISK = 'c:\rod\FileDB.bak' WITH INIT;
GO
UPDATE dbo.t 
	SET txt = LEFT(txt, 2000) 
	WHERE id BETWEEN 16000 AND 40000;
GO
DBCC PAGE (FileDB, 1, 6, 2);
GO
BACKUP DATABASE FileDB TO DISK = 'c:\rod\FileDB.bak' WITH INIT, DIFFERENTIAL;
GO
UPDATE dbo.t 
	SET txt = LEFT(txt, 2000) 
	WHERE id BETWEEN 40000 AND 60000;
GO
DBCC PAGE (FileDB, 1, 6, 2);
GO
BACKUP DATABASE FileDB TO DISK = 'c:\rod\FileDB.bak' WITH INIT, DIFFERENTIAL;
GO
DBCC SHOWCONTIG(t);
GO
DBCC PAGE (FileDB, 1, 6, 2);
GO
UPDATE dbo.t 
	SET txt = LEFT(txt, 2000) 
	WHERE id BETWEEN 1 AND 16000;
GO
DBCC PAGE (FileDB, 1, 6, 2);
GO
BACKUP DATABASE FileDB TO DISK = 'c:\rod\FileDB.bak' WITH INIT, COPY_ONLY;
GO
DBCC PAGE (FileDB, 1, 6, 2);
GO
BACKUP DATABASE FileDB TO DISK = 'c:\rod\FileDB.bak' WITH INIT, DIFFERENTIAL;
GO
DBCC PAGE (FileDB, 1, 6, 2);
GO
BACKUP DATABASE FileDB TO DISK = 'c:\rod\FileDB.bak' WITH INIT;
GO
DBCC PAGE (FileDB, 1, 6, 2);
GO
-------- minimal log -------------------------------------------------------------------------------------
ALTER DATABASE FileDB SET RECOVERY BULK_LOGGED;
GO
BACKUP DATABASE FileDB TO DISK = 'c:\rod\FileDB.bak' WITH INIT;
BACKUP LOG FileDB TO DISK =  'c:\rod\FileDB.log' WITH INIT;
GO
CREATE TABLE dbo.sqlperf_logspace 
(
	dbname		SYSNAME,
	logsize		FLOAT,
	logpct		FLOAT,
	status		SMALLINT,
	time		DATETIME2 DEFAULT(SYSDATETIME())
);
GO
INSERT INTO dbo.sqlperf_logspace (dbname, logsize, logpct, status)
	EXEC ('DBCC sqlperf(logspace)')
DBCC PAGE (FileDB, 1, 7, 2)
GO
SELECT id, txt 
	INTO dbo.t_bulk	
	FROM dbo.t 
	WHERE id BETWEEN 1 AND 35000
	ORDER BY Id;
GO
INSERT INTO dbo.sqlperf_logspace (dbname, logsize, logpct, status)
	EXEC ('DBCC sqlperf(logspace)');
DBCC PAGE (FileDB, 1, 7, 2);
GO
SET IDENTITY_INSERT dbo.t_bulk ON;
INSERT INTO dbo.t_bulk (id, txt)
	SELECT id, txt 
		FROM dbo.t 
		WHERE id BETWEEN 35001 AND 70000
		ORDER BY id;
GO
INSERT INTO dbo.sqlperf_logspace (dbname, logsize, logpct, status)
	EXEC ('DBCC sqlperf(logspace)')
DBCC PAGE (FileDB, 1, 7, 2)
GO
SELECT * 
	FROM dbo.sqlperf_logspace 
	WHERE dbname = 'FileDB' 
	ORDER BY time;
GO
DBCC TRACEON (610);		-- minimal log selvom der er data i tabellen i forvejen
GO
INSERT INTO dbo.t_bulk (id, txt)
	SELECT id, txt 
		FROM dbo.t 
		WHERE id BETWEEN 70001 AND 105000
		ORDER BY id;
GO
INSERT INTO dbo.sqlperf_logspace (dbname, logsize, logpct, status)
	EXEC ('DBCC sqlperf(logspace)')
DBCC PAGE (FileDB, 1, 7, 2)
GO
DBCC TRACEOFF (610);
GO
SELECT * 
	FROM dbo.sqlperf_logspace 
	WHERE dbname = 'FileDB' 
	ORDER BY time;
GO
-- DROP TABLE dbo.t_bulk;
-- DROP TABLE dbo.sqlperf_logspace 