USE master
DROP DATABASE DataManipulationsDB
GO
CREATE DATABASE DataManipulationsDB
GO
USE DataManipulationsDB
CREATE TABLE Vare (
	Vareid			INT NOT NULL PRIMARY KEY IDENTITY,
	VareNavn		VARCHAR(30) NOT NULL,
	Varepris		DECIMAL(9,2) NOT NULL,
	AntalPaaLager	INT NOT NULL DEFAULT (0),
	Beskrivelse		VARCHAR(2000) NULL)
GO
INSERT INTO Vare (VareNavn, Varepris, AntalPaaLager, Beskrivelse) 
	VALUES('Vare1', 40.0, 0, 'Vare1 beskrivelse')
GO
INSERT INTO Vare
	VALUES('Vare2', 50.0, 0, 'Vare2 beskrivelse')
GO
INSERT INTO Vare (VareNavn, Varepris) 
	VALUES('Vare3', 40.0)
GO
INSERT INTO Vare VALUES
	('Vare4', 40.0, 0, 'Vare4 beskrivelse'),
	('Vare5', 40.0, 0, 'Vare5 beskrivelse')
GO
SELECT * 
	FROM Vare
GO
INSERT INTO Vare
	SELECT VareNavn, Varepris, AntalPaaLager, Beskrivelse
		FROM Vare

