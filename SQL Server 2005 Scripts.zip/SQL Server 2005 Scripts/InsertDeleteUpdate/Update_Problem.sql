USE master;
GO
DROP DATABASE ProductDB;
GO
CREATE DATABASE ProductDB;
GO
USE ProductDB;
GO
CREATE TABLE dbo.Product
(
	ProductId			INT NOT NULL PRIMARY KEY,
	Productname			VARCHAR(50) NOT NULL,
	UnitsInStock		INT NOT NULL DEFAULT(0),
	UnitPrice			DECIMAL (11,2) NOT NULL DEFAULT(0)
);

CREATE TABLE dbo.Sold
(
	ProductId			INT NOT NULL,
	Units				INT NOT NULL
);

CREATE TABLE dbo.ProductChanges
(
	ProductId			INT NOT NULL,
	Productname			VARCHAR(50) NOT NULL,
	ChangeTime			DATETIME2 NOT NULL
						CONSTRAINT DF_ProductChanges_ChangeTime DEFAULT(SYSDATETIME()) 
);
GO
INSERT INTO dbo.Product (ProductId, Productname, UnitsInStock, UnitPrice) VALUES
	(1, 'Product1', 8, 25.50),
	(2, 'Product2', 4, 10.00),
	(3, 'Product3', 19, 17.75);
GO
INSERT INTO dbo.Sold (ProductId, Units) VALUES
	(1, 2),
	(1, -2),
	(2, 1),
	(2, 2),
	(3, 3),
	(3, 2),
	(3, 4),
	(3, 1),	
	(3, 1),
	(3, 2),	
	(3, 1),
	(3, 5);
GO
INSERT INTO dbo.ProductChanges(Productid, Productname) VALUES 
	(1, 'Product1_1');

WAITFOR DELAY '0:0:01'
INSERT INTO dbo.ProductChanges(Productid, Productname) VALUES 
	(2, 'Product2_1');

WAITFOR DELAY '0:0:01'
INSERT INTO dbo.ProductChanges(Productid, Productname) VALUES 
	(2, 'Product2_2');

WAITFOR DELAY '0:0:01'
INSERT INTO dbo.ProductChanges(Productid, Productname) VALUES 	
	(3, 'Product3_1');

WAITFOR DELAY '0:0:01'
INSERT INTO dbo.ProductChanges(Productid, Productname) VALUES 	
	(3, 'Product3_2');
GO
DECLARE @s		INT = 0;

SELECT @s = @s + Units
	FROM Sold
	WHERE ProductId = 2;

SELECT @s 
GO
-- Not correct, because Business key (ProductId) is not PK/UNIQUE in dbo.Sold and dbo.ProductChanges
UPDATE dbo.Product
	SET UnitsInStock = UnitsInStock - Units
	FROM dbo.Product INNER JOIN dbo.Sold ON Product.ProductId = Sold.ProductId;
GO
UPDATE dbo.Product
	SET UnitsInStock = UnitsInStock - Sold.Units
	FROM dbo.Sold
	WHERE Product.ProductId = Sold.ProductId;
GO
UPDATE dbo.Product
	SET Productname = ProductChanges.Productname
	FROM dbo.Product INNER JOIN dbo.ProductChanges ON Product.ProductId = ProductChanges.ProductId;
GO
SELECT *
	FROM dbo.Product;
-----------------------------------------------------------------
-- Recreate DB
-- correct UPDATE with data from dbo.Sold
UPDATE dbo.Product
	SET UnitsInStock = UnitsInStock -
									(
									SELECT SUM(Units)
										FROM dbo.Sold
										WHERE Sold.ProductId = Product.ProductId
										GROUP BY Sold.ProductId
									);
-- or
WITH SoldSum
AS
(
SELECT ProductId, SUM(Units) AS Units
	FROM dbo.Sold
	GROUP BY Sold.ProductId
)
UPDATE dbo.Product	
	SET UnitsInStock = UnitsInStock - Units
	FROM dbo.Product INNER JOIN SoldSum ON Product.ProductId = SoldSum.ProductId;
-- or
WITH SoldSum
AS
(
SELECT ProductId, SUM(Units) AS Units
	FROM dbo.Sold
	GROUP BY Sold.ProductId
)
UPDATE dbo.Product	
	SET UnitsInStock = UnitsInStock -  (
										SELECT Units
											FROM SoldSum
											WHERE SoldSum.ProductId = Product.ProductId
										);
GO
SELECT *
	FROM dbo.Product;
GO
-- correct UPDATE with data from dbo.ProductChanges
WITH ProductUpdate
AS
(
SELECT Changes.*
	FROM dbo.Product CROSS APPLY
						(
						SELECT TOP 1 *
							FROM dbo.ProductChanges
							WHERE ProductChanges.ProductId = Product.ProductId
							ORDER BY ProductChanges.ChangeTime DESC
						) AS Changes
)
UPDATE dbo.Product	
	SET Productname = ProductUpdate.Productname
	FROM dbo.Product INNER JOIN ProductUpdate ON Product.ProductId = ProductUpdate.ProductId
GO
SELECT *
	FROM dbo.Product;
