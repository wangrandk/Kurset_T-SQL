USE master;
GO
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE Testdb;
CREATE TABLE dbo.t
(
	ID			INT NOT NULL PRIMARY KEY IDENTITY,
	Text		VARCHAR(6000) NOT NULL DEFAULT(REPLICATE('A', 6000))
);
GO
SET NOCOUNT ON;
GO
INSERT INTO dbo.t DEFAULT VALUES;
GO 200
BEGIN TRANSACTION;
 
TRUNCATE 
	TABLE dbo.t;

SELECT * 
	FROM dbo.t;
 
ROLLBACK TRANSACTION;
GO
SELECT * 
	FROM dbo.t;
GO
DBCC IND('TestDB','dbo.t', 0);
GO
BEGIN TRANSACTION;

DBCC TRACEON (3604);
DBCC PAGE('TestDB', 1, 234, 3);

TRUNCATE 
	TABLE dbo.t;

DBCC PAGE('TestDB', 1, 234, 3);

SELECT	[Current LSN], 
		Operation, 
		[Transaction ID], 
		AllocUnitName,
        [Page ID], 
		[Lock Information], 
		Description, 
		[Transaction SID]
	FROM fn_dblog(NULL, NULL)
 
ROLLBACK TRANSACTION;
GO
CHECKPOINT;
 
SELECT	[Current LSN], 
		Operation, 
		[Transaction ID], 
		AllocUnitName,
        [Page ID], 
		[Lock Information], 
		Description, 
		[Transaction SID]
	FROM fn_dblog(NULL, NULL)
 