USE master
DROP DATABASE DataManipulationsDB
GO
CREATE DATABASE DataManipulationsDB
GO
USE DataManipulationsDB
CREATE TABLE Vare (
	Vareid		INT NOT NULL PRIMARY KEY IDENTITY,
	Varenavn	VARCHAR(30) NOT NULL,
	Varepris	DECIMAL(9,2) NOT NULL)
GO
INSERT INTO Vare VALUES
	('Vare1', 40.0),
	('Vare2', 50.0),
	('Vare3', 60.0)
GO
SELECT * 
	FROM Vare
UPDATE Vare 
	SET Varepris = 55 
	WHERE Vareid = 2
SELECT * 
	FROM Vare
GO
SELECT * 
	FROM Vare
UPDATE Vare 
	SET Varepris = Varepris * 1.1 
	WHERE Vareid = 1
SELECT * 
	FROM Vare
GO
DECLARE @stigningspct	SMALLINT
DECLARE @glpris			DECIMAL(9,2)
DECLARE @nypris			DECIMAL(9,2)

SET @stigningspct = 25

SELECT	*, 
		@glpris AS glpris, 
		@nypris AS nypris, 
		@stigningspct AS stigningspct
	FROM Vare 
	WHERE Vareid = 3
UPDATE Vare 
	SET @glpris = Varepris, 
		@nypris = Varepris = Varepris + Varepris / 100 *  @stigningspct
	WHERE Vareid = 3 
SELECT	*, 
		@glpris AS glpris, 
		@nypris AS nypris, 
		@stigningspct AS stigningspct
	FROM Vare 
	WHERE Vareid = 3
