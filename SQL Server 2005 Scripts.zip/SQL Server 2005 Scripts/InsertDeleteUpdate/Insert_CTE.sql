USE master
GO
DROP DATABASE InsertDB
GO
CREATE DATABASE InsertDB
GO
USE InsertDB
CREATE TABLE Person (
	PersonId		INT NOT NULL PRIMARY KEY IDENTITY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	Gade			VARCHAR(30) NULL,
	Postnr			SMALLINT NULL)
GO
INSERT INTO							-- fejl
	(SELECT Fornavn, Efternavn
		FROM Person)
	VALUES ('Ole', 'Olsen')
GO
WITH p
AS
(
SELECT Fornavn, Efternavn
		FROM Person
)
INSERT INTO	p
	VALUES ('Ole', 'Olsen')
GO
SELECT *
	FROM Person
