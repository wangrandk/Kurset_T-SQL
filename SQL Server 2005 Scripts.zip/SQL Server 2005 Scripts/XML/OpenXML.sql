USE XMLDB;
GO
DECLARE @xml	XML;
DECLARE @idoc	INT;

SET @xml = '<Personer>
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
	        </Personer>';

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml;

SELECT @idoc;

SELECT *
	FROM OPENXML(@idoc, 'Personer/Person[@Alder > 20]', 3)
			WITH
			(Navn 	VARCHAR(30),
			 Alder 	INT,
			 Tlfnr 	CHAR(8));

EXEC sp_xml_removedocument @idoc;
GO
--*****************************************************************
DECLARE @xml	VARCHAR(1000);
DECLARE @idoc	INT;

SET @xml = '<Personer>
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
	    </Personer>';

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml;

SELECT *
	FROM OPENXML(@idoc, 'Personer/Person', 3)   
			WITH
				(Navn 		VARCHAR(30),
				 mpid		INT			'@mp:id',
				 Overflow 	XML			'@mp:xmltext');

EXEC sp_xml_removedocument @idoc;
GO
--*****************************************************************
DECLARE @xml	VARCHAR(1000);
DECLARE @idoc	INT;

SET @xml = '<Personer Type="100">
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
	    </Personer>';

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml;

SELECT *
	FROM OPENXML(@idoc, 'Personer/Person', 11)    -- +8
			WITH
				(Navn 		VARCHAR(30),
				 Alder		SMALLINT,
				 Overflow 	XML			'@mp:xmltext' );

EXEC sp_xml_removedocument @idoc;
GO
--*****************************************************************
DECLARE @xml	VARCHAR(1000);
DECLARE @idoc	INT;

SET @xml = '<Personer>
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
	    </Personer>';

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml;

SELECT *
	FROM OPENXML(@idoc, 'Personer/Person', 11)    -- +8
			WITH
				(
				 ID			INT				'@mp:id',
				 localname  VARCHAR(100)	'@mp:localname',
				 Prev		INT				'@mp:prev',
				 Navn 		VARCHAR(30),
				 Alder		SMALLINT,
				 Overflow 	XML				'@mp:xmltext' );

EXEC sp_xml_removedocument @idoc;
GO
--*****************************************************************
DECLARE @xml	VARCHAR(1000);
DECLARE @idoc	INT;

SET @xml = '<Personer TilmeldingsType="WEB" Dato="2010-12-5">
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"><CprNr>2511761234</CprNr></Person>
              <Person Navn="Ida" Alder="35"><CprNr>2711761234</CprNr></Person>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"><CprNr>1711761234</CprNr></Person>
              <Person Navn="Per" Alder="56"><CprNr>032311441235</CprNr><CprNr>044591441237</CprNr></Person>
			</Personer>';

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml;

SELECT *
	FROM OPENXML(@idoc, '/Personer/Person', 1)  
			WITH
				(Navn 				VARCHAR(30),
				 PersonAlder 		SMALLINT	'./@Alder',
				 TilmeldingsType 	VARCHAR(3)	'../@TilmeldingsType',
				 CprNr1				CHAR(10)	'./CprNr',
				 CprNr2				CHAR(10)	'./CprNr[2]');

SELECT *
	FROM OPENXML(@idoc, '/Personer/Person', 11)  
			WITH
				(Navn 				VARCHAR(30),
				 PersonAlder 		SMALLINT	'./@Alder',
				 TilmeldingsType 	VARCHAR(3)	'../@TilmeldingsType',
				 CprNr				CHAR(10)	'./CprNr',
				 Overflow			XML			'@mp:xmltext');

SELECT *
	FROM OPENXML(@idoc, '/Personer', 1)  
			WITH
				(TilmeldingsType 	VARCHAR(3),
				 Dato 				DATETIME);

EXEC sp_xml_removedocument @idoc;
GO
--*****************************************************************
DECLARE @xml	VARCHAR(1000);
DECLARE @idoc	INT;

SET @xml =	'<Data>
				<Personer TilmeldingsType="WEB" Dato="2008-12-5">
				  <Person Navn="Ole" Alder="22" Tlfnr="86111111"><CprNr>2511761234</CprNr></Person>
				  <Person Navn="Ida" Alder="35"><CprNr>2711761234</CprNr></Person>
				  <Person Navn="Ane" Alder="17" Tlfnr="86222222"><CprNr>1711761234</CprNr></Person>
				  <Person Navn="Per" Alder="56"><CprNr>032311441234</CprNr></Person>
				 </Personer>
				 <AdresseOpl>
				   <Adresse Gade="Nygade" Postnr="8000"/>
				   <Adresse Gade="Vestergade" Postnr="9000"/>
				 </AdresseOpl>
			</Data>';

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml;

SELECT *
	FROM OPENXML(@idoc, '/Data/Personer/Person', 1)  
			WITH
				(Navn 				VARCHAR(30),
				 PersonAlder 		SMALLINT	'./@Alder',
				 TilmeldingsType 	VARCHAR(3)	'../@TilmeldingsType',
				 CprNr 				CHAR(10)	'./CprNr',
				 Gade1				VARCHAR(30) '../../AdresseOpl/Adresse[1]/@Gade',   -- f�rste adresse
				 Gade2				VARCHAR(30) '../../AdresseOpl/Adresse[2]/@Gade');   -- anden adresse

EXEC sp_xml_removedocument @idoc;
GO
--*****************************************************************
DECLARE @xml	VARCHAR(1000);
DECLARE @idoc	INT;

SET @xml = '<Personer>
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
			</Personer>';

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml;

SELECT localname, Nodetype
	FROM OPENXML(@idoc, 'Personer')
	WHERE Localname NOT LIKE '#%'
	GROUP BY Nodetype, localname;

SELECT *
	FROM OPENXML(@idoc, 'Personer');


EXEC sp_xml_removedocument @idoc;
GO
--*****************************************************************
DECLARE @xml	VARCHAR(1000);
DECLARE @idoc	INT;

SET @xml = '<Personer>
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
	    </Personer>';

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml;

SELECT *
	FROM OPENXML(@idoc, 'Personer/Person');

EXEC sp_xml_removedocument @idoc;
GO

--*****************************************************************
DROP TABLE dbo.PersonOpl;
GO
CREATE TABLE dbo.PersonOpl
(
	Personid	INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
	Navn		VARCHAR(30),
	Alder		INT NULL,
	Tlfnr		CHAR(8) NULL
);

DECLARE @xml	VARCHAR(1000);
DECLARE @idoc	INT;

SET @xml = '<Personer>
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
	    </Personer>';

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml;

INSERT INTO dbo.PersonOpl
	SELECT * 
		FROM OPENXML(@idoc, 'Personer/Person[@Alder > 21]', 3)
		WITH dbo.PersonOpl;

EXEC sp_xml_removedocument @idoc;

SELECT *
   FROM dbo.PersonOpl;

--*****************************************************************
GO
DROP TABLE dbo.PersonOpl;
GO
CREATE TABLE dbo.PersonOpl
(
	Personid	INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
	Navn		VARCHAR(30)
);
GO
TRUNCATE TABLE dbo.PersonOpl;

INSERT INTO dbo.PersonOpl (Navn) VALUES
	('Ole'),
	('Ida'),
	('Ane'),
	('Per'),
	('Sofus');

DECLARE @xml	VARCHAR(1000);
DECLARE @idoc	INT;

SET @xml = '<Personer>
              <Person Personid="1"/>
              <Person Personid="2"/>
			  <Person Personid="4"/>
	        </Personer>';

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml;

DELETE 
   FROM dbo.PersonOpl
   WHERE Personid IN (SELECT *
						FROM OPENXML(@idoc, 'Personer/Person',3)
								WITH (Personid	INT));

EXEC sp_xml_removedocument @idoc;

SELECT *
   FROM dbo.PersonOpl;
GO
--- eksempel med schema
DECLARE @xml	XML;
DECLARE @idoc	INT;

SET @xml = 
'<?xml version="1.0"?>
<Kunder>
<xs:schema attributeFormDefault="unqualIFied" elementFormDefault="qualIFied" xmlns:xs="http://www.w3.org/2001/XMLSchema">
  <xs:element name="Kunder">
    <xs:complexType>
      <xs:sequence>
        <xs:element minOccurs="0" maxOccurs="unbounded" name="Kunde">
          <xs:complexType>
            <xs:sequence minOccurs="0">
              <xs:element minOccurs="0" maxOccurs="unbounded" name="Ordreopl">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element minOccurs="1" maxOccurs="unbounded" name="OrdreLinie">
                      <xs:complexType>
                        <xs:attribute name="Varenummer" type="xs:unsignedByte" use="required" />
                        <xs:attribute name="AntalEnheder" type="xs:unsignedByte" use="required" />
                      </xs:complexType>
                    </xs:element>
                  </xs:sequence>
                  <xs:attribute name="OrdreNummer" type="xs:unsignedByte" use="required" />
                  <xs:attribute name="Bestillingsdato" type="xs:datetime" use="optional" />
                  <xs:attribute name="Leveringsdato" type="xs:datetime" use="optional" />
                </xs:complexType>
              </xs:element>
            </xs:sequence>
            <xs:attribute name="KundeNummer" type="xs:unsignedByte" use="required" />
            <xs:attribute name="Navn" type="xs:string" use="required" />
            <xs:attribute name="Adresse" type="xs:string" use="optional" />
            <xs:attribute name="Postnr" type="xs:unsignedShort" use="optional" />
            <xs:attribute name="Bynavn" type="xs:string" use="optional" />
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>
  <Kunde KundeNummer="1" Navn="Jens Hansen" Adresse="Nygade 3" Postnr="2000" Bynavn="Frederiksberg">
    <Ordreopl OrdreNummer="2" Bestillingsdato="2007-05-15T15:49:56.757" Leveringsdato="2007-05-17T15:49:56.757">
      <OrdreLinie Varenummer="3" AntalEnheder="4" />
    </Ordreopl>
  </Kunde>
  <Kunde KundeNummer="2" Navn="Ole Larsen" Adresse="Vestergade 4" Postnr="9000" Bynavn="Aalborg">
    <Ordreopl OrdreNummer="1" Bestillingsdato="2007-05-15T15:49:56.757" Leveringsdato="2007-05-25T15:49:56.757">
      <OrdreLinie Varenummer="3" AntalEnheder="2" />
      <OrdreLinie Varenummer="6" AntalEnheder="8" />
    </Ordreopl>
    <Ordreopl OrdreNummer="3" Bestillingsdato="2007-05-15T15:49:56.757" Leveringsdato="2007-06-04T15:49:56.757">
      <OrdreLinie Varenummer="1" AntalEnheder="1" />
      <OrdreLinie Varenummer="2" AntalEnheder="2" />
    </Ordreopl>
    <Ordreopl OrdreNummer="5" Bestillingsdato="2007-05-15T15:49:56.773" Leveringsdato="2007-06-08T15:49:56.773">
      <OrdreLinie Varenummer="2" AntalEnheder="6" />
      <OrdreLinie Varenummer="6" AntalEnheder="1" />
      <OrdreLinie Varenummer="7" AntalEnheder="1" />
    </Ordreopl>
  </Kunde>
  <Kunde KundeNummer="3" Navn="Karen Olsen" Adresse="Borgergade 13" Postnr="9000" Bynavn="Aalborg">
    <Ordreopl OrdreNummer="4" Bestillingsdato="2007-05-15T15:49:56.773" Leveringsdato="2007-05-19T15:49:56.773">
      <OrdreLinie Varenummer="4" AntalEnheder="3" />
    </Ordreopl>
  </Kunde>
  <Kunde KundeNummer="4" Navn="Karl Nielsen" Adresse="S�ndergade 67" Postnr="8000" Bynavn="�rhus C" />
</Kunder>';

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml;

SELECT *
	FROM OPENXML(@idoc, '/');

EXEC sp_xml_removedocument @idoc;
GO
