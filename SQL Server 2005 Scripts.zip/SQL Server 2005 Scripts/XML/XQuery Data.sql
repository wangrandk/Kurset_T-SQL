DECLARE @x XML;
DECLARE @y XML;

SET @x = '<k><l>27</l>234</k>';
SET @y = '<k l="27">234</k>';

SELECT @x.query('data(k)'), @x.query('k');
SELECT @y.query('data(k)'), @y.query('k');
