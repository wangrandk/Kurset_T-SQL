USE master;
DROP DATABASE XmlDB;
GO
CREATE DATABASE XmlDB;
GO
USE XmlDB;
CREATE TABLE dbo.KundeOrdre 
(
	KundeId			INT NOT NULL PRIMARY KEY IDENTITY,
	Kundenavn		VARCHAR(30) NOT NULL,
	OrdreData		XML NOT NULL
);
GO
DECLARE @Xml		XML;

SET @Xml =  '<Ordrer>
				<Ordre Ordreid="6" Leveringsdato="2009-4-1">
					<Ordrelinie Varenr="34" AntalEnheder="2"/>
				</Ordre>
			</Ordrer>';

INSERT INTO dbo.KundeOrdre(Kundenavn, OrdreData) VALUES 
	('Jens Olsen', @Xml);

SET @Xml =  '<Ordrer>
				<Ordre Ordreid="4" Leveringsdato="2009-3-21">
					<Ordrelinie Varenr="7" AntalEnheder="1"/>
					<Ordrelinie Varenr="87" AntalEnheder="2"/>
					<Ordrelinie Varenr="33" AntalEnheder="1"/>
				</Ordre>
				<Ordre Ordreid="17" Leveringsdato="2009-5-3">
					<Ordrelinie Varenr="2" AntalEnheder="10"/>
					<Ordrelinie Varenr="56" AntalEnheder="4"/>
				</Ordre>
				<Ordre Ordreid="18">
					<Ordrelinie Varenr="12" AntalEnheder="1"/>
					<Ordrelinie Varenr="7" AntalEnheder="24"/>
				</Ordre>
			</Ordrer>';

INSERT INTO dbo.KundeOrdre(Kundenavn, OrdreData) VALUES 
	('Ane Hansen', @Xml);

SET @Xml =  '<Ordrer>
				<Ordre Ordreid="23">
					<Ordrelinie Varenr="3" AntalEnheder="1"/>
					<Ordrelinie Varenr="6" AntalEnheder="3"/>
				</Ordre>
				<Ordre Ordreid="47" Leveringsdato="2009-4-30">
					<Ordrelinie Varenr="45" AntalEnheder="2"/>
					<Ordrelinie Varenr="21" AntalEnheder="1"/>
					<Ordrelinie Varenr="13" AntalEnheder="5"/>
				</Ordre>
			</Ordrer>';

INSERT INTO dbo.KundeOrdre(Kundenavn, OrdreData) VALUES 
	('Sanne Larsen', @Xml)
GO
SELECT OrdreData.query('   
	<Ordrer>
	{
	for $o in /Ordrer/Ordre
		WHERE COUNT($o/Ordrelinie) < 3
		ORDER BY $o/@Ordreid
        return
			(
            <Ordre Ordrenummer = "{ $o/@Ordreid }"
				   Leveret = "{ $o/@Leveringsdato }" 
            />
			)
	 }
	</Ordrer>
     ') AS Result
	FROM dbo.KundeOrdre;
GO
SELECT OrdreData.query('   
	<Ordrer>
	{
	for $o in /Ordrer/Ordre
		WHERE $o/@Leveringsdato
        return
			(
            <Ordre Ordrenummer = "{ $o/@Ordreid }"
				   Leveret = "{ $o/@Leveringsdato }" 
            />
			)
	 }
	</Ordrer>
     ') AS Result
	FROM dbo.KundeOrdre;
GO
SELECT OrdreData.query('   
	<Ordrer>
	{
	for $o in /Ordrer/Ordre
        return
			(
            <Ordre Ordrenummer = "{ $o/@Ordreid }"
				   Leveret = "{ $o/@Leveringsdato }" 
				   LeveretDagsDato = "{ contains($o/@Leveringsdato, "2009-4-1") }" 
            />
			)
	 }
	</Ordrer>
     ') AS Result
	FROM dbo.KundeOrdre;
