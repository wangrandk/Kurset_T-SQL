USE master
DROP DATABASE XMLDB2;
GO
CREATE DATABASE XMLDB2;
GO
USE XMLDB2;
CREATE TABLE dbo.Postopl
(
	PostNr			SMALLINT NOT NULL PRIMARY KEY,
	Bynavn			VARCHAR(20) NOT NULL
);
GO
CREATE TABLE dbo.Biograf
(
	BiografID		INT NOT NULL PRIMARY KEY,
	BiografNavn		VARCHAR(50) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	PostNr			SMALLINT NOT NULL,
	TlfNr			CHAR(8) NOT NULL,
	CONSTRAINT FK_Biograf_PostOpl FOREIGN KEY(PostNr) REFERENCES dbo.Postopl (PostNr)
);
GO
CREATE TABLE dbo.Sal
(
	SalID			INT NOT NULL PRIMARY KEY,
	BiografID		INT NOT NULL,
	SalNr			INT NOT NULL,
	AntalPladser	SMALLINT NOT NULL,
	CONSTRAINT U_Sal_BiografID_SalNr UNIQUE NONCLUSTERED (BiografID, SalNr),
	CONSTRAINT FK_Sal_Biograf FOREIGN KEY(BiografID) REFERENCES dbo.Biograf (BiografID)
);
GO
CREATE TABLE dbo.Film
(
	FilmID			INT NOT NULL PRIMARY KEY,
	FilmNavn		VARCHAR(50) NOT NULL,
	VarighedMin		SMALLINT NOT NULL
);
GO
CREATE TABLE dbo.Forestilling
(
	SalID			INT NOT NULL,
	FilmID			INT NOT NULL,
	Tidspunkt		SMALLDATETIME NOT NULL,
	CONSTRAINT PK_Forestilling PRIMARY KEY CLUSTERED (SalID,FilmID,Tidspunkt),
	CONSTRAINT FK_Forestilling_Film FOREIGN KEY(FilmID)REFERENCES dbo.Film (FilmID),
	CONSTRAINT FK_Forestilling_Sal FOREIGN KEY(SalID) REFERENCES dbo.Sal (SalID)
);
GO
SET NOCOUNT ON;
INSERT INTO dbo.Postopl VALUES 
	(2000, 'Frederiksberg'),
	(8000, '�rhus C'),
	(9000, 'Aalborg');

INSERT INTO dbo.Biograf VALUES 
	(1, 'Scala', 'Vestergade 3', 2000, '22111213'),
	(2, 'Bio', 'Nygade 23', 2000, '22989786'),
	(3, 'Biografen', '�stergade 14', 9000, '98111112'),
	(4, 'Palads', 'Torvet', 8000, '86202122');

INSERT INTO dbo.Sal VALUES 
	(1, 1, 1, 100),
	(2, 1, 2, 324),
	(3, 2, 1, 60),
	(4, 2, 2, 96),
	(5, 2, 3, 128),
	(6, 3, 1, 200),
	(7, 4, 1, 102),
	(8, 4, 2, 60),
	(9, 4, 3, 178);

INSERT INTO dbo.Film VALUES 
	(1, 'en kort en lang', 98),
	(2, 'Italiensk for Begyndere', 108),
	(3, 'Den eneste Ene', 103),
	(4, 'B�nken', 89),
	(5, 'Arven', 105);

INSERT INTO dbo.Forestilling VALUES 
	(1, 2, '2015-03-21 20:00:00'),
	(1, 3, '2015-03-21 22:30:00'),
	(2, 1, '2015-03-21 19:30:00'),
	(2, 4, '2015-03-21 22:00:00'),
	(3, 1, '2015-03-21 16:00:00'),
	(3, 1, '2015-03-21 19:30:00'),
	(3, 1, '2015-03-21 22:00:00'),
	(4, 2, '2015-03-21 15:00:00'),
	(4, 2, '2015-03-21 20:00:00'),
	(5, 5, '2015-03-21 20:30:00'),
	(6, 5, '2015-03-21 20:00:00'),
	(7, 3, '2015-03-21 19:00:00'),
	(7, 3, '2015-03-21 21:30:00'),
	(8, 4, '2015-03-21 16:00:00'),
	(8, 4, '2015-03-21 20:00:00'),
	(9, 3, '2015-03-21 18:30:00'),
	(9, 3, '2015-03-21 21:00:00');

SET NOCOUNT OFF;
GO