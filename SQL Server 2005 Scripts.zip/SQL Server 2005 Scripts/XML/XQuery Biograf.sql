USE XMLDB2;
GO
SELECT 1 AS ID,*
INTO dbo.Bio
FROM (
	SELECT  *
		FROM dbo.Biograf	INNER JOIN dbo.Sal ON Biograf.BiografID = Sal.BiografID
							INNER JOIN dbo.Forestilling ON Sal.SalID = Forestilling.SalID
		FOR XML AUTO, ROOT('Bio'), TYPE) as B(XMLData);
GO
SELECT *
	FROM dbo.Bio;
GO
SELECT	XmlData.query('/Bio/Biograf') 
	FROM dbo.Bio
GO
SELECT XmlData.query('
		<Biografer>
		{
		for $b in /Bio/Biograf
		where sum($b/Sal/@AntalPladser) > 250
		order by $b/@BiografID
        return
			(
            <Biograf BiografID = "{ $b/@BiografID }"
					  Navn = "{ $b/@BiografNavn }" >

			{for $f in $b/Sal/Forestilling
			return
			(
			<Forestilling FilmID = "{ $f/@FilmID }"
						  Antalpladser = "{ $f/../@AntalPladser }" />
			)
			}			
			</Biograf>
			)
		}
		</Biografer>') AS Result
FROM dbo.Bio;
GO
SELECT XmlData.query('
		<Biografer>
		{
		for $b in /Bio/Biograf
		where $b/@BiografNavn != "Bio"
		order by $b/@BiografID
        return
			(
            <Biograf BiografID = "{ $b/@BiografID }"
					  Navn = "{ $b/@BiografNavn }" >

			{for $f in $b/Sal/Forestilling
			return
			(
			<Forestilling FilmID = "{ $f/@FilmID }"
						  Antalpladser = "{ $f/../@AntalPladser }" />
			)
			}			
			</Biograf>
			)
		}
		</Biografer>') AS Result
FROM dbo.Bio;
GO
DECLARE @BiografNavn	VARCHAR(20);

SET @BiografNavn = 'Bio';

SELECT XmlData.query('/Bio/Biograf[@BiografNavn = sql:variable("@BiografNavn")]')
	FROM dbo.Bio
	WHERE XmlData.exist('/Bio/Biograf[@BiografNavn = sql:variable("@BiografNavn")]') = 'true';
GO
