USE XMLDB2;
GO
SELECT
	BiografID		AS '@BiografID',
	BiografNavn		AS '@BiografNavn',
	Adresse			AS '@Adresse',
	Biograf.PostNr	AS '@Postnr',
	Bynavn			AS '@Bynavn',
	(SELECT 
		Film.FilmID	AS '@FilmId',
		FilmNavn	AS 'FilmNavn',
		Tidspunkt	AS 'Tidspunkt',
		VarighedMin	AS 'VarighedMin'
		FROM dbo.Forestilling INNER JOIN dbo.Film ON  Forestilling.FilmId = Film.FilmID
							  INNER JOIN dbo.Sal ON  Forestilling.SalId = Sal.SalId
		WHERE Sal.BiografId = Biograf.BiografId
		ORDER BY Tidspunkt
		FOR XML PATH('Film'), ROOT('Forestillinger'), TYPE)
	FROM dbo.Biograf INNER JOIN dbo.Postopl ON  Biograf.Postnr = Postopl.Postnr
	FOR XML PATH ('Biograf'), ROOT('Biografer');
GO
SELECT 
	Tidspunkt	AS '@Tidspunkt',
	(SELECT
		BiografNavn	AS '@BiografNavn',
		Film.FilmID	AS '@FilmId',
		FilmNavn	AS '@FilmNavn',
		VarighedMin	AS '@VarighedMin'
		FROM dbo.Forestilling INNER JOIN dbo.Film ON  Forestilling.FilmId = Film.FilmID
							  INNER JOIN dbo.Sal ON  Forestilling.SalId = Sal.SalId
							  INNER JOIN dbo.Biograf ON  Sal.BiografID = Biograf.BiografID 
		WHERE FYdre.Tidspunkt = Forestilling.Tidspunkt
		ORDER BY Film.FilmID, Tidspunkt
		FOR XML PATH('Film'), ROOT('Forestillinger'), TYPE)
	FROM (SELECT DISTINCT Tidspunkt FROM dbo.Forestilling) AS FYdre
	ORDER BY Tidspunkt
	FOR XML PATH('Tid'), ROOT('Forestillinger');
