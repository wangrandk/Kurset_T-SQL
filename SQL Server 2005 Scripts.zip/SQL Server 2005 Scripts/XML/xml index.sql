USE master
DROP DATABASE XmlDB;
GO
CREATE DATABASE XmlDB;
GO
USE XmlDB;
GO
CREATE TABLE dbo.BogPaaLager
(
	ISBN10			VARCHAR(13) NOT NULL 
					CONSTRAINT PK_BogPaaLager PRIMARY KEY,
	ISBN13			VARCHAR(17) NULL,
	Titel			VARCHAR(100) NOT NULL,
	Beskrivelse		VARCHAR(2000) NULL,
	VejledendePris	DECIMAL(9,2) NULL,
	AntalPaaLager	SMALLINT NOT NULL DEFAULT(0),
	Placering		VARCHAR(20) NULL,
	XmlData			XML NULL
);
GO
INSERT INTO dbo.BogPaaLager (ISBN10, ISBN13, Titel, Beskrivelse, VejledendePris,AntalPaaLager, Placering) VALUES 
	('1-1234-5678-0', NULL, 'Windows Server', NULL, 200, 3, 'Butik'),
	('1-2345-9876-4', NULL, 'Windows Client', 'Hvad b�r en superbruger vide om Windows', 300, 0, 'Butik'),
	('2-5678-9887-3', '987-2-5678-9887-3', 'SQL Server Administration', 'Intro til  SQL Server Administration', 250, 2, 'Butik'),
	('3-8765-7654-4', NULL, 'Word', NULL, 200, 7, 'Lager'),
	('3-9753-0987-6', NULL, 'Excel', 'Introduktion til Excel', 150, 3, 'Butik'),
	('4-5678-9887-3', NULL, 'Billedmanipulation for Dummies', NULL, NULL, 1, 'Lager');
GO
UPDATE dbo.BogPaaLager
	SET XmlData = XmlDataBog
	FROM dbo.BogPaaLager AS BPLYdre CROSS APPLY (SELECT *
													FROM dbo.BogPaaLager AS BPLIndre
													WHERE BPLIndre.ISBN10 = BPLYdre.ISBN10
													FOR XML PATH ('Bog'), TYPE)	AS XmlData(XmlDataBog);
GO
SELECT *
	FROM dbo.BogPaaLager;
GO
CREATE PRIMARY XML INDEX PrimaryXML_BogPaaLager_XmlDataBog
    ON dbo.BogPaaLager (XmlData);

CREATE XML INDEX SecondaryXML_BogPaaLager_XmlDataBog_Path 
    ON dbo.BogPaaLager (XmlData)
    USING XML INDEX PrimaryXML_BogPaaLager_XmlDataBog FOR PATH;

CREATE XML INDEX SecondaryXML_BogPaaLager_XmlDataBog_Property 
    ON dbo.BogPaaLager (XmlData)
    USING XML INDEX PrimaryXML_BogPaaLager_XmlDataBog FOR PROPERTY;

CREATE XML INDEX SecondaryXML_BogPaaLager_XmlDataBog_Value 
    ON dbo.BogPaaLager (XmlData)
    USING XML INDEX PrimaryXML_BogPaaLager_XmlDataBog FOR VALUE;
GO
