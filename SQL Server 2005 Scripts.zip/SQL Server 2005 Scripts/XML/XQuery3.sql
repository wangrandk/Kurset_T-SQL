-- input
<Root>   
	<Student>Jhon </Student> 
	<Student> Luka </Student> 
	<Post>1</Post> 
	<Post>2</Post> 
</Root>
-- forventet output
<Root> 
	<Students> 
		<Student>Jhon </Student>   
		<Student> Luka </Student> 
	</Students> 
	<Posts> 
		<Post>1</Post> 
		<Post>2</Post> 
	</Posts> 
</Root>;
GO
DECLARE @x XML = ' 
		<Root> 
			<Student>Jhon </Student> 
			<Student> Luka </Student> 
			<Post>1</Post> 
			<Post>2</Post> 
		</Root>';
 
SELECT @x.query (' 
	for $i in (Root) 
		let $s := $i/Student 
		let $p := $i/Post 
	return 
	<Root> 
		<Students> {$s} </Students> 
		<Posts>{$p}</Posts> 
	</Root> 
');
