USE master
GO
DROP DATABASE ConstraintDB
GO
CREATE DATABASE ConstraintDB
ON PRIMARY
	(NAME = ConstraintDB_sys,
	 FILENAME = 'c:\Databaser\ConstraintDB_sys.mdf',
     SIZE = 400MB,
     MAXSIZE = 600MB,
     FILEGROWTH = 10%)

LOG ON
	(NAME = ConstraintDB_log,
	 FILENAME = 'c:\Databaser\ConstraintDB.ldf',
     SIZE = 200MB,
     MAXSIZE = 500MB,
     FILEGROWTH = 10%)
GO
USE ConstraintDB
CREATE TABLE t1  (
	id		INT NOT NULL PRIMARY KEY)
GO
CREATE TABLE t2 (
	id		INT NOT NULL PRIMARY KEY,
	idref	INT NOT NULL CONSTRAINT fk_t1_t2 FOREIGN KEY REFERENCES t1)
GO
INSERT INTO t1 VALUES 
	(1),
	(2),
	(3),
	(4)
GO
INSERT INTO t2 VALUES 
	(11, 1),
	(12, 3),
	(13, 4),
	(14, 4)
GO
INSERT INTO t2 VALUES 
	(15, 5)			-- fejl
GO
INSERT INTO t2 VALUES
	(16, NULL)		--fejl
GO
DROP TABLE t1		-- fejl - reference til tabellen
GO
DROP TABLE t2
DROP TABLE t1
GO
USE ConstraintDB
CREATE TABLE t1  (
	id		INT NOT NULL PRIMARY KEY)
GO
CREATE TABLE t2 (
	id		INT NOT NULL PRIMARY KEY,
	idref	INT NULL CONSTRAINT fk_t1_t2 FOREIGN KEY REFERENCES t1 (id))
GO
INSERT INTO t1 VALUES 
	(1),
	(2),
	(3),
	(4)
GO
INSERT INTO t2 VALUES 
	(11, 1),
	(12, 3),
	(13, 4),
	(14, 4),
	(16, NULL)
GO
INSERT INTO t2 VALUES 
	(15, 5)		-- fejl
GO
SELECT *
	FROM t1 INNER JOIN t2 ON t1.id = t2.idref
GO
SELECT *
	FROM t1 RIGHT JOIN t2 ON t1.id = t2.idref
GO
DECLARE @i INT = 1

WHILE @i <= 15
BEGIN
	INSERT INTO t1
		SELECT id + (SELECT MAX(id) FROM t1) 
			FROM t1
	INSERT INTO t2
		SELECT	id + (SELECT MAX(id) FROM t2), 
				idref + (SELECT MAX(idref) FROM t2) 
			FROM t2
	SET @i = @i + 1
END
SELECT COUNT(*) FROM t1
SELECT COUNT(*) FROM t2
GO
SELECT *
	FROM t1 INNER JOIN t2 ON t1.id = t2.idref
GO
SELECT *
	FROM t1 RIGHT JOIN t2 ON t1.id = t2.idref
GO
SELECT *
	FROM t1 FULL JOIN t2 ON t1.id = t2.idref
GO
CREATE NONCLUSTERED INDEX nc_t2_idref ON t2 (idref)
GO
DROP TABLE t2
DROP TABLE t1
GO
USE ConstraintDB
CREATE TABLE t1  (
	id		INT NOT NULL PRIMARY KEY,
	txt1	CHAR(100) DEFAULT ('xxxx'),
	txt2	CHAR(100) DEFAULT ('xxxx'),
	txt3	CHAR(100) DEFAULT ('xxxx'),
	txt4	CHAR(100) DEFAULT ('xxxx'),
	txt5	CHAR(100) DEFAULT ('xxxx'),
	txt6	CHAR(100) DEFAULT ('xxxx'),
	txt7	CHAR(100) DEFAULT ('xxxx'),
	txt8	CHAR(100) DEFAULT ('xxxx'),
	txt9	CHAR(100) DEFAULT ('xxxx'),
	txt10	CHAR(100) DEFAULT ('xxxx'))
GO
CREATE TABLE t2 (
	id		INT NOT NULL PRIMARY KEY,
	txt1	CHAR(100) DEFAULT ('xxxx'),
	txt2	CHAR(100) DEFAULT ('xxxx'),
	txt3	CHAR(100) DEFAULT ('xxxx'),
	txt4	CHAR(100) DEFAULT ('xxxx'),
	txt5	CHAR(100) DEFAULT ('xxxx'),
	txt6	CHAR(100) DEFAULT ('xxxx'),
	txt7	CHAR(100) DEFAULT ('xxxx'),
	txt8	CHAR(100) DEFAULT ('xxxx'),
	txt9	CHAR(100) DEFAULT ('xxxx'),
	txt10	CHAR(100) DEFAULT ('xxxx'),
	idref	INT NULL CONSTRAINT fk_t1_t2 FOREIGN KEY REFERENCES t1 (id))
GO
INSERT INTO t1 VALUES 
	(1),
	(2),
	(3),
	(4)
GO
INSERT INTO t2 VALUES 
	(11, 1),
	(12, 3),
	(13, 4),
	(14, 4),
	(16, NULL)
GO
DECLARE @i INT = 1
WHILE @i <= 15
BEGIN
	INSERT INTO t1 (id)
		SELECT id + (SELECT MAX(id) FROM t1) FROM t1
	INSERT INTO t2 (id, idref)
		SELECT	id + (SELECT MAX(id) FROM t2), 
				idref + (SELECT MAX(idref) FROM t2) FROM t2
	SET @i = @i + 1
END
SELECT COUNT(*) FROM t1
SELECT COUNT(*) FROM t2
GO
SELECT *
	FROM t1 INNER JOIN t2 ON t1.id = t2.idref
GO
SELECT *
	FROM t1 RIGHT JOIN t2 ON t1.id = t2.idref
GO
SELECT *
	FROM t1 LEFT JOIN t2 ON t1.id = t2.idref
GO
SELECT *
	FROM t1 FULL JOIN t2 ON t1.id = t2.idref
GO
CREATE NONCLUSTERED INDEX nc_t2_idref ON t2 (idref)
GO
SELECT t2.*
	FROM t1 INNER JOIN t2 ON t1.id = t2.idref
GO
SELECT t2.*
	FROM t1 RIGHT JOIN t2 ON t1.id = t2.idref
GO
SELECT t2.*
	FROM t1 LEFT JOIN t2 ON t1.id = t2.idref
GO
SELECT t2.*
	FROM t1 FULL JOIN t2 ON t1.id = t2.idref
GO
SELECT t1.id, t2.id, t1.txt3, t2.txt4
	FROM t1 INNER JOIN t2 ON t1.id = t2.idref
	WHERE t2.id BETWEEN 5000 and 10000 or
		  t1.id BETWEEN 2000 and 8000
GO
SELECT t1.id, t2.id, t1.txt3, t2.txt4
	FROM t1 RIGHT JOIN t2 ON t1.id = t2.idref
	WHERE t2.id BETWEEN 5000 and 10000 or
		  t1.id BETWEEN 2000 and 8000
GO
SELECT t1.id, t2.id, t1.txt3, t2.txt4
	FROM t1 LEFT JOIN t2 ON t1.id = t2.idref
	WHERE t2.id BETWEEN 5000 and 10000 or
		  t1.id BETWEEN 2000 and 8000
GO
SELECT t1.id, t2.id, t1.txt3, t2.txt4
	FROM t1 FULL JOIN t2 ON t1.id = t2.idref
	WHERE t2.id BETWEEN 5000 and 10000 or
		  t1.id BETWEEN 2000 and 8000
GO
DROP TABLE t2
DROP TABLE t1
GO
USE ConstraintDB
CREATE TABLE t1  (
	id		INT NOT NULL PRIMARY KEY NONCLUSTERED,
	txt1	CHAR(100) DEFAULT ('xxxx'),
	txt2	CHAR(100) DEFAULT ('xxxx'),
	txt3	CHAR(100) DEFAULT ('xxxx'),
	txt4	CHAR(100) DEFAULT ('xxxx'),
	txt5	CHAR(100) DEFAULT ('xxxx'),
	txt6	CHAR(100) DEFAULT ('xxxx'),
	txt7	CHAR(100) DEFAULT ('xxxx'),
	txt8	CHAR(100) DEFAULT ('xxxx'),
	txt9	CHAR(100) DEFAULT ('xxxx'),
	txt10	CHAR(100) DEFAULT ('xxxx'))
GO
CREATE TABLE t2 (
	id		INT NOT NULL PRIMARY KEY NONCLUSTERED,
	txt1	CHAR(100) DEFAULT ('xxxx'),
	txt2	CHAR(100) DEFAULT ('xxxx'),
	txt3	CHAR(100) DEFAULT ('xxxx'),
	txt4	CHAR(100) DEFAULT ('xxxx'),
	txt5	CHAR(100) DEFAULT ('xxxx'),
	txt6	CHAR(100) DEFAULT ('xxxx'),
	txt7	CHAR(100) DEFAULT ('xxxx'),
	txt8	CHAR(100) DEFAULT ('xxxx'),
	txt9	CHAR(100) DEFAULT ('xxxx'),
	txt10	CHAR(100) DEFAULT ('xxxx'),
	idref	INT NULL CONSTRAINT fk_t1_t2 FOREIGN KEY REFERENCES t1 (id))
GO
INSERT INTO t1 VALUES 
	(1),
	(2),
	(3),
	(4)
GO
INSERT INTO t2 VALUES 
	(11, 1),
	(12, 3),
	(13, 4),
	(14, 4),
	(16, NULL)
GO
DECLARE @i INT = 1
WHILE @i <= 15
BEGIN
	INSERT INTO t1 (id)
		SELECT id + (SELECT MAX(id) FROM t1) 
			FROM t1
	INSERT INTO t2 (id, idref)
		SELECT	id + (SELECT MAX(id) FROM t2), 
				idref + (SELECT MAX(idref) FROM t2) 
			FROM t2
	SET @i = @i + 1
END
SELECT COUNT(*) FROM t1
SELECT COUNT(*) FROM t2
GO
SELECT *
	FROM t1 INNER JOIN t2 ON t1.id = t2.idref
GO
SELECT *
	FROM t1 RIGHT JOIN t2 ON t1.id = t2.idref
GO
SELECT *
	FROM t1 LEFT JOIN t2 ON t1.id = t2.idref
GO
SELECT *
	FROM t1 FULL JOIN t2 ON t1.id = t2.idref
GO
CREATE NONCLUSTERED INDEX nc_t2_idref ON t2 (idref)
GO
SELECT t2.*
	FROM t1 INNER JOIN t2 ON t1.id = t2.idref
GO
SELECT t2.*
	FROM t1 RIGHT JOIN t2 ON t1.id = t2.idref
GO
SELECT t2.*
	FROM t1 LEFT JOIN t2 ON t1.id = t2.idref
GO
SELECT t2.*
	FROM t1 FULL JOIN t2 ON t1.id = t2.idref
GO
