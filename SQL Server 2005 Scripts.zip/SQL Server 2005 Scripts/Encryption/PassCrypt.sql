USE master
DROP DATABASE Cryptdb
GO
CREATE DATABASE Cryptdb
GO
USE Cryptdb
GO
CREATE TABLE MasterkeyTable (
	Masterkey	VARCHAR(20) NOT NULL)
GO
INSERT INTO MasterkeyTable VALUES ('hdgtr?ferhhd#trs!erh')
go
CREATE TABLE Info (
	Id			INT IDENTITY NOT NULL PRIMARY KEY,
	navn		VARCHAR(40) NOT NULL,
	userkey		VARBINARY(8000) NOT NULL,
	tekst		VARBINARY(8000) NOT NULL)
GO

CREATE PROCEDURE usp_InsertProc
	@navn		VARCHAR(40),
	@userkey	VARCHAR(30),
	@tekst		VARCHAR(200)
AS 
	DECLARE @MasterKey		VARCHAR(20)
	DECLARE @CryptedUserkey VARBINARY(8000)
	DECLARE @CryptedText	VARBINARY(8000)

	SET @MasterKey = (SELECT TOP 1 MasterKey FROM MasterKeyTable)

	SET @CryptedUserkey = EncryptByPassPhrase(@MasterKey,@userkey)
	SET @cryptedtext = EncryptByPassPhrase(@userkey,@tekst)

	INSERT INTO Info 
		VALUES (@navn, @CryptedUserkey, @Cryptedtext)
GO
CREATE PROCEDURE usp_ReadProc
	@Id			INT,
	@userkey	VARCHAR(30)
AS 
	DECLARE @MasterKey			VARCHAR(20)
	DECLARE @CryptedUserkey		VARBINARY(8000)
	DECLARE @UnCryptedText		VARCHAR(300)

	SET @MasterKey = (SELECT TOP 1 MasterKey FROM MasterKeyTable)

	SET @CryptedUserkey = EnCryptByPassPhrase(@MasterKey, @userkey)
	SELECT @Uncryptedtext = DeCryptByPassPhrase(@userkey, tekst) 
			FROM info
			WHERE id = @id AND
			      DeCryptByPassPhrase(@MasterKey,userkey) = @userkey

	IF @@ROWCOUNT = 0
		RAISERROR ('Id eller password forkert', 16, 1)
	ELSE
		SELECT Id, Navn, @UncryptedText 
			FROM Info 
			WHERE id = @id
GO

EXEC usp_insertproc 'Claus', 'Baldur Claus df', 'dette er en test'

--select * from Info

EXEC usp_readproc 1, 'Baldur Claus df'


EXEC usp_insertproc 'Henrik', 'hhsgdffe!# kljddd', 'dette er stadig en test'

EXEC usp_readproc 2, 'hhsgdffe!# kljddd'
EXEC usp_readproc 2, 'Baldur Claus df'
--select * from info