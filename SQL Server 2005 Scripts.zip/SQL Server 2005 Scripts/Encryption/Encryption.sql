USE master
DROP DATABASE EncryptionDB
GO
CREATE DATABASE EncryptionDB
go
USE EncryptionDB

