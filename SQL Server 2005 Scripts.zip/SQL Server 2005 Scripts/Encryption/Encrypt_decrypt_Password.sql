DECLARE @txt		VARCHAR(20)
DECLARE @txtcrypt	varbinary(256)

SET @txt = 'test kryptering'
SET @txtcrypt = EncryptByPassPhrase ('qlpzxcv1234!!', @txt)

SELECT @txt, @txtcrypt

SET @txt = DecryptByPassphrase('qlpzxcv1234!!', @txtcrypt)
SELECT @txt
