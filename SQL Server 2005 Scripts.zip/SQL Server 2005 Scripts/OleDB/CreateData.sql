USE master	
DROP DATABASE SSISDB
GO
CREATE DATABASE SSISDB
GO
USE SSISDB
CREATE TABLE Vare (
	SurrogatId	INT PRIMARY KEY NOT NULL IDENTITY,
	VareID		INT NOT NULL,
	Varenavn	VARCHAR(20) NOT NULL,
	Pris		DECIMAL(7) NOT NULL,
	StartTid	DATETIME2	NOT NULL DEFAULT(SYSDATETIME()),
	SlutTid		DATETIME2 NULL)

CREATE TABLE VareTransaktioner (
	VareID		INT NOT NULL,
	Varenavn	VARCHAR(20) NOT NULL,
	Pris		DECIMAL(7) NOT NULL,
	Tid			DATETIME2 DEFAULT(SYSDATETIME())	)
GO
INSERT INTO VareTransaktioner (VareID, Varenavn, Pris) VALUES (1, '�l', 3)
WAITFOR DELAY '00:00:00:09'
GO
INSERT INTO VareTransaktioner (VareID, Varenavn, Pris) VALUES (2, 'Vin', 50)
WAITFOR DELAY '00:00:00:09'
GO
INSERT INTO VareTransaktioner (VareID, Varenavn, Pris) VALUES (1, 'R�d Tuborg', 7)
WAITFOR DELAY '00:00:00:09'
GO
INSERT INTO VareTransaktioner (VareID, Varenavn, Pris) VALUES (1, 'R�d Tuborg', 6)
WAITFOR DELAY '00:00:00:09'
GO
INSERT INTO VareTransaktioner (VareID, Varenavn, Pris) VALUES (2, 'R�dvin', 60)
WAITFOR DELAY '00:00:00:09'
GO
INSERT INTO VareTransaktioner (VareID, Varenavn, Pris) VALUES (3, 'Hvidvin', 40)
WAITFOR DELAY '00:00:00:09'
GO
SELECT *
	FROM VareTransaktioner
	
SELECT *
	FROM Vare
GO
DELETE FROM VareTransaktioner
