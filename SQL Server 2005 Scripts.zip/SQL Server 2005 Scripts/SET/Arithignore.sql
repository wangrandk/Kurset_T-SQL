set arithignore on
go
select 1 / 0 as dividebyzero
go
select cast(32768 as smallint) as overflow
go
set arithignore off
go
select 1 / 0 as dividebyzero
go
select cast(32768 as smallint) as overflow
go