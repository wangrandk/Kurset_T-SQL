set concat_null_yields_null on
declare @s1		varchar(10)
declare @s2		varchar(10)
declare @s3		varchar(10)
set @s1 = null	-- er allerede null, men for ....
set @s2 = 'xxxxx'
set @s3 = @s1 + @s2
select @s3
go
set concat_null_yields_null off
declare @s1		varchar(10)
declare @s2		varchar(10)
declare @s3		varchar(10)
set @s1 = null	-- er allerede null, men for ....
set @s2 = 'xxxxx'
set @s3 = @s1 + @s2
select @s3
