use master
drop database SetDB
go
create database SetDB
go
use SetDB
create table t (
	id int not null identity,
	navn	varchar(20) not null)
go
set implicit_transactions on
insert into t (navn) values ('ole')
insert into t (navn) values ('hans')
insert into t (navn) values ('per')
commit transaction
go
set implicit_transactions off
select * from t
go
set implicit_transactions on
insert into t (navn) values ('ane')
insert into t (navn) values ('ida')
insert into t (navn) values ('sanne')
rollback transaction
go
set implicit_transactions off
select * from t
go
set implicit_transactions on
truncate table t
commit transaction
go
set implicit_transactions off
select * from t
go
set implicit_transactions on
insert into t (navn) values ('ane')
insert into t (navn) values ('ida')
insert into t (navn) values ('sanne')
commit transaction
go
set implicit_transactions on
truncate table t
rollback transaction
go
set implicit_transactions off
select * from t
go
begin transaction
truncate table t
rollback transaction
go
select * from t
go
begin transaction
truncate table t

select * from t

insert into t (navn) values ('ane')
insert into t (navn) values ('ida')
insert into t (navn) values ('sanne')

select * from t

rollback transaction
go
select * from t
