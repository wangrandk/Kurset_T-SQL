USE master;
DROP DATABASE IF EXISTS AdmDB;
GO
CREATE DATABASE AdmDB;
CREATE DATABASE TestBackupDB1;
CREATE DATABASE TestBackupDB2;
CREATE DATABASE TestBackupDB3;
CREATE DATABASE TestBackupDB4;
CREATE DATABASE TestBackupDB5;
GO
USE AdmDB;
CREATE TABLE dbo.BackupDB1
(
	name		SYSNAME
);

CREATE TABLE dbo.BackupDB2
(
	name		SYSNAME
);
GO
INSERT INTO dbo.BackupDB1 VALUES 
	('TestBackupDB1'),
	('TestBackupDB3');

INSERT INTO dbo.BackupDB2 VALUES 
	('TestBackupDB1'),
	('TestBackupDB4'),
	('TestBackupDB5');
GO
CREATE PROCEDURE usp_backup_db
(
	@DbDataTable		SYSNAME,	
	@directory			VARCHAR(255) = 'c:\rod\'
)
AS
DECLARE @dbname		SYSNAME;
DECLARE @filename	VARCHAR (255);
DECLARE @tid		VARCHAR(20);
DECLARE @SQL		NVARCHAR(4000) =  CONCAT('SELECT name FROM ', @DbDataTable);

DECLARE @Database TABLE
(
	name		SYSNAME
);

INSERT INTO @Database (name)	
	EXECUTE sp_executesql @stmt = @SQL;
 
WHILE EXISTS(SELECT * FROM @database)
BEGIN
	SET @tid = CONVERT(VARCHAR(20), GETDATE(), 112);
	SET @dbname = (SELECT TOP 1 name FROM @database);
	SET @filename = CONCAT(@directory, @dbname, '_', @tid, '.bak');

	IF NOT EXISTS (SELECT *
						FROM master.sys.databases
						WHERE name = @dbname)
	BEGIN
		DELETE 
			FROM @database 
			WHERE name = @dbname
		CONTINUE
	END;

	BACKUP DATABASE @dbname 
		TO DISK = @filename WITH FORMAT;

	IF DATABASEPROPERTYEX( @dbname , 'Recovery' ) <> 'SIMPLE'
	BEGIN
		SET @filename = CONCAT(@directory, @dbname, '_', @tid, '.log');

		BACKUP LOG @dbname 
			TO DISK = @filename WITH FORMAT;
	END;
	
	DELETE 
		FROM @database 
		WHERE name = @dbname;
END;
GO
EXEC usp_backup_db 'dbo.BackupDB2';
GO
DROP DATABASE TestBackupDB1;
DROP DATABASE TestBackupDB2;
DROP DATABASE TestBackupDB3;
DROP DATABASE TestBackupDB4;
DROP DATABASE TestBackupDB5;
