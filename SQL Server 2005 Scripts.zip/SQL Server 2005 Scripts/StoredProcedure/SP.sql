USE IndexDB
GO
CREATE PROCEDURE usp_postopl
AS
SELECT *
	FROM Postopl
GO
EXEC usp_postopl
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT
AS
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr
GO
EXEC usp_postopl 2000
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT = 2000
AS
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr
GO
EXEC usp_postopl
EXEC usp_postopl 2000
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT = NULL
AS
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr OR
	      @Postnr IS NULL
GO
EXEC usp_postopl
EXEC usp_postopl 2000
EXEC usp_postopl NULL
EXEC usp_postopl @Postnr = 9000
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT
AS
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr
	
IF @@ROWCOUNT = 0
	RAISERROR('Postnr %i findes ikke', 16, 1, @Postnr)
GO
EXEC usp_postopl 2001
EXEC usp_postopl 2000
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT
AS
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr
	
IF @@ROWCOUNT = 0
	RETURN 99
ELSE
	RETURN 0
GO
EXEC usp_postopl 2001
EXEC usp_postopl 2000

DECLARE @Fejlkode		INT
EXEC @Fejlkode =  usp_postopl 2001
SELECT @Fejlkode
GO
DECLARE @Fejlkode		INT
EXEC @Fejlkode =  usp_postopl @Postnr = 2001
SELECT @Fejlkode
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT,
@Fejlkode	INT OUTPUT
AS
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr
	
IF @@ROWCOUNT = 0
	SET @Fejlkode = 99
ELSE
	SET @Fejlkode = 0
GO
EXEC usp_postopl 2001		-- Fejl
GO
DECLARE @Fejlkode		INT
EXEC  usp_postopl 2001, @Fejlkode OUTPUT
SELECT @Fejlkode
GO
DECLARE @Fejlkode		INT
EXEC  usp_postopl 2001, @Fejlkode   -- intet retur
SELECT @Fejlkode
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT OUTPUT
AS
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr
	
IF @@ROWCOUNT = 0
	SET @Postnr = 99
ELSE
	SET @Postnr = 0
GO
DECLARE @Fejlkode		INT = 2001
EXEC  usp_postopl @Fejlkode OUTPUT
SELECT @Fejlkode
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT
AS
SET NOCOUNT ON
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr
	
IF @@ROWCOUNT = 0
BEGIN
	RAISERROR('Postnr %i findes ikke', 16, 1, @Postnr)
	RETURN
END
SELECT TOP 100 *
	FROM Person
	WHERE Postnr = @Postnr
	
SET NOCOUNT OFF
GO
EXEC  usp_postopl 2000
EXEC  usp_postopl 2001
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT OUTPUT
AS
SELECT *
	INTO #p
	FROM Postopl
	WHERE Postnr = @Postnr
	
SELECT *
	FROM #p
GO
EXEC usp_postopl 2000
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT OUTPUT
AS
SELECT *
	INTO #p
	FROM Postopl
	WHERE Postnr = @Postnr
	
EXEC usp_PostoplTemp 
GO
CREATE PROCEDURE usp_PostoplTemp
AS
SELECT *
	FROM #p
GO
EXEC usp_postopl 2000
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT OUTPUT
AS
DECLARE @p TABLE (Postnr SMALLINT)

INSERT 	INTO @p
	SELECT Postnr
		FROM Postopl
		WHERE Postnr = @Postnr
	
SELECT *
	FROM @p
GO
EXEC usp_postopl 2000
GO
CREATE TYPE PostnrTable AS TABLE 
    (Postnr	SMALLINT NULL)
GO
ALTER PROCEDURE usp_Postopl(@PostListe PostnrTable READONLY)
AS
SELECT *
	FROM Postopl
	WHERE PostNr IN (SELECT PostNr FROM @PostListe)
GO
DECLARE @PostListe	PostnrTable

INSERT INTO @PostListe
	VALUES	(1127),
			(8200),
			(9400),
			(NULL)
EXEC usp_Postopl @PostListe
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT
AS
SET NOCOUNT ON
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr
	
IF @@ROWCOUNT = 0
BEGIN
	RAISERROR('Postnr %i findes ikke', 16, 1, @Postnr)
	RETURN
END
SELECT TOP 100 *
	FROM Person
	WHERE Postnr = @Postnr
	
RETURN @@ROWCOUNT	
SET NOCOUNT OFF
GO
ALTER PROCEDURE usp_postopl
(@Postnr		SMALLINT)
AS
SET NOCOUNT ON

SET @Postnr += 200  -- d�rlig eksekveringsplan

SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr
GO
ALTER PROCEDURE usp_postopl
@Postnr		SMALLINT = 2008,
@Fejlkode	INT  = 200 OUTPUT
AS
SELECT @Fejlkode, @Postnr
	
IF @@ROWCOUNT = 0
	SET @Fejlkode = 99
ELSE
	SET @Fejlkode = 0
GO
DECLARE @f		INT 
EXEC usp_postopl @Fejlkode =  @f OUTPUT	, @Postnr = DEFAULT
GO