DROP PROCEDURE usp_p1
DROP PROCEDURE usp_p2
DROP PROCEDURE usp_p3
GO
CREATE PROCEDURE usp_p1
@personid INT
AS
SELECT *
	FROM person
	WHERE personid BETWEEN @personid AND @personid + @personid
GO
CREATE PROCEDURE usp_p2
@personid_min INT,
@personid_max INT
AS
SELECT *
	FROM person
	WHERE personid BETWEEN @personid_min AND @personid_max
GO
CREATE PROCEDURE usp_p3
@personid INT
AS
DECLARE @personid_min INT
DECLARE @personid_max INT

SET @personid_min = @personid
SET @personid_max = @personid + @personid

EXEC usp_p2 @personid_min, @personid_max
GO
DBCC FREEPROCCACHE
GO
EXEC usp_p1 50
GO
EXEC usp_p1 1000000
GO
EXEC usp_p3 50
GO
EXEC usp_p3 1000000
GO
CREATE UNIQUE NONCLUSTERED INDEX pk_person ON person(personid)
