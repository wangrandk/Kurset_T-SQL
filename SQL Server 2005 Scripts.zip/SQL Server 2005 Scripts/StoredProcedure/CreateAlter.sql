USE IndexDB
GO
CREATE PROC usp_person
AS
SELECT *
	FROM Postopl
GO
EXEC usp_person
GO
ALTER PROC usp_person
(@Postnr		SMALLINT)
AS
SELECT *
	FROM Postopl
	WHERE Postnr > @Postnr
GO
EXEC usp_person 4000
EXEC usp_person @Postnr = 4000
GO
ALTER PROC usp_person
(@Postnr		SMALLINT = 8000)
AS
SELECT *
	FROM Postopl
	WHERE Postnr > @Postnr
GO
EXEC usp_person
EXEC usp_person 4000
EXEC usp_person @Postnr = 4000
GO
ALTER PROC usp_person
(@Postnr		SMALLINT = 8000)
AS
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr

SELECT TOP 100 *
	FROM Person
	WHERE Postnr = @Postnr
	
GO
EXEC usp_person 8210
GO
ALTER PROC usp_person
(@Postnr		SMALLINT = 8000)
AS
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr

IF @@rowcount = 0
BEGIN
	RAISERROR('Postnr %i findes ikke', 16, 1, @Postnr)
	RETURN
END

SELECT TOP 100 *
	FROM Person
	WHERE Postnr = @Postnr
	
GO
EXEC usp_person 3040
GO
ALTER PROC usp_person
(@Postnr		INT OUTPUT)
AS
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr

IF @@rowcount = 0
BEGIN
	RAISERROR('Postnr %i findes ikke', 16, 1, @Postnr)
	RETURN
END

SELECT *
	FROM Person
	WHERE Postnr = @Postnr

SET @Postnr = @@ROWCOUNT
GO
DECLARE @Antalpersoner	INT = 8000
EXEC usp_person  @Postnr = @Antalpersoner OUTPUT

SELECT @Antalpersoner
GO
ALTER PROC usp_person
(@Postnr		SMALLINT)
AS
SELECT *
	FROM Postopl
	WHERE Postnr = @Postnr

IF @@rowcount = 0
BEGIN
	RAISERROR('Postnr %i findes ikke', 16, 1, @Postnr)
	RETURN 99
END

SELECT *
	FROM Person
	WHERE Postnr = @Postnr

RETURN 0
GO
DECLARE @Postnr		SMALLINT = 2000
DECLARE @Fejlkode	INT

EXEC @Fejlkode = usp_person  @Postnr = @Postnr

SELECT @Fejlkode
GO
SELECT *
	FROM sys.objects

GO
ALTER PROC usp_x
AS
ALTER TABLE t ADD  j SMALLINT
GO
EXEC usp_x
