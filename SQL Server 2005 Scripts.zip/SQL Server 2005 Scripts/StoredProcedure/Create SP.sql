USE master
DROP DATABASE StoredProcDB
GO
CREATE DATABASE StoredProcDB
GO
USE StoredProcDB
CREATE TABLE dbo.Postopl 
(
	Postnr				SMALLINT		NOT NULL PRIMARY KEY,	
	Bynavn				VARCHAR (30)	NOT NULL
);

CREATE TABLE dbo.Kunde 
(
	KundeId				INT	NOT NULL PRIMARY KEY IDENTITY,
	Navn				VARCHAR (30) NOT NULL,
	Adresse				VARCHAR (30) NOT NULL,
	Postnr				SMALLINT NOT NULL 
						CONSTRAINT fk_Postopl_Kunde 
						FOREIGN KEY REFERENCES dbo.Postopl (Postnr)
);

CREATE TABLE dbo.Ordre 
(
	OrdreId				INT	NOT NULL PRIMARY KEY IDENTITY,
	Bestillingsdato		DATETIME2 NOT NULL DEFAULT (SYSDATETIME()),
	Leveringsdato		DATE NULL,
	KundeId				INT NULL 
						CONSTRAINT fk_Kunde_Ordre 
						FOREIGN KEY REFERENCES dbo.Kunde (KundeId)
);

CREATE TABLE dbo.Ordrelinie 
(
	OrdreId				INT	NOT NULL
						CONSTRAINT fk_Ordre_Ordrelinie 
						FOREIGN KEY REFERENCES dbo.Ordre (OrdreId),
	VareId				INT	NOT NULL,
	AntalEnheder		SMALLINT NOT NULL,
	CONSTRAINT pk_Ordrelinie PRIMARY KEY (OrdreId, VareId)
);
GO
SET NOCOUNT ON
INSERT INTO Postopl VALUES 
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(9000, 'Aalborg');

INSERT INTO Kunde VALUES 
	('Jens Hansen', 'Nygade 3', 2000),
	('Ole Larsen', 'Vestergade 4', 9000),
	('Karen Olsen', 'Borgergade 13', 9000),
	('Karl Nielsen', 'S�ndergade 67', 8000);

INSERT INTO Ordre (Leveringsdato, KundeId) VALUES 
	(DATEADD(DAY, 10, SYSDATETIME()), 2),
	(DATEADD(DAY, 2, SYSDATETIME()), 1),
	(DATEADD(DAY, 20, SYSDATETIME()), 2),
	(DATEADD(DAY, 4, SYSDATETIME()), 3),
	(DATEADD(DAY, 24, SYSDATETIME()), 2);

INSERT INTO Ordrelinie VALUES 
	(1, 3, 2),
	(1, 6, 8),
	(2, 3, 4),
	(3, 1, 1),
	(3, 2, 2),
	(4, 4, 3),
	(5, 2, 6),
	(5, 6, 1),
	(5, 7, 1);
SET NOCOUNT OFF
GO
CREATE PROCEDURE dbo.usp_Kunde
AS
BEGIN
SELECT	Kunde.KundeId,
		Kunde.navn,
		Kunde.Adresse,
		Kunde.Postnr, 
		Postopl.Bynavn
	FROM dbo.Kunde INNER JOIN dbo.Postopl ON Kunde.Postnr = Postopl.Postnr;
END;
GO
EXECUTE dbo.usp_Kunde;
GO
DROP PROCEDURE dbo.usp_Kunde;
GO
CREATE PROC dbo.usp_Kunde
(
	@KundeId	INT
)
AS
SELECT	Kunde.KundeId,
		Kunde.navn,
		Kunde.Adresse,
		Kunde.Postnr, 
		Postopl.Bynavn
	FROM dbo.Kunde INNER JOIN dbo.Postopl ON Kunde.Postnr = Postopl.Postnr
	WHERE KundeId = @KundeId;
GO
EXEC usp_Kunde		--fejl, param mangler
EXEC usp_Kunde 2
EXEC usp_Kunde @KundeId=2
GO
CREATE PROCEDURE usp_Kunde_Ordre
@KundeId	INT
AS
SELECT Kunde.*, Bynavn
	FROM Kunde INNER JOIN Postopl ON Kunde.Postnr = Postopl.Postnr
	WHERE KundeId = @KundeId
SELECT *
	FROM Ordre INNER JOIN Ordrelinie ON Ordre.OrdreId = Ordrelinie.OrdreId
	WHERE Ordre.KundeId = @KundeId
GO
EXEC usp_Kunde_Ordre 2
GO
ALTER PROCEDURE usp_Kunde_Ordre
@KundeId	INT
AS
SELECT Kunde.*, Bynavn
	FROM Kunde INNER JOIN Postopl ON Kunde.Postnr = Postopl.Postnr
	WHERE KundeId = @KundeId
SELECT *
	FROM Ordre INNER JOIN Ordrelinie ON Ordre.OrdreId = Ordrelinie.OrdreId
	WHERE Ordre.KundeId = @KundeId
RETURN @@ROWCOUNT
GO
EXEC usp_Kunde_Ordre 2
GO
DECLARE @antal_ol	INT
EXEC @antal_ol = usp_Kunde_Ordre 2
SELECT @antal_ol
GO
ALTER PROC usp_Kunde_Ordre
@KundeId			INT,
@antal_Ordrelinier	INT OUTPUT
AS
SELECT Kunde.*, Bynavn
	FROM Kunde INNER JOIN Postopl ON Kunde.Postnr = Postopl.Postnr
	WHERE KundeId = @KundeId
if @@ROWCOUNT = 0
	RETURN 1
SELECT *
	FROM Ordre INNER JOIN Ordrelinie ON Ordre.OrdreId = Ordrelinie.OrdreId
	WHERE Ordre.KundeId = @KundeId
SET @antal_Ordrelinier = @@ROWCOUNT
RETURN 0
GO
DECLARE @antal_ol	INT
DECLARE @fejl		INT

EXEC @fejl = usp_Kunde_Ordre 5, @antal_ol OUTPUT

SELECT @antal_ol AS antal, @fejl AS fejl
GO
ALTER PROCEDURE usp_Kunde_Ordre
@KundeId			INT
AS
SELECT Kunde.*, Bynavn
	FROM Kunde INNER JOIN Postopl ON Kunde.Postnr = Postopl.Postnr
	WHERE KundeId = @KundeId
IF @@ROWCOUNT = 0
BEGIN
	RAISERROR ('Kunde %i findes ikke', 16, 1, @KundeId)
	RETURN
END
SELECT *
	FROM Ordre INNER JOIN Ordrelinie ON Ordre.OrdreId = Ordrelinie.OrdreId
	WHERE Ordre.KundeId = @KundeId
GO
EXEC usp_Kunde_Ordre 5
GO
CREATE PROCEDURE usp_Ordre
@OrdreId_fra	INT,
@OrdreId_til	INT = @OrdreId_fra
AS
SELECT *
	FROM Ordre
	WHERE OrdreId BETWEEN @OrdreId_fra AND @OrdreId_til
GO
EXEC usp_Ordre 1,3
GO
EXEC usp_Ordre 2
GO
ALTER PROCEDURE usp_Ordre
@OrdreId_fra	INT = NULL,
@OrdreId_til	INT = @OrdreId_fra
AS
DECLARE @i INT = 20
IF @OrdreId_fra IS NULL
BEGIN
	SET @OrdreId_fra = (SELECT MIN(OrdreId) FROM Ordre)
	SET @OrdreId_til = (SELECT MAX(OrdreId) FROM Ordre)
END 
SET @i += 30
SELECT *
	FROM Ordre
	WHERE OrdreId BETWEEN @OrdreId_fra AND @OrdreId_til
GO
EXEC usp_Ordre
GO
ALTER PROCEDURE usp_Ordre
@OrdreId_fra	INT,
@OrdreId_til	INT
AS
SELECT *
	FROM Ordre
	WHERE OrdreId BETWEEN @OrdreId_fra AND @OrdreId_til
GO
DECLARE @Fra		INT = 2
DECLARE @Til		INT = 4

EXEC usp_Ordre @Fra, @Til
GO
DECLARE @Fra		SMALLINT = 2
DECLARE @Til		SMALLINT = 4

EXEC usp_Ordre @Fra, @Til
GO
DECLARE @Fra		DECIMAL(9) = 2
DECLARE @Til		DECIMAL(9) = 4

EXEC usp_Ordre @Fra, @Til
GO
DECLARE @Fra		VARCHAR(4) = 'k2' -- fejl
DECLARE @Til		SMALLINT = 4

EXEC usp_Ordre @Fra, @Til
