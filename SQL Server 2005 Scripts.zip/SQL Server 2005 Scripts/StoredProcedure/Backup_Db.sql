CREATE PROCEDURE usp_backup_db
(
	@directory VARCHAR(255) = 'c:\rod\'
)
AS
DECLARE @dbname		SYSNAME;
DECLARE @filename	VARCHAR (255);
DECLARE @tid		VARCHAR(20);

SELECT name
   INTO #databases
   FROM master..sysdatabases
   WHERE name NOT IN ('tempdb', 'model');

WHILE EXISTS(SELECT * FROM #databases)
BEGIN
	SET @tid = CONVERT(VARCHAR(20), GETDATE(), 112);
	SET @dbname = (SELECT TOP 1 name FROM #databases);
	SET @filename = CONCAT(@directory, @dbname, '_',  @tid, '.bak');
	
	BACKUP DATABASE @dbname 
		TO DISK = @filename WITH FORMAT;

	IF DATABASEPROPERTYEX( @dbname , 'Recovery' ) <> 'SIMPLE'
	BEGIN
		SET @filename = CONCAT(@directory, @dbname, '_',  @tid, '.log');

		BACKUP LOG @dbname 
			TO DISK = @filename WITH FORMAT;
	END;
	
	DELETE 
		FROM #databases 
		WHERE name = @dbname;
END;
GO
EXEC usp_backup_db;
