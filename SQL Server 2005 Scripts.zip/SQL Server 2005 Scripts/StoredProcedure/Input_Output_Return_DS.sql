USE master
DROP DATABASE StoredProcDB
GO
CREATE DATABASE StoredProcDB
GO
USE StoredProcDB
GO
CREATE PROCEDURE dbo.usp_test
(
	@i		SMALLINT,
	@j		INT
)
AS
BEGIN
	PRINT @i;
	PRINT @j;
END;
GO
DECLARE @x		SMALLINT = 20000;
DECLARE @y		INT = 100000;

EXEC dbo.usp_test @x, @y;
GO
DECLARE @x		INT = 20000;
DECLARE @y		INT = 100000;

EXEC dbo.usp_test @x, @y;
GO
DECLARE @x		INT = 200000;
DECLARE @y		INT = 100000;

EXEC dbo.usp_test @x, @y;
GO
DECLARE @x		INT = 20000;
DECLARE @y		SMALLINT = 10000;

EXEC dbo.usp_test @x, @y;
GO
DECLARE @x		SMALLINT = 20000;
DECLARE @y		INT = 100000;

EXEC dbo.usp_test @x, @y;

EXEC dbo.usp_test 20000, 100000;
GO
DECLARE @x		SMALLINT = 20000;
DECLARE @y		INT = 100000;

EXEC dbo.usp_test @i = @x, @j = @y;

EXEC dbo.usp_test  @j = @y, @i = @x;
GO
DECLARE @x		SMALLINT = 20000;
DECLARE @y		INT = 100000;

EXEC dbo.usp_test @x, @j = @y;

EXEC dbo.usp_test  @i = @x, @y;			-- Fejl
GO
-- readonly
DROP PROCEDURE dbo.usp_test;
GO
CREATE PROCEDURE dbo.usp_test
(
	@i		SMALLINT,
	@j		INT
)
AS
BEGIN
	SET @i = @i + 10;
	SET @j = @i + @j;
	PRINT @j;
END;
GO
EXEC dbo.usp_test 10, 20;
GO
DROP PROCEDURE dbo.usp_test;
GO
CREATE PROCEDURE dbo.usp_test
(
	@i		SMALLINT,
	@j		INT READONLY			-- kan kun angives for table-valued param
)
AS
BEGIN
	SET @i = @i + 10;
	SET @j = @i + @j;
	PRINT @j;
END;
GO
EXEC dbo.usp_test 10, 20;
GO
-- table-valued parameter
CREATE TYPE IntTable AS TABLE 
(
	i	INT NOT NULL
);
GO
DROP PROCEDURE dbo.usp_test;
GO
CREATE PROCEDURE dbo.usp_test
(
	@i			IntTable READONLY,
	@iListe		VARCHAR(8000) OUTPUT
)
AS
BEGIN
	SELECT @iListe = ISNULL(@iListe + ', ', '') + CAST(i AS VARCHAR(10))
		FROM @i;
END;
GO
DECLARE @i		IntTable;
DECLARE @Liste	VARCHAR(8000);

INSERT INTO @i VALUES
	(20),
	(50),
	(40);

EXEC dbo.usp_test  @i, @Liste OUTPUT;

SELECT @Liste;
GO
-- Output
DROP PROCEDURE dbo.usp_test;
GO
CREATE PROCEDURE dbo.usp_test
(
	@i		SMALLINT,
	@j		INT,
	@k		INT OUTPUT
)
AS
BEGIN
	SET @k = @i + @j;
END;
GO
DECLARE @x		SMALLINT = 20000;
DECLARE @y		INT = 100000;
DECLARE @z		INT;

EXEC dbo.usp_test @x, @y, @z OUTPUT;

SELECT @z;

EXEC dbo.usp_test 30000, 50000, @z OUTPUT;

SELECT @z;
GO
DROP PROCEDURE dbo.usp_test;
GO
CREATE PROCEDURE dbo.usp_test
(
	@k		INT OUTPUT,
	@i		SMALLINT,
	@j		INT

)
AS
BEGIN
	SET @k = @i + @j;
END;
GO
DECLARE @x		SMALLINT = 20000;
DECLARE @y		INT = 100000;
DECLARE @z		INT;

EXEC dbo.usp_test  @z OUTPUT, @x, @y;

SELECT @z;
GO
DROP PROCEDURE dbo.usp_test;
GO
CREATE PROCEDURE dbo.usp_test
(
	@i		SMALLINT,
	@j		INT,
	@k		INT OUTPUT
)
AS
BEGIN
	SET @k = @i + @j + @k;
END;
GO
DECLARE @x		SMALLINT = 20000;
DECLARE @y		INT = 100000;
DECLARE @z		INT;

EXEC dbo.usp_test @x, @y, @z OUTPUT;

SELECT @z;
GO
DECLARE @x		SMALLINT = 20000;
DECLARE @y		INT = 100000;
DECLARE @z		INT = 40000;

EXEC dbo.usp_test @x, @y, @z OUTPUT;

SELECT @z;
GO
DROP PROCEDURE dbo.usp_test;
GO
CREATE PROCEDURE dbo.usp_test
(
	@i		SMALLINT = 20000,
	@j		INT = 30000
)
AS
BEGIN
	PRINT @i + @j;
END;
GO
EXEC dbo.usp_test;

EXEC dbo.usp_test 10000;

EXEC dbo.usp_test 10000, 40000;

EXEC dbo.usp_test @j = 40000;

EXEC dbo.usp_test DEFAULT, 40000;
GO
DROP PROCEDURE dbo.usp_test;
GO
CREATE PROCEDURE dbo.usp_test
(
	@i		SMALLINT = 20000,
	@j		INT = 30000,
	@k		INT OUTPUT
)
AS
BEGIN
	SET @k = @i + @j;
END;
GO
DECLARE @z		INT;

EXEC dbo.usp_test @k = @z OUTPUT;

SELECT @z;
GO
-- return
DROP PROCEDURE dbo.usp_test;
GO
CREATE PROCEDURE dbo.usp_test
AS
BEGIN
	DECLARE    @i		INT;

	SELECT @i = 1/1;
END;
GO
DECLARE @Return		INT;

EXEC @Return = dbo.usp_test;

SELECT @Return;
GO
DROP PROCEDURE dbo.usp_SletKunde;
GO
CREATE TABLE dbo.Postopl
(
	Postnr		SMALLINT NOT NULL PRIMARY KEY,
	Bynavn		VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Kunde
(
	Kundeid		INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(30) NOT NULL,
	Adresse		VARCHAR(30) NOT NULL,
	Postnr		SMALLINT NOT NULL REFERENCES Postopl
);
GO
INSERT INTO dbo.Postopl VALUES
	(2000, 'Frederiksberg'),
	(5000, 'Odense C');

INSERT INTO dbo.Kunde VALUES
	(1, 'Hanne Olsen', 'Nygade 2', 2000),
	(2, 'Per Hansen', 'Vestergade 21', 5000),
	(3, '�ge Carlsen', 'Torvet 44', 5000),
	(4, 'Maren Knudsen', 'S�ndergade 7', 2000);
GO
CREATE PROCEDURE dbo.usp_SletKunde
(
	@KundeId		INT
)
AS
BEGIN
	DELETE
		FROM dbo.Kunde
		WHERE KundeId = @Kundeid;

	IF @@ROWCOUNT = 1
		RETURN 0;
	ELSE
		RETURN -1;
END;
GO
DECLARE @Return		INT;

EXEC @Return = dbo.usp_SletKunde @Kundeid = 1;

SELECT @Return;
GO
DECLARE @Return		INT;

EXEC @Return = dbo.usp_SletKunde @Kundeid = 1123;

SELECT @Return;
GO
DROP PROCEDURE dbo.usp_InsertKunde
GO
CREATE PROCEDURE dbo.usp_InsertKunde
(
	@KundeId		INT,
	@Navn			VARCHAR(30),
	@Adresse		VARCHAR(30),
	@Postnr			SMALLINT
)
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION;
		INSERT INTO dbo.Kunde (KundeId, Navn, Adresse, Postnr) VALUES
			(@KundeId, @Navn, @Adresse, @Postnr);
		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		IF ERROR_NUMBER() = 2627					-- PK findes i forvejen
			THROW 56432,'Kundeid findes allerede', 1
		ELSE
			IF ERROR_NUMBER() = 547					-- FK fejler
				THROW 56433,'Postnr findes ikke', 1
			ELSE 
				IF ERROR_NUMBER() = 515				-- kolonne NOT NULL
					THROW 56435,'Alle felter skal udfyldes', 1
				ELSE
					THROW;


	END CATCH;
END;
GO
EXEC dbo.usp_InsertKunde @Kundeid = 1, @Navn = 'Ole Larsen', @Adresse = 'Nygade 2', @Postnr = 2000;

EXEC dbo.usp_InsertKunde @Kundeid = 1, @Navn = 'Ole Larsen', @Adresse = 'Nygade 2', @Postnr = 2000;

EXEC dbo.usp_InsertKunde @Kundeid = 33, @Navn = 'Ida Hansen', @Adresse = 'Nygade 22', @Postnr = 6000;

EXEC dbo.usp_InsertKunde @Kundeid = 87, @Navn = NULL, @Adresse = 'Nygade 22', @Postnr = 5000;

EXEC dbo.usp_InsertKunde @Kundeid = 112, @Navn = 'S�rine Pedersen', @Adresse = 'Strandgade 19', @Postnr = 50000;
GO
TRUNCATE TABLE dbo.Kunde;
GO
DROP PROCEDURE usp_InsertKunde
GO
CREATE PROCEDURE usp_InsertKunde
	@Kundeid		INT,
	@Navn			VARCHAR(30),
	@Adresse		VARCHAR(30),
	@Postnr			SMALLINT
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION;
		INSERT INTO dbo.Kunde (Kundeid, Navn, Adresse, Postnr) VALUES
			(@Kundeid, @Navn, @Adresse, @Postnr);
		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		THROW 67543, 'Fejl ved oprettelse af Kunde', 1;
	END CATCH
END;
GO
EXEC usp_InsertKunde 234, 'Ole Olsen', 'Vestergade 76', 2000;

EXEC usp_InsertKunde 234, 'Ole Olsen', 'Vestergade 76', 2000;
GO