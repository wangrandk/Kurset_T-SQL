use Indexdb
GO
CREATE PROCEDURE usp_person
@min_personid	INT,
@max_personid	INT
AS
SELECT personid, Navn
	FROM person
	WHERE personid BETWEEN @min_personid AND @max_personid

SELECT *
	FROM person
	WHERE personid < @min_personid

SELECT *
	FROM person
	WHERE personid > @max_personid
GO
CREATE INDEX nc_person_personid ON person(personid, Navn)
GO
EXEC usp_person 10000, 2000000
GO
EXEC usp_person 20000, 3000000
GO
DROP INDEX person.nc_person_personid
GO
EXEC usp_person 20000, 3000000
