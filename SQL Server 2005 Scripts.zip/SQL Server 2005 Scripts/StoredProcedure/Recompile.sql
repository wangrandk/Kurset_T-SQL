USE IndexDB;
GO
CREATE INDEX nc_Person_Navn ON dbo.Person(Navn);
GO
DBCC FREEPROCCACHE;

DBCC DROPCLEANBUFFERS;
SELECT *
	FROM dbo.Person
	WHERE Navn = 'Poul Ove Carlson';

DBCC DROPCLEANBUFFERS;
SELECT *
	FROM dbo.Person
	WHERE Navn = 'Andreas Nielsen';
GO
UPDATE dbo.Person
	SET Fornavn = 'Andreas', Efternavn = 'Nielsen'		-- ca. 170000 forekomster
	WHERE PersonID % 30 = 2;

UPDATE dbo.Person
	SET Fornavn = 'Poul Ove', Efternavn = 'Carlson'		-- 1 forekomst
	WHERE PersonID = 45;

UPDATE STATISTICS dbo.Person WITH FULLSCAN;
GO
SELECT COUNT(*)
	FROM dbo.Person
	WHERE Navn = 'Poul Ove Carlson';

SELECT COUNT(*)
	FROM dbo.Person
	WHERE Navn = 'Andreas Nielsen';
GO
DROP PROCEDURE usp_Person;
GO
CREATE PROCEDURE usp_Person
	@Navn		VARCHAR(41)
AS
BEGIN
	SELECT *
		FROM dbo.Person
		WHERE Navn = @Navn;
END;
GO
DBCC FREEPROCCACHE;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

DBCC DROPCLEANBUFFERS;
EXEC usp_Person 'Poul Ove Carlson';

DBCC DROPCLEANBUFFERS;
EXEC usp_Person 'Andreas Nielsen';
GO
DBCC FREEPROCCACHE;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

DBCC DROPCLEANBUFFERS;
EXEC usp_Person 'Andreas Nielsen';

DBCC DROPCLEANBUFFERS;
EXEC usp_Person 'Poul Ove Carlson';
GO
ALTER PROCEDURE usp_Person
	@Navn		VARCHAR(41)
WITH RECOMPILE
AS
BEGIN
	SELECT *
		FROM dbo.Person
		WHERE Navn = @Navn;
END;
GO
DBCC FREEPROCCACHE;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

DBCC DROPCLEANBUFFERS;
EXEC usp_Person 'Poul Ove Carlson';

DBCC DROPCLEANBUFFERS;
EXEC usp_Person 'Andreas Nielsen';
GO
DBCC FREEPROCCACHE;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

DBCC DROPCLEANBUFFERS;
EXEC usp_Person 'Andreas Nielsen';

DBCC DROPCLEANBUFFERS;
EXEC usp_Person 'Poul Ove Carlson';
GO
DROP PROCEDURE usp_Person;
GO
CREATE PROCEDURE usp_Person
	@Navn		VARCHAR(41)
AS
BEGIN
	IF @Navn = 'Andreas Nielsen'
		SET @Navn = 'Poul Ove Carlson';
	ELSE
		SET @Navn = 'Andreas Nielsen';

	SELECT *
		FROM dbo.Person
		WHERE Navn = @Navn;
END;
GO
DBCC FREEPROCCACHE;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

DBCC DROPCLEANBUFFERS;
EXEC usp_Person 'Poul Ove Carlson';

DBCC DROPCLEANBUFFERS;
EXEC usp_Person 'Andreas Nielsen';
GO
DBCC FREEPROCCACHE;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

DBCC DROPCLEANBUFFERS;
EXEC usp_Person 'Andreas Nielsen';

DBCC DROPCLEANBUFFERS;
EXEC usp_Person 'Poul Ove Carlson';
GO
