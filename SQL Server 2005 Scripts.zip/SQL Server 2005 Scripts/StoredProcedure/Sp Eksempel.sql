USE IntroDB
GO
SELECT TOP 10 *
	FROM Kunde
GO
CREATE PROC usp_Kunde
	@Efternavn			VARCHAR(20),
	@Koen				CHAR(1) = NULL
AS
IF @Efternavn IS NULL
BEGIN
	RAISERROR('EFternavn SKAL v�re udfyldt', 16, 1)
	RETURN
END

IF @Koen IS NULL
	SELECT *
		FROM Kunde
		WHERE Efternavn = @Efternavn
ELSE
	SELECT *
		FROM Kunde
		WHERE	Efternavn = @Efternavn AND
				Koenkode = @Koen
GO
EXEC usp_Kunde NULL, NULL
EXEC usp_Kunde 'Christiansen', NULL
EXEC usp_Kunde 'Christiansen', 'M'
EXEC usp_Kunde 'Christiansen', 'K'
GO
ALTER PROC usp_Kunde
	@Efternavn			VARCHAR(20),
	@Koen				CHAR(1) = NULL
AS
IF @Efternavn IS NULL
BEGIN
	RAISERROR('EFternavn SKAL v�re udfyldt', 16, 1)
	RETURN
END

IF @Koen NOT IN (SELECT DISTINCT KoenKode FROM Kunde WHERE KoenKode IS NOT NULL)
BEGIN
	RAISERROR('K�n har en ikke lovlig v�rdi', 16, 1)
	RETURN
END

SELECT *
	FROM Kunde
	WHERE	Efternavn = @Efternavn AND
			(Koenkode = @Koen OR @Koen IS NULL)
GO
EXEC usp_Kunde 'Christiansen', NULL
EXEC usp_Kunde 'Christiansen', 'M'
EXEC usp_Kunde 'Christiansen', 'K'
EXEC usp_Kunde 'Christiansen', 'P'
GO
ALTER PROC usp_Kunde
	@Efternavn			VARCHAR(20),
	@Koen				CHAR(1) = NULL,
	@Postnr				SMALLINT = NULL,
	@Kundetype			CHAR(1) = NULL
AS
IF @Efternavn IS NULL
BEGIN
	RAISERROR('EFternavn SKAL v�re udfyldt', 16, 1)
	RETURN
END

IF @Koen NOT IN (SELECT DISTINCT KoenKode FROM Kunde WHERE KoenKode IS NOT NULL)
BEGIN
	RAISERROR('%s har en ikke lovlig v�rdi for k�n', 16, 1, @Koen)
	RETURN
END

SELECT *
	FROM Kunde
	WHERE	Efternavn = @Efternavn AND
			(Koenkode = @Koen OR @Koen IS NULL) AND
			(Postnr = @Postnr OR @Postnr IS NULL) AND
			(KundetypeKode = @Kundetype OR @Kundetype IS NULL)
GO