USE master
DROP DATABASE ScdDB
GO
CREATE DATABASE ScdDB
GO
USE ScdDB
CREATE TABLE Person (
	Surrogatid		INT NOT NULL PRIMARY KEY IDENTITY,
	Personid		INT NOT NULL,
	Navn			VARCHAR (30) NOT NULL,
	Adresse			VARCHAR (30) NOT NULL,
	Postnr			SMALLINT NOT NULL,
	Oprettet_dato	DATETIME2 DEFAULT (SYSDATETIME()),
	Udgaaet_dato	DATETIME2 NULL)
GO
CREATE TABLE Person_transaktion (
	Transaktionsid	INT NOT NULL PRIMARY KEY IDENTITY,
	Personid		INT NOT NULL,	
	Navn			VARCHAR (30) NOT NULL,
	Adresse			VARCHAR (30) NOT NULL,
	Postnr			SMALLINT NOT NULL,
	Dato			DATETIME2 DEFAULT(SYSDATETIME()))
GO
SET NOCOUNT ON
INSERT INTO Person VALUES 
	(1, 'Ole Olsen', 'Nygade', 8000, DEFAULT, DEFAULT),
	(2, 'Ane Larson', 'Vestergade', 9000, DEFAULT, DEFAULT),
	(3, 'Ida Hansen', 'Torvet', 2000, DEFAULT, DEFAULT)

INSERT INTO Person_transaktion VALUES 
	(4, 'Bo Knudsen', 'Nytorv', 3000, SYSDATETIME()),
	(2, 'ane Larsen', 'Nytorv', 3000, SYSDATETIME()),
	(5, 'Knud Petersen', '�stergade', 5000, SYSDATETIME()),
	(6, 'Maren Hansen', 'S�ndergadegade', 4000, SYSDATETIME()),
	(3, 'Ida Hansen', 'N�rregade', 3000, SYSDATETIME())
	
SET NOCOUNT OFF
GO
SELECT * 
	FROM Person

SELECT * 
	FROM Person_transaktion
---------------------------------------------------------------------------------------
USE ScdDB
GO
TRUNCATE TABLE Person
TRUNCATE TABLE Person_transaktion
GO
SET NOCOUNT ON
INSERT INTO Person VALUES 
	(1, 'Ole Olsen', 'Nygade', 8000, DEFAULT, DEFAULT),
	(2, 'Ane Larson', 'Vestergade', 9000, DEFAULT, DEFAULT),
	(3, 'Ida Hansen', 'Torvet', 2000, DEFAULT, DEFAULT)

INSERT INTO Person_transaktion VALUES 
	(4, 'Bo Knudsen', 'Nytorv', 3000, SYSDATETIME()),
	(2, 'Ane Larson', 'Nytorv', 5000, SYSDATETIME()),
	(2, 'Ane Larsen', 'Nytorv', 9000, SYSDATETIME())
SET NOCOUNT OFF
GO
SELECT * 
	FROM Person

SELECT * 
	FROM Person_transaktion
GO
SELECT pa.*
	FROM 
	(SELECT DISTINCT PersonID	
		FROM Person_transaktion) AS PID CROSS APPLY 
								(SELECT TOP 1 *
									FROM Person_transaktion AS pt
									WHERE pt.Personid = pid.Personid
									ORDER BY Dato DESC) AS Pa
