USE master
DROP DATABASE DataModelDB
GO
CREATE DATABASE DataModelDB
GO
USE DataModelDB
CREATE TABLE Pasning (
	PasningsID		INT NOT NULL,
	HundeID			INT NOT NULL,
	HundeStr		VARCHAR(5) NOT NULL,
	StartDato		DATE NOT NULL,
	SlutDato		DATE NOT NULL,
	CONSTRAINT PK_Pasning PRIMARY KEY(PasningsID, HundeID),
	CONSTRAINT CK_Pasning_Dato CHECK(StartDato < SlutDato))

CREATE TABLE Bure (
	HundeStr		VARCHAR(5) NOT NULL PRIMARY KEY,
	Antalbure		INT NOT NULL,
	Prioritet		INT NOT NULL UNIQUE)
GO
INSERT INTO Pasning VALUES 
	(1, 11, 'Mini', '2011-5-20', '2011-6-8'),
	(1, 32, 'Midi', '2011-5-20', '2011-6-8'),

	(2, 44, 'Midi', '2011-5-22', '2011-5-23'),

	(3, 81, 'Maxi', '2011-5-22', '2011-5-25'),

	(4, 51, 'Mini', '2011-5-29', '2011-6-5'),
	(4, 67, 'Midi', '2011-5-29', '2011-6-5'),
	(4, 76, 'Maxi', '2011-5-29', '2011-6-5')

INSERT INTO Bure VALUES
	('Mini', 5, 1),
	('Midi', 3, 2),
	('Maxi', 2, 3)
GO
CREATE FUNCTION dbo.LedigeBure 
	(
	@Startdato		DATE, 
	@Slutdato		DATE,
	@HundeStr		VARCHAR(5)
	)
RETURNS @Ledige TABLE (
				Dato				DATE NOT NULL,
				HundeStr			VARCHAR(5) NOT NULL,
				Prioritet			SMALLINT NOT NULL,
				AntalLedigeBure		INT NOT NULL
	)
AS
BEGIN
	WITH 
	Dage 
	AS
	(
	SELECT @Startdato AS Dato
	UNION ALL
	SELECT DATEADD(d, 1, Dato)
		FROM Dage
		WHERE DATEADD(d, 1, Dato) <= @Slutdato)
		
	INSERT INTO @Ledige	
		SELECT	Dage.Dato,
				AktBure.HundeStr,
				AktBure.Prioritet,
				AktBure.Antalbure - COUNT(Pasning.HundeID) AS AntalLedigeBure
			FROM (Dage	CROSS JOIN (SELECT * 
										FROM Bure
										WHERE Prioritet >= (SELECT Prioritet 
																FROM Bure
																WHERE Bure.HundeStr = @HundeStr)) AS AktBure)
						LEFT JOIN Pasning ON	Pasning.HundeStr = AktBure.HundeStr AND
												Dage.Dato BETWEEN Pasning.StartDato AND Pasning.SlutDato
			GROUP BY AktBure.HundeStr, Dage.Dato, AktBure.Prioritet, AktBure.Antalbure
	OPTION (MAXRECURSION 9000);
RETURN
END
GO
DECLARE @Startdato		DATE = '2011-5-21';
DECLARE @Slutdato		DATE = '2011-5-22';
DECLARE @HundeStr		VARCHAR(5) 

SET @HundeStr = 'Mini'

SELECT *
	FROM dbo.LedigeBure (@Startdato, @Slutdato, @HundeStr)
	ORDER BY Dato, Prioritet

SET @HundeStr = 'Midi'

SELECT *
	FROM dbo.LedigeBure (@Startdato, @Slutdato, @HundeStr)
	ORDER BY Dato, Prioritet

SET @HundeStr = 'Maxi'

SELECT *
	FROM dbo.LedigeBure (@Startdato, @Slutdato, @HundeStr)
	ORDER BY Dato, Prioritet
GO
INSERT INTO Pasning VALUES 
	(5, 32, 'Mini', '2011-5-21', '2011-5-22'),
	(5, 19, 'Mini', '2011-5-21', '2011-5-22'),
	(5, 48, 'Mini', '2011-5-21', '2011-5-22'),

	(5, 16, 'Midi', '2011-5-21', '2011-5-22'),
	(5, 82, 'Midi', '2011-5-21', '2011-5-22'),

	(5, 17, 'Maxi', '2011-5-21', '2011-5-22')
GO
DECLARE @Startdato		DATE = '2011-5-21';
DECLARE @Slutdato		DATE = '2011-5-22';
DECLARE @HundeStr		VARCHAR(5) 

SET @HundeStr = 'Mini'

SELECT *
	FROM dbo.LedigeBure (@Startdato, @Slutdato, @HundeStr)
	ORDER BY Dato, Prioritet

SET @HundeStr = 'Midi'

SELECT *
	FROM dbo.LedigeBure (@Startdato, @Slutdato, @HundeStr)
	ORDER BY Dato, Prioritet

SET @HundeStr = 'Maxi'

SELECT *
	FROM dbo.LedigeBure (@Startdato, @Slutdato, @HundeStr)
	ORDER BY Dato, Prioritet
GO
