USE master
DROP DATABASE DataModelDB
GO
CREATE DATABASE DataModelDB
GO
USE DataModelDB
CREATE TABLE PrisKlasse (
	ID				INT NOT NULL PRIMARY KEY IDENTITY,
	HundeStr		VARCHAR(5) NOT NULL,
	StartDato		DATE NOT NULL,
	SlutDato		DATE NULL,
	Pris			SMALLINT)
GO
CREATE TRIGGER ins_upd_del__Prisklasse ON Prisklasse
AFTER INSERT, DELETE, UPDATE
AS
BEGIN
DECLARE @StartDato			DATE
DECLARE @SlutDato			DATE
DECLARE @HundeStr			VARCHAR(5)

DECLARE @HundeStrTable		TABLE (
		HundeStr			VARCHAR(5) NOT NULL)

DECLARE @Datoer				TABLE (
		Dato				DATE NOT NULL)
		
DECLARE @PrisKlasseDatoer	TABLE (
		Dato				DATE NOT NULL)

	INSERT INTO @HundeStrTable	
		SELECT HundeStr	
			FROM INSERTED
		UNION
		SELECT HundeStr
			FROM DELETED
		
	WHILE EXISTS (SELECT * FROM @HundeStrTable)
	BEGIN
				
		DELETE FROM @Datoer
		DELETE FROM @PrisKlasseDatoer
		
		SET @HundeStr = (SELECT MIN(HundeStr) FROM @HundeStrTable);
		SET @StartDato = (SELECT MIN(StartDato) FROM PrisKlasse WHERE HundeStr = @HundeStr);
		SET @SlutDato = (SELECT MAX(SlutDato) FROM PrisKlasse WHERE HundeStr = @HundeStr);
		
		IF @StartDato IS NULL 
		BEGIN
			DELETE 
				FROM @HundeStrTable
				WHERE HundeStr = @HundeStr

			CONTINUE
		END;
		WITH 
		Datoer (Dato)
		AS
		(
		SELECT @StartDato
		UNION ALL
		SELECT DATEADD(Day, 1, Dato)
			FROM Datoer
			WHERE Dato < @SlutDato
		)
		INSERT INTO @Datoer
			SELECT Dato	
				FROM Datoer
			OPTION (MAXRECURSION 9000);
		
		WITH		
		PrisKlasseDatoer (Dato)
		AS
		(
		SELECT StartDato
			FROM PrisKlasse
			WHERE HundeStr = @HundeStr
		UNION ALL
		SELECT DATEADD(day, 1, Dato)
			FROM PrisKlasse INNER JOIN PrisKlasseDatoer 
				ON PrisKlasseDatoer.Dato BETWEEN PrisKlasse.StartDato AND PrisKlasse.SlutDato
			WHERE	PrisKlasseDatoer.Dato < PrisKlasse.SlutDato AND 
					PrisKlasse.HundeStr = @HundeStr
		)
		INSERT INTO @PrisKlasseDatoer
			SELECT Dato
				FROM PrisKlasseDatoer
			OPTION (MAXRECURSION 9000);
				
		IF EXISTS (SELECT Dato
						FROM @Datoer
					EXCEPT
					SELECT Dato
						FROM @PrisKlasseDatoer)
		BEGIN
			RAISERROR('Prisklassedatoer er ikke kontinuerlige', 16, 1)
			ROLLBACK TRANSACTION
		END
		
		IF EXISTS (SELECT DATO	
						FROM @PrisKlasseDatoer
						GROUP BY Dato
						HAVING COUNT(*) > 1)
		BEGIN
			RAISERROR('Prisklassedatoer overlapper', 16, 1)
			ROLLBACK TRANSACTION
		END
		
		DELETE 
			FROM @HundeStrTable
			WHERE HundeStr = @HundeStr
	END
END
GO
INSERT INTO PrisKlasse VALUES 
	('Mini', '2011-5-1', '2011-5-31', 50),
	('Mini', '2011-6-1', '2011-12-31', 55),
	('Mini', '2012-1-1', '2012-12-31', 65),

	('Midi', '2011-1-1', '2011-6-3', 70),
	('Midi', '2011-6-4', '2011-12-31', 75),
	('Midi', '2012-1-1', '2012-12-31', 85),

	('Maxi', '2011-1-1', '2011-8-14', 90),
	('Maxi', '2011-8-15', '2012-12-31', 95)
GO
DELETE 
	FROM PrisKlasse 
	WHERE ID = 3
	
UPDATE PrisKlasse
	SET SlutDato = DATEADD(Day, 90, Slutdato)
	WHERE HundeStr = 'Maxi' AND SlutDato = (SELECT MAX(Slutdato) FROM PrisKlasse WHERE HundeStr = 'Maxi')
GO
SELECT *
	FROM PrisKlasse
