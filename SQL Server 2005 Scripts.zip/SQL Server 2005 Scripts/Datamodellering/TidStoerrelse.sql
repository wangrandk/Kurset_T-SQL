USE master
DROP DATABASE DataModelDB
GO
CREATE DATABASE DataModelDB
GO
USE DataModelDB
CREATE TABLE PrisKlasse (
	ID				INT NOT NULL PRIMARY KEY IDENTITY,
	HundeStr		VARCHAR(5) NOT NULL,
	StartDato		DATE NOT NULL,
	SlutDato		DATE NULL,
	Pris			SMALLINT)

CREATE TABLE Pasning (
	PasningsID		INT NOT NULL,
	HundeID			INT NOT NULL,
	HundeStr		VARCHAR(5) NOT NULL,
	StartDato		DATE NOT NULL,
	SlutDato		DATE NOT NULL,
	CONSTRAINT PK_Pasning PRIMARY KEY(PasningsID, HundeID),
	CONSTRAINT CK_Pasning_Dato CHECK(StartDato < SlutDato))
	
SELECT *
	INTO dbo.Bure
	FROM (VALUES('MINI', 5, 1),
				('MIDI', 2, 2), 
				('MAXI', 4, 3)) AS Bure(Stoerrelse, Antalbure, Prioritet)
GO
INSERT INTO PrisKlasse VALUES ('Mini', '2011-1-1', '2011-5-30', 50)
INSERT INTO PrisKlasse VALUES ('Mini', '2011-6-1', '2012-12-31', 55)
INSERT INTO PrisKlasse VALUES ('Mini', '2012-1-1', '2012-12-31', 65)

INSERT INTO PrisKlasse VALUES ('Midi', '2011-1-1', '2011-6-3', 70)
INSERT INTO PrisKlasse VALUES ('Midi', '2011-6-4', '2012-12-31', 75)
INSERT INTO PrisKlasse VALUES ('Midi', '2012-1-1', '2012-12-31', 85)

INSERT INTO PrisKlasse VALUES ('Maxi', '2011-1-1', '2011-8-14', 90)
INSERT INTO PrisKlasse VALUES ('Maxi', '2011-8-15', '2012-12-31', 95)
GO
INSERT INTO Pasning VALUES (1, 1, 'Mini', '2011-5-20', '2011-6-8')
INSERT INTO Pasning VALUES (1, 2, 'Midi', '2011-5-20', '2011-6-8')

INSERT INTO Pasning VALUES (2, 3, 'Midi', '2011-5-22', '2011-5-23')

INSERT INTO Pasning VALUES (3, 4, 'Maxi', '2011-5-22', '2011-5-25')

INSERT INTO Pasning VALUES (4, 5, 'Mini', '2011-5-29', '2011-6-5')
INSERT INTO Pasning VALUES (4, 6, 'Midi', '2011-5-29', '2011-6-5')
INSERT INTO Pasning VALUES (4, 7, 'Maxi', '2011-5-29', '2011-6-5')
GO
CREATE FUNCTION dbo.MinDato 
	(
	@Dato1		DATE, 
	@Dato2		DATE
	)
RETURNS DATE
AS
BEGIN
	DECLARE @Dato	DATE
	
	IF @Dato1 < @Dato2
		SET @Dato = @Dato1
	ELSE
		SET @Dato = @Dato2
	
	RETURN @Dato
END
GO
CREATE FUNCTION dbo.MaxDato 
	(
	@Dato1		DATE, 
	@Dato2		DATE
	)
RETURNS DATE
AS
BEGIN
	DECLARE @Dato	DATE
	
	IF @Dato1 < @Dato2
		SET @Dato = @Dato2
	ELSE
		SET @Dato = @Dato1
	
	RETURN @Dato
END
GO
CREATE FUNCTION dbo.LedigeBure 
	(
	@Startdato		DATE, 
	@Slutdato		DATE,
	@HundeStr			VARCHAR(5)
	)
RETURNS @Ledige TABLE (
	Dato				DATE NOT NULL,
	AntalLedigeBure		INT NOT NULL,
	HundeStr			VARCHAR(5) NOT NULL
	)
AS
BEGIN
	WITH
	Dage 
	AS
	(
	SELECT @Startdato AS Dato
	UNION ALL
	SELECT DATEADD(d, 1, Dato)
		FROM Dage
		WHERE DATEADD(d, 1, Dato) <= @Slutdato
	)
		
	INSERT INTO @Ledige	
		SELECT	Dage.Dato,
				(SELECT Antalbure FROM Bure WHERE Bure.Stoerrelse = AktBure.Stoerrelse) - COUNT(Pasning.HundeID) AS AntalLedigeBure,
				AktBure.Stoerrelse
			FROM (Dage	CROSS JOIN (SELECT *
									FROM Bure
									WHERE Bure.Prioritet  >= (SELECT Prioritet FROM Bure WHERE Stoerrelse = @HundeStr)) AS AktBure)
	
						LEFT JOIN Pasning ON Dage.Dato BETWEEN Pasning.StartDato AND Pasning.SlutDato
			GROUP BY  AktBure.Stoerrelse, Dage.Dato
	OPTION (MAXRECURSION 9000);
RETURN
END
GO
DECLARE @Startdato		DATE = '2011-5-21';
DECLARE @Slutdato		DATE = '2011-5-24';
DECLARE @HundeStr		VARCHAR(5) = 'MINI'

SELECT *
	FROM dbo.LedigeBure (@Startdato, @Slutdato, @HundeStr)
	ORDER BY Dato, HundeStr
		
SELECT *
	FROM Bure

SELECT *
	FROM Pasning
	WHERE	StartDato BETWEEN @Startdato AND @Slutdato OR
			SlutDato BETWEEN @Startdato AND @Slutdato			
GO
DECLARE @Startdato		DATE = '2011-5-21';
DECLARE @Slutdato		DATE = '2011-5-28';
DECLARE @HundeStr		VARCHAR(5) = 'MIDI'

SELECT *
	FROM dbo.LedigeBure (@Startdato, @Slutdato, @HundeStr)
	ORDER BY Dato
GO
DECLARE @Startdato		DATE = '2011-5-21';
DECLARE @Slutdato		DATE = '2011-5-28';
DECLARE @HundeStr		VARCHAR(5) = 'MAXI'

SELECT *
	FROM dbo.LedigeBure (@Startdato, @Slutdato, @HundeStr)
	ORDER BY Dato
GO
DECLARE @Startdato		DATE = '2011-5-1';
DECLARE @Slutdato		DATE = '2011-12-31';
DECLARE @HundeStr		VARCHAR(5) = 'MIDI'

SELECT *
	FROM dbo.LedigeBure (@Startdato, @Slutdato, @HundeStr)
	ORDER BY Dato
