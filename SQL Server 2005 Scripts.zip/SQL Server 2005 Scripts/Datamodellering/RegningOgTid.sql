USE master
DROP DATABASE DataModelDB
GO
CREATE DATABASE DataModelDB
GO
USE DataModelDB
CREATE TABLE PrisKlasse (
	ID				INT NOT NULL PRIMARY KEY IDENTITY,
	HundeStr		VARCHAR(5) NOT NULL,
	StartDato		DATE NOT NULL,
	SlutDato		DATE NULL,
	Pris			SMALLINT)

CREATE TABLE Pasning (
	PasningsID		INT NOT NULL,
	HundeID			INT NOT NULL,
	HundeStr		VARCHAR(5) NOT NULL,
	StartDato		DATE NOT NULL,
	SlutDato		DATE NOT NULL,
	CONSTRAINT PK_Pasning PRIMARY KEY(PasningsID, HundeID),
	CONSTRAINT CK_Pasning_Dato CHECK(StartDato < SlutDato))
	
SELECT 5 AS AntalBure
	INTO dbo.Bure
GO
INSERT INTO PrisKlasse VALUES ('Mini', '2011-1-1', '2011-5-31', 50)
INSERT INTO PrisKlasse VALUES ('Mini', '2011-6-1', '2012-12-31', 55)
INSERT INTO PrisKlasse VALUES ('Mini', '2012-1-1', '2012-12-31', 65)

INSERT INTO PrisKlasse VALUES ('Midi', '2011-1-1', '2011-6-3', 70)
INSERT INTO PrisKlasse VALUES ('Midi', '2011-6-4', '2012-12-31', 75)
INSERT INTO PrisKlasse VALUES ('Midi', '2012-1-1', '2012-12-31', 85)

INSERT INTO PrisKlasse VALUES ('Maxi', '2011-1-1', '2011-8-14', 90)
INSERT INTO PrisKlasse VALUES ('Maxi', '2011-8-15', '2012-12-31', 95)
GO
INSERT INTO Pasning VALUES (1, 1, 'Mini', '2011-5-20', '2011-6-8')
INSERT INTO Pasning VALUES (1, 2, 'Midi', '2011-5-20', '2011-6-8')

INSERT INTO Pasning VALUES (2, 3, 'Midi', '2011-5-22', '2011-5-23')

INSERT INTO Pasning VALUES (3, 4, 'Maxi', '2011-5-22', '2011-5-25')

INSERT INTO Pasning VALUES (4, 5, 'Mini', '2011-5-29', '2011-6-5')
INSERT INTO Pasning VALUES (4, 6, 'Midi', '2011-5-29', '2011-6-5')
INSERT INTO Pasning VALUES (4, 7, 'Maxi', '2011-5-29', '2011-6-5')
GO
CREATE FUNCTION dbo.MinDato 
	(
	@Dato1		DATE, 
	@Dato2		DATE
	)
RETURNS DATE
AS
BEGIN
	DECLARE @Dato	DATE
	
	IF @Dato1 < @Dato2
		SET @Dato = @Dato1
	ELSE
		SET @Dato = @Dato2
	
	RETURN @Dato
END
GO
CREATE FUNCTION dbo.MaxDato 
	(
	@Dato1		DATE, 
	@Dato2		DATE
	)
RETURNS DATE
AS
BEGIN
	DECLARE @Dato	DATE
	
	IF @Dato1 < @Dato2
		SET @Dato = @Dato2
	ELSE
		SET @Dato = @Dato1
	
	RETURN @Dato
END
GO
CREATE FUNCTION dbo.Regning
	(
	@PasningsID		INT
	)
RETURNS @Regning TABLE
	(
	PasningsID		INT NOT NULL,
	HundeID			INT NOT NULL,
	HundeStr		VARCHAR(5) NOT NULL,
	Antaldage		SMALLINT NOT NULL,	
	DagsPris		SMALLINT NOT NULL,
	PrisIalt		INT NOT NULL,
	TakstDatoFra	DATE NOT NULL,
	TakstDatoTil	DATE NOT NULL,
	PasningsDatoFra	DATE NOT NULL,
	PasningsDatoTil	DATE NOT NULL
	) 
AS
BEGIN
INSERT INTO @Regning
	SELECT	Pasning.PasningsID,
			Pasning.HundeID,
			Pasning.HundeStr,
			DATEDIFF(d,
					dbo.MaxDato(Pasning.StartDato, PrisKlasse.StartDato),
					dbo.MinDato(Pasning.SlutDato, PrisKlasse.SlutDato)) AS Tid, 
			Pris,
			DATEDIFF(d,
					dbo.MaxDato(Pasning.StartDato, PrisKlasse.StartDato),
					dbo.MinDato(Pasning.SlutDato, PrisKlasse.SlutDato)) * Pris AS PrisIalt,
			dbo.MaxDato(Pasning.StartDato, PrisKlasse.StartDato),
			dbo.MinDato(Pasning.SlutDato, PrisKlasse.SlutDato),
			Pasning.StartDato,
			Pasning.SlutDato
		FROM Pasning INNER JOIN PrisKlasse 
			ON	(Pasning.StartDato BETWEEN PrisKlasse.StartDato AND PrisKlasse.SlutDato OR
				 Pasning.SlutDato BETWEEN PrisKlasse.StartDato AND PrisKlasse.SlutDato) AND
				 Pasning.HundeStr = PrisKlasse.HundeStr
		WHERE Pasning.PasningsID = @PasningsID
RETURN
END
GO
SELECT *
	FROM dbo.Regning(1)
	ORDER BY HundeID
	
SELECT *
	FROM dbo.Regning(2)
	ORDER BY HundeID
		
SELECT *
	FROM dbo.Regning(4)
	ORDER BY HundeID
GO
CREATE FUNCTION dbo.LedigeBure 
	(
	@Startdato		DATE, 
	@Slutdato		DATE
	)
RETURNS @Ledige TABLE (
	Dato				DATE NOT NULL,
	AntalLedigeBure		INT NOT NULL
	)
AS
BEGIN
	WITH 
	Dage 
	AS
	(
	SELECT @Startdato AS Dato
	UNION ALL
	SELECT DATEADD(d, 1, Dato)
		FROM Dage
		WHERE DATEADD(d, 1, Dato) <= @Slutdato)
		
	INSERT INTO @Ledige	
		SELECT Dage.Dato, (SELECT Antalbure FROM Bure) - COUNT(Pasning.HundeID) AS AntalLedigeBure
			FROM Dage LEFT JOIN Pasning ON Dage.Dato BETWEEN Pasning.StartDato AND Pasning.SlutDato
			GROUP BY Dage.Dato
	OPTION (MAXRECURSION 9000);
RETURN
END
GO
DECLARE @Startdato		DATE = '2011-5-21';
DECLARE @Slutdato		DATE = '2011-5-28';

SELECT *
	FROM dbo.LedigeBure (@Startdato, @Slutdato)
	ORDER BY Dato
GO
DECLARE @Startdato		DATE = '2011-5-1';
DECLARE @Slutdato		DATE = '2011-12-31';

SELECT *
	FROM dbo.LedigeBure (@Startdato, @Slutdato)
	ORDER BY Dato
