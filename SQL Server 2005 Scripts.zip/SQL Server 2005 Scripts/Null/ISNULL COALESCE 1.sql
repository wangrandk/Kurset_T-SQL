USE master;
GO
DROP DATABASE NullDB;
GO
CREATE DATABASE NullDB;
GO
USE NullDB;

CREATE TABLE dbo.t
(
	ID			INT NOT NULL PRIMARY KEY,
	a			INT NOT NULL,
	b			INT NOT NULL,
	c			INT NULL,
	d			INT NULL
);
GO
INSERT INTO dbo.t VALUES
	(1, 23, 44, 17, 56),
	(2, 23, 44, NULL, NULL),
	(3, 23, 44, NULL, 56),
	(4, 23, 44, 17, NULL);
GO
SELECT	ISNULL(a, b) AS res1,
		ISNULL(a, c) AS res2,
		ISNULL(c, a) AS res3,
		ISNULL(c, d) AS res4
	FROM dbo.t;
GO
SELECT	COALESCE(a, b) AS res1,
		COALESCE(a, c) AS res2,
		COALESCE(c, a) AS res3,
		COALESCE(c, d) AS res4
	FROM dbo.t;
GO
SELECT	COALESCE(a, b, c, d) AS res1,
		COALESCE(d, c, b, a) AS res2,
		COALESCE(c, d, 123) AS res3,
		COALESCE(NULL, NULL, a) AS res4
	FROM dbo.t;
GO
INSERT INTO dbo.t
	SELECT	ID + (SELECT MAX(ID) FROM dbo.t),
			a,
			b,
			c,
			d
		FROM dbo.t;
GO 18
SELECT COUNT(*)
	FROM dbo.t;
GO
SET STATISTICS TIME, IO ON;

SELECT	ISNULL(a, b) AS res1,
		ISNULL(a, c) AS res2,
		ISNULL(c, a) AS res3,
		ISNULL(c, d) AS res4
	FROM dbo.t;
GO
SELECT	COALESCE(a, b) AS res1,
		COALESCE(a, c) AS res2,
		COALESCE(c, a) AS res3,
		COALESCE(c, d) AS res4
	FROM dbo.t;

SET STATISTICS TIME, IO OFF;
GO
