USE master
DROP DATABASE TestDb
GO
CREATE DATABASE TestDb
GO
USE TestDb
CREATE TABLE t (
	i					INT NULL,
	i_isnull_pers		AS ISNULL(i, 23) PERSISTED,
	i_isnull_notpers	AS ISNULL(i, 45),
	i_coalesce_pers		AS COALESCE(i, 12) PERSISTED,
	i_coalesce_notpers	AS COALESCE(i, 28) --,
--	test_Isnull			AS ISNULL(NULL, NULL),
--	test_coalesce		AS COALESCE(NULL, NULL)
)
GO
INSERT INTO t (i) VALUES 
	(199), (NULL)
GO
SELECT *
	FROM t
