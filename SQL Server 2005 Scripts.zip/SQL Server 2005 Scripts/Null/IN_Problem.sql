USE master
DROP DATABASE testdb
go
CREATE DATABASE testdb
go
USE testdb
CREATE TABLE Kunde (
	KundeId INT NOT NULL PRIMARY KEY,
	Navn	VARCHAR(20) NOT NULL)

CREATE TABLE Ordre (
	OrdreId	INT NOT NULL,
	KundeId INT NULL FOREIGN KEY REFERENCES Kunde)
GO
SET NOCOUNT ON
INSERT INTO Kunde VALUES(1, 'Ole')
INSERT INTO Kunde VALUES(2, 'Ida')
INSERT INTO Kunde VALUES(3, 'Per')

INSERT INTO Ordre VALUES (10, 1)
INSERT INTO Ordre VALUES (11, 1)
INSERT INTO Ordre VALUES (12, 1)
INSERT INTO Ordre VALUES (13, 2)
INSERT INTO Ordre VALUES (14, 2)
INSERT INTO Ordre VALUES (15, 2)
SET NOCOUNT OFF
GO
SELECT KundeId, Navn
	FROM Kunde
	WHERE KundeId IN (SELECT KundeId FROM Ordre)
GO
SELECT KundeId, Navn
	FROM Kunde
	WHERE KundeId NOT IN (SELECT KundeId FROM Ordre)
GO
INSERT INTO Ordre VALUES (16, NULL)
GO
SELECT KundeId, Navn
	FROM Kunde
	WHERE KundeId IN (SELECT KundeId FROM Ordre)
GO
SELECT KundeId, Navn
	FROM Kunde
	WHERE KundeId NOT IN (SELECT KundeId FROM Ordre)
GO
SELECT KundeId, Navn
	FROM Kunde
	WHERE KundeId NOT IN (SELECT KundeId FROM Ordre WHERE KundeId IS NOT NULL)
GO
SELECT KundeId, Navn
	FROM Kunde
	WHERE EXISTS (SELECT KundeId 
					FROM Ordre
					WHERE Kunde.KundeId = Ordre.KundeId)
GO
SELECT KundeId, Navn
	FROM Kunde
	WHERE NOT EXISTS (SELECT KundeId 
						FROM Ordre
						WHERE Kunde.KundeId = Ordre.KundeId)
GO