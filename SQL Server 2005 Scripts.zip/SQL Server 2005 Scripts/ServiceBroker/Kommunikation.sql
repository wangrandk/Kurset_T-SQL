use master
drop database AfsenderDB
drop database ModtagerDB
go
create database AfsenderDB
create database ModtagerDB
go
use master
alter database AfsenderDB set enable_broker
go
use master
alter database ModtagerDB set enable_broker
go
use AfsenderDB
create message type [//CSJ/SendMeddelelse] 
validation = well_formed_xml
create message type [//CSJ/ModtagSvar] 
validation = well_formed_xml
go
use ModtagerDB
create message type [//CSJ/SendMeddelelse] 
validation = well_formed_xml
create message type [//CSJ/ModtagSvar]
 validation = well_formed_xml
go
use AfsenderDB
create contract [//CSJ/Kontrakt] 
		([//CSJ/SendMeddelelse] sent by initiator,
		 [//CSJ/ModtagSvar] sent by target)
go
use ModtagerDB
create contract [//CSJ/Kontrakt]
		([//CSJ/SendMeddelelse] sent by initiator,
		 [//CSJ/ModtagSvar] sent by target)
go
use AfsenderDB
create queue AfsenderQueue with status = on, 
								retention = on
go
use ModtagerDB
create queue ModtagerQueue with status = on, 
								retention = on
go
use AfsenderDB
create service [//CSJ/AfsenderService] 
		on queue dbo.AfsenderQueue([//CSJ/Kontrakt])
go
use ModtagerDB
create service [//CSJ/ModtagerService] 
		on queue dbo.ModtagerQueue([//CSJ/Kontrakt])
go
use AfsenderDB
declare @broker_instance	uniqueidentifier
declare @sql				varchar(1000)

select @broker_instance = service_broker_guid
from sys.databases
where database_id = DB_ID('AfsenderDB')
set @sql = 
		'create route AfsenderRoute
			with service_name = ''[//CSJ/ModtagerService]'', 
				broker_instance = ''' +  cast(@broker_instance as varchar(100)) + ''',
				address = ''LOCAL'''
exec (@sql)
go
use ModtagerDB
declare @broker_instance	uniqueidentifier
declare @sql				varchar(1000)

select @broker_instance = service_broker_guid
from sys.databases
where database_id = DB_ID('ModtagerDB')

set @sql = 
		'create route ModtagerRoute
			with service_name = ''[//CSJ/AfsenderService]'', 
				broker_instance = ''' + cast(@broker_instance as varchar(100)) + ''',
				address = ''LOCAL'''
exec (@sql)
go
use AfsenderDB
declare @konversations_handle	uniqueidentifier
declare @meddelelse				xml

begin dialog conversation @konversations_handle
	from service [//CSJ/AfsenderService] 
	to service '[//CSJ/ModtagerService]' 
	on contract [//CSJ/Kontrakt]

set @meddelelse = '<meddelelse id="1" tekst="send svar"></meddelelse>';

send on conversation @konversations_handle 
	message type [//CSJ/SendMeddelelse] (@meddelelse);

end conversation @konversations_handle WITH ERROR = 2008 DESCRIPTION = 'fejl' ;
go
use AfsenderDB
select * from dbo.AfsenderQueue
go
use ModtagerDB
select * from dbo.ModtagerQueue
go
use ModtagerDB
declare @Meddelelese			xml
declare @Svar					xml
declare @konversations_handle	uniqueidentifier
declare @konversations_group	uniqueidentifier;

waitfor (
receive top(1)	@Meddelelese = message_body, 
				@konversations_handle = conversation_handle, 
				@konversations_group = conversation_group_id
from dbo.ModtagerQueue), timeout 600

if @@rowcount > 0
begin
	select @Meddelelese

	set @Svar = '<svar id="1" modtaget="ja"/>';

	send on conversation @konversations_handle message type [//CSJ/ModtagSvar] (@Svar);
end
else
	select 'Ingen medddelelse' as tekst




