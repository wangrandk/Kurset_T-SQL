SET NOCOUNT ON

DECLARE @PostnrTabel TABLE 
(
	Id		INT IDENTITY PRIMARY KEY NOT NULL, 
	Postnr	SMALLINT
);

DECLARE @Postnr	SMALLINT

INSERT INTO @PostnrTabel (Postnr) VALUES
	(2000),
	(3000),
	(9000),
	(8000);

WHILE EXISTS (SELECT * FROM  @PostnrTabel)
BEGIN
	SET @Postnr = (SELECT TOP 1 Postnr FROM @PostnrTabel);

	PRINT @Postnr;
	
	DELETE FROM @PostnrTabel WHERE Postnr = @Postnr;
END;
SELECT *		-- vise at tabel er tom
	FROM @PostnrTabel;
SET NOCOUNT OFF;
GO
SET NOCOUNT ON;

DECLARE @PostnrTabel TABLE 
(
	Id		INT IDENTITY PRIMARY KEY NOT NULL, 
	Postnr	SMALLINT
);

INSERT INTO @PostnrTabel (Postnr) VALUES
	(2000),
	(3000),
	(9000),
	(8000);

DECLARE @Postnr	SMALLINT = (SELECT MIN(Postnr) FROM @PostnrTabel) - 1;

WHILE EXISTS (SELECT * FROM  @PostnrTabel WHERE Postnr > @Postnr)
BEGIN
	SET @Postnr = (SELECT MIN(Postnr) FROM @PostnrTabel WHERE Postnr > @Postnr);

	PRINT @Postnr;
END;

SELECT *
	FROM @PostnrTabel;

SET NOCOUNT OFF;
GO
SELECT 1 AS Start, 12 AS Slut
	INTO #Graenser;

SELECT *
	FROM #Graenser;

DECLARE @i		INT = (SELECT Start FROM #Graenser);

WHILE @i <= (SELECT Slut FROM #Graenser)
BEGIN
	PRINT @i;
	SET @i += 1;
END;
GO
DROP TABLE #Graenser;