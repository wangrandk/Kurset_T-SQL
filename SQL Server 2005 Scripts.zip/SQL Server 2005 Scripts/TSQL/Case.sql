USE master;
GO
DROP DATABASE CaseDB;
GO
CREATE DATABASE CaseDB;
GO
USE CaseDB;
CREATE TABLE TestResultat
(
	ID			INT NOT NULL,
	Resultat	SMALLINT NOT NULL
);
GO
-- 1 i Resultat er God, 2 er Halgod, 3 er D�rlig
INSERT INTO TestResultat VALUES
	(1, 1),
	(2, 1),
	(3, 3),
	(4, 2);
GO
SELECT	ID,
		Resultat,
		CASE Resultat	
			WHEN 1 THEN 'God'
			WHEN 2 THEN 'Halvgod'
			WHEN 3 THEN 'D�rlig'
			ELSE 'Ukendt'
		END AS Text
	FROM TestResultat;

SELECT	TestResultat.ID,
		Oversaet.Txt,
		Oversaet.value1,
		Oversaet.value2
	FROM TestResultat INNER JOIN (VALUES	(1, 'God', 20, 27), 
											(2, 'Halvgod', 15, 18), 
											(3, 'D�rlig', 0, 0)) AS Oversaet(Id, Txt, Value1, Value2)
			ON TestResultat.Resultat = Oversaet.Id;

SELECT	ID,
		Resultat,
		CASE	
			WHEN Resultat = 1 THEN 'God'
			WHEN Resultat = 2 THEN 'Halvgod'
			WHEN Resultat = 3 THEN 'D�rlig'
			ELSE 'Ukendt'
		END
	FROM TestResultat;
GO
SELECT *
	FROM TestResultat INNER JOIN (VALUES	(1,'God'), 
											(2,'Halvgod'), 
											(3,'D�rlig')) AS ResultatOversaet(id,Txt)
			ON TestResultat.Resultat = ResultatOversaet.Id
GO
SELECT	ID,
		CASE	
			WHEN Resultat IN (1, 2) THEN 'God'
			WHEN Resultat = 3 THEN 'D�rlig'
			ELSE 'Ukendt'
		END
	FROM TestResultat;
GO
SELECT	ID,
		CASE	
			WHEN Resultat IN (SELECT TOP 2 Resultat FROM TestResultat ORDER BY Id DESC ) THEN 'God'
			WHEN Resultat = 3 THEN 'D�rlig'
			ELSE 'Ukendt'
		END
	FROM TestResultat;