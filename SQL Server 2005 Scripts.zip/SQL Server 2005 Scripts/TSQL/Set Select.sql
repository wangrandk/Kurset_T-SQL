USE master;
DROP DATABASE TSQLDB;
GO
CREATE DATABASE TSQLDB;
GO
USE TSQLDB;

CREATE TABLE dbo.Postopl 
(
	Id		INT IDENTITY PRIMARY KEY	NOT NULL, 
	Postnr	SMALLINT					NOT NULL,
	Bynavn	VARCHAR(20)					NOT NULL
);

INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(6000, 'Kolding'),
	(9000, 'Aalborg'),
	(8000, 'Aarhus C');
GO
SELECT * 
	FROM dbo.Postopl;
GO 
DECLARE @Postnr	SMALLINT = 0;

SET @Postnr = 2000;
GO 
DECLARE @i	SMALLINT = 0;

SET @i = @i + 200;

SET @i += 300;

SET @i *= 3;

SELECT @i;
GO 
DECLARE @Postnr	SMALLINT = 0;

SET @Postnr = (SELECT Postnr FROM dbo.Postopl WHERE Bynavn = 'Kolding');

SELECT @Postnr;
GO 
DECLARE @Postnr	SMALLINT = 0;

SET @Postnr = (SELECT Postnr FROM dbo.Postopl WHERE Bynavn = 'gggggg');

SELECT @Postnr;
GO 
DECLARE @Postnr	SMALLINT = 0;

SET @Postnr = (SELECT Postnr FROM dbo.Postopl);    -- fejl
GO
DECLARE @Postnr	SMALLINT;

SELECT @Postnr = Postnr 
	FROM dbo.Postopl
	
SELECT @Postnr
GO
DECLARE @Postnr	SMALLINT

SELECT TOP 1 @Postnr = Postnr 
	FROM dbo.Postopl
	
SELECT @Postnr
GO
DECLARE @Postnr	SMALLINT

SELECT TOP 1 @Postnr = Postnr 
	FROM dbo.Postopl
	ORDER BY Postnr DESC;

SELECT @Postnr
GO
DECLARE @Postnr	SMALLINT

SELECT @Postnr = Postnr 
	FROM dbo.Postopl
	ORDER BY Postnr
	
SELECT @Postnr
GO
CREATE INDEX nc_Postopl_Postnr ON dbo.Postopl(Postnr DESC)
GO
DECLARE @Postnr	SMALLINT

SELECT @Postnr = Postnr 
	FROM dbo.Postopl;

SELECT @Postnr;
GO
DECLARE @Postnr	SMALLINT;
DECLARE @Bynavn	VARCHAR(20);

SELECT	@Postnr = Postnr,
		@Bynavn = Bynavn
	FROM dbo.Postopl
	WHERE Id = 2;

SELECT @Postnr, @Bynavn;
GO
DECLARE @Bynavne	VARCHAR(8000);

SELECT @Bynavne = Bynavn + ISNULL(', ' + @Bynavne, '')
	FROM dbo.Postopl;

SELECT @Bynavne;
GO
DECLARE @Bynavne	VARCHAR(8000);

SELECT @Bynavne = Bynavn + ISNULL(', ' + @Bynavne, '')
	FROM dbo.Postopl
	ORDER BY Bynavn DESC;

SELECT @Bynavne;
GO
DECLARE @Bynavne	VARCHAR(8000) = '';

SELECT @Bynavne = Bynavn + ', ' + @Bynavne
	FROM dbo.Postopl;

SELECT @Bynavne;
GO
DECLARE @Sum		INT = 0,
		@Count		INT = 0;

SELECT	@Sum = @Sum + Postnr,
		@Count = @Count + 1
	FROM dbo.Postopl;

SELECT @Sum, @Count, @Sum / @Count AS Avg;
GO
-- Performance
CREATE PROC usp_1
AS
	DECLARE @i		INT = 1
	DECLARE @j		INT
	DECLARE @k		INT
	DECLARE @l		INT
	DECLARE @m		INT
	DECLARE @n		INT

	WHILE @i <= 1000000
	BEGIN
		SELECT @j = 1, @k = 2, @l = 3, @m = 4, @n = 5
		
		SET @i+= 1
	END
GO
CREATE PROC usp_2
AS
	DECLARE @i		INT = 1
	DECLARE @j		INT
	DECLARE @k		INT
	DECLARE @l		INT
	DECLARE @m		INT
	DECLARE @n		INT

	WHILE @i <= 1000000
	BEGIN
		SELECT @j = 1
		SELECT @k = 2
		SELECT @l = 3
		SELECT @m = 4
		SELECT @n = 5
		
		SET @i+= 1
	END
GO
CREATE PROC usp_3
AS
	DECLARE @i		INT = 1
	DECLARE @j		INT
	DECLARE @k		INT
	DECLARE @l		INT
	DECLARE @m		INT
	DECLARE @n		INT

	WHILE @i <= 1000000
	BEGIN
		SET @j = 1
		SET @k = 2
		SET @l = 3
		SET @m = 4
		SET @n = 5
		
		SET @i+= 1
	END
GO
DECLARE @Tid1		DATETIME2;
DECLARE @Tid2		DATETIME2;
DECLARE @Tid3		DATETIME2;
DECLARE @Tid4		DATETIME2;

SET @Tid1 = SYSDATETIME();
EXEC usp_1;
SET @Tid2 = SYSDATETIME();
EXEC usp_2;
SET @Tid3 = SYSDATETIME();
EXEC usp_3;
SET @Tid4 = SYSDATETIME();

SELECT	DATEDIFF(MILLISECOND, @Tid1, @Tid2) AS p1,
		DATEDIFF(MILLISECOND, @Tid2, @Tid3) AS p2,
		DATEDIFF(MILLISECOND, @Tid3, @Tid4) AS p3;
GO
DECLARE @i		INT = 0;

SET @i += 2;
SELECT @i;

SET @i *= 13;
SELECT @i;
