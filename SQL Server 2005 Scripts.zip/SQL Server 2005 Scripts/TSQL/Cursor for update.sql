USE master;
GO
DROP DATABASE IF EXISTS TestDB;
GO
CREATE DATABASE TestDB
ON  PRIMARY 
(	NAME = N'TestDB', 
	FILENAME = N'C:\Databaser\TestDB.mdf' , 
	SIZE = 100MB, 
	MAXSIZE = UNLIMITED, 
	FILEGROWTH = 20MB
)
LOG ON 
(	NAME = N'TestDB_log', 
	FILENAME = N'C:\Databaser\TestDB_log.ldf', 
	SIZE = 200MB , 
	MAXSIZE = UNLIMITED, 
	FILEGROWTH = 20MB
);
GO
USE TestDB;
CREATE TABLE DataTabel
(
	ID bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_DataTabel PRIMARY KEY CLUSTERED,
	Tekst1 nvarchar(50) NULL,
	Tekst2 nvarchar(50) NULL
);

INSERT INTO DataTabel (Tekst1) 
	VALUES ('Hans'), ('Grete'), ('Ole'), ('Anna'), ('Gurli');

DECLARE @Tal	INT;

SET @Tal= 3;

WHILE @Tal > 0
BEGIN
	SET @Tal = @Tal - 1
	INSERT INTO DataTabel 
		SELECT Tekst1, NULL 
			FROM DataTabel;
END;

SELECT COUNT(*) 
	FROM DataTabel;

DECLARE @Tekst1 NVARCHAR(50);

DECLARE CursorDataTabel CURSOR FOR
	SELECT Tekst1 
		FROM DataTabel;

OPEN CursorDataTabel;

FETCH NEXT FROM CursorDataTabel
	INTO @Tekst1;

WHILE @@FETCH_STATUS = 0
BEGIN
	UPDATE DataTabel
		SET Tekst2 = Tekst1
		WHERE CURRENT OF CursorDataTabel;

	FETCH NEXT FROM CursorDataTabel
		INTO @Tekst1;
END;

CLOSE CursorDataTabel;
DEALLOCATE CursorDataTabel;
GO
DECLARE @Id			BIGINT, 
		@Tekst1		NVARCHAR(50);

SELECT ID, Tekst1 
	INTO #temp_DataTabel 
	FROM DataTabel;

WHILE EXISTS(SELECT TOP 1 * FROM #temp_DataTabel)
BEGIN
	SELECT TOP 1 @Id = id,@Tekst1 = Tekst1 
		FROM #temp_DataTabel;

	UPDATE DataTabel 
		SET Tekst2 = @Tekst1 
		WHERE ID = @Id;

	DELETE 
		FROM #temp_DataTabel 
		WHERE id = @id;
END;

DROP TABLE #temp_DataTabel;
