USE master;
DROP DATABASE TSQLDB;
GO
CREATE DATABASE TSQLDB;
GO 
USE TSQLDB;
CREATE TABLE dbo.Person 
(
	id		INT NOT NULL PRIMARY KEY IDENTITY,
	Navn	VARCHAR(20) NOT NULL
);
GO
INSERT INTO dbo.Person (Navn) VALUES 
	('Ib'),
	('Bo'),
	('Ane'),
	('Maren'),
	('Sanne'),
	('Hans'),
	('Hans');
GO
DECLARE @Navn		VARCHAR(20);

SET @Navn = 'Uffe';
SELECT @Navn;
GO
DECLARE @Navn		VARCHAR(20);

SET @Navn = (SELECT Navn FROM dbo.Person WHERE Navn = 'Hans');
SELECT @Navn;
GO
DECLARE @Navn		VARCHAR(20);

SELECT @Navn = Navn FROM dbo.Person; --WHERE Navn = 'Hans'
SELECT @Navn;
GO
DECLARE @Navne		VARCHAR(200);

SELECT @Navne = ISNULL(@Navne, '') + ', ' + Navn 
	FROM dbo.Person;

SELECT @Navne;
GO
DECLARE @Navne		VARCHAR(200);
DECLARE @id			VARCHAR(200);

SELECT @Navne = ISNULL(@Navne, '') + ', ' + Navn,
		@id = ISNULL(@id, '') + ', ' + CAST(id as VARCHAR(5))
	FROM dbo.Person;

SELECT @Navne, @id;
GO
DECLARE @i		INT;

SET @i = 0;
IF @i = 0
	SELECT 27
ELSE
	SELECT 45;
GO
DECLARE @i		INT;

SET @i = 3;
IF @i IN (SELECT id FROM dbo.Person)
	SELECT 27
ELSE
	SELECT 45;
GO
DECLARE @i_min		INT;
DECLARE @i_max		INT;

SET @i_min = 3;
SET @i_max = 8;

IF EXISTS (SELECT * FROM dbo.Person WHERE id BETWEEN @i_min AND @i_max)
	SELECT 27
ELSE
	SELECT 45;
GO
TRUNCATE TABLE dbo.Person;

IF NOT EXISTS (SELECT * FROM dbo.Person)
	RAISERROR ('Der er ingen forekomster i tabellen dbo.Person', 16, 1) WITH LOG;
GO 
DECLARE @dbname		SYSNAME;

SET @dbname = '';

WHILE EXISTS (SELECT * FROM sys.databases WHERE name > @dbname)
BEGIN
	SET @dbname = (SELECT MIN(name) FROM sys.databases WHERE name > @dbname);
	PRINT @dbname;
END;
GO
CREATE FUNCTION dbo.ufn_Person (@Navn VARCHAR(20))
RETURNS INT
AS
BEGIN
	DECLARE @Antal INT;

	SET @Antal = (SELECT COUNT(*) FROM dbo.Person WHERE Navn = @Navn);

	RETURN @Antal;
END;
GO
SELECT  dbo.ufn_Person('Hans');

SELECT * FROM dbo.Person WHERE  dbo.ufn_Person(Navn) > 1
GO
CREATE TABLE dbo.t (
	 Navn	VARCHAR(10) CHECK (dbo.ufn_Person(Navn) <  3));
GO
CREATE TABLE dbo.t2 
(
	Navn	VARCHAR(10),
	Antal	AS dbo.ufn_Person(Navn)
);
GO
INSERT INTO dbo.t2 (Navn) VALUES
	('Ole');

SELECT * 
	FROM dbo.t2;
GO
ALTER FUNCTION ufn_dbo.Person
(
	@Navn VARCHAR(20)
)
RETURNS @t TABLE (id INT NOT NULL PRIMARY KEY IDENTITY, Navn VARCHAR(10))
AS
BEGIN
	INSERT INTO @t VALUES ('Ida');

	INSERT INTO @t
		SELECT Navn 
			FROM dbo.Person 
			WHERE Navn = @Navn;
	RETURN;
END;
GO
SELECT *
	FROM ufn_dbo.Person('Hans') AS tf INNER JOIN dbo.Person ON tf.id = dbo.Person.id
GO
CREATE FUNCTION dbo.ufn_Id_Navn 
(
	@id			INT
)
RETURNS VARCHAR(30)
AS
BEGIN
RETURN (SELECT CAST(id AS VARCHAR(10)) + ' ' + Navn 
			FROM dbo.Person 
			WHERE id = @id)
END;
GO
CREATE FUNCTION dbo.ufn_Id_Navn
(
	@minid INT, 
	@maxid INT
)
RETURNS @t TABLE (Personopl VARCHAR(30))
AS
BEGIN
	INSERT INTO @t
		SELECT dbo.ufn_id_Navn (id)
			FROM dbo.Person 
			WHERE id BETWEEN @minid AND @maxid;
	RETURN;
END;
GO
SELECT *
	FROM dbo.ufn_Person_Navn(2, 5);

SELECT dbo.ufn_id_Navn (4);
