USE master;
DROP DATABASE CaseDB;
GO
CREATE DATABASE CaseDB;
GO
USE CaseDB;
GO
CREATE TABLE dbo.Person 
(
	PersonID		INT NOT NULL IDENTITY PRIMARY KEY,
	PersonType		CHAR(1) NULL
);
GO
INSERT INTO dbo.Person(PersonType) VALUES 
	('A'),
	('B'),	
	('C'),
	('D'),
	('E'),	
	(NULL);
GO
SELECT PersonType,
		CASE PersonType
			WHEN 'A' THEN 'AAAAAAAAAAAAAA'
			WHEN 'B' THEN 'BBBBBBBBBBBBBB'
			WHEN 'C' THEN 'CCCCCCCCCCCCCC'
			WHEN 'D' THEN 'DDDDDDDDDDDDDD'
			ELSE 'Andet'
		END AS PersonTypeTxt
	FROM dbo.Person;
GO
SELECT PersonType,		--implicit ELSE = NULL
		CASE PersonType
			WHEN 'A' THEN 'AAAAAAAAAAAAAA'
			WHEN 'B' THEN 'BBBBBBBBBBBBBB'
			WHEN 'C' THEN 'CCCCCCCCCCCCCC'
		END AS PersonTypeTxt
	FROM dbo.Person;
GO
SELECT PersonType,
		CASE PersonType
			WHEN 'A' THEN 'AAAAAAAAAAAAAA'
			WHEN 'B' THEN 'BBBBBBBBBBBBBB'
			WHEN 'C' THEN 'CCCCCCCCCCCCCC'
			WHEN NULL THEN 'n/a'
		END AS PersonTypeTxt
	FROM dbo.Person;
GO
SELECT PersonType,
		CASE 
			WHEN PersonType = 'A' THEN 'AAAAAAAAAAAAAA'
			WHEN PersonType = 'B' THEN 'BBBBBBBBBBBBBB'
			WHEN PersonType = 'C' THEN 'CCCCCCCCCCCCCC'
			WHEN PersonType IS NULL THEN 'n/a'
		END AS PersonTypeTxt
	FROM dbo.Person;
GO
SELECT PersonType,
		CASE 
			WHEN PersonType  IN ('A', 'B', 'C') THEN 'AAAAAAAAAAAAAA'
			WHEN PersonType = 'B' THEN 'BBBBBBBBBBBBBB'					-- brugews ikke
			WHEN PersonType = 'C' THEN 'CCCCCCCCCCCCCC'					-- brugews ikke
			WHEN PersonType IS NULL THEN 'n/a'
		END AS PersonTypeTxt
	FROM dbo.Person;
GO
DECLARE @PersontypeText	VARCHAR(30);

SELECT @PersontypeText =
		CASE 
			WHEN PersonType  IN ('A', 'B', 'C') THEN 'AAAAAAAAAAAAAA'
			WHEN PersonType = 'B' THEN 'BBBBBBBBBBBBBB'					-- brugews ikke
			WHEN PersonType = 'C' THEN 'CCCCCCCCCCCCCC'					-- brugews ikke
			WHEN PersonType IS NULL THEN 'n/a'
		END 
	FROM dbo.Person;

SELECT @PersontypeText
GO