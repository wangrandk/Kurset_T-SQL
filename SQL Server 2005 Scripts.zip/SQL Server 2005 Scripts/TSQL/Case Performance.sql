USE IndexDB;
GO
SET STATISTICS IO, TIME ON;
SELECT CASE Persontype
		WHEN 'A' THEN 'Aaaaaaa'
		WHEN 'B' THEN 'Bbbbbbb'
		WHEN 'C' THEN 'Ccccccc'
		WHEN 'D' THEN 'Ddddddddddd'
		END
	FROM dbo.Person


SELECT CASE Persontype
		WHEN 'D' THEN 'Ddddddddddd'
		WHEN 'C' THEN 'Ccccccc'
		WHEN 'B' THEN 'Bbbbbbb'
		WHEN 'A' THEN 'Aaaaaaa'
		END
	FROM dbo.Person
