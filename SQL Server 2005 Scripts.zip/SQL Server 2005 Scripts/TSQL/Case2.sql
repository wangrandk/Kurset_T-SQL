USE master;
DROP DATABASE CaseDB;
GO
CREATE DATABASE CaseDB;
GO
USE CaseDB;
CREATE TABLE dbo.t 
(
	ID		INT NOT NULL IDENTITY PRIMARY KEY,
	i		INT NULL,
	j		INT NULL
);
GO
INSERT INTO dbo.t VALUES
	(10, 2),
	(20, 5),
	(10, 5),
	(20, 2),
	(NULL, 10),
	(20, NULL),
	(NULL, NULL);
GO
SELECT *, i/j AS k
	FROM dbo.t
	WHERE i/j > 2;
GO
SELECT *, i/j AS k
	FROM dbo.t
	WHERE	CASE
				WHEN j = 0 THEN 'FALSE'
				WHEN i IS NULL THEN 'TRUE'
				WHEN i/j > 2 THEN 'TRUE'
				ELSE 'FALSE'
			END = 'TRUE';
GO
