USE master;
GO
DROP DATABASE IF EXISTS TestDB
GO
CREATE DATABASE TestDB
ON  PRIMARY 
(	NAME = N'TestDB', 
	FILENAME = N'C:\Databaser\TestDB.mdf' , 
	SIZE = 100MB, 
	MAXSIZE = UNLIMITED, 
	FILEGROWTH = 20MB
)
LOG ON 
(	NAME = N'TestDB_log', 
	FILENAME = N'C:\Databaser\TestDB_log.ldf', 
	SIZE = 200MB , 
	MAXSIZE = UNLIMITED, 
	FILEGROWTH = 20MB
);
GO
USE TestDB;
SELECT 1 AS ID, CAST(N'abcdefgh' AS NCHAR(100)) AS Tekst
	INTO DataTabel;
GO
INSERT INTO DataTabel
	SELECT	ID + (SELECT MAX(ID) FROM DataTabel),
			Tekst
		FROM DataTabel
GO 15
CREATE UNIQUE INDEX nc_t_Id_Tekst ON DataTabel (Id) INCLUDE (Tekst) 
GO
-----------------------------------------------------------------
SET NOCOUNT ON;

SELECT	1 AS ID, 
		SYSDATETIME() AS Tid
	INTO Tidopl;

DECLARE @Variable	NCHAR(100), 
		@Tal		BIGINT = 0;

DECLARE CursorDataTabel CURSOR FAST_FORWARD
FOR
	SELECT Tekst 
		FROM DataTabel;

OPEN CursorDataTabel;

FETCH NEXT FROM CursorDataTabel
	INTO @Variable

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @Tal = @Tal + 1;

	FETCH NEXT FROM CursorDataTabel
		INTO @Variable;
END;
CLOSE CursorDataTabel;
DEALLOCATE CursorDataTabel;

SELECT @Tal;

INSERT INTO Tidopl
	SELECT 2 AS ID, SYSDATETIME() AS Tid;
-----------------------------------------------------------------
GO
INSERT INTO Tidopl
	SELECT 3 AS ID, SYSDATETIME() AS Tid;

DECLARE		@Id BIGINT, 
			@tekst NCHAR(100), 
			@Tal BIGINT = 0;

SELECT Id,Tekst 
	INTO #temp_DataTabel 
	FROM DataTabel;

WHILE EXISTS(SELECT * FROM #temp_DataTabel)
BEGIN
	SELECT	TOP 1 @id = id, 
			@tekst = tekst 
		FROM #temp_DataTabel;

	DELETE 
		FROM #temp_DataTabel 
		WHERE id = @id;

	SET @Tal += 1;
END;

SELECT @Tal;

INSERT INTO Tidopl
	SELECT 4 AS ID, SYSDATETIME() AS Tid;
GO
DROP TABLE #temp_DataTabel
GO
-----------------------------------------------------------------
INSERT INTO Tidopl
	SELECT 5 AS ID, SYSDATETIME() AS Tid;

DECLARE		@Id		BIGINT = 0, 
			@tekst	NCHAR(100), 
			@Tal	BIGINT = 0;

WHILE EXISTS(SELECT * FROM DataTabel WHERE Id > @Id)
BEGIN
	SELECT @id = id, @tekst = tekst 
		FROM DataTabel
		WHERE Id = @Id + 1;

	SET @Tal = @Tal + 1;
END;
SELECT @Tal;

INSERT INTO Tidopl
	SELECT 6 AS ID, SYSDATETIME() AS Tid;
GO
-----------------------------------------------------------------
INSERT INTO Tidopl
	SELECT 7 AS ID, SYSDATETIME() AS Tid;

DECLARE		@Id		BIGINT = 0, 
			@tekst	NCHAR(100), 
			@Tal BIGINT = 0;

WHILE EXISTS (SELECT * FROM DataTabel WHERE Id > @Id)
BEGIN
	SELECT @id = id, @tekst = tekst 
		FROM DataTabel
		WHERE Id = (SELECT MIN(Id) FROM DataTabel WHERE Id > @Id);

	SET @Tal = @Tal + 1;
END;
SELECT @Tal;

INSERT INTO Tidopl
	SELECT 8 AS ID, SYSDATETIME() AS Tid;
GO
-----------------------------------------------------------------
GO
INSERT INTO Tidopl
	SELECT 9 AS ID, SYSDATETIME() AS Tid;

DECLARE		@Id		BIGINT, 
			@tekst	NCHAR(100), 
			@Tal	BIGINT = 0;

DECLARE @t TABLE
(
	ID		INT,
	Tekst	NCHAR(100)
);

INSERT INTO @t
	SELECT Id,Tekst 
		FROM DataTabel;

WHILE EXISTS(SELECT * FROM @t)
BEGIN
	SELECT TOP 1 @id = id, @tekst = tekst 
		FROM @t;

	DELETE 
		FROM @t 
		WHERE id = @id;

	SET @Tal = @Tal + 1;
END;
SELECT @Tal;

INSERT INTO Tidopl
	SELECT 10 AS ID, SYSDATETIME() AS Tid;
GO
-----------------------------------------------------------------
SELECT	'Cursortid' AS Type,
		DATEDIFF(MS, 
				(SELECT Tid FROM Tidopl WHERE ID = 1),
				(SELECT Tid FROM Tidopl WHERE ID = 2)) AS Tid
UNION ALL
SELECT	'While Delete' AS Type,
		DATEDIFF(MS, 
				(SELECT Tid FROM Tidopl WHERE ID = 3),
				(SELECT Tid FROM Tidopl WHERE ID = 4)) AS Tid
UNION ALL
SELECT	'While Next ID' AS Type,
		DATEDIFF(MS, 
				(SELECT Tid FROM Tidopl WHERE ID = 5),
				(SELECT Tid FROM Tidopl WHERE ID = 6)) AS Tid
UNION ALL
SELECT	'While Min ID' AS Type,
		DATEDIFF(MS, 
				(SELECT Tid FROM Tidopl WHERE ID = 7),
				(SELECT Tid FROM Tidopl WHERE ID = 8)) AS Tid
UNION ALL
SELECT	'While Tabel-variabel' AS Type,
		DATEDIFF(MS, 
				(SELECT Tid FROM Tidopl WHERE ID = 9),
				(SELECT Tid FROM Tidopl WHERE ID = 10)) AS WhileTabelvar;
