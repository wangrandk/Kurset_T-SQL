USE master;
DROP DATABASE TSQLDB;
GO
CREATE DATABASE TSQLDB;
GO
USE TSQLDB;
CREATE TABLE dbo.Postopl 
(
	Id		INT IDENTITY PRIMARY KEY NOT NULL, 
	Postnr	SMALLINT NOT NULL,
	Bynavn	VARCHAR(20) NOT NULL
);

INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(6000, 'Kolding'),
	(9000, 'Aalborg'),
	(8000, 'Aarhus C');
GO
DECLARE @postnr	SMALLINT = 2000;

IF @postnr = 3000
	PRINT 'postnr findes'
ELSE
	PRINT 'postnr findes ikke';
GO
DECLARE @postnr	SMALLINT = 2000;

IF @postnr IN (SELECT Postnr FROM dbo.Postopl)
	PRINT 'postnr findes'
ELSE
	PRINT 'postnr findes ikke';
GO
DECLARE @Koen	CHAR(1) = 'p';

IF @Koen IN ('K', 'M')
	PRINT 'K�n OK'
ELSE
	PRINT 'K�n ikke OK';
GO
DECLARE @postnr	SMALLINT = 2001;

IF @postnr BETWEEN	(SELECT MIN(Postnr) FROM dbo.Postopl) AND
					(SELECT MAX(Postnr) FROM dbo.Postopl)
	PRINT 'postnr i interval'
ELSE
	PRINT 'postnr ikke i interval';
GO
DECLARE @postnr	SMALLINT  = 2000;

IF @postnr = ANY (SELECT Postnr FROM dbo.Postopl)
BEGIN
	PRINT '------------------'
	PRINT 'postnr findes'
	PRINT '------------------'
END
ELSE
BEGIN
	PRINT 'postnr findes ikke'
END;
GO
DECLARE @postnr	SMALLINT;

SET @postnr = 2000;

IF LEFT(CAST(@postnr AS VARCHAR(5)), 1) = '2'
BEGIN
	PRINT 'OK'
END
ELSE
BEGIN
	PRINT 'Fejl'
END;
GO
DECLARE @Bynavn	VARCHAR(20);

SET @Bynavn = 'Aarhus C';

IF @Bynavn LIKE 'Aa%'
BEGIN
	PRINT 'Bynavn starter med Aa'
END
ELSE
BEGIN
	PRINT 'Bynavn starter IKKE med Aa'
END;
GO
IF (SELECT COUNT(*) FROM dbo.Postopl) > 2
	PRINT 'Mere end 2 postnr'
ELSE 
	PRINT 'Mindre end 3 postnr';
