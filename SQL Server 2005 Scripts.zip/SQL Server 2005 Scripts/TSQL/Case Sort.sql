USE master;
DROP DATABASE TSQLDb;
GO
CREATE DATABASE TSQLDb;
GO 
USE TSQLDb
CREATE TABLE dbo.Person 
(
	Id			INT NOT NULL PRIMARY KEY IDENTITY,
	Navn		VARCHAR(20) NOT NULL,
	Adresse		VARCHAR(30) NOT NULL,
	Postnr		SMALLINT NOT NULL
);
GO
INSERT INTO dbo.Person VALUES
	('Ib Jensen', 'Vestergade 3', 9000),
	('Bo Hansen', 'Torvet 34', 8000),
	('Ane Larsen', 'Torvet 4', 2000),
	('Maren Svendsen', 'Pilestr�de 6', 8000),
	('Sanne Olsen', 'Strandvejen 4', 2000),
	('Hans Pedersen', 'S�ndergade 27', 2000),
	('Hans Petersen', 'Torvet 22', 7000),
	('Maren Knudsen', 'Lille Torv 4', 6000),
	('Karen Hansen', 'Strandvejen 4', 2000),
	('Erik Pedersen', 'S�ndergade 27', 2000),
	('Ole Petersen', 'N�rregade 11', 6000);
GO
CREATE TABLE dbo.Sortkolonner 
(
	SortKol			SYSNAME NOT NULL PRIMARY KEY
);
	
CREATE TABLE dbo.Userdata 
(
	Username		SYSNAME DEFAULT (SUSER_SNAME()),
	DT				DATETIME2 DEFAULT (SYSDATETIME())
);
GO
INSERT INTO dbo.Sortkolonner VALUES
	('Navn'),
	('Adresse'),
	('Postnr'),
	('Id');
GO	
DECLARE @SortKol	VARCHAR(255) = 'hghghgh'

SELECT *
	FROM dbo.Person
	ORDER BY CASE @SortKol
				WHEN 'Navn' THEN Navn
				WHEN 'Adresse' THEN Adresse
				WHEN 'Postnr' THEN RIGHT('0000' + CAST(Postnr AS VARCHAR(30)), 4)
				ELSE RIGHT('00000000000' + CAST(Id AS VARCHAR(10)), 10)
			 END;
GO
CREATE PROC usp_Person 
(
	@Sortkol	SYSNAME
)
AS
INSERT INTO dbo.Userdata DEFAULT VALUES
	SELECT *
		FROM dbo.Person
		ORDER BY CASE @SortKol
					WHEN 'Navn' THEN Navn
					WHEN 'Adresse' THEN Adresse
					WHEN 'Postnr' THEN RIGHT('0000' + CAST(Postnr AS VARCHAR(30)), 4)
					ELSE RIGHT('00000000000' + CAST(Id AS VARCHAR(20)), 10)
				 END;
GO
EXEC usp_Person 'Adresse';
EXEC usp_Person 'Navn';
EXEC usp_Person 'Fejl Sortkol';
GO
DECLARE @SortKol		VARCHAR(255) = 'Navn';
DECLARE @SortDirection	VARCHAR(255) = 'DESC';

SELECT *
	FROM dbo.Person
	ORDER BY CASE @SortDirection
				WHEN 'ASC' THEN 
					CASE @SortKol
						WHEN 'Navn' THEN Navn
						WHEN 'Adresse' THEN Adresse
						WHEN 'Postnr' THEN RIGHT('0000' + CAST(Postnr AS VARCHAR(30)), 4)
						ELSE RIGHT('00000000000' + CAST(Id AS VARCHAR(20)), 10)
					END
				END
				ASC,
				CASE @SortDirection
				WHEN 'DESC' THEN  
					CASE @SortKol
						WHEN 'Navn' THEN Navn
						WHEN 'Adresse' THEN Adresse
						WHEN 'Postnr' THEN RIGHT('0000' + CAST(Postnr AS VARCHAR(30)), 4)
						ELSE RIGHT('00000000000' + CAST(Id AS VARCHAR(20)), 10)
					END
				END
				DESC;
GO
SELECT *
	FROM dbo.Userdata;
GO
CREATE TABLE dbo.t1 
(
	Dato1		DATE NULL,
	Dato2		DATE NULL,
	CONSTRAINT CK_t1_Dato1_Dato2 CHECK (Dato1 IS NOT NULL OR Dato2 IS NOT NULL)
);

CREATE TABLE dbo.t2 
(
	Id			INT NOT NULL PRIMARY KEY,
	Dato		DATE NOT NULL
);
GO
INSERT INTO dbo.t1 VALUES 
	('2010-3-1', '2010-5-1'),
	('2010-4-1', '2010-3-1'),
	('2010-6-1', '2010-6-1'),
	(NULL, '2010-6-1'),
	('2010-3-1', NULL);

INSERT INTO dbo.t2 VALUES 
	(1, '2010-3-1'),
	(2, '2010-4-1'),
	(3, '2010-5-1'),
	(4, '2010-6-1');
GO
SELECT *
	FROM dbo.t1 INNER JOIN dbo.t2 
			ON t2.Dato = CASE
							WHEN Dato1 >= Dato2  THEN Dato1
							WHEN Dato2 > Dato1  THEN Dato2
							WHEN Dato1 IS NULL AND Dato2 IS NOT NULL THEN Dato2
							WHEN Dato2 IS NULL AND Dato1 IS NOT NULL THEN Dato1
						 END;

GO
CREATE TABLE dbo.Kunde 
(
	KundeId		INT NOT NULL PRIMARY KEY,
	LandeKode	CHAR(3) NOT NULL
);
GO
INSERT INTO dbo.Kunde VALUES 
	(1, 'DK'),
	(2, 'S'),
	(3, 'N'),
	(4, 'DK');
GO
SELECT	KundeId,
		CASE LandeKode
			WHEN 'DK' THEN 'Danmark'
			WHEN 'D'  THEN 'Tyskland'
			WHEN 'N'  THEN 'Norge'
			WHEN 'S'  THEN 'Sverige'
			ELSE 'Ukendt'
		END AS LandeNavn
	FROM dbo.Kunde;
