USE master;
DROP DATABASE TSQLDB;
GO
CREATE DATABASE TSQLDB;
GO
USE TSQLDB;

CREATE TABLE dbo.Postopl 
(
	id		INT IDENTITY PRIMARY KEY NOT NULL, 
	Postnr	SMALLINT NOT NULL,
	Bynavn	VARCHAR(20) NOT NULL
);

INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(6000, 'Kolding'),
	(9000, 'Aalborg'),
	(8000, 'Aarhus C');
GO
DECLARE @Postnr		SMALLINT;
DECLARE @Bynavn		VARCHAR(20);

SELECT @Postnr, @Bynavn;
GO
DECLARE	@Postnr		SMALLINT,
		@Bynavn		VARCHAR(20);

SELECT @Postnr, @Bynavn;
GO
DECLARE @Postnr		SMALLINT = 5000;
DECLARE @Region		SMALLINT = @Postnr/1000;

SELECT @Postnr, @Region
GO
-- fejl
DECLARE @Postnr2		SMALLINT = @Postnr1;
DECLARE @Postnr1		SMALLINT = 1000;

SELECT @Postnr2;
GO
DECLARE @Postnr		SMALLINT = 1000;

SELECT @Postnr;
GO
DECLARE @Postnr		SMALLINT = (SELECT MIN(Postnr) FROM dbo.Postopl);

SELECT @Postnr;
GO
DECLARE @Postnr		SMALLINT

SET @Postnr = (SELECT MIN(Postnr) FROM dbo.Postopl);

SELECT @Postnr;
GO
SELECT @@VERSION
GO
-- tabel-variabel
DECLARE @Postdata TABLE
(
	ID			INT			NOT NULL PRIMARY KEY IDENTITY,
 	Postnr		SMALLINT	NOT NULL CHECK(Postnr > 2000),
	Bynavn		VARCHAR(20) NOT NULL INDEX nc_Postdata_Bynavn
);

INSERT INTO @Postdata (Postnr, Bynavn)
	SELECT Postnr, Bynavn
		FROM dbo.Postopl
		WHERE Postnr > 5000;

SELECT *
	FROM @Postdata;

SELECT *
	FROM tempdb.sys.tables

-- fejler
CREATE INDEX nc_temp_table ON @Postdata (Postnr)
GO
SELECT Postnr, Bynavn
	INTO #Postdata
	FROM dbo.Postopl
	WHERE Postnr < 5000

SELECT *
	FROM #Postdata

CREATE INDEX nc_temp_table ON #Postdata (Postnr)

DROP TABLE #Postdata
GO
-- Transaktioner og tabel-variable

DECLARE @t TABLE
(
	Navn		VARCHAR(30)
);

CREATE TABLE #t
(
	Navn		VARCHAR(30)
);

INSERT INTO @t(Navn) VALUES
	('Ole');

INSERT INTO #t(Navn) VALUES
	('Ole');

BEGIN TRANSACTION

	UPDATE @t	
		SET Navn = 'Ole Erik';

	UPDATE #t	
		SET Navn = 'Ole Erik';

SELECT *
	FROM @t;

SELECT *
	FROM #t;

ROLLBACK TRANSACTION;

SELECT *
	FROM @t;

SELECT *
	FROM #t;
GO
-- tabel-variabel
DECLARE @Postdata TABLE
(
	ID			INT NOT NULL PRIMARY KEY IDENTITY,
 	Postnr		SMALLINT NOT NULL CHECK(Postnr > 2000) INDEX nc_Person_Postnr,
	Bynavn		VARCHAR(20) NOT NULL INDEX nc_Person_Bynavn
);

INSERT INTO @Postdata (Postnr, Bynavn)
	SELECT Postnr, Bynavn
		FROM dbo.Postopl
		WHERE Postnr > 5000;

SELECT *
	FROM @Postdata;

SELECT *
	FROM tempdb.sys.tables
