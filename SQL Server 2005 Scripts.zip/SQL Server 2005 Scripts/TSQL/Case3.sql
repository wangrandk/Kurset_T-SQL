USE IndexDB
GO
SET STATISTICS TIME ON
SELECT	TOP 20000 PersonType,
		CASE PersonType
			WHEN 'A' THEN 'AAAAAAAAAAAAAA'
			WHEN 'B' THEN 'BBBBBBBBBBBBBB'
			WHEN 'C' THEN 'CCCCCCCCCCCCCC'
			WHEN 'D' THEN 'DDDDDDDDDDDDDD'
		END AS PersonTypeTxt
	FROM dbo.Person
	ORDER BY Persontype DESC;
GO
SELECT	TOP 20000 PersonType,
		CASE 
			WHEN PersonType ='A' THEN 'AAAAAAAAAAAAAA'
			WHEN PersonType  IN ('B', 'C','D')  THEN 'BCDBCS'
		END AS PersonTypeTxt
	FROM dbo.Person
	ORDER BY Persontype DESC;
GO
DBCC DROPCLEANBUFFERS;
GO
SELECT	Person.PersonType, 
		ISNULL(PersonTypeTxt, 'Andet')
	FROM dbo.Person INNER JOIN  (SELECT 'A', 'AAAAAAAAAAAAAA'
							 UNION ALL
							 SELECT 'B', 'BBBBBBBBBBBBBB'
							 UNION All
							 SELECT 'C', 'CCCCCCCCCCCCCC'
							 UNION All
							 SELECT 'D', 'DDDDDDDDDDDDDD') AS P(PersonType, PersonTypeTxt)
	ON Person.PersonType = P.PersonType;
GO
DBCC DROPCLEANBUFFERS;
GO
SELECT	Person.PersonType, 
		ISNULL(PersonTypeTxt, 'Andet')
	FROM dbo.Person INNER JOIN  (VALUES	('A', 'AAAAAAAAAAAAAA'),
									('B', 'BBBBBBBBBBBBBB'),
									('C', 'CCCCCCCCCCCCCC'),
									('D', 'DDDDDDDDDDDDDD')) AS P(PersonType, PersonTypeTxt)
	ON Person.PersonType = P.PersonType;
GO
SET STATISTICS TIME OFF;
