USE master
DROP DATABASE MirrorDB
GO
RESTORE DATABASE MirrorDB FROM DISK = 'c:\rod\MirrorDB.bak' WITH NORECOVERY,
	 MOVE 'MirrorDB' TO 'c:\rod\MirrorDB.mdf',
	 MOVE 'MirrorDB_log' TO 'c:\rod\MirrorDB.ldf'
GO
RESTORE LOG MirrorDB 
	FROM DISK = 'c:\rod\MirrorDB.log' WITH NORECOVERY
