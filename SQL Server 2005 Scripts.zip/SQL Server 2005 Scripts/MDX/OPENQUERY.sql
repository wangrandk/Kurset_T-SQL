SELECT r.* 
FROM OPENQUERY(BI,
'WITH 
MEMBER MEASURES.MemName AS [Vare].[Kategori - Sub Kategori].CURRENTMEMBER.NAME 
MEMBER MEASURES.LevelName AS [Vare].[Kategori - Sub Kategori].Level.NAME 
MEMBER MEASURES.HieName AS [Vare].[Kategori - Sub Kategori].HIERARCHY.NAME 
MEMBER MEASURES.MemOrdinal AS [Vare].[Kategori - Sub Kategori].Level.Ordinal 

SELECT	{MEASURES.MemName, MEASURES.MemOrdinal} on 0,
		[Vare].[Kategori - Sub Kategori].members on 1
FROM [BIDB]') as r
go

SELECT REPLICATE('|', "[Measures].[MemOrdinal]") + "[Measures].[MemName]"	
FROM OPENQUERY(BI,
'WITH 
MEMBER MEASURES.MemName AS [Vare].[Kategori - Sub Kategori].CURRENTMEMBER.NAME 
MEMBER MEASURES.LevelName AS [Vare].[Kategori - Sub Kategori].Level.NAME 
MEMBER MEASURES.HieName AS [Vare].[Kategori - Sub Kategori].HIERARCHY.NAME 
MEMBER MEASURES.MemOrdinal AS [Vare].[Kategori - Sub Kategori].Level.Ordinal 

SELECT	{MEASURES.MemName, MEASURES.MemOrdinal} on 0,
		[Vare].[Kategori - Sub Kategori].members on 1
FROM [BIDB]') as r
go

