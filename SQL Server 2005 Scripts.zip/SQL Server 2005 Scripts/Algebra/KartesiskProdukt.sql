USE master;
DROP DATABASE AlgebraDB;
GO
CREATE DATABASE AlgebraDB;
GO
USE AlgebraDB;
GO
CREATE TABLE dbo.v 
(
	i		INT,
	a		CHAR(1)
);

CREATE TABLE dbo.u
(
	b		CHAR(1)
);
GO
SET NOCOUNT ON
INSERT INTO dbo.v VALUES 
	(1,'a'),
	(2,'a'),
	(3,'c');

INSERT INTO dbo.u VALUES 
	('x'),
	('y');
SET NOCOUNT OFF;

--KARTESISK PRODUKT (V * U)
SELECT *
    FROM dbo.v, dbo.u;

--ELLER
SELECT *
    FROM dbo.v CROSS JOIN dbo.u;
