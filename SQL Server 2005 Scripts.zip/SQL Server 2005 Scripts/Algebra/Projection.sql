USE master;
DROP DATABASE AlgebraDB;
GO
CREATE DATABASE AlgebraDB;
GO
USE AlgebraDB;
GO
CREATE TABLE dbo.Person 
(
	PersonId		INT			NOT NULL 
								CONSTRAINT PK_Vare PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT	NOT NULL,
	Opretdato		DATE		NULL
);
GO
INSERT INTO dbo.Person VALUES 
	(1,'Hansen', 'Vestergade', 3000, DATEADD(DAY, - 6, SYSDATETIME())),
	(2,'Jensen', '�stergade', 2000, DATEADD(DAY, -7, SYSDATETIME())),
	(3,'Jensen', 'Nygade', 5000, DATEADD(DAY, -14, SYSDATETIME())),
	(4,'S�rensen', 'Torvet', 4000, DATEADD(DAY, - 6, SYSDATETIME())),
	(5,'Petersen', 'Vestergade', 9000, DATEADD(DAY, -4, SYSDATETIME())),
	(6,'Pedersen', 'N�rregade', 3000, DATEADD(DAY, -12, SYSDATETIME())),
	(7,'Hansen', 'Vestergade', 9000, DATEADD(DAY, -4, SYSDATETIME())),
	(8,'Knudsen', 'Vestergade', 8000, NULL),
	(9,'Olsen', 'Nygade', 8000, NULL);
GO
SELECT PersonId 
	FROM dbo.Person;			--pk, derfor er distinct overfl�dig
GO			
SELECT PersonId, Navn 
	FROM dbo.Person;			--pk, derfor er distinct overfl�dig
GO
SELECT DISTINCT PersonId, Navn 
	FROM dbo.Person;			--pk, derfor er distinct overfl�dig
GO
SELECT DISTINCT Postnr 
	FROM dbo.Person;			-- ikke en kandidatn�gle derfor skal distinct med
GO
SELECT DISTINCT Navn, Adresse 
	FROM dbo.Person;
GO
SELECT DISTINCT Opretdato 
	FROM dbo.Person;
