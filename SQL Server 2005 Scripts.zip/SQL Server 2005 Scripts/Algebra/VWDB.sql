USE master;
DROP DATABASE VWDB;
GO
CREATE DATABASE VWDB;
GO
USE VWDB;
CREATE TABLE dbo.Leverandoer 
(
	LeverandoerId	INT			NOT NULL PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	LeverandoerBy	VARCHAR(30) NOT NULL,
	Status			INT			NOT NULL
);

CREATE TABLE dbo.Vare 
(
	VareId			INT			NOT NULL PRIMARY KEY,
	VareBetegnelse	VARCHAR(50) NOT NULL,
	Vaegt			INT			NOT NULL,
	VareGruppe		INT			NOT NULL
);

CREATE TABLE dbo.Bil 
(
	BilId			INT			NOT NULL PRIMARY KEY,
	Model			VARCHAR(30) NOT NULL UNIQUE,
	Fabrik			VARCHAR(30) NOT NULL
);

CREATE TABLE dbo.LVB 
(
	LeverandoerId	INT NOT NULL FOREIGN KEY REFERENCES dbo.Leverandoer,
	VareId			INT NOT NULL FOREIGN KEY REFERENCES dbo.Vare,
	BilId			INT NOT NULL FOREIGN KEY REFERENCES dbo.Bil,
	Kvantum			INT NOT NULL
);
GO
INSERT INTO dbo.Leverandoer VALUES
	(1, 'M�ller', 'Wolfsburg', 7),
	(2, 'Schmidt', 'Stuttgart', 2),
	(3, 'Hansen', 'Stuttgart', 3),
	(4, 'Man', 'Wolfsburg', 7),
	(5, 'Dohrmann', 'Berlin', 3);

INSERT INTO dbo.Vare VALUES
	(1, 'M�trik', 1, 1),
	(2, 'Motorblok', 38, 7),
	(3, 'Stempel', 1, 2),
	(4, 'D�rplade', 14, 3),
	(5, 'Bremser�r', 1, 6),
	(6, 'Krumtap', 3, 7);

INSERT INTO dbo.Bil VALUES
	(1, 'Golf', 'Stuttgart'),
	(2, 'Passat', 'M�nchen'),
	(3, 'Polo', 'Berlin'),
	(4, 'Jetta', 'Berlin'),
	(5, 'Derby', 'Wolfsburg'),
	(6, 'Audi 80', 'Augsburg'),
	(7, 'Audi 100', 'Wolfsburg');

INSERT INTO dbo.LVB VALUES
	(1, 1, 1, 80000),
	(1, 1, 4, 4000),
	(2, 3, 1, 10000),
	(2, 3, 2, 5000),
	(2, 3, 3, 12000),
	(2, 3, 4, 13000),
	(2, 3, 5, 8000),
	(2, 3, 6, 6000),
	(2, 3, 7, 4000),
	(2, 5, 2, 600),
	(3, 3, 1, 1400),
	(3, 4, 2, 800),
	(4, 6, 3, 3000),
	(4, 6, 7, 2000),
	(5, 2, 2, 2000),
	(5, 2, 4, 8000),
	(5, 5, 5, 1400),
	(5, 5, 7, 1800),
	(5, 6, 2, 9000),
	(5, 1, 4, 60000),
	(5, 3, 4, 1500),
	(5, 4, 4, 2500),
	(5, 5, 4, 1600),
	(5, 6, 4, 200);
GO
SELECT DISTINCT LeverandoerBy
	FROM dbo.Leverandoer
GO
SELECT DISTINCT Model
	FROM dbo.Bil
	WHERE Fabrik = 'Wolfsburg'
GO
SELECT DISTINCT Model
	FROM dbo.Bil
	WHERE Fabrik NOT IN ('Stuttgart', 'Berlin')
GO
SELECT DISTINCT LeverandoerId
	FROM dbo.Bil INNER JOIN dbo.LVB ON dbo.Bil.BilId = dbo.LVB.BilId
	WHERE Model = 'Jetta'
GO
SELECT DISTINCT Model
	FROM dbo.Bil INNER JOIN dbo.LVB ON dbo.Bil.BilId = dbo.LVB.BilId
	WHERE LeverandoerId = 1
GO
SELECT Navn
	FROM dbo.Leverandoer
	WHERE EXISTS (SELECT * 
					FROM dbo.LVB INNER JOIN dbo.Bil ON dbo.LVB.BilId = dbo.Bil.BilId
					WHERE Model = 'Passat' AND
						  dbo.Leverandoer.LeverandoerId = dbo.LVB.LeverandoerId) AND
          EXISTS (SELECT * 
					FROM dbo.LVB INNER JOIN dbo.Bil ON dbo.LVB.BilId = dbo.Bil.BilId
					WHERE Model = 'Golf' AND
						  dbo.Leverandoer.LeverandoerId = dbo.LVB.LeverandoerId)

SELECT Navn 
	FROM dbo.LVB INNER JOIN dbo.Bil ON dbo.LVB.BilId = dbo.Bil.BilId
			 INNER JOIN dbo.Leverandoer ON dbo.Leverandoer.LeverandoerId = dbo.LVB.LeverandoerId
	WHERE Model = 'Passat'  
INTERSECT 
SELECT Navn
	FROM dbo.LVB INNER JOIN dbo.Bil ON dbo.LVB.BilId = dbo.Bil.BilId
			 INNER JOIN dbo.Leverandoer ON dbo.Leverandoer.LeverandoerId = dbo.LVB.LeverandoerId
	WHERE Model = 'Golf'

SELECT Navn
FROM dbo.Leverandoer
WHERE NOT EXISTS 
		(SELECT BilId
			FROM dbo.Bil
			WHERE Model IN ('Passat', 'Golf') AND
				  NOT EXISTS (SELECT * 
								FROM dbo.LVB 
								WHERE dbo.LVB.BilId = dbo.Bil.BilId AND
									  dbo.LVB.LeverandoerId = dbo.Leverandoer.LeverandoerId))
GO
SELECT DISTINCT dbo.Vare.VareId, VareBetegnelse, Vaegt
	FROM dbo.LVB INNER JOIN dbo.Vare ON dbo.LVB.VareId = dbo.Vare.VareId
			 INNER JOIN dbo.Bil ON dbo.LVB.BilId = dbo.Bil.BilId
			 INNER JOIN dbo.Leverandoer ON dbo.LVB.LeverandoerId = dbo.Leverandoer.LeverandoerId
	WHERE Vaegt > 10 AND
		  Fabrik <> LeverandoerBy
GO
SELECT DISTINCT dbo.Leverandoer.LeverandoerId
FROM dbo.Leverandoer 
WHERE NOT EXISTS 
	(SELECT BilId
		FROM dbo.Bil
		WHERE NOT EXISTS 
				(SELECT * 
					FROM dbo.LVB
					WHERE dbo.LVB.LeverandoerId = dbo.Leverandoer.LeverandoerId AND
						  dbo.Bil.BilId = dbo.LVB.BilId))

GO
SELECT LeverandoerId
	FROM dbo.Leverandoer 
	WHERE Status IN (SELECT Status
						FROM dbo.Leverandoer
						WHERE Navn = 'M�ller') AND
		  Navn <> 'M�ller'
GO
SELECT DISTINCT LeverandoerBy
   FROM dbo.Leverandoer
UNION
SELECT DISTINCT Fabrik
   FROM dbo.Bil

SELECT LeverandoerBy
   FROM dbo.Leverandoer
UNION
SELECT Fabrik
   FROM dbo.Bil
GO
SELECT DISTINCT LeverandoerBy
	FROM dbo.Leverandoer
	WHERE EXISTS 
			(SELECT Fabrik
				FROM dbo.Bil
				WHERE LeverandoerBy = Fabrik)

SELECT LeverandoerBy
	FROM dbo.Leverandoer
INTERSECT
SELECT Fabrik
	FROM dbo.Bil
GO
SELECT DISTINCT LeverandoerBy
	FROM dbo.Leverandoer
	WHERE NOT EXISTS 
			(SELECT Fabrik
				FROM dbo.Bil
				WHERE LeverandoerBy = Fabrik)

SELECT LeverandoerBy
	FROM dbo.Leverandoer
EXCEPT
SELECT Fabrik
	FROM dbo.Bil
GO
SELECT DISTINCT Fabrik
	FROM dbo.Bil
	WHERE NOT EXISTS 
			(SELECT LeverandoerBy
				FROM dbo.Leverandoer
				WHERE LeverandoerBy = Fabrik)

SELECT Fabrik
	FROM dbo.Bil
EXCEPT
SELECT LeverandoerBy
	FROM dbo.Leverandoer

