USE master;
DROP DATABASE JoinDB;
GO
CREATE DATABASE JoinDB;
GO
USE JoinDB;
--sammensat join ref
CREATE TABLE dbo.OrdreLinie 
(
	OrdreID			INT NOT NULL,
	VareId			INT NOT NULL,
	AntalEnh		INT NOT NULL,
	CONSTRAINT PK_OrdreLinie PRIMARY KEY (OrdreID, VareId)
);

CREATE TABLE dbo.FakturaLinie 
(
	FakturaID		INT NOT NULL IDENTITY PRIMARY KEY,
	OrdreID			INT NOT NULL,
	VareId			INT NOT NULL,
	AntalEnh		INT NOT NULL,
	CONSTRAINT FK_FakturaLinie_OrdreLinie 
	FOREIGN KEY (OrdreID, VareId)REFERENCES dbo.OrdreLinie (OrdreID, VareId)
);

INSERT INTO dbo.OrdreLinie VALUES 
	(1,3,2),
	(1,5,4),
	(2,1,1);

INSERT INTO dbo.FakturaLinie VALUES 
	(1,3,2),
	(1,5,1),
	(1,5,3),
	(2,1,1);

SELECT *
	FROM dbo.OrdreLinie INNER JOIN dbo.FakturaLinie 
			ON	dbo.OrdreLinie.OrdreID = dbo.FakturaLinie.OrdreID AND
				dbo.OrdreLinie.VareId = dbo.FakturaLinie.VareId

--self join
CREATE TABLE dbo.Medarbejder 
(
	MedarbejderID		INT NOT NULL PRIMARY KEY,
	Navn				VARCHAR(30) NOT NULL,
	ChefID				INT NULL 
						FOREIGN KEY REFERENCES dbo.Medarbejder (MedarbejderID)
);
GO
INSERT INTO dbo.Medarbejder VALUES 
	(1, 'Ane', NULL),
	(2, 'Per', 1),
	(3, 'Ida', 1),
	(4, 'Ole', 2),
	(5, 'Karl', 2);
GO
SELECT M.*, Chef.Navn
	FROM dbo.Medarbejder AS M LEFT JOIN dbo.Medarbejder AS Chef 
		ON M.ChefID = Chef.MedarbejderID
GO
--join med between - THETA JOIN
CREATE TABLE dbo.Vikar
(
	VikarID			INT NOT NULL
					CONSTRAINT PK_Vikar PRIMARY KEY,
	Vikarnavn		VARCHAR(30) NOT NULL
);	

CREATE TABLE dbo.VikarBlokering 
(
	VikarID			INT NOT NULL,
	StartTid		SMALLDATETIME NOT NULL,
	SlutTid			SMALLDATETIME NOT NULL,
	CONSTRAINT PK_VikarBlokering PRIMARY KEY (VikarID, StartTid),
	CONSTRAINT CK_VB_StartTid_SlutTid CHECK (Starttid < SlutTid)
);

CREATE TABLE dbo.VikarOensker 
(
	ID				INT NOT NULL PRIMARY KEY,
	StartTid		SMALLDATETIME NOT NULL,
	SlutTid			SMALLDATETIME NOT NULL,
	CONSTRAINT CK_VO_StartTid_SlutTid CHECK (Starttid < SlutTid)
);
GO
INSERT INTO dbo.Vikar VALUES
	(1, 'Hanne Hansen'),
	(2, 'Ole Petersen'),
	(3, 'Maren Madsen');

INSERT INTO dbo.VikarBlokering VALUES 
	(1, '2014-4-3 8:00', '2014-4-3 16:00'),
	(1, '2014-4-4 15:00', '2014-4-4 23:00'),
	(1, '2014-4-5 10:00', '2014-4-5 12:00'),
	(1, '2014-4-5 20:00', '2014-4-5 23:00'),
	(2, '2014-4-3 15:00', '2014-4-3 23:00');

INSERT INTO dbo.VikarOensker VALUES 
	(1, '2014-4-3 15:00', '2014-4-3 23:00'),
	(2, '2014-4-5 8:00', '2014-4-5 16:00'),
	(3, '2014-4-4 8:00', '2014-4-4 16:00'),
	(4, '2014-4-6 8:00', '2014-4-6 16:00');
GO
SELECT *
	FROM dbo.VikarBlokering;

SELECT *
	FROM dbo.VikarOensker;
GO
-- ikke mulige
SELECT *
	FROM dbo.VikarOensker AS VO LEFT JOIN dbo.VikarBlokering AS VB
		ON	VO.StartTid BETWEEN VB.StartTid AND VB.SlutTid OR
			VO.SlutTid BETWEEN VB.StartTid AND VB.SlutTid OR 
			VB.StartTid BETWEEN VO.StartTid AND VO.SlutTid OR
			VB.SlutTid BETWEEN VO.StartTid AND VO.SlutTid;
 
 -- Mulige
 SELECT *
	FROM dbo.Vikar AS VRes CROSS JOIN dbo.VikarOensker AS VORes
	WHERE NOT EXISTS (
				SELECT *
				FROM dbo.VikarOensker AS VO LEFT JOIN dbo.VikarBlokering AS VB
					ON	VO.StartTid BETWEEN VB.StartTid AND VB.SlutTid OR
						VO.SlutTid BETWEEN VB.StartTid AND VB.SlutTid OR 
						VB.StartTid BETWEEN VO.StartTid AND VO.SlutTid OR
						VB.SlutTid BETWEEN VO.StartTid AND VO.SlutTid
				WHERE	VRes.VikarID = VB.VikarID AND
						VORes.ID = VO.ID)