USE master
DROP DATABASE JoinDB
GO
CREATE DATABASE JoinDB
GO
USE JoinDB
CREATE TABLE dbo.t1 
(
	pk		INT NOT NULL PRIMARY KEY
);

CREATE TABLE dbo.t2 
(
	pk		INT NOT NULL PRIMARY KEY,
	fk		INT NOT NULL FOREIGN KEY REFERENCES dbo.t1(pk)
);

CREATE TABLE dbo.t3 
(
	pk		INT NOT NULL PRIMARY KEY
);

CREATE TABLE dbo.t4 
(
	pk		INT NOT NULL PRIMARY KEY,
	fk		INT NULL FOREIGN KEY REFERENCES dbo.t3(pk)
);
GO
INSERT INTO dbo.t1 VALUES 
	(1),
	(2),
	(3);

INSERT INTO dbo.t2 VALUES 
	(1, 1),
	(2, 2),
	(3, 2);

INSERT INTO dbo.t3 VALUES 
	(11),
	(12),
	(13),
	(14);

INSERT INTO dbo.t4 VALUES 
	(1, 11),
	(2, 12),
	(3, 13),
	(4, NULL);
GO
SELECT *
	FROM dbo.t1 INNER JOIN dbo.t2 ON dbo.t1.pk = t2.fk
		 CROSS JOIN
		 dbo.t3 RIGHT JOIN dbo.t4 ON dbo.t3.pk = t4.fk
EXCEPT
SELECT *
	FROM (dbo.t1 INNER JOIN dbo.t2 ON t1.pk = t2.fk)
		  CROSS JOIN
		 (dbo.t3 RIGHT JOIN dbo.t4 ON t3.pk = t4.fk);

SELECT *
	FROM (dbo.t1 INNER JOIN dbo.t2 ON t1.pk = t2.fk)
		  CROSS JOIN 
		 (dbo.t3 RIGHT JOIN dbo.t4 ON t3.pk = t4.fk)
EXCEPT
SELECT *
	FROM dbo.t1 INNER JOIN dbo.t2 ON t1.pk = t2.fk
		 CROSS JOIN 
		 dbo.t3 RIGHT JOIN dbo.t4 ON t3.pk = t4.fk;
GO
SELECT *
	FROM dbo.t1 INNER JOIN dbo.t2 ON t1.pk = t2.fk
		 CROSS JOIN
		 dbo.t3 INNER JOIN dbo.t4 ON t3.pk = t4.fk
EXCEPT
SELECT *
	FROM (dbo.t1 INNER JOIN dbo.t2 ON t1.pk = t2.fk)
		  CROSS JOIN
		 (dbo.t3 INNER JOIN dbo.t4 ON t3.pk = t4.fk);

SELECT *
	FROM (dbo.t1 INNER JOIN dbo.t2 ON t1.pk = t2.fk)
		 CROSS JOIN
		 (dbo.t3 INNER JOIN dbo.t4 ON t3.pk = t4.fk)
EXCEPT
SELECT *
	FROM dbo.t1 INNER JOIN dbo.t2 ON t1.pk = t2.fk
		  CROSS JOIN
		 dbo.t3 INNER JOIN dbo.t4 ON t3.pk = t4.fk;
GO
SELECT *
	FROM dbo.t1 INNER JOIN dbo.t2 ON t1.pk = t2.fk
SELECT *
	FROM dbo.t3 RIGHT JOIN dbo.t4 ON t3.pk = t4.fk;
