USE master;
DROP DATABASE AlgebraDB;
GO
CREATE DATABASE AlgebraDB;
GO
USE AlgebraDB;
GO
CREATE TABLE dbo.v 
(
	Id			INT,
	Tekst		VARCHAR(10)
);

CREATE TABLE dbo.u 
(
	Id			INT,
	Tekst		VARCHAR(10)
);
GO
SET NOCOUNT ON;
INSERT INTO dbo.v VALUES 
	(1, 'a'),
	(2, 'b'),
	(3, 'c');

INSERT INTO dbo.u VALUES 
	(3, 'c'),
	(4, 'd'),
	(5, 'e');
SET NOCOUNT OFF;

--INTERSECT
SELECT *
	FROM dbo.v
INTERSECT
SELECT *
	FROM dbo.u;
GO
SELECT *
   FROM dbo.v
   WHERE EXISTS
	(SELECT *
   		FROM dbo.u
		WHERE v.Id = u.Id AND
			  v.Tekst = u.Tekst)

--INTERSECT - praktisk (med kandIdatn�gle)
SELECT *
   FROM dbo.v
   WHERE EXISTS
	(SELECT *
   		FROM dbo.u
		WHERE v.Id = u.Id)

--DUBLETTER
GO
CREATE TABLE dbo.t1 
(
	Id		INT,
	Tekst	VARCHAR(10)
);

CREATE TABLE dbo.t2 
(
	Id		INT,
	Tekst	VARCHAR(10)
);
GO
INSERT INTO dbo.t1 VALUES 
	(1,'a'),
	(3,'c'),
	(3,'c');

INSERT INTO dbo.t2 VALUES 
	(3,'c'),
	(3,'c'),
	(3,'c'),
	(4,'d'),
	(5,'e');
GO
SELECT *
	FROM dbo.t1
INTERSECT 
SELECT *
	FROM dbo.t2;
GO
SELECT DISTINCT *
	FROM dbo.t1
INTERSECT 
SELECT DISTINCT *
	FROM dbo.t2;
	
--INTERSECT dubletter
SELECT DISTINCT Id, Tekst
   FROM dbo.t1
   WHERE EXISTS
	(SELECT *
   		FROM dbo.t2
		WHERE t1.Id = t2.Id and
			  t1.Tekst = t2.Tekst);

SELECT Id, Tekst
   FROM dbo.t2
   WHERE EXISTS
	(SELECT *
   		FROM dbo.t1
		WHERE t1.Id = t2.Id and
			  t1.Tekst = t2.Tekst);

-- MED NULL
DROP TABLE dbo.t1;
DROP TABLE dbo.t2;

CREATE TABLE dbo.t1 
(
	Id		INT PRIMARY KEY,
	Tekst	VARCHAR(10) NULL
);

CREATE TABLE dbo.t2 
(
	Id		INT PRIMARY KEY,
	Tekst	VARCHAR(10) NULL
);

INSERT INTO t1 VALUES 
	(1, 'a'),
	(3, 'c'),
	(4, NULL);

INSERT INTO dbo.t2 VALUES 
	(3, 'c'),
	(4, NULL),
	(5, 'e');
GO
SELECT DISTINCT Id, Tekst
   FROM dbo.t1
   WHERE EXISTS
	(SELECT *
   		FROM dbo.t2
		WHERE t1.Id = t2.Id AND
			  t1.Tekst = t2.Tekst)

SELECT *
	FROM dbo.t1
INTERSECT
SELECT *
	FROM dbo.t2;


--INTERSECT med null
SELECT Id, Tekst
   FROM dbo.t1
   WHERE EXISTS
	(SELECT *
   		FROM dbo.t2
		WHERE (t1.Id = t2.Id) AND
			  (t1.Tekst = t2.Tekst OR (t1.Tekst IS NULL AND t2.Tekst IS NULL)))

--INTERSECT ALL, dubletter medtages, hvor der er f�rrest
TRUNCATE TABLE dbo.u;
TRUNCATE TABLE dbo.v;

SET NOCOUNT ON;

INSERT INTO dbo.v VALUES 
	(1,'a'),
	(3,'c'),
	(3,'c'),
	(4,'d'),
	(4,'d'),
	(5,'e');

INSERT INTO dbo.u VALUES 
	(3,'c'),
	(3,'c'),
	(3,'c'),
	(4,'d'),
	(5,'e');
SET NOCOUNT OFF;
GO
SELECT * 
FROM dbo.v
WHERE (SELECT COUNT(*) 
          FROM dbo.v AS vlbnr
          WHERE v.Id = vlbnr.Id AND
                v.Tekst = vlbnr.Tekst) <= (SELECT COUNT(*) 
               							        FROM dbo.u AS ulbnr
            							        WHERE v.Id = ulbnr.Id AND
                   							          v.Tekst = ulbnr.Tekst)
UNION ALL
SELECT * 
FROM dbo.u
WHERE (SELECT COUNT(*) 
          FROM dbo.u AS ulbnr
          WHERE u.Id = ulbnr.Id AND
                u.Tekst = ulbnr.Tekst) < (SELECT COUNT(*) 
             							       FROM dbo.v AS vlbnr
                							   WHERE u.Id = vlbnr.Id AND
                      							     u.Tekst = vlbnr.Tekst);
GO
SELECT Id, Tekst
FROM (
	SELECT *,
		ROW_NUMBER() OVER (PARTITION BY Id, Tekst ORDER BY Id) AS RowNumber
		FROM dbo.u
	INTERSECT
	SELECT *,
		ROW_NUMBER() OVER (PARTITION BY Id, Tekst ORDER BY Id)
		FROM dbo.v) AS t
