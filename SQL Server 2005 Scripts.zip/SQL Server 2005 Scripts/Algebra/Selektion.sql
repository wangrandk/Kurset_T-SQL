USE master
DROP DATABASE AlgebraDB
GO
CREATE DATABASE AlgebraDB
GO
USE AlgebraDB
GO
CREATE TABLE dbo.Person 
(	
	PersonID		INT				NOT NULL,
	Navn			VARCHAR(30)		NOT NULL,
	Adresse			VARCHAR(30)		NOT NULL,
	Postnr			SMALLINT		NOT NULL,
	Opretdato		SMALLDATETIME	NOT NULL
);
GO
SET NOCOUNT ON;

INSERT INTO dbo.Person VALUES 
	(1,'Hansen', 'Vestergade', 3000, DATEADD(DAY, -5, SYSDATETIME())),
	(2,'Jensen', '�stergade', 2000, DATEADD(DAY, -21, SYSDATETIME())),
	(3,'Olsen', 'Nygade', 5000, DATEADD(DAY, -1, SYSDATETIME())),
	(4,'S�rensen', 'Torvet', 4000, DATEADD(DAY, -7, SYSDATETIME())),
	(5,'Petersen', 'Vestergade', 9000, DATEADD(DAY, 1, SYSDATETIME())),
	(6,'Pedersen', 'N�rregade', 3000, DATEADD(DAY, 9, SYSDATETIME())),
	(7,'H�g', 'Vestergade', 9000, DATEADD(DAY, 2, SYSDATETIME()));

SET NOCOUNT OFF;
GO
SELECT * 
	FROM dbo.Person;
GO
SELECT * 
	FROM dbo.Person 
	WHERE Postnr = 9000;
GO
SELECT * 
	FROM dbo.Person 
	WHERE Postnr = 1000;
GO
SELECT * 
	FROM dbo.Person 
	WHERE Postnr >= 1000;
GO
SELECT * 
	FROM dbo.Person 
	WHERE Navn LIKE 'Pe[dt]ersen';
GO
SELECT * 
	FROM dbo.Person 
	WHERE Opretdato < GETDATE() AND Adresse =  'N�rregade';
