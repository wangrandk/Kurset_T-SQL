USE IndexDB;
GO
SELECT	PersonId,
		CAST(Fornavn AS NVARCHAR(20)) AS Fornavn,
		CAST(Efternavn AS NVARCHAR(20)) AS Efternavn,
		CAST(Postnr as INT) AS Postnr
	INTO dbo.P1
	FROM dbo.Person;
GO
SELECT	PersonId,
		Fornavn,
		Efternavn,
		Postnr
	INTO dbo.P2
	FROM dbo.Person;
GO
DECLARE @Fornavn1		NVARCHAR(20) = N'Ole';
DECLARE @Efternavn1		NVARCHAR(20) = N'Olsen';

SELECT *
	FROM dbo.P1
	WHERE	Fornavn = @Fornavn1 AND
			Efternavn = @Efternavn1;
GO
DECLARE @Fornavn2		VARCHAR(20) = 'Ole';
DECLARE @Efternavn2		VARCHAR(20) = 'Olsen';

SELECT *
	FROM dbo.P1
	WHERE	Fornavn = @Fornavn2 AND
			Efternavn = @Efternavn2;
GO
DECLARE @Fornavn1		NVARCHAR(20) = N'Ole';
DECLARE @Efternavn1		NVARCHAR(20) = N'Olsen';

SELECT *
	FROM dbo.P2
	WHERE	Fornavn = @Fornavn1 AND
			Efternavn = @Efternavn1;
GO
DECLARE @Fornavn2		VARCHAR(20) = 'Ole';
DECLARE @Efternavn2		VARCHAR(20) = 'Olsen';

SELECT *
	FROM dbo.P2
	WHERE	Fornavn = @Fornavn2 AND
			Efternavn = @Efternavn2;
GO
------------------------------------------------------------
CREATE CLUSTERED INDEX NC_P1_PersonId ON dbo.P1(PersonId);
CREATE NONCLUSTERED INDEX NC_P1_Fornavn ON dbo.P1(Fornavn);
CREATE NONCLUSTERED INDEX NC_P1_Efternavn ON dbo.P1(Efternavn);

CREATE CLUSTERED INDEX NC_P2_PersonId ON dbo.P2(PersonId);
CREATE NONCLUSTERED INDEX NC_P2_Fornavn ON dbo.P2(Fornavn);
CREATE NONCLUSTERED INDEX NC_P2_Efternavn ON dbo.P2(Efternavn);
GO
DECLARE @Fornavn1		NVARCHAR(20) = N'Ole';
DECLARE @Efternavn1		NVARCHAR(20) = N'Olsen';

SELECT *
	FROM dbo.P1
	WHERE	Fornavn = @Fornavn1 AND
			Efternavn = @Efternavn1;
GO
DECLARE @Fornavn2		VARCHAR(20) = 'Ole';
DECLARE @Efternavn2		VARCHAR(20) = 'Olsen';

SELECT *
	FROM dbo.P1
	WHERE	Fornavn = @Fornavn2 AND
			Efternavn = @Efternavn2;
GO
DECLARE @Fornavn1		NVARCHAR(20) = N'Ole';
DECLARE @Efternavn1		NVARCHAR(20) = N'Olsen';

SELECT *
	FROM dbo.P2
	WHERE	Fornavn = @Fornavn1 AND
			Efternavn = @Efternavn1;
GO
DECLARE @Fornavn2		VARCHAR(20) = 'Ole';
DECLARE @Efternavn2		VARCHAR(20) = 'Olsen';

SELECT *
	FROM dbo.P2
	WHERE	Fornavn = @Fornavn2 AND
			Efternavn = @Efternavn2;
