USE IndexDB;
GO
DROP INDEX IF EXISTS NC_Person_MissingIndexProposal1 ON dbo.Person;
DROP INDEX IF EXISTS NC_Person_MissingIndexProposal2 ON dbo.Person;
GO
SELECT	Person.PersonID,
		Person.Navn,
		Person.Gade,
		Person.Postnr,
		Postopl.Bynavn,
		Koen.Koentext
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					INNER JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
GO
SELECT	DISTINCT
		Person.PersonID,
		Person.Navn,
		Person.Gade,
		Person.Postnr,
		Postopl.Bynavn,
		Koen.Koentext
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					INNER JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
GO
SELECT	Person.PersonID,
		Person.Navn,
		Person.Gade,
		Person.Postnr,
		Postopl.Bynavn,
		Koen.Koentext
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					LEFT JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
GO
SELECT	DISTINCT
		Person.PersonID,
		Person.Navn,
		Person.Gade,
		Person.Postnr,
		Postopl.Bynavn,
		Koen.Koentext
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					LEFT JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
GO
CREATE NONCLUSTERED INDEX NC_Person_MissingIndexProposal1
	ON dbo.Person (Postnr) INCLUDE (Gade, Koenkode, Navn);
GO
CREATE NONCLUSTERED INDEX NC_Person_MissingIndexProposal2
	ON dbo.Person (Koenkode) INCLUDE (Gade, Postnr, Navn);
GO
SELECT	Person.PersonID,
		Person.Navn,
		Person.Gade,
		Person.Postnr,
		Postopl.Bynavn,
		Koen.Koentext
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					INNER JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
GO
SELECT	DISTINCT
		Person.PersonID,
		Person.Navn,
		Person.Gade,
		Person.Postnr,
		Postopl.Bynavn,
		Koen.Koentext
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					INNER JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
GO

SELECT	Person.PersonID,
		Person.Navn,
		Person.Gade,
		Person.Postnr,
		Postopl.Bynavn,
		Koen.Koentext
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					LEFT JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
GO
SELECT	DISTINCT
		Person.PersonID,
		Person.Navn,
		Person.Gade,
		Person.Postnr,
		Postopl.Bynavn,
		Koen.Koentext
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					LEFT JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
GO
DROP INDEX IF EXISTS NC_Person_MissingIndexProposal1 ON dbo.Person;
DROP INDEX IF EXISTS NC_Person_MissingIndexProposal2 ON dbo.Person;
GO
CREATE UNIQUE NONCLUSTERED INDEX NC_Person_MissingIndexProposal1
	ON dbo.Person (Postnr, PersonId) INCLUDE (Gade, Koenkode, Navn);
GO
CREATE UNIQUE NONCLUSTERED INDEX NC_Person_MissingIndexProposal2
	ON dbo.Person (Koenkode, PersonId) INCLUDE (Gade, Postnr, Navn);
GO
SELECT	Person.PersonID,
		Person.Navn,
		Person.Gade,
		Person.Postnr,
		Postopl.Bynavn,
		Koen.Koentext
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					INNER JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
GO
SELECT	DISTINCT
		Person.PersonID,
		Person.Navn,
		Person.Gade,
		Person.Postnr,
		Postopl.Bynavn,
		Koen.Koentext
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					INNER JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
GO

SELECT	Person.PersonID,
		Person.Navn,
		Person.Gade,
		Person.Postnr,
		Postopl.Bynavn,
		Koen.Koentext
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					LEFT JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
GO
SELECT	DISTINCT
		Person.PersonID,
		Person.Navn,
		Person.Gade,
		Person.Postnr,
		Postopl.Bynavn,
		Koen.Koentext
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					LEFT JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
GO
