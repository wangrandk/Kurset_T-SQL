USE master;
DROP DATABASE UnionDB;
GO
CREATE DATABASE UnionDB;
GO
USE UnionDB;
CREATE TABLE dbo.Kunde 
(
	KundeId			INT			NOT NULL PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT	NOT NULL,
	Tlfnr			VARCHAR(8)	NOT NULL
);

CREATE TABLE dbo.Leverandor 
(
	LeverandorId	INT			NOT NULL PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT	NOT NULL,
	Tlfnr			VARCHAR(8)	NOT NULL
);
GO
INSERT INTO dbo.Kunde VALUES 
	(1, 'Jens Hansen', 'Nygade 2', 8000, '12345678'),
	(2, 'Peter Olesen', 'Vestergade 23', 9000, '98765432'),
	(3, 'Ida Hansen', 'Torvet 8', 8000, '11223344'),
	(4, 'Sanne Carlsen', 'S�ndergade 33', 2000, '99887766'),
	(5, 'Finn Poulsen', 'Poulsgade 62', 7000, '11114444');

INSERT INTO dbo.Leverandor VALUES 
	(1, 'Ida Hansen', 'Torvet 8', 8000, '11223344'),
	(2, 'Sanne Carlsen', 'S�ndergade 33 2. tv.', 2000, '99887766'),
	(3, 'Finn Poulsen', 'Poulsgade 62', 7000, '11114444'),
	(4, 'Slagteren', '�stergade 3', 4000, '66662222'),
	(5, 'Bageren', 'Nygade 17', 5000, '88884444');
GO
SELECT *
	FROM dbo.Kunde
UNION
SELECT *
	FROM dbo.Leverandor;
GO
SELECT Navn, Adresse, Postnr, Tlfnr
	FROM dbo.Kunde
UNION
SELECT Navn, Adresse, Postnr, Tlfnr
	FROM dbo.Leverandor;
GO
SELECT *
	FROM dbo.Kunde
	WHERE NOT EXISTS (
		SELECT *
			FROM dbo.Leverandor
			WHERE Kunde.Tlfnr = Leverandor.Tlfnr)
UNION ALL
SELECT *
	FROM dbo.Leverandor;
GO
SELECT	KL_Tlfnr.Tlfnr, 
		ISNULL(Kunde.Navn, Leverandor.Navn) AS Navn,
		ISNULL(Kunde.Adresse, Leverandor.Adresse) AS Adresse,
		ISNULL(Kunde.Postnr, Leverandor.Postnr) AS Postnr
	FROM (SELECT Tlfnr
			FROM dbo.Kunde
		  UNION 
		  SELECT Tlfnr
			FROM dbo.Leverandor) AS KL_Tlfnr
	LEFT JOIN dbo.Kunde ON KL_Tlfnr.Tlfnr = Kunde.Tlfnr
	LEFT JOIN dbo.Leverandor ON KL_Tlfnr.Tlfnr = Leverandor.Tlfnr;
GO
USE master;
DROP DATABASE UnionDB;
GO
CREATE DATABASE UnionDB
ON PRIMARY
	( NAME = UnionDB_file_1,
	  FILENAME = 'C:\Databaser\UnionDB_p.mdf',
      SIZE = 1000MB,
      MAXSIZE = 2000MB,
      FILEGROWTH = 10%)
LOG ON
	( NAME = UnionDB_log_file_1,
	  FILENAME = 'C:\Databaser\UnionDB_log_1.ldf',
      SIZE = 1000MB,
      MAXSIZE = 2000MB,
      FILEGROWTH = 10%);
GO
USE UnionDB
CREATE TABLE dbo.Person1 
(
	ID			INT			NOT NULL PRIMARY KEY IDENTITY,
	Data		CHAR(200)	NOT NULL DEFAULT (REPLICATE('x', 200)),
	Postnr		SMALLINT	NOT NULL
)
	
CREATE TABLE dbo.Person2 
(
	ID			INT			NOT NULL PRIMARY KEY IDENTITY,
	Data		CHAR(200)	NOT NULL DEFAULT (REPLICATE('x', 200)),
	Postnr		SMALLINT	NOT NULL
);
GO
SET NOCOUNT ON;
DECLARE @i		INT = 1;

WHILE @i < 10000
BEGIN
	INSERT INTO dbo.Person1(Postnr) VALUES(1234 + @i % 2000);
	INSERT INTO dbo.Person1(Postnr) VALUES(1234 + @i % 3000);
	INSERT INTO dbo.Person1(Postnr) VALUES(1234 + @i % 4000);
	INSERT INTO dbo.Person1(Postnr) VALUES(1234 + @i % 5000);

	INSERT INTO dbo.Person2(Postnr) VALUES(1234 + @i % 2000);
	INSERT INTO dbo.Person2(Postnr) VALUES(1234 + @i % 4000);
	INSERT INTO dbo.Person2(Postnr) VALUES(1234 + @i % 6000);

	SET @i += 1;
END;

SET @i = 1;

WHILE @i < 4
BEGIN
	INSERT INTO dbo.Person1(Postnr)
		SELECT Postnr
			FROM dbo.Person1;

	INSERT INTO dbo.Person2(Postnr)
		SELECT Postnr
			FROM dbo.Person2;

	SET @i += 1;
END
INSERT INTO dbo.Person2(Postnr)
	SELECT Postnr
		FROM dbo.Person2;

INSERT INTO dbo.Person2(Postnr)
	SELECT Postnr
		FROM dbo.Person2;

SET NOCOUNT OFF;

SELECT COUNT(*)
	FROM dbo.Person1;

SELECT COUNT(*)
	FROM dbo.Person2;
GO
SET STATISTICS TIME ON;
DBCC DROPCLEANBUFFERS;
SELECT Postnr 
	FROM dbo.Person1
UNION
SELECT Postnr 
	FROM dbo.Person2;

DBCC DROPCLEANBUFFERS;
SELECT DISTINCT Postnr 
	FROM dbo.Person1
UNION
SELECT DISTINCT Postnr 
	FROM dbo.Person2;

SET STATISTICS TIME OFF;
GO
CREATE INDEX nc_Person1_Postnr ON dbo.Person1(Postnr);
CREATE INDEX nc_Person2_Postnr ON dbo.Person2(Postnr);
GO
SET STATISTICS TIME ON;

DBCC DROPCLEANBUFFERS;
SELECT Postnr 
	FROM dbo.Person1
UNION
SELECT Postnr 
	FROM dbo.Person2;

DBCC DROPCLEANBUFFERS;
SELECT DISTINCT Postnr 
	FROM dbo.Person1
UNION
SELECT DISTINCT Postnr 
	FROM dbo.Person2;

SET STATISTICS TIME OFF;

