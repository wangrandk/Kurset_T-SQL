USE master;
GO
DROP DATABASE DivideDB;
GO
CREATE DATABASE DivideDB;
GO
USE DivideDB;
CREATE TABLE dbo.Eksamen
(
	EksamensId			INT				NOT NULL
						CONSTRAINT PK_Eksamen PRIMARY KEY,
	EksamensTekst		VARCHAR(50)		NOT NULL,
	KursusID			SMALLINT		NOT NULL
						CONSTRAINT UQ_Eksamen_KursusId UNIQUE
);

CREATE TABLE dbo.MSCertificering
(
	CertificeringsId	INT				NOT NULL
						CONSTRAINT PK_MSCertificering PRIMARY KEY,
	CertificeringsType	VARCHAR(5)	NOT NULL,
	CertificeringsTekst	VARCHAR(50) NOT NULL
);

CREATE TABLE dbo.MSCertificeringEksamen
(
	CertificeringsId	INT				NOT NULL,
	EksamensId			INT				NOT NULL,
	CONSTRAINT PK_MSCertificeringEksamen PRIMARY KEY (CertificeringsId, EksamensId)
);
GO
INSERT INTO dbo.Eksamen VALUES
	(1, 'Querying Data with Transact-SQL', 761),
	(2, 'Developing SQL Database', 762),
	(3, 'Administring a SQL Database Infrastructure', 764),
	(4, 'Provisioning SQL Databases', 765),
	(5, 'Implementing a Data Warehouse', 767),
	(6, 'Developing SQL Data Models', 768);

INSERT INTO dbo.MSCertificering VALUES
	(1, 'MCSA', 'SQL 2016 Database Development'),
	(2, 'MCSA', 'SQL 2016 Database Administration'),
	(3, 'MCSA', 'SQL 2016 Business Intelligence Development'),
	(4, 'MCSE', 'Data Platform');

INSERT INTO dbo.MSCertificeringEksamen VALUES
	(1, 1),
	(1, 2),
	(2, 3),
	(2, 4),
	(3, 5),
	(3, 6),
	(4, 1),
	(4, 3),
	(4, 5),
	(4, 2),
	(4, 4);
GO
CREATE TABLE dbo.Person
(
	PersonId			INT				NOT NULL
						IDENTITY
						CONSTRAINT PK_Person PRIMARY KEY,
	Personnavn			VARCHAR(30)		NOT NULL
);

CREATE TABLE dbo.PersonEksamen
(
	PersonId			INT				NOT NULL,
	EksamensId			INT				NOT NULL,
	CONSTRAINT PK_PersonEksamenn PRIMARY KEY (PersonId, EksamensId)
);	
GO
INSERT INTO dbo.Person (Personnavn) VALUES
	('Anne'),	
	('Ann'),
	('Allan'),
	('Alexander'),
	('Anni'),
	('Annemette'),
	('Anne Mette'),
	('Anne Marie'),
	('Allan'),
	('Annette'),
	('Andreas'),
	('August'),
	('Arne'),
	('Andreas'),
	('Asger'),
	('Allan'),
	('Anneline'),
	('Albert'),
	('Augusta'),
	('Andrea'),
	('Bo'),
	('Birte'),
	('Birthe'),
	('Bente'),
	('Bettina'),
	('Bjarke'),
	('Bent'),
	('B�rge'),
	('Bjarne'),
	('Brian'),
	('Bruno'),
	('Benno'),
	('Carl'),
	('Carina'),
	('Carla'),
	('Claus'),
	('Claes'),
	('Curt'),
	('Christa'),
	('Christian'),
	('Charlotte'),
	('Christina'),
	('Dorte'),
	('Dorthe'),
	('David'),
	('Daniel'),
	('Doris'),
	('Dan'),
	('Dagmar'),
	('Dagny'),
	('Dennis'),
	('Ditte'),
	('Diana'),
	('Erik'),
	('Eva'),
	('Emma'),
	('Ebba'),
	('Ebbe'),
	('Ellen'),
	('Edvard'),
	('Edward'),
	('Egon'),
	('Esben'),
	('Elisabeth'),
	('Egil'),
	('Esther'),
	('Frank'),
	('Frederikke'),
	('Flemming'),
	('Frede'),
	('Frode'),
	('Frida'),
	('Finn'),
	('Frank'),
	('Franz'),
	('Grete'),
	('Gitte'),
	('Grethe'),
	('Gert'),
	('Gerd'),
	('Gunnar'),
	('Gustav'),
	('Gudrun'),
	('Gorm'),
	('Gerner'),
	('Henrik'),
	('Hans'),
	('Hans Erik'),
	('Hans Ole'),
	('Hanne'),
	('Henriette'),
	('Hedvig'),
	('Henning'),
	('Helen'),
	('Helmer'),
	('Henry'),
	('Hugo'),
	('Ib'),
	('Ida'),
	('Ilse'),
	('Ivar'),
	('Ivan'),
	('Iben'),
	('Inger'),
	('Inge'),
	('Irene'),
	('Jens'),
	('Jens Erik'),
	('Jens Ole'),
	('Jens Peter'),
	('Jakob'),
	('Jacob'),
	('Jesper'),
	('Jonna'),
	('Jesper'),
	('Jette'),
	('J�rgen'),
	('J�rn'),
	('Jenny'),
	('Jytte'),
	('Jane'),
	('Karl'),
	('Karen'),
	('Karin'),
	('Karine'),
	('Karina'),
	('Kamilla'),
	('Kathrine'),
	('Kis'),
	('Karina'),
	('Kristina'),
	('Kristine'),
	('Karsten'),
	('Kurt'),
	('Klaus'),
	('Kasper'),
	('Keld'),
	('Kaj'),
	('Knud'),
	('Kenneth'),
	('Lars'),
	('Lars Ole'),
	('Lars Bo'),
	('Ludvig'),
	('Line'),
	('Lone'),
	('Lise'),
	('Lotte'),
	('Lisette'),
	('Lene'),
	('Lisbet'),
	('Lena'),
	('Lisbeth'),
	('Laura'),
	('Liselotte'),
	('Lise Lotte'),
	('Morten'),
	('Marie'),
	('Mads'),
	('Maren'),
	('Malene'),
	('Mette'),
	('Michael'),
	('Mikael'),
	('Niels'),
	('Niels'),	
	('Nils'),
	('Nicolaj'),
	('Nikolaj'),
	('Nadia'),
	('Naja'),
	('Nina'),
	('Ninna'),
	('Nette'),
	('Nanna'),
	('Ole'),
	('Oda'),
	('Olivia'),
	('Oskar'),
	('Otto'),
	('Ove'),
	('Peter'),
	('Per'),
	('Petrea'),
	('Peder'),
	('Pil'),
	('Povl'),
	('Pia'),
	('Paul'),
	('Preben'),
	('Poula'),
	('Rasmus'),
	('Rie'),
	('Rikke'),
	('Richard'),
	('Rune'),
	('Rene'),
	('Ruth'),
	('Rosa'),
	('Robert'),
	('Rasmus'),
	('Rie'),
	('Ronald'),
	('Rositta'),
	('Randi'),
	('Rikard'),
	('S�ren'),
	('Sys'),
	('Sara'),
	('Simone'),
	('Susanne'),
	('Sanne'),
	('Stig'),
	('Stine'),
	('Sofus'),
	('Solvej'),
	('Signe'),
	('Thomas'),
	('Tove'),
	('Tommy'),
	('Tanja'),
	('Tone'),
	('Tom'),
	('Trine'),
	('Tine'),
	('Tina'),
	('Tobias'),
	('Uffe'),
	('Ulla'),
	('Ulrik'),
	('Ursula'),
	('Ulrika'),
	('Nadia'),
	('Ulf'),
	('Vera'),
	('Villy'),
	('Vagn'),
	('Vibeke'),
	('Vivi'),
	('Vagn'),
	('Willy'),
	('Winnie'),
	('Wolfgang'),
	('Walter'),
	('Yrsa'),
	('Yvonne'),
	('�jvind'),
	('�ge'),
	('�se');
GO
INSERT INTO dbo.PersonEksamen
	SELECT	Person.PersonId,
			Eksamen.EksamensId
		FROM dbo.Person CROSS JOIN dbo.Eksamen 
		WHERE Person.PersonId % (DATEPART(MILLISECOND, SYSDATETIME()) % 177) + 1 = 56;

INSERT INTO dbo.PersonEksamen
	SELECT	Person.PersonId,
			Eksamen.EksamensId
		FROM dbo.Person INNER JOIN dbo.Eksamen 
			ON Eksamen.EksamensId = (Person.PersonId % (SELECT MAX(EksamensId) FROM dbo.Eksamen)) + 1
		WHERE NOT EXISTS (
					SELECT *
						FROM dbo.PersonEksamen
						WHERE	PersonEksamen.PersonId = Person.PersonId AND
								PersonEksamen.EksamensId = Eksamen.EksamensId);

DELETE 
	FROM dbo.PersonEksamen
	WHERE (PersonId * EksamensId) % 156 = (DATEPART(MILLISECOND, SYSDATETIME())) % 247;

INSERT INTO dbo.PersonEksamen
	SELECT	Person.PersonId,
			Eksamen.EksamensId
		FROM dbo.Person INNER JOIN dbo.Eksamen 
			ON	Eksamen.EksamensId > (Person.PersonId % (SELECT MAX(EksamensId) FROM dbo.Eksamen)) + 1 AND
				Eksamen.EksamensId % (DATEPART(MILLISECOND, SYSDATETIME())) = 3
		WHERE NOT EXISTS (
					SELECT *
						FROM dbo.PersonEksamen
						WHERE	PersonEksamen.PersonId = Person.PersonId AND
								PersonEksamen.EksamensId = Eksamen.EksamensId);

INSERT INTO dbo.PersonEksamen
	SELECT	Person.PersonId,
			Eksamen.EksamensId
		FROM dbo.Person INNER JOIN dbo.Eksamen 
			ON	Eksamen.EksamensId > (Person.PersonId % (SELECT MAX(EksamensId) FROM dbo.Eksamen)) + 1 AND
				Eksamen.EksamensId % (DATEPART(MILLISECOND, SYSDATETIME())) = 5
		WHERE NOT EXISTS (
					SELECT *
						FROM dbo.PersonEksamen
						WHERE	PersonEksamen.PersonId = Person.PersonId AND
								PersonEksamen.EksamensId = Eksamen.EksamensId);
GO
SELECT *
	FROM dbo.PersonEksamen
	ORDER BY PersonId, EksamensId;

SELECT PersonId AS PersonMedAlleEksaminer
	FROM dbo.PersonEksamen
	GROUP BY PersonId
	HAVING COUNT(*) = (SELECT COUNT(*) FROM dbo.Eksamen)
GO
SELECT	PersonId AS PersonMedAlleEksaminer,
		Person.Personnavn
	FROM dbo.Person
	WHERE NOT EXISTS (
		SELECT *
			FROM dbo.Eksamen
			WHERE NOT EXISTS (
				SELECT *
					FROM dbo.PersonEksamen
					WHERE PersonEksamen.PersonId = Person.PersonId AND
						  PersonEksamen.EksamensId = Eksamen.EksamensId));
GO
SELECT	PersonId AS PersonMedAlleEksaminer,
		Person.Personnavn
	FROM dbo.Person
	WHERE NOT EXISTS (
		SELECT *
			FROM dbo.MSCertificeringEksamen INNER JOIN dbo.MSCertificering 
				ON MSCertificeringEksamen.CertificeringsId = MSCertificering.CertificeringsId					
			WHERE	MSCertificering.CertificeringsTekst = 'Data Platform' AND
					NOT EXISTS (
				SELECT *
					FROM dbo.PersonEksamen
					WHERE PersonEksamen.PersonId = Person.PersonId AND
						  PersonEksamen.EksamensId = MSCertificeringEksamen.EksamensId));
GO
SELECT	PersonId AS PersonMedAlleEksaminer,
		Person.Personnavn
	FROM dbo.Person
	WHERE NOT EXISTS (
		SELECT *
			FROM dbo.MSCertificeringEksamen INNER JOIN dbo.MSCertificering 
				ON MSCertificeringEksamen.CertificeringsId = MSCertificering.CertificeringsId					
			WHERE	MSCertificering.CertificeringsTekst = 'SQL 2016 Business Intelligence Development' AND
					NOT EXISTS (
				SELECT *
					FROM dbo.PersonEksamen
					WHERE PersonEksamen.PersonId = Person.PersonId AND
						  PersonEksamen.EksamensId = MSCertificeringEksamen.EksamensId));
GO
SELECT *
	FROM dbo.PersonEksamen;

SELECT	PersonId AS PersonMedAlleEksaminer,
		Person.Personnavn
	FROM dbo.Person
	WHERE NOT EXISTS (
		SELECT *
			FROM dbo.Eksamen
			WHERE	EksamensId IN (2, 3, 5) AND
					NOT EXISTS (
				SELECT *
					FROM dbo.PersonEksamen
					WHERE PersonEksamen.PersonId = Person.PersonId AND
						  PersonEksamen.EksamensId = Eksamen.EksamensId));
