USE IndexDB;
GO
DROP TABLE dbo.PersonBiggerDT;
GO
SELECT	PersonId,
		CAST(Fornavn AS NVARCHAR(20)) AS Fornavn,
		CAST(Efternavn AS NVARCHAR(20)) AS Efternavn,
		CAST(Postnr AS INT) AS Postnr
	INTO dbo.PersonBiggerDT
	FROM dbo.Person;
GO
CREATE UNIQUE CLUSTERED INDEX cl_PersonBiggerDT ON dbo.PersonBiggerDT(PersonId);
CREATE NONCLUSTERED INDEX nc_PersonBiggerDT_Fornavn_3 
	ON dbo.PersonBiggerDT (Fornavn) INCLUDE (Efternavn);

CREATE NONCLUSTERED INDEX nc_PersonBiggerDT_Postnr_3 
	ON dbo.PersonBiggerDT (Postnr) INCLUDE (Efternavn);

CREATE NONCLUSTERED INDEX nc_Person_Fornavn_3 
	ON dbo.Person (Fornavn) INCLUDE (Efternavn);

CREATE NONCLUSTERED INDEX nc_Person_Postnr_3 
	ON dbo.Person (Postnr) INCLUDE (Efternavn);
GO
SELECT COUNT(*)
	FROM dbo.PersonBiggerDT
	WHERE Fornavn = 'Ole';

SELECT COUNT(*)
	FROM dbo.PersonBiggerDT
	WHERE Fornavn = N'Ole';
GO
SELECT	Fornavn,
		Efternavn
	FROM dbo.PersonBiggerDT
	WHERE Fornavn = 'Ole';

SELECT	Fornavn,
		Efternavn
	FROM dbo.PersonBiggerDT
	WHERE Fornavn = N'Ole';
GO
DECLARE @Fornavn1		VARCHAR(20) = 'Ole';
DECLARE @Fornavn2		NVARCHAR(20) = 'Ole';

SELECT	Fornavn,
		Efternavn
	FROM dbo.PersonBiggerDT
	WHERE Fornavn = @Fornavn1;

SELECT	Fornavn,
		Efternavn
	FROM dbo.PersonBiggerDT
	WHERE Fornavn = @Fornavn2;
GO
SET STATISTICS IO, TIME ON;
DECLARE @Fornavn1		VARCHAR(20) = 'Ole';
DECLARE @Fornavn2		NVARCHAR(20) = 'Ole';

SELECT	Fornavn,
		Efternavn
	FROM dbo.Person
	WHERE Fornavn = @Fornavn1;

SELECT	Fornavn,
		Efternavn
	FROM dbo.Person
	WHERE Fornavn = @Fornavn2;
SET STATISTICS IO, TIME OFF;
GO
DECLARE @Postnr1		SMALLINT = 2000;
DECLARE @Postnr2		INT = 2000;

SELECT	Postnr,
		Efternavn
	FROM dbo.PersonBiggerDT
	WHERE Postnr = @Postnr1;

SELECT	Postnr,
		Efternavn
	FROM dbo.PersonBiggerDT
	WHERE Postnr = @Postnr2;
GO
DECLARE @Postnr1		SMALLINT = 2000;
DECLARE @Postnr2		INT = 2000;

SELECT	Postnr,
		Efternavn
	FROM dbo.Person
	WHERE Postnr = @Postnr1;

SELECT	Postnr,
		Efternavn
	FROM dbo.Person
	WHERE Postnr = @Postnr2;
