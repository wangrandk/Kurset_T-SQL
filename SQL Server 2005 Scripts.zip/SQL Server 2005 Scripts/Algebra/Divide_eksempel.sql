USE master;
DROP DATABASE AlgebraDB;
GO
CREATE DATABASE AlgebraDB;
GO
USE AlgebraDB;
GO
CREATE TABLE dbo.Vare 
(
	VareId		    INT			NOT NULL PRIMARY KEY,
	VareNavn		VARCHAR(30) NOT NULL,
	VareGruppe	    SMALLINT	NOT NULL
);

CREATE TABLE dbo.Ordre 
(
	OrdreId		    INT			NOT NULL PRIMARY KEY,
	LeveringsDato	DATETIME2	NOT NULL DEFAULT (SYSDATETIME())
);

CREATE TABLE dbo.OrdreLinie 
(
	OrdreId			INT			NOT NULL
					CONSTRAINT FK_Ordre_OrdreLinie 
					FOREIGN KEY REFERENCES dbo.Ordre,
	VareId			INT			NOT NULL 
					CONSTRAINT FK_Vare_OrdreLinie 
					FOREIGN KEY REFERENCES dbo.Vare,
	AntalEnheder	INT			NOT NULL,

	CONSTRAINT PK_OrdreLinie PRIMARY KEY (OrdreId, VareId)
);

CREATE TABLE dbo.VareDivide 
(
		VareId		INT			NOT NULL PRIMARY KEY
					CONSTRAINT FK_Vare_VareDivide 
					FOREIGN KEY REFERENCES dbo.Vare
);
GO
INSERT INTO dbo.Vare VALUES 
	(1, 'dbo.Vare1', 1),
	(2, 'dbo.Vare2', 1),
	(3, 'dbo.Vare3', 1),
	(4, 'dbo.Vare4', 2),
	(5, 'dbo.Vare5', 2);

INSERT INTO dbo.Ordre VALUES 
	(1, DATEADD(DAY, 4, SYSDATETIME())),
	(2, DATEADD(DAY, 2, SYSDATETIME())),
	(3, DATEADD(DAY, 7, SYSDATETIME())),
	(4, DATEADD(DAY, 1, SYSDATETIME()));

INSERT INTO dbo.OrdreLinie VALUES 
	(1, 2, 4)
INSERT INTO dbo.OrdreLinie VALUES 
	(1, 3, 1),
	(1, 5, 2),
	(2, 1, 4),
	(2, 2, 4),
	(2, 3, 4),
	(2, 4, 4),
	(3, 1, 4),
	(3, 2, 4),
	(3, 4, 4),
	(4, 5, 4);

INSERT INTO dbo.VareDivide VALUES 
	(1),
	(2),
	(4);
GO
SELECT DISTINCT OrdreId
	FROM dbo.OrdreLinie AS OL_Resultat
	WHERE NOT EXISTS (
		SELECT *
			FROM dbo.VareDivide 
			WHERE NOT EXISTS (
				SELECT *
					FROM dbo.OrdreLinie AS OL_Div
					WHERE OL_Div.OrdreId = OL_Resultat.OrdreId AND
						  OL_Div.VareId = dbo.VareDivide.VareId))

SELECT OrdreId
	FROM dbo.Ordre
	WHERE NOT EXISTS (
		SELECT *
			FROM dbo.VareDivide 
			WHERE NOT EXISTS (
				SELECT *
					FROM dbo.OrdreLinie
					WHERE dbo.OrdreLinie.OrdreId = dbo.Ordre.OrdreId AND
						  dbo.OrdreLinie.VareId = dbo.VareDivide.VareId))


SELECT dbo.OrdreLinie.OrdreId
	FROM dbo.OrdreLinie INNER JOIN dbo.VareDivide
		ON dbo.OrdreLinie.VareId = dbo.VareDivide.VareId
	GROUP BY dbo.OrdreLinie.OrdreId
	HAVING COUNT(*) = (SELECT COUNT(*) 
							FROM dbo.VareDivide)
GO
SELECT OrdreId
	FROM dbo.Ordre
	WHERE NOT EXISTS (
		SELECT *
			FROM dbo.VareDivide 
			WHERE NOT EXISTS (
				SELECT *
					FROM dbo.OrdreLinie
					WHERE dbo.OrdreLinie.OrdreId = dbo.Ordre.OrdreId AND
						  dbo.OrdreLinie.VareId = dbo.VareDivide.VareId)) AND
	NOT EXISTS (
		SELECT *
			FROM dbo.OrdreLinie
			WHERE dbo.Ordre.OrdreId = dbo.OrdreLinie.OrdreId AND
				  dbo.OrdreLinie.VareId NOT IN
						(SELECT VareId 
							FROM dbo.VareDivide))

SELECT dbo.OrdreLinie.OrdreId
	FROM dbo.OrdreLinie LEFT JOIN dbo.VareDivide
		ON dbo.OrdreLinie.VareId = dbo.VareDivide.VareId
	GROUP BY dbo.OrdreLinie.OrdreId
	HAVING COUNT(OrdreLinie.VareId) = (SELECT COUNT(*) 
											FROM dbo.VareDivide)

	 
SELECT OrdreId
	FROM dbo.Ordre
	WHERE NOT EXISTS (
		SELECT *
			FROM dbo.VareDivide 
			WHERE NOT EXISTS (
				SELECT *
					FROM dbo.OrdreLinie
					WHERE dbo.OrdreLinie.OrdreId = dbo.Ordre.OrdreId AND
						  dbo.OrdreLinie.VareId = dbo.VareDivide.VareId)) AND
	 EXISTS (
		SELECT *
			FROM dbo.OrdreLinie
			WHERE dbo.Ordre.OrdreId = dbo.OrdreLinie.OrdreId AND
				  dbo.OrdreLinie.VareId NOT IN
						(SELECT VareId 
							FROM dbo.VareDivide))
GO
SELECT OrdreId
	FROM dbo.Ordre
	WHERE NOT EXISTS (
		SELECT *
			FROM dbo.Vare
			WHERE VareGruppe = 1 AND 
				  NOT EXISTS (
				SELECT *
					FROM dbo.OrdreLinie
					WHERE dbo.OrdreLinie.OrdreId = dbo.Ordre.OrdreId AND
						  dbo.OrdreLinie.VareId = dbo.Vare.VareId))

SELECT OrdreId
	FROM dbo.Ordre
	WHERE NOT EXISTS (
		SELECT *
			FROM dbo.Vare
			WHERE VareId IN (1, 2, 4) AND 
				  NOT EXISTS (
				SELECT *
					FROM dbo.OrdreLinie
					WHERE dbo.OrdreLinie.OrdreId = dbo.Ordre.OrdreId AND
						  dbo.OrdreLinie.VareId = dbo.Vare.VareId))
GO
-- Division med den tomme m�ngde
SELECT OrdreId
	FROM dbo.Ordre
	WHERE NOT EXISTS (
		SELECT TOP 0 *
			FROM dbo.VareDivide 
			WHERE NOT EXISTS (
				SELECT *
					FROM dbo.OrdreLinie
					WHERE dbo.OrdreLinie.OrdreId = dbo.Ordre.OrdreId AND
						  dbo.OrdreLinie.VareId = dbo.VareDivide.VareId))

SELECT dbo.OrdreLinie.OrdreId	-- Virker ikke med den tomme m�ngde
	FROM dbo.OrdreLinie INNER JOIN (SELECT TOP 0 * 
										FROM dbo.VareDivide) AS VareDivide
		ON dbo.OrdreLinie.VareId = VareDivide.VareId
	GROUP BY dbo.OrdreLinie.OrdreId
	HAVING COUNT(*) = (SELECT COUNT(*) 
						FROM dbo.VareDivide)
