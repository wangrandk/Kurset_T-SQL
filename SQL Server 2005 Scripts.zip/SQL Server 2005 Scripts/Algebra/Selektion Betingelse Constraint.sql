USE master;
GO
DROP DATABASE BetingelsesDB;
GO
CREATE DATABASE BetingelsesDB;
ALTER DATABASE BetingelsesDB SET DELAYED_DURAdbo.BilITY = FORCED;
GO
USE BetingelsesDB;
CREATE TABLE dbo.t
(
	ID			INT NOT NULL IDENTITY
				CONSTRAINT PK_t PRIMARY KEY NONCLUSTERED,
	x1			INT NOT NULL,
	y1			INT NOT NULL,
	z1			INT NOT NULL,

	x2			INT NULL,
	y2			INT NULL,
	z2			INT NULL
);
GO
SET NOCOUNT ON;
DECLARE @Loop			SMALLINT = 1;

INSERT INTO dbo.t(x1, x2, y1, y2, z1, z2) VALUES
	(1, 1, 1, 1, 1, 1);

WHILE @Loop < 20
BEGIN
	INSERT INTO dbo.t(x1, x2, y1, y2, z1, z2)
		SELECT	x1 + 1, 
				x2 + 1, 
				y1 + 1, 
				y2 + 1, 
				z1 + 1, 
				z2 + 1
			FROM dbo.t;

	SET @Loop += 1;
END;

SELECT COUNT(*)
	FROM dbo.t;
GO
SELECT *
	FROM dbo.t
	WHERE	x1 > 0;

SELECT *
	FROM dbo.t
	WHERE	x2 > 0;

SELECT *
	FROM dbo.t
	WHERE	y1 > 0;

SELECT *
	FROM dbo.t
	WHERE	y2 > 0;

SELECT *
	FROM dbo.t
	WHERE	z1 > 0;

SELECT *
	FROM dbo.t
	WHERE	z2 > 0;

GO
ALTER TABLE dbo.t WITH CHECK
	ADD CONSTRAINT ck__t_x1 CHECK (x1 > 0);

ALTER TABLE dbo.t WITH CHECK
	ADD CONSTRAINT ck__t_x2 CHECK (x2 > 0);

ALTER TABLE dbo.t WITH NOCHECK
	ADD CONSTRAINT ck__t_y1 CHECK (y1 > 0);

ALTER TABLE dbo.t WITH NOCHECK
	ADD CONSTRAINT ck__t_y2 CHECK (y2 > 0);
GO
CREATE NONCLUSTERED INDEX nc_t_x1 ON dbo.t(x1);
CREATE NONCLUSTERED INDEX nc_t_x2 ON dbo.t(x2);
CREATE NONCLUSTERED INDEX nc_t_y1 ON dbo.t(y1);
CREATE NONCLUSTERED INDEX nc_t_y2 ON dbo.t(y2);
CREATE NONCLUSTERED INDEX nc_t_z1 ON dbo.t(z1);
CREATE NONCLUSTERED INDEX nc_t_z2 ON dbo.t(z2);
GO
DBCC FREEPROCCACHE;

SELECT *
	FROM dbo.t
	WHERE	ID BETWEEN 100 AND 220 AND
			x1 > 0;

SELECT *
	FROM dbo.t
	WHERE	ID BETWEEN 100 AND 220 AND
			x2 > 0;

SELECT *
	FROM dbo.t
	WHERE	ID BETWEEN 100 AND 220 AND
			y1 > 0;

SELECT *
	FROM dbo.t
	WHERE	ID BETWEEN 100 AND 220 AND
			y2 > 0;

SELECT *
	FROM dbo.t
	WHERE	ID BETWEEN 100 AND 220 AND
			z1 > 0;

SELECT *
	FROM dbo.t
	WHERE	ID BETWEEN 100 AND 220 AND
			z2 > 0;

