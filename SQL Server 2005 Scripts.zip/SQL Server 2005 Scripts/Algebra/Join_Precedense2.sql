USE master;
GO
DROP DATABASE JoinDB;
GO
CREATE DATABASE JoinDB;
GO
USE JoinDB;
GO
CREATE TABLE dbo.Postopl 
(
	Postnr			SMALLINT		NOT NULL PRIMARY KEY,
	Bynavn			VARCHAR(20)		NOT NULL
);

CREATE TABLE dbo.Kunde 
(
	Kundeid			INT				NOT NULL PRIMARY KEY,
	Navn			VARCHAR(30)		NOT NULL,
	Adresse			VARCHAR(40)		NULL,
	Postnr			SMALLINT		NULL REFERENCES dbo.Postopl
);

CREATE TABLE dbo.Ordre 
(
	Ordreid			INT				NOT NULL PRIMARY KEY,
	LeveringsDato	DATE			NOT NULL,
	Kundeid			INT				NULL REFERENCES dbo.Kunde
);

CREATE TABLE dbo.Vare
(
	VareId			INT				NOT NULL PRIMARY KEY IDENTITY,
	Varenavn		VARCHAR(30)		NOT NULL,
	Vejlpris		DECIMAL(9,2)	NOT NULL DEFAULT(0),
	AntalPaaLager	INT				NOT NULL DEFAULT(0)
);

CREATE TABLE dbo.OrdreLinie 
(
	Ordreid			INT				NOT NULL REFERENCES dbo.Ordre,
	VareId			INT				NOT NULL REFERENCES dbo.Vare,
	AntalEnheder	SMALLINT		NOT NULL,
	CONSTRAINT PK_OrdreLinie PRIMARY KEY (Ordreid, VareId)
);
GO
INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES 
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(5000, 'Odense C'),
	(4000, 'Roskilde');

INSERT INTO dbo.Kunde (Kundeid, Navn, Adresse, Postnr) VALUES 
	(1, 'Knud Olsen', 'Nygade 2', 2000),
	(2, 'Ane Jensen', 'Torvet 5', 2000),
	(3, 'Hans Knudsen', 'Strandvejen 125', 8000),
	(4, 'Ida S�rensen', NULL, NULL),
	(5, 'Per Hansen', NULL, NULL);
GO
INSERT INTO dbo.Kunde (Kundeid, Navn, Adresse, Postnr)
	SELECT	Kundeid + (SELECT MAX(KundeID) FROM dbo.Kunde), 
			Navn, 
			Adresse, 
			Postnr
		FROM dbo.Kunde
GO 10
INSERT INTO dbo.Ordre (Ordreid, LeveringsDato, Kundeid) VALUES 
	(11, DATEADD(DAY, 20, SYSDATETIME()), 1),
	(12, DATEADD(DAY, 5, SYSDATETIME()), 2),
	(13, DATEADD(DAY, 45, SYSDATETIME()), 1),
	(14, DATEADD(DAY, 17, SYSDATETIME()), 4)
	
INSERT INTO dbo.Ordre (Ordreid, LeveringsDato) VALUES 
	(15, SYSDATETIME());
GO
INSERT INTO dbo.Ordre (Ordreid, LeveringsDato, Kundeid)
	SELECT	Ordreid + (SELECT MAX(OrdreId) FROM dbo.Ordre), 
			LeveringsDato, 
			Kundeid + (SELECT MAX(KundeID) FROM dbo.Ordre)
		FROM dbo.Ordre;
GO 10
WITH dbo.Varedata
AS
(
SELECT	1 AS ID,
		'dbo.Varenavn' AS dbo.Varenavn,
		CAST(7.50 AS DECIMAL(9,2)) AS Vejlpris,
		CAST(42 AS SMALLINT) AS AntalPaaLager
UNION ALL
SELECT	ID + 1,
		dbo.Varenavn,
		CAST(((Vejlpris * ID) % 79) AS DECIMAL(9,2)),
		CAST((AntalPaaLager + ID * Vejlpris) % 12635 AS SMALLINT)
	FROM dbo.Varedata
	WHERE ID < 20000
)
INSERT INTO dbo.Vare(dbo.Varenavn, Vejlpris, AntalPaaLager)
	SELECT dbo.Varenavn, Vejlpris, AntalPaaLager
		FROM dbo.Varedata
	OPTION(MAXRECURSION 0);
GO
INSERT INTO dbo.OrdreLinie (Ordreid, VareId, AntalEnheder) VALUES 
	(11, 113, 2),
	(11, 119, 1),
	(12, 117, 2),
	(13, 131, 1),
	(13, 118, 5),
	(13, 112, 2),
	(14, 138, 1),
	(15, 122, 1);
GO
INSERT INTO dbo.OrdreLinie (Ordreid, VareId, AntalEnheder)
	SELECT	Ordreid + (SELECT MAX(OrdreId) FROM dbo.OrdreLinie), 
			((VareId + (SELECT MAX(VareId) FROM dbo.OrdreLinie)) % 20000) + 1, 
			AntalEnheder
		FROM dbo.OrdreLinie;
GO 10
SET STATISTICS TIME, IO ON;
SELECT *			
	FROM dbo.Postopl INNER JOIN dbo.Kunde ON Kunde.Postnr = Postopl.Postnr
					 INNER JOIN dbo.Ordre ON Kunde.KundeId = Ordre.KundeId
					 INNER JOIN dbo.OrdreLinie ON Ordre.OrdreId = OrdreLinie.OrdreId
					 INNER JOIN dbo.Vare ON dbo.Vare.VareId = OrdreLinie.VareId;

SELECT *			
	FROM dbo.Ordre	 INNER JOIN dbo.OrdreLinie ON Ordre.OrdreId = OrdreLinie.OrdreId
					 INNER JOIN dbo.Kunde ON Kunde.KundeId = Ordre.KundeId
					 INNER JOIN dbo.Vare ON dbo.Vare.VareId = OrdreLinie.VareId
					 INNER JOIN dbo.Postopl ON Kunde.Postnr = Postopl.Postnr;
SELECT *			
	FROM	(dbo.Ordre INNER JOIN dbo.OrdreLinie ON Ordre.OrdreId = OrdreLinie.OrdreId)
			INNER JOIN 
			(dbo.Postopl INNER JOIN dbo.Kunde ON Kunde.Postnr = Postopl.Postnr)
					ON Kunde.KundeId = Ordre.KundeId
			INNER JOIN dbo.Vare 
					ON dbo.Vare.VareId = OrdreLinie.VareId;
GO
SELECT *			
	FROM	(dbo.Ordre INNER JOIN dbo.OrdreLinie ON Ordre.OrdreId = OrdreLinie.OrdreId)
			LEFT JOIN 
			(dbo.Postopl RIGHT JOIN dbo.Kunde ON Kunde.Postnr = Postopl.Postnr)
					ON Kunde.KundeId = Ordre.KundeId
			INNER JOIN dbo.Vare 
					ON dbo.Vare.VareId = OrdreLinie.VareId;
GO
