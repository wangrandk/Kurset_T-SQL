USE master;
DROP DATABASE JoinDB;
GO
CREATE DATABASE JoinDB;
GO
USE JoinDB;
CREATE TABLE dbo.t1 
(
	Pk			INT		NOT NULL PRIMARY KEY
);

CREATE TABLE dbo.t2 (
	Pk			INT		NOT NULL PRIMARY KEY,
	Fk			INT		REFERENCES dbo.t1
);
GO
INSERT INTO dbo.t1 VALUES
	(1),
	(2),
	(3),
	(4);

INSERT INTO dbo.t2 VALUES 
	(1, 1),
	(2, 1),
	(3, 2),
	(4, 4),
	(5, 4);
GO
SELECT *
	FROM dbo.t1 LEFT JOIN dbo.t2 ON t1.Pk = t2.Fk
GO
SELECT *
	FROM dbo.t1 LEFT JOIN dbo.t2 ON 1 = 1
	WHERE t1.Pk = t2.Fk
GO
SELECT *
	FROM dbo.t1 INNER JOIN dbo.t2 ON t1.Pk = t2.Fk AND t2.Pk > 3 AND t1.PK < 2
GO
SELECT *
	FROM dbo.t1 LEFT JOIN dbo.t2 ON t1.Pk = t2.Fk AND t1.Pk = 1
GO
SELECT *
	FROM dbo.t1 LEFT JOIN dbo.t2 ON t1.Pk = t2.Fk 
	WHERE t1.Pk = 1
