USE master;
DROP DATABASE AlgebraDB;
GO
CREATE DATABASE AlgebraDB;
GO
USE AlgebraDB;
CREATE TABLE dbo.Ordre 
(
	OrdreId			INT NOT NULL PRIMARY KEY,
	OrdreVaerdi		INT NOT NULL
);

CREATE TABLE dbo.OrdreLinie 
(
	OrdreId			INT NOT NULL 
					FOREIGN KEY REFERENCES dbo.Ordre(OrdreId),
	VareId			INT NOT NULL,
	AntalEnheder	INT NOT NULL,
	EnhedsPris		INT NOT NULL,
	CONSTRAINT PK_OrdreLinie PRIMARY KEY (OrdreId, VareId)
);
GO
INSERT INTO dbo.Ordre VALUES 
	(1, 200),
	(2, 200),
	(3, 200),
	(4, 200);

INSERT INTO dbo.OrdreLinie VALUES 
	(1, 12, 2, 50),
	(1, 47, 4, 25),

	(2, 12, 2, 50),
	(2, 47, 3, 25),

	(3, 12, 2, 50),
	(3, 47, 5, 25),

	(4, 45, 8, 25);
GO
SELECT *
	FROM dbo.Ordre INNER JOIN dbo.OrdreLinie 
		ON Ordre.OrdreId = OrdreLinie.OrdreId AND
			Ordre.OrdreVaerdi <> (SELECT SUM(AntalEnheder * EnhedsPris)
									FROM dbo.OrdreLinie
									WHERE Ordre.OrdreId = OrdreLinie.OrdreId);