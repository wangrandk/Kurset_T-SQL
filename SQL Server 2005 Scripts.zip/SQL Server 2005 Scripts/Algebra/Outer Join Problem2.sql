USE master;
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB
CREATE TABLE dbo.t1 
(
	t1ID		INT			NOT NULL PRIMARY KEY,
	Data		VARCHAR(10) NOT NULL
);

CREATE TABLE dbo.t2 
(
	t2ID		INT			NOT NULL PRIMARY KEY,
	FraDato		DATE		NOT NULL,
	TilDato		DATE		NOT NULL,
	t1ID		INT			NOT NULL REFERENCES dbo.t1
);
GO
INSERT INTO dbo.t1 VALUES 
	(1, '1'),
	(2, '2'), 
	(3, '3')

INSERT INTO dbo.t2 VALUES
	(1, DATEADD(d, -9,SYSDATETIME()), DATEADD(d, -6, SYSDATETIME()), 1),
	(2, DATEADD(d, -3,SYSDATETIME()), DATEADD(d, 2, SYSDATETIME()), 1),
	(3, DATEADD(d, -8,SYSDATETIME()), DATEADD(d, -4, SYSDATETIME()), 2),
	(4, DATEADD(d, -2,SYSDATETIME()), DATEADD(d, 3, SYSDATETIME()), 2)
GO
SELECT *
	FROM dbo.t1

SELECT *
	FROM dbo.t2
GO
SELECT *
	FROM dbo.t1 LEFT JOIN dbo.t2 ON t1.t1ID = t2.t1ID
GO
SELECT *
	FROM dbo.t1 LEFT JOIN dbo.t2 ON t1.t1ID = t2.t1ID
	WHERE t1.t1ID = 3

SELECT *
	FROM dbo.t1 LEFT JOIN dbo.t2 ON t1.t1ID = t2.t1ID
	WHERE t2.t1ID = 3
GO
SELECT t1.t1ID, t1.Data, t2.t2ID, t2.FraDato, t2.TilDato
	FROM dbo.t1 LEFT JOIN dbo.t2 ON t1.t1ID = t2.t1ID
	WHERE	t1.t1ID = 3 AND
			SYSDATETIME() BETWEEN t2.FraDato AND t2.TilDato
GO
SELECT t1.t1ID, t1.Data, t2.t2ID, t2.FraDato, t2.TilDato
	FROM dbo.t1 LEFT JOIN dbo.t2 ON t1.t1ID = t2.t1ID
	WHERE	t1.t1ID = 3 AND
			(SYSDATETIME() BETWEEN t2.FraDato AND t2.TilDato OR t2.FraDato IS NULL OR t2.TilDato IS NULL)
GO
SELECT *
	FROM
	(SELECT t1.t1ID, t1.Data, t2.t2ID, t2.FraDato, t2.TilDato
		FROM dbo.t1 LEFT JOIN dbo.t2 ON t1.t1ID = t2.t1ID
		WHERE	t1.t1ID = 3) AS t
	WHERE SYSDATETIME() BETWEEN t.FraDato AND t.TilDato
GO
SELECT *
	FROM
	(SELECT t1.t1ID, t1.Data, t2.t2ID, t2.FraDato, t2.TilDato
		FROM dbo.t1 LEFT JOIN dbo.t2 ON t1.t1ID = t2.t1ID
		WHERE	t1.t1ID = 3) AS t
	WHERE SYSDATETIME() BETWEEN t.FraDato AND t.TilDato OR t.FraDato IS NULL OR t.TilDato IS NULL
