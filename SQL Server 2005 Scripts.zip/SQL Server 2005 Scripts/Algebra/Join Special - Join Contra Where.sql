USE master;
DROP DATABASE JoinDB;
GO
CREATE DATABASE JoinDB;
GO
USE JoinDB;
CREATE TABLE dbo.ProcessTid 
(
		ID			INT			NOT NULL IDENTITY PRIMARY KEY,
		ProcessID	INT			NOT NULL,
		StartSlut	VARCHAR(5)	NOT NULL,
		Tid			DATETIME2	NOT NULL
);
GO
INSERT INTO dbo.ProcessTid (ProcessID, StartSlut, Tid)VALUES
	(1, 'Start', DATEADD(MI, -20, SYSDATETIME())),
	(2, 'Start', DATEADD(MI, -18, SYSDATETIME())),
	(3, 'Start', DATEADD(MI, -17, SYSDATETIME())),
	(1, 'Slut', DATEADD(MI, -14, SYSDATETIME())),
	(3, 'Slut', DATEADD(MI, -11, SYSDATETIME())),
	(2, 'Slut', DATEADD(MI, -10, SYSDATETIME()));	
GO
SELECT PStart.ProcessID, PStart.Tid AS StartTid, PSlut.Tid AS SlutTid
	FROM dbo.ProcessTid AS PStart INNER JOIN dbo.ProcessTid AS PSlut
			ON PStart.StartSlut = 'Start' AND
				PSlut.StartSlut = 'Slut' AND
				PStart.ProcessID = PSlut.ProcessID
	WHERE PStart.StartSlut = 'Start';
GO
SELECT PStart.ProcessID, PStart.Tid AS StartTid, PSlut.Tid AS SlutTid
	FROM (SELECT ProcessID, Tid
			FROM  dbo.ProcessTid 
			WHERE StartSlut = 'Start') AS PStart 
		 INNER JOIN 
		 (SELECT ProcessID, Tid
			FROM  dbo.ProcessTid 
			WHERE StartSlut = 'Slut')AS PSlut
		ON PStart.ProcessID = PSlut.ProcessID;
GO
SELECT PStart.ProcessID, PStart.Tid AS StartTid, PSlut.Tid AS SlutTid
	FROM dbo.ProcessTid AS PStart INNER JOIN dbo.ProcessTid AS PSlut
			ON PStart.ProcessID = PSlut.ProcessID
	WHERE PStart.StartSlut = 'Start' AND
		  PSlut.StartSlut = 'Slut';
GO
INSERT INTO dbo.ProcessTid (ProcessID, StartSlut, Tid)VALUES
	(4, 'Start', DATEADD(MI, -9, SYSDATETIME()));
GO
SELECT PStart.ProcessID, PStart.Tid AS StartTid, PSlut.Tid AS SlutTid
	FROM dbo.ProcessTid AS PStart LEFT JOIN dbo.ProcessTid AS PSlut
			ON PStart.StartSlut = 'Start' AND
				PSlut.StartSlut = 'Slut' AND
				PStart.ProcessID = PSlut.ProcessID
	WHERE PStart.StartSlut = 'Start';
GO
SELECT PStart.ProcessID, PStart.Tid AS StartTid, PSlut.Tid AS SlutTid
	FROM (SELECT ProcessID, Tid
			FROM  dbo.ProcessTid 
			WHERE StartSlut = 'Start') AS PStart 
		 LEFT JOIN 
		 (SELECT ProcessID, Tid
			FROM  dbo.ProcessTid 
			WHERE StartSlut = 'Slut')AS PSlut
		ON PStart.ProcessID = PSlut.ProcessID;
GO
SELECT PStart.ProcessID, PStart.Tid AS StartTid, PSlut.Tid AS SlutTid
	FROM dbo.ProcessTid AS PStart LEFT JOIN dbo.ProcessTid AS PSlut
			ON PStart.ProcessID = PSlut.ProcessID
	WHERE PStart.StartSlut = 'Start' AND
		  PSlut.StartSlut = 'Slut';
GO
SELECT PStart.ProcessID, PStart.Tid AS StartTid, PSlut.Tid AS SlutTid
	FROM dbo.ProcessTid AS PStart LEFT JOIN dbo.ProcessTid AS PSlut
			ON PStart.ProcessID = PSlut.ProcessID AND PStart.ID <> PSlut.ID
	WHERE PStart.StartSlut = 'Start' AND
		  (PSlut.StartSlut = 'Slut' OR PSlut.StartSlut IS NULL);
GO
INSERT INTO dbo.ProcessTid (ProcessID, StartSlut, Tid)VALUES
	(5, 'Slut', DATEADD(MI, -2, SYSDATETIME()))
GO
SELECT PStart.ProcessID, PStart.Tid AS StartTid, PSlut.Tid AS SlutTid
	FROM dbo.ProcessTid AS PStart FULL JOIN dbo.ProcessTid AS PSlut
			ON PStart.StartSlut = 'Start' AND
				PSlut.StartSlut = 'Slut' AND
				PStart.ProcessID = PSlut.ProcessID
	WHERE PStart.StartSlut = 'Start' OR PSlut.StartSlut = 'Slut';
GO
SELECT PStart.ProcessID, PStart.Tid AS StartTid, PSlut.Tid AS SlutTid
	FROM (SELECT ProcessID, Tid
			FROM  dbo.ProcessTid 
			WHERE StartSlut = 'Start') AS PStart 
		 FULL JOIN 
		 (SELECT ProcessID, Tid
			FROM  dbo.ProcessTid 
			WHERE StartSlut = 'Slut')AS PSlut
		ON PStart.ProcessID = PSlut.ProcessID;
GO
SELECT PStart.ProcessID, PStart.Tid AS StartTid, PSlut.Tid AS SlutTid
	FROM dbo.ProcessTid AS PStart FULL JOIN dbo.ProcessTid AS PSlut
			ON PStart.ProcessID = PSlut.ProcessID
	WHERE PStart.StartSlut = 'Start' AND
		  PSlut.StartSlut = 'Slut';
		  
SELECT PStart.ProcessID, PStart.Tid AS StartTid, PSlut.Tid AS SlutTid
	FROM dbo.ProcessTid AS PStart FULL JOIN dbo.ProcessTid AS PSlut
			ON PStart.ProcessID = PSlut.ProcessID AND PStart.ID <> PSlut.ID
	WHERE (PStart.StartSlut = 'Start' OR PStart.StartSlut IS NULL) AND
		  (PSlut.StartSlut = 'Slut' OR PSlut.StartSlut IS NULL);
GO
