USE IndexDB
GO
CREATE INDEX nc_person_Koenkode ON dbo.Person (Koenkode)
GO
SELECT TOP 90 PERCENT *
	INTO dbo.SletPersonKoenkodeNULL
	FROM dbo.Person
	WHERE Koenkode IS NULL;
GO
DELETE 
	FROM dbo.Person
	WHERE PersonId IN (SELECT PersonId FROM dbo.SletPersonKoenkodeNULL);
GO
UPDATE STATISTICS dbo.Person
	WITH FULLSCAN;
GO
SET IDENTITY_INSERT dbo.Person ON;
INSERT INTO dbo.Person(PersonID, Fornavn, Efternavn, Gade, Postnr, Koenkode, Landekode, Tlfnr, Persontype)
	SELECT	PersonID, 
			Fornavn, 
			Efternavn, 
			Gade, 
			Postnr, 
			Koenkode, 
			Landekode, 
			Tlfnr, 
			Persontype
		FROM dbo.SletPersonKoenkodeNULL;
SET IDENTITY_INSERT dbo.Person OFF;
GO
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT	Person.PersonID,
		Person.Koenkode,
		Postopl.Postnr,
		Postopl.Bynavn
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
	WHERE	Person.Koenkode IS NULL OR
			Postopl.Bynavn LIKE 'A%';
GO
SELECT	Person.PersonID,
		Person.Koenkode,
		Postopl.Postnr,
		Postopl.Bynavn
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
	WHERE	Person.Koenkode IS NULL 
UNION 
SELECT	Person.PersonID,
		Person.Koenkode,
		Postopl.Postnr,
		Postopl.Bynavn
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
	WHERE	Postopl.Bynavn LIKE 'A%';
GO
WITH 
PersonKoen
AS
(
SELECT	Person.PersonID,
		Person.Koenkode,
		Postopl.Postnr,
		Postopl.Bynavn
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
	WHERE	Person.Koenkode IS NULL 
),
PersonBynavn
AS
(
SELECT	Person.PersonID,
		Person.Koenkode,
		Postopl.Postnr,
		Postopl.Bynavn
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
	WHERE	Postopl.Bynavn LIKE 'Bi%'
)
SELECT *
	FROM PersonKoen
UNION ALL
SELECT *
	FROM PersonBynavn
	WHERE PersonId NOT IN	
		(SELECT PersonId
			FROM PersonKoen
			WHERE PersonBynavn.PersonID = PersonKoen.PersonID);

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
