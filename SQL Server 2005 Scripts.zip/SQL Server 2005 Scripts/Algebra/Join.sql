USE master;
DROP DATABASE AlgebraDB;
go
CREATE DATABASE AlgebraDB;
go
USE AlgebraDB;
go
CREATE TABLE dbo.Postopl 
(
	Postlbnr		SMALLINT	NOT NULL 
								PRIMARY KEY,
	Postnr			SMALLINT	NOT NULL UNIQUE,
	Bynavn			VARCHAR(25) NOT NULL
);

CREATE TABLE dbo.Person  
(
	PersonID		INT			NOT NULL 
								PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	Adresse			VARCHAR(30) NULL,
	Postlbnr		SMALLINT	NULL 
								FOREIGN KEY REFERENCES dbo.Postopl(Postlbnr)
);
GO
INSERT INTO dbo.Postopl VALUES
	(1, 2000, 'Frederiksberg'),
	(2, 3000, 'Roskilde'),
	(3, 5000, 'Odense'),
	(4, 6200, 'Aabenraa'),
	(5, 8000, '�rhus C'),
	(6, 9000, 'Aalborg'),
	(7, 9800, 'Hj�rring'),
	(8, 9990, 'Skagen');

INSERT INTO dbo.Person VALUES 
	(1, 'Hansen', 'Vestergade', 2),
	(2, 'Jensen', '�stergade', 1),
	(3, 'Jensen', 'Nygade', 3),
	(4, 'S�rensen', 'Torvet', 5),
	(5, 'Petersen', 'Vestergade', 6),
	(6, 'Pedersen', 'N�rregade', 6),
	(7, 'Hansen', 'Vestergade', 8);

INSERT INTO dbo.Person(Personid, Navn) VALUES
	(8, 'Knudsen'),
	(9, 'Larsen');
GO
--inner join
----theta
SELECT *
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postlbnr < dbo.Postopl.Postlbnr;
----equi
SELECT *
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postlbnr = dbo.Postopl.Postlbnr;
----natural
SELECT Person.*, Postnr, Bynavn
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postlbnr = dbo.Postopl.Postlbnr;
----semi
SELECT Person.*
	FROM dbo.Postopl INNER JOIN dbo.Person ON Person.Postlbnr = dbo.Postopl.Postlbnr;

SELECT DISTINCT dbo.Postopl.*
	FROM dbo.Postopl INNER JOIN dbo.Person ON Person.Postlbnr = dbo.Postopl.Postlbnr;

SELECT *
	FROM dbo.Postopl WHERE Postlbnr IN (SELECT Postlbnr 
											FROM dbo.Person);

SELECT *
	FROM dbo.Postopl 
	WHERE EXISTS (SELECT Postlbnr 
					FROM dbo.Person
					WHERE Person.Postlbnr = dbo.Postopl.Postlbnr);

----anti semi
SELECT DISTINCT dbo.Postopl.*
	FROM  dbo.Postopl LEFT OUTER JOIN dbo.Person ON Person.Postlbnr = dbo.Postopl.Postlbnr
	WHERE Person.Postlbnr IS NULL;

SELECT *
	FROM dbo.Postopl 
	WHERE NOT EXISTS (SELECT Postlbnr 
						FROM dbo.Person
						WHERE Person.Postlbnr = dbo.Postopl.Postlbnr);

SELECT *										-- Fejler 
	FROM dbo.Postopl WHERE Postlbnr NOT IN (SELECT Postlbnr 
												FROM dbo.Person);
----outer
----left outer
SELECT *
	FROM dbo.Person LEFT OUTER JOIN dbo.Postopl ON Person.Postlbnr = dbo.Postopl.Postlbnr;
----right outer
SELECT *
	FROM dbo.Person RIGHT OUTER JOIN dbo.Postopl ON Person.Postlbnr = dbo.Postopl.Postlbnr;
----full outer
SELECT *
	FROM dbo.Person FULL OUTER JOIN dbo.Postopl ON Person.Postlbnr = dbo.Postopl.Postlbnr;

