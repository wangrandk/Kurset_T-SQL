USE Indexdb;
GO
SELECT *
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					INNER JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode
					INNER JOIN dbo.Persontype ON Person.Persontype = Persontype.Persontype;
SELECT *
	FROM dbo.Person INNER JOIN dbo.Persontype ON Person.Persontype = Persontype.Persontype
					INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
					INNER JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode;
SELECT *
	FROM dbo.Person INNER JOIN dbo.Persontype ON Person.Persontype = Persontype.Persontype
					INNER JOIN dbo.Koen ON Person.Koenkode = Koen.Koenkode
					INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr;
GO
CREATE INDEX nc_Person_Persontype ON dbo.Person (Persontype);
CREATE INDEX nc_Person_Koenkode ON dbo.Person (Koenkode);
CREATE INDEX nc_Person_Fornavn ON dbo.Person (Fornavn);
GO
SELECT *
	FROM dbo.Person
	WHERE	Person.Persontype = 'C' AND
			Person.Koenkode = 'M' AND
			Person.Fornavn = 'Bo';

SELECT *
	FROM dbo.Person
	WHERE	Person.Koenkode = 'M' AND
			Person.Persontype = 'C' AND
		    Person.Fornavn = 'Bo';

SELECT *
	FROM dbo.Person
	WHERE	Person.Fornavn = 'Bo'AND
			Person.Persontype = 'C' AND
		    Person.Koenkode = 'M';