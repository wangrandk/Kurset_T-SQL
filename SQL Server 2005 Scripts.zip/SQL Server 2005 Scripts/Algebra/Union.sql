USE master;
DROP DATABASE AlgebraDB;
GO
CREATE DATABASE AlgebraDB;
GO
USE AlgebraDB;
GO
CREATE TABLE dbo.v 
(
	id			INT,
	tekst		VARCHAR(10)
);

CREATE TABLE dbo.u 
(
	id			INT,
	tekst		VARCHAR(10)
);
GO
SET NOCOUNT ON
INSERT INTO dbo.v VALUES 
	(1, 'a'),
	(2, 'b'),
	(3, 'c');

INSERT INTO dbo.u VALUES 
	(3, 'c'),
	(4, 'd'),
	(5, 'e');
SET NOCOUNT OFF
--UNION
SELECT *
   FROM dbo.v
UNION
SELECT *
   FROM dbo.u;

--UNION ALL
SELECT *
   FROM dbo.v
UNION ALL
SELECT *
   FROM dbo.u;

-- med NULL
TRUNCATE TABLE dbo.u;
TRUNCATE TABLE dbo.v;
GO
SET NOCOUNT ON;
INSERT INTO dbo.v VALUES 
	(1, 'a'),
	(NULL, NULL),
	(NULL, NULL),
	(3, 'c');

INSERT INTO dbo.u VALUES 
	(3, 'c'),
	(NULL, NULL),
	(NULL, NULL),
	(NULL, NULL),
	(5, 'e');
SET NOCOUNT OFF;

--UNION MED NULL
SELECT *
   FROM dbo.v
UNION
SELECT *
   FROM dbo.u;

--UNION ALL MED NULL
SELECT *
   FROM dbo.v
UNION ALL
SELECT *
   FROM dbo.u;
