USE master;
DROP DATABASE MaengdeLoveDB;
GO
CREATE DATABASE MaengdeLoveDB;
GO
USE MaengdeLoveDB;
CREATE TABLE dbo.A 
(
	i	INT		NOT NULL
);

CREATE TABLE dbo.B 
(
	i	INT		NOT NULL
);

CREATE TABLE dbo.C 
(
	i	INT		NOT NULL
);
GO
INSERT INTO dbo.A VALUES 
	(1),
	(2);

INSERT INTO dbo.B VALUES 
	(2),
	(3),
	(4);

--INSERT INTO C VALUES (2)
INSERT INTO dbo.C VALUES 
	(4),
	(5);
GO
--Den tomme m�ngdes love
SELECT * 
	FROM dbo.A
INTERSECT
SELECT TOP 0 * 
	FROM dbo.B;

----

SELECT * 
	FROM dbo.A
UNION
SELECT TOP 0 * 
	FROM dbo.B;

--Commutative love
SELECT * 
	FROM dbo.A
UNION
SELECT * 
	FROM dbo.B;

SELECT * 
	FROM dbo.B
UNION
SELECT * 
	FROM dbo.A;

-----

SELECT * 
	FROM dbo.A
INTERSECT
SELECT * 
	FROM dbo.B;

SELECT * 
	FROM dbo.B
INTERSECT
SELECT * 
	FROM dbo.A;

--Associative love

(SELECT * 
	FROM dbo.A
UNION
SELECT * 
	FROM dbo.B)
UNION
SELECT * 
	FROM dbo.C;

SELECT * 
	FROM dbo.A
UNION
(SELECT * 
	FROM dbo.B
UNION
SELECT * 
	FROM dbo.C);

-----

(SELECT * 
	FROM dbo.A
INTERSECT
SELECT * 
	FROM dbo.B)
INTERSECT
SELECT * 
	FROM dbo.C;

SELECT * 
	FROM dbo.A
INTERSECT
(SELECT * 
	FROM dbo.B
INTERSECT
SELECT * 
	FROM dbo.C);

--Distributive love

SELECT * 
	FROM dbo.A
UNION
(SELECT * 
	FROM dbo.B
INTERSECT
SELECT * 
	FROM dbo.C);

(SELECT * 
	FROM dbo.A
UNION
SELECT * 
	FROM dbo.B)
INTERSECT
(SELECT * 
	FROM dbo.A
UNION
SELECT * 
	FROM dbo.C);

----

SELECT * 
	FROM dbo.A
INTERSECT
(SELECT * 
	FROM dbo.B
UNION
SELECT * 
	FROM dbo.C);

(SELECT * 
	FROM dbo.A
INTERSECT
SELECT * 
	FROM dbo.B)
UNION
(SELECT * 
	FROM dbo.A
INTERSECT
SELECT * 
	FROM dbo.C);

---- fejl hvis der ikke s�ttes paranteser

SELECT * 
	FROM dbo.A
INTERSECT
SELECT * 
	FROM dbo.B
UNION
SELECT * 
	FROM dbo.C;

SELECT * 
	FROM dbo.A
INTERSECT
SELECT * 
	FROM dbo.B
UNION
SELECT * 
	FROM dbo.A
INTERSECT
SELECT * 
	FROM dbo.C;

--fejl ---

SELECT * 
	FROM dbo.A
INTERSECT
SELECT * 
	FROM dbo.B
UNION
SELECT * 
	FROM dbo.C;

SELECT * 
	FROM dbo.A
INTERSECT
(SELECT * 
	FROM dbo.B
UNION
SELECT * 
	FROM dbo.C);
