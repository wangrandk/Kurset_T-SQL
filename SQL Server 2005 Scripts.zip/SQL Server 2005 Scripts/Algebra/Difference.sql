USE master;
DROP DATABASE AlgebraDB;
GO
CREATE DATABASE AlgebraDB;
GO
USE AlgebraDB;
GO
CREATE TABLE dbo.t1 
(
	Id			INT,
	Tekst		VARCHAR(10)
);

CREATE TABLE dbo.t2 
(
	Id			INT,
	Tekst		VARCHAR(10)
);
GO
INSERT INTO dbo.t1 VALUES 
	(1, 'a'),
	(2, 'b'),
	(3, 'c');

INSERT INTO dbo.t2 VALUES 
	(3, 'c'),
	(4, 'd'),
	(5, 'e');


--DIFFERENCE (V - U)
SELECT *
   FROM dbo.t1
   WHERE NOT EXISTS
	(SELECT *
   		FROM dbo.t2
		WHERE t1.Id = t2.Id AND
			  t2.Tekst = t2.Tekst);

SELECT *
	FROM dbo.t1
EXCEPT
SELECT *
	FROM dbo.t2;

SELECT *
	FROM dbo.t2
EXCEPT
SELECT *
	FROM dbo.t1;

-- DIFFERENCE med dubletter (V - U)

SET NOCOUNT ON
INSERT INTO dbo.t1 VALUES 
	(1,'a'),
	(3,'c'),
	(3,'c');

INSERT INTO dbo.t2 VALUES 
	(3,'c'),
	(4,'d'),
	(5,'e');

SET NOCOUNT OFF;

SELECT DISTINCT *
   FROM v
   WHERE NOT EXISTS
	(SELECT *
   		FROM u
		WHERE v.Id = u.Id AND
			  v.Tekst = u.Tekst)

-- DIFFERENCE med NULL (V - U)
TRUNCATE TABLE v
TRUNCATE TABLE u

SET NOCOUNT ON
INSERT INTO dbo.t1 VALUES (1,'a')
INSERT INTO dbo.t1 VALUES (3,'c')
INSERT INTO dbo.t1 VALUES (null,null)

INSERT INTO dbo.t2 VALUES (3,'c')
--INSERT INTO dbo.t2 VALUES (null,null)
INSERT INTO dbo.t2 VALUES (5,'e')
SET NOCOUNT OFF

--DIFFERENCE med null (V - U)
SELECT  *   
   FROM v
   WHERE NOT EXISTS
	(SELECT *
   		FROM u
		WHERE (v.Id = u.Id OR (v.Id IS NULL AND u.Id IS NULL)) AND
			   (v.Tekst = u.Tekst OR (v.Tekst IS NULL AND u.Tekst IS NULL)))

-- DIFFERENCE ALL (V - U), hvis der er flere af 'dubletter' i dbo.t1 end i U, 
-- medtages det overskydende antal fra V
DROP TABLE dbo.t1
DROP TABLE dbo.t2
GO
CREATE TABLE dbo.t1 
(
	Autonum		INT IDENTITY(1,1) NOT NULL PRIMARY KEY,    -- tabellen skal indeholde en UNIQUE (dannes evt. i en temp-tabel)
	Id			INT,
	Tekst		VARCHAR(10)
);

CREATE TABLE dbo.t2 
(
	Autonum		INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	Id			INT,
	Tekst		VARCHAR(10)
);
GO
SET NOCOUNT ON;

INSERT INTO dbo.t1 VALUES 
	(1,'a'),
	(1,'a'),
	(3,'c'),
	(3,'c'),
	(4,'d'),
	(4,'d'),
	(4,'d'),
	(5,'e'),
	(5,'e');

INSERT INTO dbo.t2 VALUES 
	(3,'c'),
	(3,'c'),
	(3,'c'),
	(4,'d'),
	(5,'e'),
	(5,'e'),
	(6,'f');

SET NOCOUNT OFF;
GO
SELECT Id, Tekst 
	FROM dbo.t1
	WHERE (SELECT COUNT(*) 
          FROM dbo.t1 AS t1lbnr
          WHERE t1.Id = t1lbnr.Id AND
                t1.Tekst = t1lbnr.Tekst AND
				t1.Autonum > t1lbnr.Autonum) >= (SELECT COUNT(*) 
                									FROM dbo.t2 AS t2lbnr
                									WHERE t1.Id = t2lbnr.Id AND
                      							  		  t1.Tekst = t2lbnr.Tekst);
GO
SELECT Id, Tekst
FROM (
	SELECT *,
		ROW_NUMBER() OVER (PARTITION BY Id, Tekst ORDER BY Id) AS RN
		FROM v
	EXCEPT
	SELECT *,
		ROW_NUMBER() OVER (PARTITION BY Id, Tekst ORDER BY Id)
		FROM u) AS t;

