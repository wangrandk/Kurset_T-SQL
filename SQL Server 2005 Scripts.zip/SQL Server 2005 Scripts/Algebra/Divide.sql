USE master;
DROP DATABASE AlgebraDB;
GO
CREATE DATABASE AlgebraDB;
GO
USE AlgebraDB;
GO
CREATE TABLE dbo.t1 
(
	Id			INT			NOT NULL,
	Tekst		CHAR(1)		NOT NULL,
	CONSTRAINT PK_v PRIMARY KEY (Id, Tekst)
);

CREATE TABLE dbo.t2 
(
	Tekst		CHAR(1) NOT NULL PRIMARY KEY
);
GO
INSERT INTO dbo.t1 VALUES 
	(1,'a'),
	(1,'b'),
	(1,'c'),
	(1,'d'),
	(2,'a'),
	(2,'b'),
	(2,'d'),
	(3,'a'),
	(3,'b'),
	(3,'c');

INSERT INTO dbo.t2 VALUES 
	('a'),
	('b'),
	('c');
GO
--DIVIDE
SELECT Id
   FROM (SELECT DISTINCT Id FROM dbo.t1) AS ResData
   WHERE NOT EXISTS
	(SELECT *
   		FROM dbo.t2
		WHERE NOT EXISTS
			(SELECT *
				FROM dbo.t1 
				WHERE ResData.Id = dbo.t1.Id AND
					  t2.Tekst = t1.Tekst));
					  
SELECT DISTINCT Id
   FROM dbo.t1 AS t1_1
   WHERE NOT EXISTS
	(SELECT *
   		FROM dbo.t2
		WHERE NOT EXISTS
			(SELECT *
				FROM dbo.t1 AS t1_2
				WHERE t1_1.Id = t1_2.Id AND
					  t2.Tekst = t1_2.Tekst));

SELECT  Id
    FROM dbo.t1 INNER JOIN dbo.t2 ON t1.Tekst = t2.Tekst
	GROUP BY Id
	HAVING COUNT(*) = (SELECT COUNT(Tekst) FROM dbo.t2);

SELECT Id
	FROM dbo.t1
EXCEPT
SELECT Id
FROM (
	SELECT * FROM (SELECT DISTINCT Id FROM dbo.t1) AS t1 CROSS JOIN dbo.t2  ----)
	EXCEPT
	SELECT * FROM dbo.t1) AS f;

--DIVIDE (V div U)  �gte delm�ngde
SELECT DISTINCT Id
   FROM dbo.t1 AS t1_1
   WHERE NOT EXISTS
	(SELECT *
   		FROM dbo.t2
		WHERE NOT EXISTS
			(SELECT *
				FROM dbo.t1 AS t1_2
				WHERE t1_1.Id = t1_2.Id AND
					  t2.Tekst = t1_2.Tekst))
		AND
			EXISTS
			(SELECT *
				FROM dbo.t1 AS t1_3
				WHERE t1_1.Id = t1_3.Id AND
					  t1_3.Tekst NOT IN (SELECT Tekst FROM dbo.t2));

--DIVIDE  de 2 delm�ngde indeholder eksakt de samme elementer
SELECT DISTINCT Id
   FROM dbo.t1 as t1_1
   WHERE NOT EXISTS
	(SELECT *
   		FROM dbo.t2
		WHERE NOT EXISTS
			(SELECT *
				FROM dbo.t1 AS t1_2
				WHERE t1_1.Id = t1_2.Id AND
					  t2.Tekst  = t1_2.Tekst))
		AND
			NOT EXISTS
			(SELECT *
				FROM dbo.t1 AS t1_3
				WHERE t1_1.Id = t1_3.Id AND
					  t1_3.Tekst NOT IN (SELECT Tekst FROM dbo.t2));

GO
--DIVIDE med tom tabel
TRUNCATE TABLE dbo.t2;

SELECT Id
   FROM (SELECT DISTINCT Id FROM dbo.t1) AS ResData
   WHERE NOT EXISTS
	(SELECT *
   		FROM dbo.t2
		WHERE NOT EXISTS
			(SELECT *
				FROM dbo.t1 
				WHERE ResData.Id = dbo.t1.Id AND
					  t2.Tekst = t1.Tekst));
					  
SELECT DISTINCT Id
   FROM dbo.t1 AS t1_1
   WHERE NOT EXISTS
	(SELECT *
   		FROM dbo.t2
		WHERE NOT EXISTS
			(SELECT *
				FROM dbo.t1 AS t1_2
				WHERE t1_1.Id = t1_2.Id AND
					  t2.Tekst = t1_2.Tekst));

SELECT  Id
    FROM dbo.t1 INNER JOIN dbo.t2 ON t1.Tekst = t2.Tekst
	GROUP BY Id
	HAVING COUNT(*) = (SELECT COUNT(Tekst) FROM dbo.t2);

SELECT Id
	FROM dbo.t1
EXCEPT
SELECT Id
FROM (
	SELECT * FROM (SELECT DISTINCT Id FROM dbo.t1) AS t1 CROSS JOIN dbo.t2  ----)
	EXCEPT
	SELECT * FROM dbo.t1) AS f;

-- praktisk eksempel

DROP TABLE dbo.t1;
DROP TABLE dbo.t2;
--DROP TABLE dbo.t3
GO
CREATE TABLE dbo.t3 
(
	Id			INT NOT NULL PRIMARY KEY,
	Diverse		VARCHAR(20) DEFAULT 'xxx'
);

CREATE TABLE dbo.t1 
( 
	Id			INT,
	Tekst		CHAR(1),
	CONSTRAINT PK_t1 PRIMARY KEY (Id, Tekst),
	CONSTRAINT FK_t1_t3 FOREIGN KEY (Id) REFERENCES dbo.t3(Id)
);

CREATE TABLE dbo.t2 
(
	Tekst		CHAR(1) PRIMARY KEY
);
GO
SET NOCOUNT ON;
INSERT INTO dbo.t3(Id) VALUES
	(1),
	(2),
	(3);

INSERT INTO dbo.t1 VALUES 
	(1,'a'),
	(1,'b'),
	(1,'c'),
	(1,'d'),
	(2,'a'),
	(2,'b'),
	(3,'a'),
	(3,'b'),
	(3,'c');

INSERT INTO dbo.t2 VALUES 
	('a'),
	('b'),
	('c');
GO
SET NOCOUNT OFF;

--DIVIDE 
SELECT *
   FROM dbo.t3
   WHERE NOT EXISTS
	(SELECT *
   		FROM dbo.t2
		WHERE NOT EXISTS
			(SELECT *
				FROM dbo.t1 
				WHERE dbo.t1.Id = t3.Id AND
					  t1.Tekst = t2.Tekst));
--dubletter
DROP TABLE dbo.t1;
DROP TABLE dbo.t2;
GO
CREATE TABLE dbo.t1 
( 
	Id			INT,
	Tekst		CHAR(1)
);

CREATE TABLE dbo.t2 
(
	Tekst		CHAR(1)
);
GO
SET NOCOUNT ON
INSERT INTO dbo.t1 VALUES 
	(1,'a'),
	(1,'b'),
	(1,'c'),
	(1,'d'),
	(2,'a'),
	(2,'b'),
	(2,'b'),
	(3,'a'),
	(3,'b'),
	(3,'c'),
	(3,'c'),
	(4,'a'),
	(4,'b'),
	(4,'d'),
	(4,'d');

INSERT INTO dbo.t2 VALUES 
	('a'),
	('b'),
	('c');

SET NOCOUNT OFF
go 
SELECT Id
    FROM dbo.t1 inner join dbo.t2 ON t1.Tekst = t2.Tekst 
	GROUP BY Id
	HAVING COUNT(DISTINCT t1.Tekst) >= (SELECT COUNT(Tekst) FROM dbo.t2);

SELECT Id
    FROM dbo.t1 
	GROUP BY Id
	HAVING COUNT(DISTINCT t1.Tekst) >(SELECT COUNT(Tekst) FROM dbo.t2);
GO
DROP TABLE dbo.t3;
DROP TABLE dbo.t4;

SELECT DISTINCT Tekst	
	INTO dbo.t3
	FROM dbo.t1;
	
SELECT DISTINCT Id	
	INTO t4
	FROM dbo.t1;

SELECT DISTINCT Id
	FROM t4 
	WHERE NOT EXISTS	
		(SELECT *
			FROM dbo.t3
			WHERE Tekst IN ('a', 'b', 'c') AND 
				  NOT EXISTS (
				SELECT *
					FROM dbo.t1 
					WHERE t1.Id = t4.Id AND
						  t1.Tekst = t3.Tekst));

SELECT DISTINCT Id
	FROM dbo.t1 AS t1_1
	WHERE NOT EXISTS	
		(SELECT *
			FROM dbo.t3
			WHERE Tekst IN ('a', 'b', 'c') AND 
					NOT EXISTS (
				SELECT *
					FROM dbo.t1 AS t1_2
					WHERE t1_2.Id = t1_1.Id AND
						  t1_2.Tekst = t3.Tekst));
						  
