USE master;
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
CREATE TABLE dbo.t1
(
	a			INT,
	b			INT,
	c			INT,
	x			INT,
	y			INT,
	z			INT
);
CREATE TABLE dbo.t2
(
	a			INT,
	b			INT,
	c			INT,
	k			INT
);
GO
INSERT INTO dbo.t1 VALUES
	(1, 1, 1, 1, 1, 1),
	(2, 2, 2, 2, 2, 2),
	(3, 3, 3, 3, 3, 3),
	(4, 4, 4, 4, 4, 4);

INSERT INTO dbo.t2 VALUES 
	(3, 3, 3, 7),
	(4, 4, 4, 7),
	(5, 5, 5, 7);
GO
SELECT a, b, c, x, y, z, NULL AS k
	FROM dbo.t1
UNION ALL
SELECT a, b, c, NULL, NULL, NULL, k
	FROM dbo.t2
	WHERE NOT EXISTS
		(SELECT *
			FROM dbo.t1
			WHERE	t1.a = t2.a AND
					t1.b = t2.b AND
					t1.c = t2.c)
GO
SELECT	ISNULL(t1.a, t2.a) AS a,
		ISNULL(t1.b, t2.b) AS b,
		ISNULL(t1.c, t2.c) AS c,
		k,
		x,
		y,
		z
	FROM t1 FULL JOIN t2 ON t1.a = t2.a AND t1.b = t2.b AND t1.c = t2.c
