USE master;
DROP DATABASE SommerhusDB;
GO
CREATE DATABASE SommerhusDB;
GO
USE SommerhusDB;
CREATE TABLE dbo.Sommerhus 
(
	SommerhusId		INT			NOT NULL PRIMARY KEY,
	Adresse			VARCHAR(30) NOT NULL
);

CREATE TABLE dbo.Faciliteter 
(
	FacilitetsId	INT			NOT NULL PRIMARY KEY,
	FacilitetsNavn	VARCHAR(30) NOT NULL
);

CREATE TABLE dbo.OenskedeFaciliteter 
(
	FacilitetsId	INT			NOT NULL PRIMARY KEY
					REFERENCES dbo.Faciliteter
);

CREATE TABLE dbo.SommerhusFaciliteter 
(
	SommerhusId		INT			NOT NULL REFERENCES dbo.Sommerhus,
	FacilitetsId	INT			NOT NULL REFERENCES dbo.Faciliteter,
	CONSTRAINT FK_SommerhusFaciliteter PRIMARY KEY (SommerhusId, FacilitetsId)
);
GO
INSERT INTO dbo.Sommerhus VALUES 
	(1, 'Ved Stranden 3'),
	(2, 'Klitr�kken 4'),
	(3, 'Ved Stranden 27'),
	(4, 'Torvet 8');

INSERT INTO dbo.Faciliteter VALUES 
	(11, 'Spa bad'),
	(12, 'Vaskemaskine'),
	(13, 'TV'),
	(14, 'Parabolantenne'),
	(15, 'Cykler');

INSERT INTO dbo.OenskedeFaciliteter VALUES 
	(11),
	(13),
	(14);

INSERT INTO dbo.SommerhusFaciliteter VALUES 
	(1, 11),
	(1, 13),
	(1, 14),
	(1, 15),

	(2, 13),
	(2, 15),

	(3, 11),
	(3, 12),
	(3, 13),

	(4, 11),
	(4, 13),
	(4, 14);
GO
SELECT DISTINCT SommerhusId
	FROM dbo.SommerhusFaciliteter AS SF1
	WHERE NOT EXISTS
		(SELECT *
			FROM dbo.OenskedeFaciliteter AS OeF
			WHERE NOT EXISTS 
				(SELECT *
					FROM dbo.SommerhusFaciliteter AS SF2
					WHERE	SF1.SommerhusId = SF2.SommerhusId AND
						SF2.FacilitetsID = OeF.FacilitetsID))

SELECT SommerhusId
	FROM dbo.SommerhusFaciliteter AS SF INNER JOIN dbo.OenskedeFaciliteter AS OeF
			ON SF.FacilitetsID = OeF.FacilitetsID
	GROUP BY SommerhusId
	HAVING COUNT(*) = (SELECT COUNT(*) FROM dbo.OenskedeFaciliteter)
GO
SELECT SommerhusId
	FROM dbo.Sommerhus AS S
	WHERE NOT EXISTS
		(SELECT *
			FROM dbo.OenskedeFaciliteter AS OeF
			WHERE NOT EXISTS 
				(SELECT *
					FROM dbo.SommerhusFaciliteter AS SF
					WHERE S.SommerhusId = SF.SommerhusId AND
						  SF.FacilitetsID = OeF.FacilitetsID))
