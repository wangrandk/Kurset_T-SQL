USE master;
GO
DROP DATABASE AlgebraDB;
GO
CREATE DATABASE AlgebraDB;
GO
USE AlgebraDB
CREATE TABLE dbo.Kategori 
(
	KategoriID			SMALLINT		NOT NULL 
						CONSTRAINT PK_Kategori PRIMARY KEY,
	Kategorinavn		VARCHAR(30)		NOT NULL
);

CREATE TABLE dbo.Subkategori 
(
	SubkategoriID		SMALLINT		NOT NULL 
						CONSTRAINT PK_Subkategori PRIMARY KEY,
	SubKategorinavn		VARCHAR(30)		NOT NULL,
	KategoriID			SMALLINT		NOT NULL
						CONSTRAINT FK_SubKategori_Kategori
						REFERENCES dbo.Kategori (KategoriID)
);

CREATE TABLE dbo.Vare 
(
	VareId				INT				NOT NULL
										CONSTRAINT PK_Vare PRIMARY KEY,
	Varenavn			VARCHAR(30)		NOT NULL,
	Vejledendepris		DECIMAL(9,2)	NULL,
	IndkoebsType		CHAR(1)			NOT NULL DEFAULT('I'),
	SubkategoriID		SMALLINT		NOT NULL
										CONSTRAINT FK_Vare_Subkategori
										REFERENCES dbo.Subkategori (SubkategoriID)
);

CREATE TABLE dbo.Ordre 
(
	OrdreId				INT				NOT NULL 
										CONSTRAINT PK_Ordre PRIMARY KEY,
	Leveringsdato		DATE			NOT NULL DEFAULT (SYSDATETIME())
);

CREATE TABLE dbo.OrdreLinie 
(
	OrdreId				INT				NOT NULL 
										FOREIGN KEY REFERENCES Ordre(OrdreId),
	VareId				INT				NOT NULL 
										FOREIGN KEY REFERENCES dbo.Vare(VareId),
	AntalEnheder		INT				NOT NULL,
	EnhedsPris			INT				NOT NULL,
	CONSTRAINT PK_OrdreLinie PRIMARY KEY (OrdreId, VareId)
);
GO
INSERT INTO dbo.Kategori 
	(KategoriID, Kategorinavn) VALUES
	(1, 'Frugt og Gr�ntsager'),
	(2, 'Dagligdbo.Varer'),
	(3, 'Husholningsartikler');
GO
INSERT INTO dbo.Subkategori 
	(SubkategoriID, SubKategorinavn, KategoriID) VALUES
	(1, 'Frugt', 1),
	(2, 'Gr�ntsager', 1),
	(3, 'Kaffe og Te', 2),
	(4, 'Mel, Gryn, mv.', 2),
	(5, 'Vand og Juice', 2),
	(6, '�l og Vin', 2),
	(7, 'Toiletartikler', 3),
	(8, 'Reng�ringsmidler', 3),
	(9, 'Plasticposer mv.', 3);
GO
INSERT INTO dbo.Vare 
	(VareId, dbo.Varenavn, Vejledendepris, IndkoebsType, SubkategoriID) VALUES
	(1, '�ble', 20.00, 'I', 1),
	(2, 'Appelsin', 30.00, 'I', 1),
	(3, 'Blomme', 15.00, 'I', 1),
	(4, 'Jordb�r', 25.00, 'I', 1),
	(5, 'Kiwi', 8.00, 'I', 1),
	(6, 'Vandmelon', 10.00, 'I', 1),
	(7, 'Fersken', 10.00, 'I', 1),
	(8, 'Honningmelon', 15.00, 'I', 1),
	(9, 'Netmelon', 13.00, 'I', 1),
	(10, 'Vindruer - gr�nne', 17.25, 'I', 1),
	(11, 'Vindruer - bl�', 18.50, 'I', 1),
	(12, 'Grapefrugt', 8.00, 'I', 1),

	(13, 'Guler�dder', 15.00, 'I', 2),
	(14, 'Kartofler', 9.00, 'I', 2),
	(15, 'L�g', 10.00, 'I', 2),
	(16, 'For�rsl�g', 12.00, 'I', 2),
	(17, 'Porer', 18.00, 'I', 2),
	(18, 'Pastinak', 6.00, 'I', 2),
	(19, 'Jordskok', 8.00, 'I', 2),
	(20, 'Selleri', 13.25, 'I', 2),
	(21, 'Bagekartofler', 13.00, 'I', 2),
	
	(22, 'Kaffe', 27.00, 'I', 3),
	(23, 'Te', 15.00, 'I', 3),
	(24, 'Urtete', 20.00, 'I', 3),
	(25, '�kologisk kaffe', 37.00, 'I', 3),

	(26, 'Rugmel', 9.75, 'A', 4),
	(27, 'Sukker', 8.50, 'A', 4),
	(28, 'Havregryn', 19.75, 'A', 4),
	(29, 'Bygmel', 14.00, 'A', 4),
	(30, 'R�rsukker', 22.50, 'A', 4),
	(31, 'Hvedemel', 8.75, 'A', 4),
	(32, '3-korns mel', 16.25, 'A', 4),

	(33, 'Sodavand - 30cl', 3.00, 'I', 5),
	(34, 'Sodavand - 50cl', 5.00, 'I', 5),
	(35, 'Sodavand - 1 liter', 9.00, 'I', 5),
	(36, '�blejuice', 5.00, 'A', 5),
	(37, 'Appelsinjuice', 4.50, 'A', 5),
	(38, 'Gulerodsjuice', 7.50, 'A', 5),
	(39, '�kologisk �blejuice', 7.00, 'I', 5),
	(40, '�kologisk Appelsinjuice', 6.50, 'I', 5),
	(41, 'Blandet juice', 7.75, 'I', 5),

	(42, '�l', 4.00, 'I', 6),
	(43, 'R�dvin', 65.00, 'I', 6),
	(44, 'Hvidvin', 45.00, 'I', 6),
	(45, 'Rose', 39.75, 'I', 6),

	(46, 'Toiletpapir', 40.00, 'A', 7),
	(47, 'Papirslommet�rkl�de', 2.50, 'A', 7),
	(48, 'Vatpinde', 12.25, 'A', 7),
	(49, 'Vat', 10.00, 'A', 7),
	(50, 'S�be', 8.00, 'A', 7),
	(51, 'H�rshampoo', 29.75, 'A', 7),
	(52, 'Badesalt', 35.50, 'A', 7),

	(53, 'Opvaskemiddel', 12.00, 'A', 8),
	(54, 'WC-rens', 23.50, 'A', 8),
	(55, 'Brun s�be', 6.50, 'A', 8),
	(56, 'S�besp�ner', 8.75, 'A', 8),
	(57, 'Reng�ringssvamp', 9.50, 'A', 8),
	(58, 'Karklud - bomuld', 19.50, 'A', 8),
	(59, 'Karklud - fiber', 14.50, 'A', 8),
	(60, 'Gulvklud', 19.50, 'A', 8),

	(61, 'Affaldsposer - alm.', 6.00, 'A', 9),
	(62, 'Affaldsposer - store', 8.00, 'A', 9),
	(63, 'Sorte Affaldss�kke', 13.00, 'A', 9),
	(64, 'Klare Affaldss�kke', 13.00, 'A', 9),
	(65, 'Frostposer 1 liter', 9.00, 'A', 9),
	(66, 'Frostposer 2 liter', 14.00, 'A', 9),
	(67, 'Frostposer 5 liter', 19.00, 'A', 9),
	(68, 'Frostposer 8 liter', 29.00, 'A', 9);
GO
WITH OrdreData
AS
(
SELECT 1 AS OrdreID
UNION ALL
SELECT OrdreId + 1
	FROM Ordredata
	WHERE Ordreid < 100000
)
INSERT INTO dbo.Ordre(OrdreId, Leveringsdato)
	SELECT OrdreId, DATEADD(DAY, OrdreId % DATEPART(MICROSECOND, SYSDATETIME()) % 45 ,SYSDATETIME())
		FROM OrdreData
	OPTION (MAXRECURSION 0);
GO
INSERT INTO OrdreLinie (OrdreId, VareId, EnhedsPris, AntalEnheder)
	SELECT	Ordre.OrdreId,
			dbo.Vare.VareId,
			dbo.Vare.Vejledendepris,
			(Ordre.OrdreId % dbo.Vare.Vejledendepris) + 1 
		FROM dbo.Ordre INNER JOIN dbo.Vare ON Ordre.Ordreid % dbo.Vare.VareId = Ordre.OrdreId % DATEPART(SECOND, SYSDATETIME());
GO
SELECT	AntalOrdreLinier, 
		COUNT(*) AS AntalOrdre
	FROM
	(SELECT Ordreid, COUNT(*) AS AntalOrdreLinier
		FROM dbo.Ordrelinie
		GROUP BY OrdreID) AS AntalOL
	GROUP BY AntalOrdreLinier
	ORDER BY AntalOrdreLinier;
GO
SET STATISTICS TIME ON

SELECT	Ordre.OrdreId,
		Vare.VareId,
		Vare.Varenavn,
		Ordre.Leveringsdato
	FROM dbo.Vare	INNER JOIN dbo.OrdreLinie ON Vare.VareId = OrdreLinie.VareId
					INNER JOIN dbo.Ordre ON OrdreLinie.OrdreId = Ordre.OrdreId;
GO
SELECT	Ordre.OrdreId,
		OrdreLinie.VareId,
		Vare.Varenavn,
		Ordre.Leveringsdato
	FROM dbo.Vare	INNER JOIN dbo.OrdreLinie ON Vare.VareId = OrdreLinie.VareId
					INNER JOIN dbo.Ordre ON OrdreLinie.OrdreId = Ordre.OrdreId;

SET STATISTICS TIME OFF;
