USE IndexDB;
GO
SELECT *
	INTO dbo.p1
	FROM dbo.Person
	WHERE Postnr IN (2000, 5000, 8000, 9000);

SELECT *
	INTO dbo.p2
	FROM dbo.Person
	WHERE Efternavn = 'Jensen';
GO
SET STATISTICS TIME ON;
SELECT *
	FROM dbo.p1
UNION
SELECT *
	FROM dbo.p2;

SELECT *
	FROM dbo.p1
UNION ALL
SELECT *	
	FROM dbo.p2
	WHERE NOT EXISTS
		(SELECT *
			FROM dbo.p1
			WHERE p1.PersonID = p2.PersonID);
SET STATISTICS TIME OFF;
GO
CREATE CLUSTERED INDEX cl_p1_PersonId ON dbo.p1(PersonID);
CREATE CLUSTERED INDEX cl_p2_PersonId ON dbo.p2(PersonID);
GO
SET STATISTICS TIME ON;
SELECT *
	FROM dbo.p1
UNION
SELECT *
	FROM dbo.p2;

SELECT *
	FROM dbo.p1
UNION ALL
SELECT *	
	FROM dbo.p2
	WHERE NOT EXISTS
		(SELECT *
			FROM dbo.p1
			WHERE p1.PersonID = p2.PersonID);
SET STATISTICS TIME OFF;
GO
SET STATISTICS TIME ON;
SELECT *
	FROM dbo.p1
UNION
SELECT *
	FROM dbo.p2
ORDER BY PersonID;

SELECT *
	FROM dbo.p1
UNION ALL
SELECT *	
	FROM dbo.p2
	WHERE NOT EXISTS
		(SELECT *
			FROM dbo.p1
			WHERE p1.PersonID = p2.PersonID)
ORDER BY PersonID;
SET STATISTICS TIME OFF;
GO
DROP INDEX cl_p1_PersonId ON dbo.p1;
DROP INDEX cl_p2_PersonId ON dbo.p2;
