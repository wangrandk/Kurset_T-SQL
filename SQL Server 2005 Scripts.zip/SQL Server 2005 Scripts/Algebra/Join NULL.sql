USE master;
GO
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
GO
SELECT * 
	INTO dbo.A 
	FROM (VALUES ('0'),('1'),('2'),('3'),('4'),('5'),(''),(NULL)) x(A);
GO
SELECT * 
	INTO dbo.B 
	FROM (VALUES ('4'),('5'),('6'),('7'),('8'),('9'),(''),(NULL)) x(B);
GO
SET STATISTICS TIME ON;
SELECT * 
	FROM dbo.A INNER JOIN dbo.B 
			ON	 A.A = B.B OR 
				(A.A IS NULL AND B.B IS NULL);
GO
SELECT * 
	FROM dbo.A INNER JOIN dbo.B 
			ON	 ISNULL (A.A, 'x') = ISNULL(B.B, 'x');
GO
SELECT * 
	FROM dbo.A INNER JOIN dbo.B 
		ON EXISTS (SELECT A.A INTERSECT SELECT B.B);

SET STATISTICS TIME OFF;
GO
INSERT INTO dbo.A
	SELECT *
		FROM dbo.A;
GO 14
INSERT INTO dbo.B
	SELECT *
		FROM dbo.B;
GO 12
SET STATISTICS TIME ON;

SELECT * 
	FROM dbo.A INNER JOIN dbo.B 
			ON	 A.A = B.B OR 
				(A.A Is NULL AND B.B Is NULL);
GO
SELECT * 
	FROM dbo.A INNER JOIN dbo.B 
			ON	 ISNULL (A.A, 'x') = ISNULL(B.B, 'x');
GO
SELECT * 
	FROM dbo.A INNER JOIN dbo.B 
		ON EXISTS (SELECT A.A INTERSECT SELECT B.B);

SET STATISTICS TIME OFF;
