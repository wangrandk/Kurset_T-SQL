USE master
DROP DATABASE SchemaDB
GO
CREATE DATABASE SchemaDB
GO
USE SchemaDB
GO
CREATE SCHEMA Liv
GO
CREATE SCHEMA Motor
GO
CREATE TABLE dbo.Kunde (
	KundeId		INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(30) NOT NULL)

CREATE TABLE Liv.Police (
	PoliceId	INT NOT NULL PRIMARY KEY,
	KundeId		INT NOT NULL REFERENCES dbo.Kunde)

CREATE TABLE Motor.Police (
	PoliceId	INT NOT NULL PRIMARY KEY,
	KundeId		INT NOT NULL REFERENCES dbo.Kunde)
	
CREATE TABLE Liv.Skade (
	SkadesId	INT NOT NULL PRIMARY KEY,
	PoliceId	INT NOT NULL REFERENCES Liv.Police)

CREATE TABLE Motor.Skade (
	SkadesId	INT NOT NULL PRIMARY KEY,
	PoliceId	INT NOT NULL REFERENCES Motor.Police)
GO
INSERT INTO Kunde VALUES (1, 'Ole Hansen')
INSERT INTO Kunde VALUES (2, 'Ida Larsen')
INSERT INTO Kunde VALUES (3, 'Jens Pedersen')
INSERT INTO Kunde VALUES (4, 'Maren Thomsen')

INSERT INTO Liv.Police VALUES (1, 3)
INSERT INTO Liv.Police VALUES (2, 3)
INSERT INTO Liv.Police VALUES (3, 1)

INSERT INTO Motor.Police VALUES (1, 1)
INSERT INTO Motor.Police VALUES (2, 2)
INSERT INTO Motor.Police VALUES (3, 4)
INSERT INTO Motor.Police VALUES (4, 4)

INSERT INTO Liv.Skade VALUES (1, 2)
INSERT INTO Liv.Skade VALUES (2, 3)
INSERT INTO Liv.Skade VALUES (3, 2)

INSERT INTO Motor.Skade VALUES (1, 2)
INSERT INTO Motor.Skade VALUES (2, 1)
INSERT INTO Motor.Skade VALUES (3, 4)
INSERT INTO Motor.Skade VALUES (4, 2)
INSERT INTO Motor.Skade VALUES (5, 1)
INSERT INTO Motor.Skade VALUES (6, 2)
GO
SELECT * FROM Police		-- fejl
GO
SELECT * FROM Motor.Police
GO
SELECT * FROM Liv.Police
GO
SELECT *
	FROM dbo.Kunde LEFT JOIN Liv.Police ON Kunde.KundeId = Police.KundeId
GO
SELECT *					-- fejl
	FROM dbo.Kunde LEFT JOIN Liv.Police ON Kunde.KundeId = Police.KundeId
				   LEFT JOIN Motor.Police ON Kunde.KundeId = Police.KundeId	
GO
SELECT *					-- fejl
	FROM dbo.Kunde LEFT JOIN Liv.Police ON Kunde.KundeId = Liv.Police.KundeId
				   LEFT JOIN Motor.Police ON Kunde.KundeId = Motor.Police.KundeId	
GO
SELECT *
	FROM dbo.Kunde LEFT JOIN Liv.Police  AS LP ON Kunde.KundeId = LP.KundeId
				   LEFT JOIN Motor.Police AS MP ON Kunde.KundeId = MP.KundeId	
GO
