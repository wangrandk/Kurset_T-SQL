USE master;
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
IF OBJECT_ID('dbo.SequenceData','U') IS NOT NULL BEGIN
	DROP TABLE dbo.SequenceData;
END;
GO
CREATE TABLE dbo.SequenceData
(
	ID		INT IDENTITY,
	String	VARCHAR(4000)
);
GO
INSERT INTO dbo.SequenceData(String)
	SELECT 'ASDFKIJKLMNAXDBABCIJKPPSRNK' UNION ALL
	SELECT 'XYZABCPPCKLMIDB *)(3 xxABC' UNION ALL
	SELECT 'ASDF;LKJQWERPOIUNMLKSTUVABC' 
	SELECT * 
		FROM dbo.SequenceData
GO
WITH 
SequenceDataCTE (ID, String, FirstLetter, Position)
AS
(
SELECT ID, String, LEFT(String, 1) AS FirstLetter, 1 AS Position
	FROM dbo.SequenceData
UNION ALL
SELECT ID, String, SUBSTRING(String, Position + 1, 1), Position + 1
	FROM SequenceDataCTE
	WHERE LEN(String) > Position
),
Sequence
AS
(
SELECT	ID, 
		String, 
		CAST(FirstLetter AS VARCHAR(4000)) AS ContinueString, 
		Position
	FROM SequenceDataCTE
UNION ALL
SELECT	ID, 
		String, 
		CAST(ContinueString + SUBSTRING(String, Position + 1, 1) AS VARCHAR(4000)), 
		Position + 1
	FROM Sequence
	WHERE	ASCII(SUBSTRING(String, Position, 1)) + 1 = ASCII(SUBSTRING(String, Position + 1, 1)) AND
			SUBSTRING(String, Position + 1, 1) BETWEEN 'A' AND 'Z'
)
SELECT	ID, 
		MIN(ContinueString) AS Sequence
	FROM Sequence AS LS_Outer
	WHERE LEN(ContinueString) = (SELECT MAX(LEN(ContinueString))
										FROM Sequence AS LS_Inner
										WHERE LS_Outer.ID = LS_Inner.ID)
	GROUP BY ID;
