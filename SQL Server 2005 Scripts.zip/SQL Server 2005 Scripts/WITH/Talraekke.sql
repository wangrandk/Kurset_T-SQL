WITH 
Talraekke
AS
(
 SELECT 1 AS Tal
 UNION ALL
 SELECT Tal + 1
	FROM Talraekke
	WHERE Tal < 1000
)
SELECT *
	FROM Talraekke
	OPTION (MAXRECURSION 1000); 
GO
USE master;
GO
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE Testdb;
GO
CREATE TABLE dbo.Tid 
(
	Id			INT			NOT NULL IDENTITY,
	Dato		Date		NOT NULL,
	Aar			AS YEAR(Dato) PERSISTED,
	Md			AS MONTH(Dato) PERSISTED
);
GO
WITH 
Datoeraekke (Dato)
AS
(
 SELECT CAST('2000-01-01' AS Date) AS Dato
 UNION ALL
 SELECT DATEADD(DAY, 1, Dato)
	FROM Datoeraekke
	WHERE Dato < SYSDATETIME()
)
INSERT INTO dbo.Tid(Dato)
	SELECT Dato
		FROM Datoeraekke
		OPTION (MAXRECURSION 0); 
	
SELECT * 
	FROM dbo.Tid;
GO
WITH 
Datoeraekke (Dato)
AS
(
 SELECT CAST('2000-01-01' AS Date) AS Dato
 UNION ALL
 SELECT DATEADD(DAY, 1, Dato)
	FROM Datoeraekke
	WHERE Dato < SYSDATETIME()
)
SELECT Dato
		FROM Datoeraekke
		OPTION (MAXRECURSION 9000); 
