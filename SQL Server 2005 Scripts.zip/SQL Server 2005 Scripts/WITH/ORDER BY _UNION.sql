USE master;
DROP DATABASE WithDB;
GO
CREATE DATABASE WithDB;
GO
USE WithDB;
CREATE TABLE dbo.AktueltAar 
(
	ID			INT NOT NULL IDENTITY PRIMARY KEY,
	Beloeb		INT NOT NULL
);

CREATE TABLE dbo.SidsteAar 
(
	ID			INT NOT NULL IDENTITY PRIMARY KEY,
	Beloeb		INT NOT NULL
);
	
CREATE TABLE dbo.HistoriskeAar 
(
	ID			INT NOT NULL IDENTITY PRIMARY KEY,
	Beloeb		INT NOT NULL
);
GO
INSERT INTO dbo.AktueltAar VALUES
	(20),
	(40),
	(50),
	(60);
	
INSERT INTO dbo.SidsteAar VALUES
	(30),
	(45),
	(15);
	
INSERT INTO dbo.HistoriskeAar VALUES
	(15),
	(25),
	(15),
	(40),
	(45);
GO
-- Top 2 Beloeb (st�rste) fra hver tabel
GO
SELECT TOP 2 *, 'A' AS Aar			-- syntaksfejl, kun ORDER BY p� sidste 
	FROM dbo.AktueltAar
	ORDER BY Beloeb	DESC
UNION ALL 
SELECT TOP 2 *, 'S' AS Aar
	FROM dbo.SidsteAar
	ORDER BY Beloeb	DESC
UNION ALL
SELECT TOP 2 *, 'H' AS Aar
	FROM dbo.HistoriskeAar
	ORDER BY Beloeb	DESC
GO
SELECT TOP 2 *, 'A' AS Aar			-- semantisk fejl, tager TOP 2 uden ORDER BY fra hver tabel
	FROM dbo.AktueltAar
UNION ALL 
SELECT TOP 2 *, 'S' AS Aar
	FROM dbo.SidsteAar
UNION ALL
SELECT TOP 2 *, 'H' AS Aar
	FROM dbo.HistoriskeAar
	ORDER BY Beloeb	DESC
GO
SELECT *
FROM 
	(SELECT TOP 2 *, 'A' AS Aar
		FROM dbo.AktueltAar
		ORDER BY Beloeb	DESC) AS A
UNION ALL
SELECT *
FROM 
	(SELECT TOP 2 *, 'S' AS Aar
		FROM dbo.SidsteAar
		ORDER BY Beloeb	DESC) AS S
UNION ALL
SELECT *
FROM
	(SELECT TOP 2 *, 'H' AS Aar
		FROM dbo.HistoriskeAar
		ORDER BY Beloeb	DESC) AS H;
GO
WITH 
A
AS
(SELECT TOP 2 *, 'A' AS Aar
	FROM dbo.AktueltAar
	ORDER BY Beloeb	DESC),
S
AS
(SELECT TOP 2 *, 'S' AS Aar
	FROM dbo.SidsteAar
	ORDER BY Beloeb	DESC),
H
AS
(SELECT TOP 2 *, 'H' AS Aar
	FROM dbo.HistoriskeAar
	ORDER BY Beloeb	DESC)

SELECT *
	FROM A
UNION ALL
SELECT *
	FROM S
UNION ALL
SELECT *
	FROM H;
