USE master
DROP DATABASE UnifeederDB
GO
CREATE DATABASE UnifeederDB
GO
USE UnifeederDB
CREATE TABLE Menu (
	Id				INT NOT NULL PRIMARY KEY,
	Navn			VARCHAR(20) NOT NULL,
	Parent			INT NOT NULL,
	Prioritet		INT NOT NULL)
GO
INSERT INTO Menu VALUES
	(1, 'm1', 0, 1),
	(2, 'm2', 0, 2),
	(3, 'm3', 1, 4),
	(4, 'm4', 1, 3),
	(5, 'm5', 2, 5),
	(6, 'm6', 3, 6),
	(7, 'm7', 5, 9),
	(8, 'm8', 5, 7),
	(9, 'm9', 5, 8),
	(10, 'm7', 8, 10),
	(11, 'm8', 8, 12),
	(12, 'm9', 8, 11)
GO
WITH MenuHierarki (Id, Navn, Parent, Prioritet, ParentStr)
AS
(
SELECT	Id, 
		Navn, 
		Parent, 
		Prioritet, 
		CAST('' AS VARCHAR(1000))AS ParentStr
	FROM Menu
	WHERE Parent = 0
UNION ALL
SELECT	Menu.Id, 
		Menu.Navn, 
		Menu.Parent, 
		Menu.Prioritet, 
		CAST(MenuHierarki.ParentStr + '/' + RIGHT('000000000' + CAST(MenuHierarki.Id AS VARCHAR(10)), 10) AS VARCHAR(1000)) AS ParentStr
	FROM Menu INNER JOIN  MenuHierarki ON Menu .Parent = MenuHierarki.ID
)
SELECT Id, Navn, Parent, Prioritet, ParentStr
	FROM MenuHierarki
	ORDER BY ParentStr ASC, Prioritet ASC