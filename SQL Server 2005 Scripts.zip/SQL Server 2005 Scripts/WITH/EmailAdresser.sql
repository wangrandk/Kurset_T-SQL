USE master;
DROP DATABASE WithDB;
GO
CREATE DATABASE WithDB;
GO
USE WithDB;
CREATE TABLE dbo.EMailAdresser 
(
	ID			INT NOT NULL PRIMARY KEY,
	Tekst		VARCHAR(8000) NOT NULL
)
GO
INSERT INTO dbo.EMailAdresser VALUES
	(1, 'a@abc.com;b@abc.com;c@abc.com  ;  d@abc.com;e@abc.com'),
	(2, 'a@abc.com;b@abc.com;d@abc.com;e@abc.com;
			m@abc.com'),
	(3, 'a@abc.com;c@abc.com;d@abc.com;e@abc.com;f@abc.com;m@abc.com;d@abc.com;');
GO
CREATE FUNCTION dbo.ufn_CharindexBlank 
(
	@SoegeTegn		VARCHAR(20), 
	@Tekst			VARCHAR(8000), 
	@Startpos		INT, 
	@SoegBlank		BIT
)
RETURNS INT
-- hvis SoegeTegn skal indeholde en blank, s�ttes @SoegBlank til TRUE/1 ellers s�ttes @SoegBlank Til FALSE/0
AS
BEGIN
	DECLARE @FoerstePos		INT;
	DECLARE @Stop			CHAR(1) = CHAR(200);	-- s�tter stopv�rdi til CHAR(200)
	DECLARE @fn_SoegeTegn	CHAR(21);
	DECLARE @fn_Tekst		VARCHAR(8000)

	SET @fn_Tekst = @Tekst + @Stop;

	IF	@SoegBlank = 'TRUE' AND
		(LEN(@SoegeTegn) = 0 OR
		 @SoegeTegn IS NULL)
		SET @fn_SoegeTegn = ' ' + @Stop;
	ELSE
		IF	@SoegBlank = 'FALSE' AND
			(LEN(@SoegeTegn) = 0 OR
			 @SoegeTegn IS NULL)
			SET @fn_SoegeTegn = @Stop;
		ELSE
			IF	@SoegBlank = 'TRUE' 
				SET @fn_SoegeTegn = @SoegeTegn + ' ' + @Stop;
			ELSE
				SET @fn_SoegeTegn = @SoegeTegn + @Stop;

	WITH FoerstePosPrTegn
	AS
	(
	SELECT	CHARINDEX(SUBSTRING(@fn_SoegeTegn, 1, 1), 
			@fn_Tekst + SUBSTRING(@fn_SoegeTegn, 1, 1), 
			@Startpos) AS Position, 
			1 AS PosSoegeTegn
	UNION ALL
	SELECT	CHARINDEX(SUBSTRING(@fn_SoegeTegn, PosSoegeTegn + 1, 1), 
			@fn_Tekst + SUBSTRING(@fn_SoegeTegn, PosSoegeTegn + 1, 1), 
			@Startpos), 
			PosSoegeTegn + 1
		FROM FoerstePosPrTegn 
		WHERE PosSoegeTegn < LEN(@fn_SoegeTegn)
	)
	SELECT @FoerstePos = MIN(Position)
		FROM FoerstePosPrTegn;

	RETURN @FoerstePos;
END;
GO
DECLARE @Soeg	VARCHAR(20) = ';';
DECLARE @Blank	BIT = 'FALSE';

WITH OrdListe
AS
(
SELECT	ID, 
		Tekst, 
		CAST(LTRIM(SUBSTRING(Tekst, 1,  dbo.ufn_CharindexBlank(@Soeg, Tekst, 1, @Blank) - 1)) AS VARCHAR(8000)) AS Ord, 
		dbo.ufn_CharindexBlank(@Soeg, Tekst, 1, @Blank) + 1 AS Startpos
	FROM dbo.EMailAdresser
UNION ALL
SELECT	ID, 
		Tekst, 
		LTRIM(SUBSTRING(Tekst, Startpos,  dbo.ufn_CharindexBlank(@Soeg, Tekst, Startpos, @Blank) - Startpos)), 
		dbo.ufn_CharindexBlank(@Soeg, Tekst, Startpos, @Blank) + 1
	FROM OrdListe
	WHERE Startpos < LEN(Tekst)
),
Resultat
AS
(
SELECT ID, REPLACE(REPLACE(REPLACE(Ord, CHAR(13), ''), CHAR(10), ''), CHAR(9), '') AS Ord
	FROM OrdListe
)
SELECT Id, Ord
	INTO dbo.Deltagere
	FROM Resultat
	ORDER BY ID;
GO
SELECT *
	FROM Deltagere;
GO
SELECT Ord
	FROM dbo.Deltagere
	WHERE ID = 1
INTERSECT
SELECT Ord
	FROM dbo.Deltagere
	WHERE ID = 2
INTERSECT
SELECT Ord
	FROM dbo.Deltagere
	WHERE ID = 3;
GO
SELECT Ord
	FROM dbo.Deltagere
	WHERE ID = 1
	GROUP BY Ord
	HAVING COUNT(*) > 1
UNION ALL
SELECT Ord
	FROM dbo.Deltagere
	WHERE ID = 2
	GROUP BY Ord
	HAVING COUNT(*) > 1
UNION ALL
SELECT Ord
	FROM dbo.Deltagere
	WHERE ID = 3
	GROUP BY Ord
	HAVING COUNT(*) > 1;
GO
SELECT Ord, COUNT(*) AS AntalArrangementer
	FROM (
		SELECT DISTINCT Ord, 1 AS Arrangement
			FROM dbo.Deltagere
			WHERE ID = 1
		UNION ALL
		SELECT DISTINCT Ord, 2 AS Arrangement
			FROM dbo.Deltagere
			WHERE ID = 2
		UNION ALL
		SELECT DISTINCT Ord, 3 AS Arrangement
			FROM dbo.Deltagere
			WHERE ID = 3) AS Deltagelse
	GROUP BY Ord
	HAVING COUNT(*) > 1;
