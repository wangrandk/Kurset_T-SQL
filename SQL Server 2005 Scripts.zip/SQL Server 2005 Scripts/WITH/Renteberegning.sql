USE master;
GO
DROP DATABASE WithDB;
GO
CREATE DATABASE WithDB;
GO
USE WithDB
GO
DECLARE @Beloeb			DECIMAL(9,2) = 100000;
DECLARE @MdRente		DECIMAL(9,2) = 1;
DECLARE @Afdrag			DECIMAL(9,2) = 1000;
DECLARE @F�rsteAfdrag	DATE = '2015-8-1';

WITH AfdragsListe
AS
(
SELECT	@F�rsteAfdrag AS Dato,
		@Beloeb AS LaaneBeloeb,
		CAST((@Beloeb - @Afdrag) + (@Beloeb - @Afdrag) / 100 * @MdRente AS DECIMAL(9,2)) AS RestBeloeb,
		@MdRente AS MaanedligRente,
		@Afdrag AS Afdrag,
		CAST((@Beloeb - @Afdrag) / 100 * @MdRente AS DECIMAL(9,2)) AS AccuRente,
		CAST((@Beloeb - @Afdrag) / 100 * @MdRente AS DECIMAL(9,2)) AS Rente
UNION ALL
SELECT	DATEADD(MONTH, 1, Dato),
		LaaneBeloeb,
		IIF(RestBeloeb > Afdrag, 
			CAST((RestBeloeb - Afdrag) + (RestBeloeb - Afdrag) / 100 * MaanedligRente AS DECIMAL(9,2)),
			0),
		MaanedligRente,
		IIF(RestBeloeb > Afdrag,
			Afdrag,
			RestBeloeb),
		IIF(RestBeloeb > Afdrag, 
			CAST(AccuRente + (RestBeloeb - Afdrag) / 100 * MaanedligRente AS DECIMAL(9,2)),
			AccuRente),
		IIF(RestBeloeb > Afdrag, 
			CAST((RestBeloeb - Afdrag) / 100 * MaanedligRente AS DECIMAL(9,2)),
			0)
	FROM AfdragsListe
	WHERE RestBeloeb > 0
)
SELECT *
	FROM AfdragsListe
	OPTION (MAXRECURSION 0);
