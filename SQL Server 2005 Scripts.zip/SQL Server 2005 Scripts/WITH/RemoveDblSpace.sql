USE master;
GO
DROP DATABASE WithDB;
GO
CREATE DATABASE WithDB;
GO
USE WithDB;
DECLARE @s	TABLE
(
	ID		INT				NOT NULL IDENTITY,
	s		VARCHAR(255)	 NOT NULL
);

INSERT INTO @s (s) VALUES
	('Ole Olsen'),
	('  Ida    Hansen'),
	('Carl Jensen'),
	('    Per     Knudsen    '),
	('   Ida     Marie      Pedersen '),
	('   Anne Larsen    ');	
	
WITH RemoveDblSpace 
AS
(
SELECT	ID, 
		LEN(LTRIM(RTRIM(s))) AS Laengde, 
		CAST(LTRIM(RTRIM(s)) AS VARCHAR(255))AS Data
	FROM @s
UNION ALL
SELECT	ID, 
		LEN(REPLACE(Data, '  ', ' ')), 
		CAST(REPLACE(Data, '  ', ' ') AS VARCHAR(255))
	FROM RemoveDblSpace
	WHERE CHARINDEX('  ', Data) > 0
)
SELECT	ID,
		Data	
	FROM RemoveDblSpace AS RDSOuter
	WHERE Laengde = (SELECT MIN(Laengde) 
					FROM RemoveDblSpace AS RDSInner
					WHERE RDSInner.ID = RDSOuter.ID)
	ORDER BY ID, Laengde DESC;
GO
-- Generel scalar 
CREATE FUNCTION dbo.ufn_RemoveString
(
	@s			VARCHAR(8000),
	@From		VARCHAR(100),
	@To			VARCHAR(100)
)
RETURNS VARCHAR(8000)
AS
BEGIN
	DECLARE @s_res		VARCHAR(8000);

	WITH Remove
	AS
	(
	SELECT	1 AS Nr, 
			CAST(LTRIM(RTRIM(@s)) AS VARCHAR(8000))AS Data
	UNION ALL
	SELECT	Nr + 1, 
			CAST(REPLACE(Data, @From, @To) AS VARCHAR(8000))
		FROM Remove
		WHERE CHARINDEX(@From, Data) > 0
	)
	SELECT	@s_res = Data
		FROM Remove AS RDSOuter
		WHERE Nr = (SELECT MAX(Nr) 
						FROM Remove AS RDSInner);
			
	RETURN @s_res;

END;
GO
DECLARE @s	TABLE
(
	ID		INT				NOT NULL IDENTITY,
	s		VARCHAR(255)	NOT NULL
);

INSERT INTO @s (s) VALUES
	('Ole Olsen'),
	('  Ida    Hansen'),
	('Carl Jensen'),
	('    Per     Knudsen    '),
	('   Ida     Marie      Pedersen '),
	('   Anne Larsen    ');

SELECT 
	*,
	dbo.ufn_RemoveString(s, '  ', ' ') AS Rettet_s
	FROM @s;
GO
DECLARE @s	TABLE
(
	ID		INT				NOT NULL IDENTITY,
	Tlf		VARCHAR(255)	NOT NULL
);

INSERT INTO @s (Tlf) VALUES
	('27111111'),
	('44 45 46 47'),
	('  431 12345 '),
	('6645 3423'),
	('7654   4329');

SELECT 
	ID,
	Tlf,
	LEN(Tlf) AS Len_Tlf,
	dbo.ufn_RemoveString(Tlf, ' ', '') AS Rettet_Tlf,
	LEN(dbo.ufn_RemoveString(Tlf, ' ', '')) AS Len_Rettet_Tlf
	FROM @s;
GO
DECLARE @s	TABLE
(
	ID			INT				NOT NULL IDENTITY,
	Cprnr		VARCHAR(255)	NOT NULL
);

INSERT INTO @s (Cprnr) VALUES
	('2711781328'),
	('271178-1328'),
	('271178 1328');

SELECT 
	ID,
	Cprnr,
	LEN(Cprnr) AS Len_Cprnr,
	dbo.ufn_RemoveString(Cprnr, '-', '') AS Rettet_Cprnr,
	LEN(dbo.ufn_RemoveString(Cprnr, '-', '')) AS Len_Rettet_Cprnr
	FROM @s;
GO
-- Generel table-values 
CREATE TYPE StrengTable AS TABLE 
(
		ID			INT				NOT NULL,
		Streng		VARCHAR(8000)	NOT NULL
);
GO
CREATE FUNCTION dbo.ufn_RemoveStringTable
(
	@s			StrengTable READONLY,
	@From		VARCHAR(100),
	@To			VARCHAR(100)
)
RETURNS @Res TABLE 
	(
		ID			INT NOT NULL,
		Streng		VARCHAR(8000)
	)
AS
BEGIN

	WITH RemoveStr
	AS
	(
	SELECT	ID, 
			1 AS Nr, 
			CAST(LTRIM(RTRIM(Streng)) AS VARCHAR(8000))AS Data
		FROM @s
	UNION ALL
	SELECT	ID, 
			Nr + 1, 
			CAST(REPLACE(Data, @From, @To) AS VARCHAR(8000))
		FROM RemoveStr
		WHERE CHARINDEX(@From, Data) > 0
	)
	INSERT INTO @Res
	SELECT	ID,
			Data
		FROM RemoveStr AS RDSOuter
		WHERE Nr = (SELECT MAX(Nr) 
						FROM RemoveStr AS RDSInner
						WHERE RDSInner.ID = RDSOuter.ID);

	RETURN;
END;
GO
DECLARE @Data	StrengTable;

INSERT INTO @Data (Id, Streng) VALUES
	(1, 'Ole Olsen'),
	(2, '  Ida    Hansen'),
	(3, 'Carl Jensen'),
	(4, '    Per     Knudsen    '),
	(5, '   Ida     Marie      Pedersen '),
	(6, '   Anne Larsen    ');

SELECT *
	FROM dbo.ufn_RemoveStringTable(@Data, '  ', ' ') AS Res;

SELECT *
	FROM dbo.ufn_RemoveStringTable(@Data, '  ', ' ') AS Res INNER JOIN @Data AS d ON Res.Id = d.ID;
GO
DECLARE @Data	StrengTable;

INSERT INTO @Data (Id, Streng) VALUES
	(1, '27111111'),
	(2, '44 45 46 47'),
	(3, '  431 12345 '),
	(4, '6645 3423'),
	(5, '7654   4329');

SELECT *
	FROM dbo.ufn_RemoveStringTable(@Data, ' ', '') AS Res;

SELECT *
	FROM dbo.ufn_RemoveStringTable(@Data, ' ', '') AS Res INNER JOIN @Data AS d ON Res.Id = d.ID;
GO
DECLARE @Data	StrengTable;

INSERT INTO @Data (Id, Streng) VALUES
	(1, '2711781328'),
	(2, '271178-1328'),
	(3, '271178 1328');

SELECT *
	FROM dbo.ufn_RemoveStringTable(@Data, '-', '') AS Res;

SELECT *
	FROM dbo.ufn_RemoveStringTable(@Data, '-', '') AS Res INNER JOIN @Data AS d ON Res.Id = d.ID;
