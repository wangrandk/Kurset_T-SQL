USE master
DROP DATABASE TestDB
GO
CREATE DATABASE TestDB
GO
USE TestDB
GO
CREATE TABLE TC27(
	SchID		INT IDENTITY PRIMARY KEY,
	Patient		INT,
	Nurse		INT,
	dy			CHAR(3),
	St			CHAR(4),
	En			CHAR(4)
)

INSERT INTO TC27( Patient, Nurse, dy, st, en)
SELECT 2000, 201, 'Mon', '0800', '2000' UNION ALL
SELECT 2000, 201, 'Tue', '0800', '2000' UNION ALL
SELECT 2000, 201, 'Wed', '0800', '2000' UNION ALL
SELECT 2001, 202, 'Mon', '1900', '0800' UNION ALL
SELECT 2001, 201, 'Tue', '1900', '0800' UNION ALL
SELECT 2001, 202, 'Wed', '1900', '0800' UNION ALL
SELECT 2002, 203, 'Mon', '0800', '2000' UNION ALL
SELECT 2002, 203, 'Tue', '2000', '0800' UNION ALL
SELECT 2002, 201, 'Wed', '2000', '0830' UNION ALL
SELECT 2004, 205, 'Thu', '1000', '1600' UNION ALL
SELECT 2004, 205, 'Fri', '1000', '1600' UNION ALL
SELECT 2004, 205, 'Sat', '1000', '1600' UNION ALL
SELECT 2004, 205, 'Sun', '1000', '1600' UNION ALL
SELECT 2002, 201, 'Thu', '0800', '2000' UNION ALL
SELECT 2006, 205, 'Sat', '1200', '1400' UNION ALL
SELECT 2007, 205, 'Fri', '0800', '1100' UNION ALL
SELECT 2002, 203, 'Fri', '0800', '2000' 
GO
WITH 
DayOfWeek (DayName, DayNo)
AS
(
SELECT DayName, DayNo
	FROM (VALUES	('Mon', 1), 
					('Tue', 2), 
					('Wed', 3), 
					('Thu', 4),
					('Fri', 5), 
					('Sat', 6),
					('Sun', 7)) AS DayOfWeek(DayName, DayNo) 
),
Data
AS
(
SELECT	SchID, Patient, Nurse, dy, St, En,
		CAST(St AS INT) + (DayNo - 1) * 2400 AS St_Num, 
		CASE 
			WHEN St < En THEN CAST(En AS INT) + (DayNo - 1) * 2400		-- Same day (DayNo - 1)
			ELSE CAST(En AS INT) + (DayNo) * 2400						-- Next day (DayNo)
		END AS En_Num
	FROM TC27 INNER JOIN DayOfWeek ON TC27.dy = DayOfWeek.DayName
),
Overlap
AS
(
SELECT	*, 
		(SELECT TOP 1 SchID
				FROM Data AS DataInner
				WHERE	DataOuter.Nurse = DataInner.Nurse AND
						DataOuter.SchID <> DataInner.SchID AND
						
						((DataOuter.St_Num > DataInner.St_Num AND 
						 DataOuter.St_Num < DataInner.En_Num) OR
						 
						(DataOuter.St_Num = DataInner.St_Num AND		
						 DataOuter.En_Num > DataInner.En_Num))
						 
				ORDER BY DataInner.St_Num, En_Num DESC) AS DataOverlappingSchID	
	FROM Data AS DataOuter
),
Overlap_Yes_No
AS
(
SELECT	SchID, Patient, Nurse, dy, St, En, St_Num, En_Num,
		CASE				-- this is for rule 5
			WHEN DataOverlappingSchID IS NULL THEN 'No'
			WHEN EXISTS (SELECT * 
							FROM Overlap 
							WHERE	OverlapResult.DataOverlappingSchId = Overlap.SchID AND 
									OverlapResult.DataOverlappingSchID <> Overlap.DataOverlappingSchID) THEN 'No'
			ELSE 'Yes'
		END AS DataOverlapping
	FROM Overlap AS OverlapResult
)
SELECT SchID, Patient, Nurse, dy, St, En, DataOverlapping
	FROM Overlap_Yes_No
	ORDER BY Nurse, St_Num, En_Num
GO
--SchID	Patient	Nurse	dy	St	En	DataOverlapping
--1		2000	201	Mon	0800	2000	No
--2		2000	201	Tue	0800	2000	No
--5		2001	201	Tue	1900	0800	Yes
--3		2000	201	Wed	0800	2000	No
--9		2002	201	Wed	2000	0830	No
--14	2002	201	Thu	0800	2000	Yes
--4		2001	202	Mon	1900	0800	No
--6		2001	202	Wed	1900	0800	No
--7		2002	203	Mon	0800	2000	No
--8		2002	203	Tue	2000	0800	No
--17	2002	203	Fri	0800	2000	No
--10	2004	205	Thu	1000	1600	No
--16	2007	205	Fri	0800	1100	No
--11	2004	205	Fri	1000	1600	Yes
--12	2004	205	Sat	1000	1600	No
--15	2006	205	Sat	1200	1400	Yes
--13	2004	205	Sun	1000	1600	No

-- additional testdata
INSERT INTO TC27( Patient, Nurse, dy, st, en)
SELECT 3001, 203, 'Fri', '2000', '2200'	UNION ALL		-- Rule 1

SELECT 3002, 205, 'Sat', '1300', '2000'	UNION ALL		-- Rule 5 overlap with both the first and the second

SELECT 3003, 205, 'Fri', '1400', '2200'	UNION ALL		-- Rule 5 no overlap with the first on Fri only with the second, 
														-- which have overlap with the first

SELECT 3004, 206, 'Fri', '0800', '2000'	UNION ALL		-- Rule 5 the folling 2 rows has overlap with this
SELECT 3004, 206, 'Fri', '1400', '1600'	UNION ALL		-- Rule 5 overlap with the first
SELECT 3004, 206, 'Fri', '1700', '1900'	UNION ALL		-- Rule 5 overlap with the first both not the second

SELECT 3005, 201, 'Mon', '0800', '1900'					-- Rule 9

--SchID	Patient	Nurse	dy	St	En	DataOverlapping
--24	3005	201	Mon	0800	1900	No
--1		2000	201	Mon	0800	2000	Yes
--2		2000	201	Tue	0800	2000	No
--5		2001	201	Tue	1900	0800	Yes
--3		2000	201	Wed	0800	2000	No
--9		2002	201	Wed	2000	0830	No
--14	2002	201	Thu	0800	2000	Yes
--4		2001	202	Mon	1900	0800	No
--6		2001	202	Wed	1900	0800	No
--7		2002	203	Mon	0800	2000	No
--8		2002	203	Tue	2000	0800	No
--17	2002	203	Fri	0800	2000	No
--18	3001	203	Fri	2000	2200	No
--10	2004	205	Thu	1000	1600	No
--16	2007	205	Fri	0800	1100	No
--11	2004	205	Fri	1000	1600	Yes
--20	3003	205	Fri	1400	2200	No
--12	2004	205	Sat	1000	1600	No
--15	2006	205	Sat	1200	1400	Yes
--19	3002	205	Sat	1300	2000	Yes
--13	2004	205	Sun	1000	1600	No
--21	3004	206	Fri	0800	2000	No
--22	3004	206	Fri	1400	1600	Yes
--23	3004	206	Fri	1700	1900	Yes
