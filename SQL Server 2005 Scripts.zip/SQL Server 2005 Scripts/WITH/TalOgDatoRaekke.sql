DECLARE @Stop INT = 1000;

WITH 
Talraekke (Tal)
AS
(
 SELECT 1 AS Tal
 UNION ALL
 SELECT Tal + 1
	FROM Talraekke
	WHERE Tal < @Stop
)
SELECT *
	FROM Talraekke
	OPTION (MAXRECURSION 1000); 
GO
USE Testdb;
GO
CREATE TABLE dbo.Tid 
(
	Id			INT			NOT NULL IDENTITY,
	Dato		DATE		NOT NULL,
	Aar			AS YEAR(Dato),
	Md			AS MONTH(Dato),
	Dag			AS DAY(Dato)
);
GO
WITH 
Datoeraekke (Dato)
AS
(
 SELECT CAST('2000-01-01' AS Date) AS Dato
 UNION ALL
 SELECT DATEADD(DAY, 1, Dato)
	FROM Datoeraekke
	WHERE Dato < SYSDATETIME()
)
INSERT INTO Tid(Dato)
	SELECT Dato
		FROM Datoeraekke
		OPTION (MAXRECURSION 9000); 
	
SELECT * 
	from dbo.Tid
GO
WITH 
Datoeraekke (Dato)
AS
(
 SELECT CAST('2000-01-01' AS Date) AS Dato
 UNION ALL
 SELECT DATEADD(DAY, 1, Dato)
	FROM Datoeraekke
	WHERE Dato < DATEADD(YEAR, 1, SYSDATETIME())
)
SELECT Dato
	FROM Datoeraekke
	OPTION (MAXRECURSION 9000); 