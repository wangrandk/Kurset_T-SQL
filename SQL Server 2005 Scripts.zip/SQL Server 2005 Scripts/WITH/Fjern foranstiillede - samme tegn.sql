USE master;
GO
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
USE TestDB;
GO
CREATE TABLE dbo.t 
(
	String VARCHAR(MAX)	
);
GO
INSERT INTO dbo.t (String) VALUES
	('X8JXab'),
	('999744499XYZ'),
	('BBBBBBBBBBBBBBBA'),
	('AAAAAAAAAAAAAAAA'),
	('aaaaaaaaAAAA'),
	('*******67.50');
GO
SELECT * 
	FROM dbo.t;
GO 
WITH RemoveLeadingChar (ID, RemoveChar, String)
AS
(
SELECT	ROW_NUMBER () OVER (ORDER BY String) AS ID, 
		LEFT(String, 1) COLLATE SQL_Latin1_General_CP1_CS_AS AS RemoveChar, 
		String COLLATE SQL_Latin1_General_CP1_CS_AS
	FROM dbo.t
UNION ALL
SELECT	ID, 
		RemoveChar, 
		SUBSTRING(String, 2, LEN(String) - 1)
	FROM RemoveLeadingChar
	WHERE LEFT(String,1) = RemoveChar AND LEN(String) > 1
)
SELECT String
	FROM RemoveLeadingChar AS RLCResult
	WHERE LEN(String) = (SELECT MIN(LEN(String)) 
							FROM RemoveLeadingChar AS RLC 
							WHERE RLC.ID = RLCResult.ID)
	ORDER BY String;
