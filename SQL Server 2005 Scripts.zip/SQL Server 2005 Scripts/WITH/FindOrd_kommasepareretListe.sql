USE master;
DROP DATABASE WithDB;
GO
CREATE DATABASE WithDB;
GO
USE WithDB;
CREATE TABLE dbo.t 
(
	ID			INT				NOT NULL PRIMARY KEY,
	Tekst		VARCHAR(8000)	NOT NULL
)
GO
INSERT INTO dbo.t VALUES
	(1, 'alfa, beta!gamma,delta,epsylon'),
	(2, 'alfa, beta'),
	(3, 'alfa; beta');
GO
WITH Ord
AS
(
SELECT	ID, 
		Tekst + ',' AS Tekst, 
		CAST('' AS VARCHAR(8000)) AS Ord, 
		0 AS Startpos
	FROM t
UNION ALL
SELECT	ID, 
		Tekst, 
		LTRIM(SUBSTRING(Tekst, Startpos, CHARINDEX(',', Tekst, Startpos) - Startpos)), 
		CHARINDEX(',', Tekst, Startpos) + 1
	FROM Ord
	WHERE CHARINDEX(',', Tekst, Startpos + 1) > 0
)
SELECT *, LEN(ord)
	FROM Ord
	WHERE Startpos > 0;
GO
CREATE FUNCTION dbo.ufn_Charindex 
(
	@SoegeTegn VARCHAR(20), 
	@Tekst VARCHAR(8000), 
	@Startpos INT
)
RETURNS INT
-- hvis SoegeTegn indeholder en blank skal der altid v�re et andet tegn bagefter i SoegeTegn
AS
BEGIN
	DECLARE @FoerstePos		INT;

	WITH FoerstePosPrTegn
	AS
	(
	SELECT	CHARINDEX(SUBSTRING(@SoegeTegn, 1, 1), 
			@Tekst + SUBSTRING(@SoegeTegn, 1, 1), 
			@Startpos) AS Position, 
			1 AS PosSoegeTegn
	UNION ALL
	SELECT	CHARINDEX(SUBSTRING(@SoegeTegn, PosSoegeTegn + 1, 1), 
			@Tekst + SUBSTRING(@SoegeTegn, PosSoegeTegn + 1, 1), 
			@Startpos), 
			PosSoegeTegn + 1
		FROM FoerstePosPrTegn
		WHERE LEN(@SoegeTegn) > PosSoegeTegn
	)
	SELECT @FoerstePos = MIN(Position)
		FROM FoerstePosPrTegn;

	RETURN @FoerstePos;
END;
GO
DECLARE @Soeg VARCHAR(20) = ',;!';

WITH Ord
AS
(
SELECT	ID, 
		Tekst AS Tekst, 
		CAST(LTRIM(SUBSTRING(Tekst, 0,  dbo.ufn_Charindex(@Soeg, Tekst, 0))) AS VARCHAR(8000)) AS Ord, 
		dbo.ufn_Charindex(@Soeg, Tekst, 0) + 1 AS Startpos
	FROM dbo.t
UNION ALL
SELECT	ID, 
		Tekst, 
		LTRIM(SUBSTRING(Tekst, Startpos,  dbo.ufn_Charindex(@Soeg, Tekst, Startpos) - Startpos)), 
		dbo.ufn_Charindex(@Soeg, Tekst, Startpos) + 1
	FROM Ord
	WHERE  dbo.ufn_Charindex(@Soeg, Tekst, Startpos + 1) > 0
)
SELECT *, LEN(ord)
	FROM Ord;
GO
TRUNCATE TABLE dbo.t;
GO
INSERT INTO dbo.t VALUES
	(1, 'Carsten Saastamoinen-Jakobsen'),
	(2, 'Jens Ole Hansen'),
	(3, 'Petersen, Ida'),
	(4, 'Knudsen, Louise Marie Sofie');
GO
DECLARE @Soeg VARCHAR(20) = ' ,-';

WITH Ord
AS
(
SELECT	ID, 
		Tekst AS Tekst, 
		CAST(LTRIM(SUBSTRING(Tekst, 0,  dbo.ufn_Charindex(@Soeg, Tekst, 0))) AS VARCHAR(8000)) AS Ord, 
		dbo.ufn_Charindex(@Soeg, Tekst, 0) + 1 AS Startpos
	FROM dbo.t
UNION ALL
SELECT	ID, 
		Tekst, 
		LTRIM(SUBSTRING(Tekst, Startpos,  dbo.ufn_Charindex(@Soeg, Tekst, Startpos) - Startpos)), 
		dbo.ufn_Charindex(@Soeg, Tekst, Startpos) + 1
	FROM Ord
	WHERE  dbo.ufn_Charindex(@Soeg, Tekst, Startpos + 1) > 0
)
SELECT *, LEN(ord)
	FROM Ord
	WHERE LEN(Ord) > 0
	ORDER BY ID, Startpos;
GO
CREATE FUNCTION dbo.ufn_CharindexBlank (@SoegeTegn VARCHAR(20), @Tekst VARCHAR(8000), @Startpos INT, @SoegBlank BIT)
RETURNS INT
-- hvis SoegeTegn skal indeholde en blank, s�ttes i stedet @SoegBlank til TRUE/1 ellers s�ttes @SoegBlank Til FALSE/0
AS
BEGIN
	DECLARE @FoerstePos		INT;
	DECLARE @Stop			CHAR(1) = CHAR(200);
	DECLARE @fn_SoegeTegn	CHAR(21);
	DECLARE @fn_Tekst		VARCHAR(8000)

	SET @fn_Tekst = @Tekst + @Stop;

	IF	@SoegBlank = 'TRUE' AND
		(LEN(@SoegeTegn) = 0 OR
		 @SoegeTegn IS NULL)
		SET @fn_SoegeTegn = ' ' + @Stop;
	ELSE
		IF	@SoegBlank = 'FALSE' AND
			(LEN(@SoegeTegn) = 0 OR
			 @SoegeTegn IS NULL)
			SET @fn_SoegeTegn = @Stop;
		ELSE
			IF	@SoegBlank = 'TRUE' 
				SET @fn_SoegeTegn = @SoegeTegn + ' ' + @Stop;
			ELSE
				SET @fn_SoegeTegn = @SoegeTegn + @Stop;

	WITH FoerstePosPrTegn
	AS
	(
	SELECT	CHARINDEX(SUBSTRING(@fn_SoegeTegn, 1, 1), 
			@fn_Tekst + SUBSTRING(@fn_SoegeTegn, 1, 1), 
			@Startpos) AS Position, 
			1 AS PosSoegeTegn
	UNION ALL
	SELECT	CHARINDEX(SUBSTRING(@fn_SoegeTegn, PosSoegeTegn + 1, 1), 
			@fn_Tekst + SUBSTRING(@fn_SoegeTegn, PosSoegeTegn + 1, 1), 
			@Startpos), 
			PosSoegeTegn + 1
		FROM FoerstePosPrTegn 
		WHERE PosSoegeTegn < LEN(@fn_SoegeTegn)
	)
	SELECT @FoerstePos = MIN(Position)
		FROM FoerstePosPrTegn;

	RETURN @FoerstePos;
END;
GO
DECLARE @Soeg	VARCHAR(20) = '';
DECLARE @Blank	BIT = 'TRUE';

WITH Ord
AS
(
SELECT	ID, 
		Tekst, 
		CAST(LTRIM(SUBSTRING(Tekst, 1,  dbo.ufn_CharindexBlank(@Soeg, Tekst, 1, @Blank) - 1)) AS VARCHAR(8000)) AS Ord, 
		dbo.ufn_CharindexBlank(@Soeg, Tekst, 1, @Blank) + 1 AS Startpos
	FROM dbo.t
UNION ALL
SELECT	ID, 
		Tekst, 
		LTRIM(SUBSTRING(Tekst, Startpos,  dbo.ufn_CharindexBlank(@Soeg, Tekst, Startpos, @Blank) - Startpos)), 
		dbo.ufn_CharindexBlank(@Soeg, Tekst, Startpos, @Blank) + 1
	FROM Ord
	WHERE Startpos < LEN(Tekst)
)
SELECT *, LEN(ord), @Soeg, @Blank
	FROM Ord
	ORDER BY ID, Startpos;
GO
DECLARE @Soeg	VARCHAR(20) = '';
DECLARE @Blank	BIT = 'FALSE';

WITH Ord
AS
(
SELECT	ID, 
		Tekst, 
		CAST(LTRIM(SUBSTRING(Tekst, 1,  dbo.ufn_CharindexBlank(@Soeg, Tekst, 1, @Blank) - 1)) AS VARCHAR(8000)) AS Ord, 
		dbo.ufn_CharindexBlank(@Soeg, Tekst, 1, @Blank) + 1 AS Startpos
	FROM dbo.t
UNION ALL
SELECT	ID, 
		Tekst, 
		LTRIM(SUBSTRING(Tekst, Startpos,  dbo.ufn_CharindexBlank(@Soeg, Tekst, Startpos, @Blank) - Startpos)), 
		dbo.ufn_CharindexBlank(@Soeg, Tekst, Startpos, @Blank) + 1
	FROM Ord
	WHERE Startpos < LEN(Tekst)
)
SELECT *, LEN(ord), @Soeg, @Blank
	FROM Ord
	ORDER BY ID, Startpos;
GO
DECLARE @Soeg	VARCHAR(20) = '-,';
DECLARE @Blank	BIT = 'FALSE';

WITH Ord
AS
(
SELECT	ID, 
		Tekst, 
		CAST(LTRIM(SUBSTRING(Tekst, 1,  dbo.ufn_CharindexBlank(@Soeg, Tekst, 1, @Blank) - 1)) AS VARCHAR(8000)) AS Ord, 
		dbo.ufn_CharindexBlank(@Soeg, Tekst, 1, @Blank) + 1 AS Startpos
	FROM dbo.t
UNION ALL
SELECT	ID, 
		Tekst, 
		LTRIM(SUBSTRING(Tekst, Startpos,  dbo.ufn_CharindexBlank(@Soeg, Tekst, Startpos, @Blank) - Startpos)), 
		dbo.ufn_CharindexBlank(@Soeg, Tekst, Startpos, @Blank) + 1
	FROM Ord
	WHERE Startpos < LEN(Tekst)
)
SELECT *, LEN(ord), @Soeg, @Blank
	FROM Ord
	ORDER BY ID, Startpos;
GO
INSERT INTO dbo.t VALUES
	(5, 'SQL Server 2008 R2 introduces a range of new capabilities to help businesses of all 
	 sizes derive more value from information. Built on improvements in previous versions, SQL Server 2008 R2 adds even greater 
	 capabilities in development, manageability, BI, and data warehousing.');
GO
DECLARE @Soeg	VARCHAR(20) = '-,.' + CHAR(13);
DECLARE @Blank	BIT = 'TRUE';

WITH Ord
AS
(
SELECT	ID, 
		Tekst, 
		CAST(LTRIM(SUBSTRING(Tekst, 1,  dbo.ufn_CharindexBlank(@Soeg, Tekst, 1, @Blank) - 1)) AS VARCHAR(8000)) AS Ord, 
		dbo.ufn_CharindexBlank(@Soeg, Tekst, 1, @Blank) + 1 AS Startpos
	FROM dbo.t
UNION ALL
SELECT	ID, 
		Tekst, 
		LTRIM(SUBSTRING(Tekst, Startpos,  dbo.ufn_CharindexBlank(@Soeg, Tekst, Startpos, @Blank) - Startpos)), 
		dbo.ufn_CharindexBlank(@Soeg, Tekst, Startpos, @Blank) + 1
	FROM Ord
	WHERE Startpos < LEN(Tekst)
)
SELECT *, LEN(ord), @Soeg, @Blank
	FROM Ord
	ORDER BY ID, Startpos;
