USE master;
DROP DATABASE WithDB;
GO
CREATE DATABASE WithDB;
GO
USE WithDB;
GO
WITH 
AktuelleDatoer (Dato)
AS (
SELECT Dato
	FROM (VALUES	(CAST('2010-11-1'  AS DATE)),
					(CAST('2010-11-2'  AS DATE)),
					(CAST('2010-11-4'  AS DATE)),
					(CAST('2010-11-5'  AS DATE)),
					(CAST('2010-11-11' AS DATE)),
					(CAST('2010-11-14' AS DATE)),
					(CAST('2010-11-25' AS DATE)),
					(CAST('2010-11-30' AS DATE)) ) AS Datoer(Dato)
)
SELECT *
	INTO dbo.AktuelleDatoer
	FROM AktuelleDatoer;
GO
SELECT *
	FROM dbo.AktuelleDatoer;
GO
SET STATISTICS TIME ON;
GO
WITH
Mindato
AS
(SELECT MIN(Dato) AS Dato
	FROM dbo.AktuelleDatoer
),
Maxdato
AS
(SELECT MAX(Dato) AS Dato
	FROM dbo.AktuelleDatoer
),
Datoraekke (Dato)
AS
(SELECT *
	FROM MinDato
 UNION ALL
 SELECT DATEADD(DAY, 1, Dato) AS Dato
	FROM Datoraekke
	WHERE Dato < (SELECT Dato FROM MaxDato)
)
SELECT *
	FROM Datoraekke
EXCEPT
SELECT *
	FROM dbo.AktuelleDatoer
	ORDER BY Dato
OPTION (MAXRECURSION 0);
GO
WITH
MaxDato
AS
(
SELECT MAX(Dato) AS Dato
	FROM dbo.AktuelleDatoer
),
Datoraekke (Dato)
AS
(
SELECT DATEADD(d, 1, AdY.Dato) AS Dato
	FROM dbo.AktuelleDatoer AS AdY
	WHERE NOT EXISTS (
			SELECT *
				FROM dbo.AktuelleDatoer AS AdI
				WHERE	Ady.Dato = DATEADD(d, -1, AdI.Dato)) AND
		 AdY.Dato < (SELECT Dato FROM MaxDato)
UNION ALL
SELECT DATEADD(d, 1, Dato) AS Dato
	FROM Datoraekke AS AdY
	WHERE NOT EXISTS (
			SELECT *
				FROM dbo.AktuelleDatoer AS AdI
				WHERE	DATEADD(d, 1, Ady.Dato) = AdI.Dato) AND
						AdY.Dato < (SELECT Dato FROM MaxDato)	
)
SELECT *
	FROM Datoraekke
	ORDER BY Dato
	OPTION (MAXRECURSION 0);

SET STATISTICS TIME OFF;
