USE master;
GO
DROP DATABASE RecursiveDB1;
DROP DATABASE RecursiveDB2;
GO
CREATE DATABASE RecursiveDB1;
CREATE DATABASE RecursiveDB2;
GO
USE RecursiveDB1;
CREATE TABLE dbo.t 
(
	Id				INT NOT NULL PRIMARY KEY,
	IdRef			INT NULL
)
GO
USE RecursiveDB2;
CREATE TABLE dbo.t 
(
	Id				INT NOT NULL PRIMARY KEY,
	IdRef			INT NULL,
	OprindeligID	INT NOT NULL
)
GO
USE RecursiveDB1;
INSERT INTO dbo.t VALUES
	(1, NULL),
	(2, 1),
	(3, 1),
	(4, 1),
	(5, 2),
	(6, 2),
	(7, 3),
	(8, 3),
	(9, 3);
GO
USE RecursiveDB2;
INSERT INTO t VALUES
	(100, 1, 3),
	(101, 100, 8);
GO
DECLARE @Id		INT = 100;

WITH 
Virtuel_t (Id, IdRef, OprindeligId)
AS
(SELECT Id, IdRef, NULL AS OprindeligId FROM RecursiveDB1.dbo.t
 UNION
 SELECT Id, IdRef, OprindeligId FROM RecursiveDB2.dbo.t
),

Recursive_t (Id, IdRef, OprindeligId)
AS
(SELECT Id, IdRef, NULL AS OprindeligID FROM RecursiveDB1.dbo.t WHERE Id = @Id
 UNION 
 SELECT Id, IdRef, OprindeligId FROM RecursiveDB2.dbo.t WHERE Id = @Id
 UNION ALL
 SELECT Virtuel_t.*
	FROM Virtuel_t INNER JOIN Recursive_t ON Recursive_t.IdRef = Virtuel_t.Id
),
Resultat
AS
(
SELECT * 
	FROM Recursive_t)

SELECT *
	FROM Resultat;
