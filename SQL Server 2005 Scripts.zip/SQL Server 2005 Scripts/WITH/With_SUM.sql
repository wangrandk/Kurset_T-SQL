USE master;
DROP DATABASE WithDB;
GO
CREATE DATABASE WithDB;
GO
USE WithDB
CREATE TABLE dbo.Medarbejder 
(
	MedarbejderId		INT			NOT NULL						
						CONSTRAINT PK_Medarbejder PRIMARY KEY,
	Navn				VARCHAR(20) NOT NULL,
	AfdelingsId			CHAR(1)		NOT NULL,
	Beloeb				INT			NOT NULL, 
	ChefId				INT			NULL
						CONSTRAINT FK_Medarbejder_Chef 
						FOREIGN KEY REFERENCES Medarbejder(MedarbejderId)
);
GO
SET NOCOUNT ON;

INSERT INTO dbo.Medarbejder VALUES
	(1,  'Anne',  'A', 0, NULL),
	(2,  'Ole',   'B', 200, 1),
	(3,  'Per',   'C', 150, 1),
	(4,  'Sanne', 'D', 100, 1),
	(5,  'Kurt',  'B', 400, 2),
	(6,  'Poul',  'B', 500, 2),
	(7,  'Kamma', 'B', 350, 5),
	(8,  'Hans',  'B', 400, 5),
	(9,  'Irene', 'B', 500, 5),
	(10, 'Lotte', 'D', 200, 4),
	(11, 'Lars',  'D', 300, 4),
	(12, 'Vivi',  'D', 400, 2),
	(13, 'Sofus', 'E', 200, 11),
	(14, 'Lilly',  'E', 400, 12),
	(15, 'Johan',  'E', 300, 11);

SET NOCOUNT OFF;
GO
DECLARE @MedarbejderId	INT = 1;

WITH 
MedarbejderCTE (MedarbejderId, Navn, ChefId, Niveau, Beloeb, Level)
AS
(SELECT		MedarbejderId, 
			Navn, 
			ChefId, 
			CAST(RIGHT('00000' + CAST(Medarbejder.MedarbejderId AS VARCHAR(5)), 5) AS VARCHAR(500)) AS Niveau,
			Beloeb,
			1 AS Level
	FROM dbo.Medarbejder
	WHERE MedarbejderId = @MedarbejderId
 UNION ALL
 SELECT		Medarbejder.
			MedarbejderId, 
			Medarbejder.Navn,  
			Medarbejder.ChefId,
			CAST(Niveau + RIGHT('00000' + CAST(Medarbejder.MedarbejderId AS VARCHAR(5)), 5) AS VARCHAR(500)) AS Niveau,
			dbo.Medarbejder.Beloeb,
			Level + 1
	FROM dbo.Medarbejder INNER JOIN MedarbejderCTE
		ON Medarbejder.ChefId = MedarbejderCTE.MedarbejderId
),
Hierarki
AS
(SELECT	*, 
		REPLICATE(' ', 	LEN(Niveau) - 5) +  Navn AS HierarkiStruktur
	FROM MedarbejderCTE
)

SELECT	*,
		RIGHT('00000' + CAST(MedarbejderId AS VARCHAR(5)), 5) AS u,
		SUBSTRING(Y_hi.Niveau, ((Y_hi.Level - 1) *  5) + 1, 5) AS x,
		(SELECT SUM(Beloeb) AS y
			FROM Hierarki AS I_hi
			WHERE  RIGHT('00000' + CAST(Y_hi.MedarbejderId AS VARCHAR(5)), 5) = SUBSTRING(I_hi.Niveau, ((Y_hi.Level - 1) *  5) + 1, 5)) AS SumUnderordnede
	FROM Hierarki AS Y_hi
	ORDER BY Niveau;
GO
DECLARE @MedarbejderId	INT = 1;

WITH 
MedarbejderCTE (MedarbejderId, Navn, ChefId, Niveau, Beloeb, Level)
AS
(SELECT		MedarbejderId, 
			Navn, 
			ChefId, 
			CAST(RIGHT('00000' + CAST(Medarbejder.MedarbejderId AS VARCHAR(5)), 5) AS VARCHAR(500)) AS Niveau,
			Beloeb,
			1 AS Level
	FROM dbo.Medarbejder
	WHERE MedarbejderId = @MedarbejderId
 UNION ALL
 SELECT		Medarbejder.MedarbejderId, 
			Medarbejder.Navn,  
			Medarbejder.ChefId,
			CAST(Niveau + RIGHT('00000' + CAST(Medarbejder.MedarbejderId AS VARCHAR(5)), 5) AS VARCHAR(500)) AS Niveau,
			dbo.Medarbejder.Beloeb,
			Level + 1
	FROM dbo.Medarbejder INNER JOIN MedarbejderCTE
		ON Medarbejder.ChefId = MedarbejderCTE.MedarbejderId
),
Hierarki
AS
(SELECT	*, 
		REPLICATE(' ', 	(Level * 3)) +  Navn AS HierarkiStruktur,
		(SELECT COUNT(*) 
			FROM MedarbejderCTE AS I_Med
			WHERE I_med.Chefid = Y_Med.MedarbejderId) AS AntalDirekteUnderordnede
	FROM MedarbejderCTE AS Y_Med
)

SELECT	*,
--		RIGHT('00000' + CAST(dbo.MedarbejderId AS VARCHAR(5)), 5) AS u,
--		SUBSTRING(Y_hi.Niveau, ((Y_hi.Level - 1)  * 5) + 1, 5) AS x,
		(SELECT SUM(Beloeb) AS y
			FROM Hierarki AS I_hi
			WHERE  RIGHT('00000' + CAST(Y_hi.MedarbejderId AS VARCHAR(5)), 5) = SUBSTRING(I_hi.Niveau, ((Y_hi.Level - 1)  * 5) + 1, 5)) AS SumUnderordnede
	FROM Hierarki AS Y_hi
UNION ALL
SELECT	MedarbejderId,
		Navn + ' - egenprod',
		ChefId,
		Niveau,
		Beloeb,
		Level + 1,
		'   ' + HierarkiStruktur,
		AntalDirekteUnderordnede,
		Beloeb
	FROM Hierarki
	WHERE Hierarki.AntalDirekteUnderordnede > 0
	ORDER BY Niveau;
