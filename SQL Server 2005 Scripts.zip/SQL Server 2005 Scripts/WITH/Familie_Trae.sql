USE master;
GO
IF EXISTS(SELECT * 
            FROM sys.databases 
			WHERE name = 'FamilieDB')
	DROP DATABASE FamilieDB;
GO
CREATE DATABASE FamilieDB;
GO
USE FamilieDB;
GO
CREATE TABLE dbo.Person 
(
	PersonId			INT				NOT NULL 
						CONSTRAINT PK_Person PRIMARY KEY, 
    Navn				VARCHAR (20)	NOT NULL,
	Koen				CHAR(1)			NOT NULL
						CONSTRAINT CK_Person_Koen CHECK(Koen IN ('K', 'M')),
	BiologiskMor		INT				NULL 
						CONSTRAINT FK_Person_BiologiskMor FOREIGN KEY REFERENCES dbo.Person(PersonId),
	BiologiskFar		INT				NULL 
						CONSTRAINT FK_Person_BiologiskFar FOREIGN KEY REFERENCES dbo.Person(PersonId),
);
GO
INSERT INTO dbo.Person (PersonId, Navn, Koen, BiologiskMor, BiologiskFar) VALUES 
	(1, 'Jensine Jensen', 'K', NULL, NULL),
	(2, 'Karl Erik Jensen', 'M', NULL, NULL),

	(3, 'Poula Olsen', 'K', NULL, NULL),
	(4, 'Peder Olsen', 'M', NULL, NULL),

	(5, 'Kirstine S�rensen', 'K', NULL, NULL),
	(6, 'Chresten S�rensen', 'M', NULL, NULL),

	(7, 'Laura Hansen', 'K', NULL, NULL),
	(8, 'Lauritz Hansen', 'M', NULL, NULL),

	(11, 'Oline Jensen', 'K', 1, 2),
	(12, 'Lars Erik Jensen', 'M', 1, 2),
	(13, 'Knud Erik Jensen', 'M', 1, 2),
	(14, 'Ivan Erik Jensen', 'M', 1, 2),

	(21, 'Pia Olsen', 'K', 3, 4),
	(22, 'Maren Olsen', 'K', 3, 4),

	(31, 'Finn Ove S�rensen', 'M', 3, 4),
	(32, 'Lars Ole S�rensen', 'M', 3, 4),

	(101, 'Martin Ove Jensen', 'M', 5, 12),
	(102, 'Morten Jensen', 'M', 5, 12),

	(111, 'Mie Marie S�rensen', 'K', 21, 6),
	(112, 'Mads S�rensen', 'M', 21, 6),
	(113, 'Daniel S�rensen', 'M', 21, 14),

	(1001, 'Line S�rensen', 'K', 111, 101),
	
	(1002, 'George Olsen', 'M', 22, NULL);
GO
-- Det engelske kongehus
DROP	
	TABLE dbo.Person;

CREATE TABLE dbo.Person 
(
	PersonId			INT				NOT NULL 
						CONSTRAINT PK_Person PRIMARY KEY, 
    Navn				VARCHAR (50)	NOT NULL,
	BiologiskMor		INT				NULL 
						CONSTRAINT FK_Person_BiologiskMor FOREIGN KEY REFERENCES dbo.Person(PersonId),
	BiologiskFar		INT				NULL 
						CONSTRAINT FK_Person_BiologiskFar FOREIGN KEY REFERENCES dbo.Person(PersonId),
);
INSERT INTO dbo.Person (PersonId, Navn, BiologiskMor, BiologiskFar) VALUES
	(1, 'George V, King of England', NULL, NULL),
	(2, 'Mary, Princess of Teck', NULL, NULL),
	(3, 'George VI Windsor, King of England', 2, 1),
	(4, 'Claude George Bowes-Lyon', NULL, NULL),
	(5, 'Nina Cecilia  Cavendish-Bentinck', NULL, NULL),
	(6, 'Elizabeth Angela Marguerite Bowes-Lyon', 5, 4),
	(7, 'William George I of the Hellenes', NULL, NULL),
	(8, 'Olga Konstantinovna Romanova', NULL, NULL),
	(9, 'Louis Alexander von Battenburg', NULL, NULL),
	(10, 'Victoria von Hessen und bei Rhein', NULL, NULL),
	(11, 'Andreas, Prince of Greece', 8, 7),
	(12, 'Alice, Princess of Battenburg', 10, 9),
	(13, 'Phillip Mountbatten, Duke of Edinburgh', 12, 11),
	(14, 'Elizabeth II Windsor, Queene of England', 6, 3),
	(15, 'Charles Philip Arthur Windsor', 14, 13),
	(16, 'Diana Frances (Lady) Spencer', 18, 19),
	(17, 'William Arthur Phillip Windsor', 16, 15),
	(18, 'Frances Ruth Burke Roche', NULL, NULL),
	(19, 'Edward John Spencer', NULL, NULL);
GO
SELECT *
	FROM dbo.Person;
GO
DECLARE @Foraeldre		INT = 111;

WITH FamilieTrae 
AS
(
SELECT	*, 
		0 AS lvl,
		CAST(Navn AS VARCHAR(8000)) AS Sti
     FROM dbo.Person 
	 WHERE	BiologiskMor = @Foraeldre OR
			BiologiskFar = @Foraeldre
UNION ALL
SELECT	Person.*, 
		lvl + 1 AS lvl,
		CAST(FamilieTrae.Sti + '--> Far:' +
               Person.Navn AS VARCHAR(8000)) AS Sti
     FROM dbo.Person INNER JOIN FamilieTrae ON FamilieTrae.BiologiskFar = Person.PersonId
UNION ALL
SELECT	Person.*, 
		lvl + 1 AS lvl,
		CAST(FamilieTrae.Sti + '--> Mor:' + Person.Navn AS VARCHAR(8000)) AS Sti
     FROM dbo.Person INNER JOIN FamilieTrae ON FamilieTrae.BiologiskMor = Person.PersonId
)
SELECT Sti
	FROM FamilieTrae
	ORDER BY Sti;
GO
DECLARE @Foraeldre		INT = 21;

WITH FamilieTrae AS
(
SELECT	*, 
		0 AS lvl,
		CAST(Navn AS VARCHAR(8000)) AS Sti,
		CAST('Aktuel ' AS VARCHAR(10)) AS Relation
	FROM dbo.Person 
	WHERE	BiologiskMor = @Foraeldre OR
			BiologiskFar = @Foraeldre
UNION ALL
SELECT	Person.*, 
		lvl + 1 AS lvl,
		CAST(FamilieTrae.Sti + '--> Far :' + Person.Navn AS VARCHAR(8000)) AS Sti,
		CAST('Far' AS VARCHAR(10)) AS Relation
     FROM dbo.Person INNER JOIN FamilieTrae ON FamilieTrae.BiologiskFar = Person.PersonId
UNION ALL
SELECT	Person.*, 
		lvl + 1 AS lvl,
		CAST(FamilieTrae.Sti + '--> Mor :' + Person.Navn AS VARCHAR(8000)) AS Sti,
		CAST('Mor' AS VARCHAR(10)) AS Relation
	FROM dbo.Person INNER JOIN FamilieTrae ON FamilieTrae.BiologiskMor = Person.PersonId
)
SELECT	REPLICATE('.      ', lvl) + Relation + ': ' + Navn
	FROM FamilieTrae
	ORDER BY Sti;
GO
