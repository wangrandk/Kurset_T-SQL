USE master;
DROP DATABASE WithDB;
GO
CREATE DATABASE WithDB;
GO
USE WithDB;
CREATE TABLE dbo.t 
(
	Type		CHAR(1) NOT NULL,
	Antal		INT		NOT NULL
)
GO
INSERT INTO dbo.t VALUES 
	('A', 5),
	('B', 4),
	('C', 3);
GO
WITH t_expand (Type, Antal, Rk)
AS
(
SELECT *, 1 AS Rk
	FROM t
UNION ALL
SELECT t_expand.Type, t_expand.Antal, t_expand.Rk + 1
	FROM t INNER jOIN t_expand ON t.Type = t_expand.Type
	WHERE t_expand.Antal > t_expand.Rk
)
SELECT *
	FROM t_expand
	ORDER BY Type, RK;
