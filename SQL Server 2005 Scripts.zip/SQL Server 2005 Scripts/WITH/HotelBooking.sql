USE master;
GO
DROP DATABASE HotelDB;
GO
CREATE DATABASE HotelDB;
GO
USE HotelDB;
CREATE TABLE dbo.Vaerelsestype
(
	VaerelsestypeId		SMALLINT		NOT NULL 
						CONSTRAINT PK_Vaerelsestype PRIMARY KEY,
	VaerelsestypeTxt	VARCHAR(20)		NOT NULL 
						CONSTRAINT UQ_Vaerelsestype_VaerelsestypeTxt UNIQUE
);

CREATE TABLE dbo.VaerelsestypePris
(
	VaerelsestypeId		SMALLINT		NOT NULL,
	Standardpris		SMALLINT		NOT NULL,
	Datofra				DATE			NOT NULL,
	Datotil				DATE			NOT NULL,
	CONSTRAINT PK_VaerelsestypePris PRIMARY KEY (VaerelsestypeId, Datofra),
	CONSTRAINT CK_VaerelsestypePris_Datofra_Datotil CHECK(Datofra < Datotil)
);

CREATE TABLE dbo.Vaerelse
(
	Vaerelsesnr			SMALLINT		NOT NULL
						CONSTRAINT PK_Vaerelse PRIMARY KEY,
	VaerelsestypeId		SMALLINT		NOT NULL 
						CONSTRAINT FK_Vaerelse_Vaerelsestype 
						FOREIGN KEY REFERENCES dbo.Vaerelsestype(VaerelsestypeId)
);

CREATE TABLE dbo.VaerelsesSpecpriser
(
	PrisId				INT				NOT NULL IDENTITY
						CONSTRAINT PK_VaerelsesSpecpriser PRIMARY KEY,
	VaerelsestypeId		SMALLINT		NOT NULL 
						CONSTRAINT FK_Vaerelsepriser_Vaerelsestype 
						FOREIGN KEY REFERENCES dbo.Vaerelsestype(VaerelsestypeId),
	Datofra				DATE			NOT NULL,
	Datotil				DATE			NOT NULL,
	Pris				SMALLINT		NOT NULL,
	CONSTRAINT CK_VaerelsesSpecpriser_Datofra_Datotil CHECK(Datofra < Datotil)
);

CREATE TABLE dbo.Bestilling
(
	BestillingsId		INT				NOT NULL
						CONSTRAINT PK_Bestilling PRIMARY KEY,
	VaerelsestypeId		SMALLINT		NOT NULL 
						CONSTRAINT FK_Bestilling_Vaerelsestype 
						FOREIGN KEY REFERENCES dbo.Vaerelsestype(VaerelsestypeId),
	Ankomstdato			DATE			NOT NULL,
	Afrejsedato			DATE			NOT NULL,
	KundeId				INT				NOT NULL,
	Vaerelsesnr			SMALLINT		NULL
						CONSTRAINT FK_Bestilling_Vaerelse 
						FOREIGN KEY REFERENCES dbo.vaerelse(Vaerelsesnr),
	CONSTRAINT CK_Bestilling_Datofra_Datotil CHECK(Ankomstdato < Afrejsedato)
);
GO
INSERT INTO dbo.Vaerelsestype (VaerelsestypeId, VaerelsestypeTxt) VALUES
	(1, 'Standard'),
	(2, 'Deluxe'),
	(3, 'Suite');

INSERT INTO dbo.VaerelsestypePris (VaerelsestypeId, Standardpris, Datofra, Datotil) VALUES
	(1, 800, '2012-1-1', '2014-12-31'),
	(2, 1200, '2012-1-1', '2014-12-15'),
	(3, 1800, '2012-1-1', '2014-6-30'),
	(1, 825, '2015-1-1', '2099-12-31'),
	(2, 1300, '2014-12-16', '2099-12-31'),
	(3, 1850, '2014-7-1', '2099-12-31');

INSERT INTO dbo.Vaerelse (Vaerelsesnr, VaerelsestypeId) VALUES
	(101, 1),
	(102, 1),
	(103, 1),
	(201, 2),
	(202, 2),
	(301, 3);

INSERT INTO dbo.VaerelsesSpecpriser (VaerelsestypeId, Datofra, Datotil, Pris) VALUES
	(1, '2014-10-15', '2014-10-24', 850),
	(1, '2014-12-22', '2014-12-29', 850),
	(1, '2014-12-30', '2015-1-4', 900),
	(2, '2014-10-15', '2014-10-24', 1300),
	(2, '2014-12-22', '2014-12-27', 1350),
	(2, '2014-12-30', '2015-1-4', 1400),	 
	(3, '2014-10-15', '2014-10-24', 2000),
	(3, '2014-12-22', '2015-1-4', 2300);

INSERT INTO dbo.Bestilling (BestillingsId, VaerelsestypeId, Ankomstdato, Afrejsedato, KundeId, Vaerelsesnr) VALUES
	(2011, 1, '2014-10-11', '2014-10-12', 2134, 101),
	(3456, 1, '2014-12-22', '2014-12-23', 534, NULL),
	(3487, 2, '2014-12-14', '2014-12-29', 8887, 202),
	(2867, 3, '2014-12-23', '2015-1-6', 3408, 301);
GO
DECLARE @BestillingsId		INT = 3487;

WITH
Dage
AS
(
SELECT	1 AS DageId,
		Ankomstdato AS Dato
	FROM dbo.Bestilling
	WHERE BestillingsId = @BestillingsId
UNION ALL
SELECT	DageId + 1,
		DATEADD(DAY, 1, Dato)
	FROM Dage
	WHERE Dato < DATEADD(DAY, -1, (SELECT Afrejsedato
									FROM dbo.Bestilling
									WHERE BestillingsId = @BestillingsId))
)
SELECT	Bestilling.BestillingsId,
		Bestilling.KundeId,
		Bestilling.Vaerelsesnr,
		Bestilling.Ankomstdato,
		Bestilling.Afrejsedato,
		Dage.Dato,
		ISNULL(VaerelsesSpecpriser.Pris, VaerelsestypePris.Standardpris) AS Dagspris
	FROM dbo.Bestilling CROSS JOIN Dage
						INNER JOIN VaerelsestypePris ON Bestilling.VaerelsestypeId = VaerelsestypePris.VaerelsestypeId AND
														Dage.Dato BETWEEN VaerelsestypePris.Datofra AND VaerelsestypePris.Datotil						
						LEFT JOIN dbo.VaerelsesSpecpriser ON Bestilling.VaerelsestypeId = VaerelsesSpecpriser.VaerelsestypeId AND	
															 Dage.Dato BETWEEN VaerelsesSpecpriser.Datofra AND VaerelsesSpecpriser.Datotil
	WHERE BestillingsId = @BestillingsId
	ORDER BY Dage.Dato;
GO
DECLARE @BestillingsId		INT = 3487;

WITH
Dage
AS
(
SELECT	1 AS DageId,
		Ankomstdato AS Dato
	FROM dbo.Bestilling
	WHERE BestillingsId = @BestillingsId
UNION ALL
SELECT	DageId + 1,
		DATEADD(DAY, 1, Dato)
	FROM Dage
	WHERE Dato < DATEADD(DAY, -1, (SELECT Afrejsedato
									FROM dbo.Bestilling
									WHERE BestillingsId = @BestillingsId))
),
Regningslinier
AS
(
SELECT	Bestilling.BestillingsId,
		Bestilling.Ankomstdato,
		Bestilling.Afrejsedato,
		Dage.Dato,
		ISNULL(VaerelsesSpecpriser.Pris, VaerelsestypePris.Standardpris) AS Dagspris
	FROM dbo.Bestilling CROSS JOIN Dage
						INNER JOIN VaerelsestypePris ON Bestilling.VaerelsestypeId = VaerelsestypePris.VaerelsestypeId AND
														Dage.Dato BETWEEN VaerelsestypePris.Datofra AND VaerelsestypePris.Datotil						
						LEFT JOIN dbo.VaerelsesSpecpriser ON Bestilling.VaerelsestypeId = VaerelsesSpecpriser.VaerelsestypeId AND	
															 Dage.Dato BETWEEN VaerelsesSpecpriser.Datofra AND VaerelsesSpecpriser.Datotil
	WHERE BestillingsId = @BestillingsId
),
RegningslinierGrpdata
AS
(
SELECT	Dato,
		Dagspris,
		(SELECT MAX(Dato)
			FROM Regningslinier AS RlIndre1
			WHERE	RlIndre1.Dagspris = RlRes.Dagspris AND
					NOT EXISTS (SELECT  *
									FROM Regningslinier AS RlIndre2
									WHERE	RlIndre1.Dato > RlIndre2.Dato AND
											Rlres.Dato < RlIndre2.Dato AND 
											RlIndre1.Dagspris <> RlIndre2.Dagspris)) AS GrpDato
	FROM Regningslinier AS RlRes
)
SELECT	MIN(Dato) AS Startdato,
		DATEADD(DAY, COUNT(*), MIN(Dato)) AS Slutdato,
		COUNT(*) AS Antaldage,
		AVG(Dagspris) AS Dagspris,
		COUNT(*) * AVG(Dagspris) AS Prisialt
	FROM RegningslinierGrpdata
	GROUP BY GrpDato;
GO
DECLARE @BestillingsId		INT = 3487;

WITH
Dage
AS
(
SELECT	1 AS DageId,
		Ankomstdato AS Dato
	FROM dbo.Bestilling
	WHERE BestillingsId = @BestillingsId
UNION ALL
SELECT	DageId + 1,
		DATEADD(DAY, 1, Dato)
	FROM Dage
	WHERE Dato < DATEADD(DAY, -1, (SELECT Afrejsedato
									FROM dbo.Bestilling
									WHERE BestillingsId = @BestillingsId))
),
Regningslinier
AS
(
SELECT	Bestilling.BestillingsId,
		Bestilling.Ankomstdato,
		Bestilling.Afrejsedato,
		Dage.Dato,
		ISNULL(VaerelsesSpecpriser.Pris, VaerelsestypePris.Standardpris) AS Dagspris
	FROM dbo.Bestilling CROSS JOIN Dage
						INNER JOIN VaerelsestypePris ON Bestilling.VaerelsestypeId = VaerelsestypePris.VaerelsestypeId AND
														Dage.Dato BETWEEN VaerelsestypePris.Datofra AND VaerelsestypePris.Datotil						
						LEFT JOIN dbo.VaerelsesSpecpriser ON Bestilling.VaerelsestypeId = VaerelsesSpecpriser.VaerelsestypeId AND	
															 Dage.Dato BETWEEN VaerelsesSpecpriser.Datofra AND VaerelsesSpecpriser.Datotil
	WHERE BestillingsId = @BestillingsId
)
--SELECT *
--	FROM Regningslinier
,
RegningslinierGrpdata
AS
(
SELECT	BestillingsId,
		Dato AS Startdato,
		Dato AS Slutdato,
		Dagspris
	FROM Regningslinier AS Startgrp
	WHERE NOT EXISTS ( 
		SELECT *
			FROM Regningslinier AS Foregaaende
			WHERE Startgrp.Dagspris = Foregaaende.Dagspris AND
				  DATEADD(DAY, -1, Startgrp.Dato) = Foregaaende.Dato)
UNION ALL
SELECT	RegningslinierGrpdata.BestillingsId,
		RegningslinierGrpdata.Startdato,
		DATEADD(DAY, 1, RegningslinierGrpdata.Slutdato) AS Slutdato,
		RegningslinierGrpdata.Dagspris
	FROM RegningslinierGrpdata INNER JOIN Regningslinier 
		ON DATEADD(DAY, 1, RegningslinierGrpdata.Slutdato) = Regningslinier.Dato AND
			RegningslinierGrpdata.Dagspris = Regningslinier.Dagspris
)
SELECT	Bestillingsid,
		Startdato,
		MAX(Slutdato) AS Slutdato,
		COUNT(*) AS Antaldage,
		MAX(Dagspris) AS Dagspris,
		SUM(Dagspris) AS Prisialt
	FROM RegningslinierGrpdata
	GROUP BY Bestillingsid, Startdato
	ORDER BY Bestillingsid, Startdato;
