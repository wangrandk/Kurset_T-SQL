USE master;
DROP DATABASE WithDB;
GO
CREATE DATABASE WithDB;
GO
USE WithDB;
CREATE TABLE dbo.Medarbejder 
(
	MedarbejderId		INT			NOT NULL 
						CONSTRAINT PK_Medarbejder PRIMARY KEY,
	Navn				VARCHAR(20) NOT NULL,
	AfdelingsId			CHAR(1)		NOT NULL, 
	ChefId				INT			NULL 
						CONSTRAINT FK_Medarbejder_Chef 
						FOREIGN KEY REFERENCES Medarbejder(MedarbejderId)
);
GO
SET NOCOUNT ON;
INSERT INTO dbo.Medarbejder VALUES
	(1,  'Anne',  'A', NULL),
	(2,  'Ole',   'B', 1),
	(3,  'Per',   'C', 1),
	(4,  'Sanne', 'D', 1),
	(5,  'Kurt',  'B', 2),
	(6,  'Poul',  'B', 2),
	(7,  'Kamma', 'B', 5),
	(8,  'Hans',  'B', 5),
	(9,  'Irene', 'B', 5),
	(10, 'Lotte', 'D', 4),
	(11, 'Lars',  'D', 4),
	(12, 'Vivi',  'D', 4),
	(13, 'Sofus', 'E', 11),
	(14, 'Lilly',  'E', 12),
	(15, 'Johanne',  'E', 11);
SET NOCOUNT OFF;
GO
WITH AntalKollegaer (AfdelingsId, AntalMedarbejder)
AS
(
SELECT AfdelingsID, COUNT(*) AS AntalMedarbejder
	FROM dbo.Medarbejder
	GROUP BY AfdelingsID
)

SELECT Medarbejder.*, AntalMedarbejder - 1 AS AntalKollegaer
	FROM dbo.Medarbejder INNER JOIN AntalKollegaer
		ON Medarbejder.AfdelingsID = AntalKollegaer.AfdelingsID;
GO
WITH 
SammeAfdeling (AfdelingsId, AntalMedarbejder)
AS
(
SELECT AfdelingsID, COUNT(*) AS AntalSammeAfdeling
	FROM dbo.Medarbejder
	GROUP BY AfdelingsID
), 
SammeChef (ChefId, AntalSammeChef)
AS
(
SELECT ChefId, COUNT(*) AS AntalSammeChef
	FROM dbo.Medarbejder
	GROUP BY ChefId
)

SELECT M.*, 
		AntalMedarbejder - 1 AS AntalMedarbejder,
		AntalSammeChef - 1 AS AntalSammeChef
	FROM dbo.Medarbejder AS M INNER JOIN SammeAfdeling AS SA ON M.AfdelingsID = SA.AfdelingsID
							  INNER JOIN SammeChef AS SC ON M.ChefId = SC.ChefId;;
GO
WITH MedarbejderCTE (MedarbejderId, Navn, AntalOverordnede)
AS
(SELECT	MedarbejderId, 
		Navn, 
		0 AS AntalOverordnede
	FROM dbo.Medarbejder
	WHERE ChefId IS NULL
 UNION ALL
 SELECT	Medarbejder.MedarbejderId, 
		Medarbejder.Navn,
		MedarbejderCTE.AntalOverordnede + 1 AS AntalOverordnede
	FROM dbo.Medarbejder INNER JOIN MedarbejderCTE
		ON Medarbejder.ChefId = MedarbejderCTE.MedarbejderId
)
SELECT *
	FROM MedarbejderCTE
	ORDER BY MedarbejderId;
GO
WITH MedarbejderCTE (MedarbejderId, Navn, AntalOverordnede, LongKey)
AS
(SELECT MedarbejderId, Navn, 0 AS AntalOverordnede, 
	CAST(RIGHT('00000' + CAST(MedarbejderId AS VARCHAR(5)), 5) AS VARCHAR(1000)) AS LongKey
	FROM dbo.Medarbejder
	WHERE ChefId IS NULL
 UNION ALL
 SELECT Medarbejder.MedarbejderId, Medarbejder.Navn,
		AntalOverordnede + 1 AS AntalOverordnede,
		CAST(LongKey + RIGHT('00000' + CAST(Medarbejder.MedarbejderId AS VARCHAR(5)), 5) AS VARCHAR(1000)) AS LongKey
	FROM dbo.Medarbejder INNER JOIN MedarbejderCTE
		ON Medarbejder.ChefId = MedarbejderCTE.MedarbejderId
)
SELECT *
	FROM MedarbejderCTE
	ORDER BY LongKey
GO
DECLARE @MedarbejderId	INT = 5;

WITH MedarbejderCTE (MedarbejderId, Navn, ChefId, Niveau)
AS
(
SELECT MedarbejderId, Navn, ChefId, 0 AS Niveau
	FROM dbo.Medarbejder
	WHERE MedarbejderId = @MedarbejderId
 
 UNION ALL
 SELECT Medarbejder.MedarbejderId, Medarbejder.Navn,  Medarbejder.ChefId,
		Niveau + 1 AS Niveau
	FROM dbo.Medarbejder INNER JOIN MedarbejderCTE
		ON Medarbejder.ChefId = MedarbejderCTE.MedarbejderId
	WHERE Niveau >= 0

 UNION ALL
 SELECT Medarbejder.MedarbejderId, Medarbejder.Navn,  Medarbejder.ChefId,
		Niveau - 1 AS Niveau
	FROM dbo.Medarbejder INNER JOIN MedarbejderCTE
		ON Medarbejder.MedarbejderId = MedarbejderCTE.ChefId
	WHERE Niveau <= 0
)
SELECT *
	FROM MedarbejderCTE
	ORDER BY MedarbejderId;
GO
DECLARE @MedarbejderId	INT;

SET @MedarbejderId = 1;

WITH MedarbejderCTE (MedarbejderId, Navn, ChefId, Niveau)
AS
(SELECT MedarbejderId, Navn, ChefId, CAST(RIGHT('00000' + CAST(Medarbejder.MedarbejderId AS VARCHAR(5)), 5) AS VARCHAR(500)) AS Niveau
	FROM dbo.Medarbejder
	WHERE MedarbejderId = @MedarbejderId
 UNION ALL
 SELECT Medarbejder.MedarbejderId, Medarbejder.Navn,  Medarbejder.ChefId,
		CAST(Niveau + RIGHT('00000' + CAST(Medarbejder.MedarbejderId AS VARCHAR(5)), 5) AS VARCHAR(500)) AS Niveau
	FROM dbo.Medarbejder INNER JOIN MedarbejderCTE
		ON Medarbejder.ChefId = MedarbejderCTE.MedarbejderId
)
SELECT	*, 
		REPLICATE('.', LEN(Niveau) - 5) +  Navn
	FROM MedarbejderCTE
	ORDER BY Niveau;
GO
-- Fejl i hierarki
TRUNCATE 
	TABLE dbo.Medarbejder;
GO
SET NOCOUNT ON
INSERT INTO dbo.Medarbejder VALUES
	(1,  'Anne',  'A', NULL),
	(2,  'Ole',   'B', 1),
	(3,  'Per',   'C', 1),
	(4,  'Sanne', 'D', 13),
	(5,  'Kurt',  'B', 2),
	(6,  'Poul',  'B', 2),
	(7,  'Kamma', 'B', 5),
	(8,  'Hans',  'B', 5),
	(9,  'Irene', 'B', 5),
	(10, 'Lotte', 'D', 4),
	(11, 'Lars',  'D', 4),
	(12, 'Vivi',  'D', 4),
	(13, 'Sofus', 'E', 11),
	(14, 'Lilly',  'E', 12),
	(15, 'Johanne',  'E', 11);
SET NOCOUNT OFF
GO
WITH MedarbejderCTE (MedarbejderId, Navn, AntalOverordnede)
AS
(SELECT	MedarbejderId, 
		Navn, 
		0 AS AntalOverordnede
	FROM dbo.Medarbejder
	WHERE ChefId IS NULL
 UNION ALL
 SELECT	Medarbejder.MedarbejderId, 
		Medarbejder.Navn,
		AntalOverordnede + 1 AS AntalOverordnede
	FROM dbo.Medarbejder INNER JOIN MedarbejderCTE
		ON Medarbejder.ChefId = MedarbejderCTE.MedarbejderId
)
SELECT *
	FROM MedarbejderCTE
	ORDER BY MedarbejderId;
GO
WITH MedarbejderCTE (MedarbejderId)
AS
(SELECT	MedarbejderId
	FROM dbo.Medarbejder
	WHERE ChefId IS NULL
 UNION ALL
 SELECT	Medarbejder.MedarbejderId
	FROM dbo.Medarbejder INNER JOIN MedarbejderCTE
		ON Medarbejder.ChefId = MedarbejderCTE.MedarbejderId
)
SELECT 
	IIF ((SELECT COUNT(*) FROM MedarbejderCTE) = (SELECT COUNT(*) FROM Medarbejder),
	'Hierarki OK',
	'Fejl i hierarki');
