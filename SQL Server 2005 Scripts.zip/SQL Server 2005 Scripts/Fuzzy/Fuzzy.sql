USE master
DROP DATABASE PersonDB;
GO
CREATE DATABASE PersonDB;
GO
USE PersonDB;
GO
CREATE TABLE dbo.Person 
(
	Personid		INT			NOT NULL PRIMARY KEY IDENTITY,
	Navn			VARCHAR(35) NOT NULL,
	Adresse			VARCHAR(35) NOT NULL,
	Postnr			SMALLINT	NOT NULL
);
GO
SET NOCOUNT ON;
INSERT INTO dbo.Person (Navn, Adresse, Postnr) VALUES 
	('Saastamoinen-Jakobsen Carsten', 'Weidekampsgade 51', 2300),
	('Carsten Saastamoinen-Jakobsen', 'Weidekampsgade 51', 2300),
	('Carsten Sastamoinen-Jakobsen', 'Weidekampsgade 51 st.', 2300),
	('Carsten Saastamoinen-Jacobsen', 'Weidekampsgade 51 st.', 2300),
	('Carsten Saastamoinen-Jakobsen', 'M�llegade 4', 8000),
	('Carsten S-Jakobsen', 'Weidekampsgade 51 st. tv.', 2300),

	('Ane Jensen', 'Nygade 4', 9000),

	('Lene Jensen', 'Torvet 3', 2000),
	('Lene Marie Jensen', 'Torvet 3', 2000),

	 ('Knud J�rgensen', '�gade 2', 3000),
	('Knud Erik J�rgensen', '�gade 2', 3000),
	('Knud J�rgensen', '�gade 2 2. tv', 3000),
	('Knud J�rgensen', '�gade 2 2.', 3000),

	('Allan Andersen', 'N�rregade 34', 2610),
	('Jens Allan Andersen', 'N�rregade 34', 2610);

SET NOCOUNT OFF;
