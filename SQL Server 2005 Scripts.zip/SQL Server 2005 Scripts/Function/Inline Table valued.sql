USE master;
DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
USE FunctionDB;
CREATE TABLe dbo.Postopl 
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY,	
	ByNavn			VARCHAR (30) NOT NULL
);
CREATE TABLE dbo.Kunde 
(
	KundeId			INT	NOT NULL PRIMARY KEY IDENTITY,
	Navn			VARCHAR (30) NOT NULL,
	Adresse			VARCHAR (30) NOT NULL,
	Postnr			SMALLINT NOT NULL 
					CONSTRAINT fk_postopl_kunde FOREIGN KEY REFERENCES postopl (Postnr)
);
GO
SET NOCOUNT ON;

INSERT INTO dbo.Postopl VALUES 
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(9000, 'Aalborg');

INSERT INTO dbo.Kunde VALUES 
	('Jens Hansen', 'Nygade 3', 2000),
	('Ole Larsen', 'Vestergade 4', 9000),
	('Karen Olsen', 'Borgergade 13', 9000),
	('Karl Nielsen', 'S�ndergade 67', 8000);

SET NOCOUNT OFF
GO
CREATE FUNCTION ufn_Postopl
(
	@Postnr		SMALLINT
)
RETURNS TABLE
AS
RETURN		(
			SELECT * 
				FROM dbo.Postopl 
				WHERE Postnr > @Postnr
			);
GO
SELECT *
	FROM ufn_Postopl(7000);
GO
SELECT *
	FROM ufn_postopl(7000) AS p INNER JOIN dbo.Kunde ON p.Postnr = Kunde.Postnr;
GO
CREATE TYPE PostnrTableType AS TABLE
(
	Postnr		SMALLINT
);
GO
DROP FUNCTION dbo.ufn_Postopl;
GO
CREATE FUNCTION dbo.ufn_Postopl
(
	@PostnrData		PostnrTableType READONLY
)
RETURNS TABLE
AS
RETURN	(SELECT *
			FROM Postopl
			WHERE Postnr IN (SELECT Postnr FROM @PostnrData)
		);
GO
DECLARE @Postopl	PostnrTableType;

INSERT INTO @Postopl (Postnr) VALUES
	(2000),
	(6000),
	(8000);

SELECT *
	FROM dbo.ufn_Postopl(@Postopl) AS P;

SELECT *
	FROM dbo.ufn_Postopl(@Postopl) AS P INNER JOIN dbo.Kunde ON p.Postnr = Kunde.Postnr;