USE master
DROP DATABASE FunctionDB
GO
CREATE DATABASE FunctionDB
GO
USE FunctionDB
GO
CREATE FUNCTION dbo.ufn_Navn 
(
	@Fornavn		VARCHAR(20), 
	@Efternavn		VARCHAR(20)
)
RETURNS VARCHAR(30)
AS
BEGIN
	IF LEN(@Fornavn) + LEN(@Efternavn) < 30
		RETURN @Fornavn + ' ' + @Efternavn;
	ELSE
		RETURN LEFT(@Fornavn, 1) + '. ' + @Efternavn;

	RETURN 0
END;
GO
SELECT dbo.ufn_Navn('Ole', 'Olsen') AS Navn;
SELECT dbo.ufn_Navn('Ole Erik Jens Arne', 'Jensen Hansen Olsen') AS Navn;
GO
DROP FUNCTION dbo.ufn_Navn;
GO
CREATE FUNCTION dbo.ufn_Navn 
(
	@Fornavn		VARCHAR(20), 
	@Efternavn		VARCHAR(20)
)
RETURNS VARCHAR(30)
AS
BEGIN
	DECLARE @Navn		VARCHAR(30);

	IF LEN(@Fornavn) + LEN(@Efternavn) < 30
		SET @Navn = @Fornavn + ' ' + @Efternavn;
	ELSE
		SET @Navn = LEFT(@Fornavn, 1) + ' ' + @Efternavn;
	
	RETURN @Navn;
END;
GO
DECLARE @r		VARCHAR(30)

EXEC @r = dbo.ufn_Navn  'Ole', 'Olsen'

SELECT @r
GO
SELECT dbo.ufn_Navn('Ole', 'Olsen') AS Navn;
SELECT dbo.ufn_Navn('Ole Erik Jens Arne', 'Jensen Hansen Olsen') AS Navn;
GO
CREATE TABLE dbo.Person 
(
	Id				INT NOT NULL PRIMARY KEY IDENTITY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	LangtNavn		AS Fornavn + ' ' + Efternavn,
	KortNavn		AS dbo.ufn_Navn(Fornavn, Efternavn)
);
GO
CREATE TABLE dbo.PersonPersist 
(
	Id				INT NOT NULL PRIMARY KEY IDENTITY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	LangtNavn		AS Fornavn + ' ' + Efternavn PERSISTED,
	KortNavn		AS dbo.ufn_Navn(Fornavn, Efternavn) PERSISTED     -- fejl
);
GO
SELECT OBJECTPROPERTYEX(OBJECT_ID('dbo.ufn_Navn') , 'IsDeterministic');

SELECT COLUMNPROPERTY(OBJECT_ID('dbo.Person') , 'LangtNavn','IsDeterministic')
GO
CREATE TABLE dbo.PersonPersist
(
	Id				INT NOT NULL PRIMARY KEY IDENTITY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	LangtNavn		AS Fornavn + ' ' + Efternavn PERSISTED,
	KortNavn		AS dbo.ufn_Navn(Fornavn, Efternavn)
);
GO
INSERT INTO dbo.Person(Fornavn, Efternavn) 
	VALUES('Ole', 'Olsen')
INSERT INTO dbo.Person(Fornavn, Efternavn) 
	VALUES('Ole Erik Jens Arne', 'Jensen Hansen Olsen')
GO
SELECT * 
	FROM dbo.Person;

SELECT	Id, 
		LangtNavn 
	FROM dbo.Person;

SELECT	Id, 
		KortNavn 
	FROM dbo.Person;

SELECT	Id,
		Fornavn + ' ' + Efternavn,
		dbo.ufn_Navn (Fornavn, Efternavn) AS Navn
	FROM dbo.Person;
GO
CREATE FUNCTION dbo.ufn_date(@dato DATETIME)
RETURNS DATETIME
AS
BEGIN
	RETURN CAST(FLOOR(CAST(@dato AS DECIMAL(9,4))) AS DATETIME);
END
GO
SELECT dbo.ufn_date(GETDATE());
SELECT dbo.ufn_date(CAST('1843-6-27 8:00' AS DATETIME));
SELECT dbo.ufn_date(CAST('2006-6-27 18:00' AS DATETIME));
GO
CREATE FUNCTION dbo.ufn_time(@time DATETIME)
RETURNS DATETIME
AS
BEGIN
DECLARE @datetime	AS DECIMAL(38,19);
DECLARE @date		AS DECIMAL(38,19);

	SET @datetime = CAST(@time AS DECIMAL(38,19));
	set @date = FLOOR(CAST(@time AS DECIMAL(38,19)));
	RETURN CAST((@datetime - @date) AS DATETIME);
END;
GO
SELECT dbo.ufn_time(GETDATE());
SELECT dbo.ufn_time(CAST('1867-6-27 8:00' AS DATETIME));
SELECT dbo.ufn_time(CAST('2006-6-27 18:27:56:877' AS DATETIME));
SELECT dbo.ufn_time(CAST('8:00' AS DATETIME));
GO
CREATE TABLE dbo.Ordre 
(
	OrderId			INT NOT NULL PRIMARY KEY IDENTITY,
	Bestillingsdato	DATETIME NOT NULL DEFAULT (dbo.ufn_date(GETDATE())),
	Leveringsdato	DATETIME NOT NULL,
	TidFra			DATETIME NOT NULL DEFAULT (CAST('8:00' AS DATETIME)),
	TidTil			DATETIME NOT NULL DEFAULT (CAST('18:00' AS DATETIME)),
	CONSTRAINT ck_ordre_Bestillingsdato_Leveringsdato CHECK (Bestillingsdato < Leveringsdato),
	CONSTRAINT ck_ordre_TidFra_TidTil CHECK (TidFra < TidTil)
);
GO
INSERT INTO dbo.Ordre  (Leveringsdato) VALUES (dbo.ufn_date(GETDATE() + 14));
GO
SELECT * 
	FROM dbo.Ordre;
SELECT *, Leveringsdato + TidFra, Leveringsdato + TidTil
	FROM dbo.Ordre;
