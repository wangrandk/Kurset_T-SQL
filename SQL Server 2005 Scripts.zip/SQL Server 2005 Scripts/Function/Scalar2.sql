USE master
DROP DATABASE TestDB
GO
CREATE DATABASE TestDB
GO
USE TestDB
GO
CREATE FUNCTION dbo.ufn_Max
	(@Vaerdi1		INT,
	 @Vaerdi2		INT)
RETURNS INT
AS
BEGIN
DECLARE @MaxVaerdi INT

IF @Vaerdi1 < @Vaerdi2
	SET @MaxVaerdi = @Vaerdi2
ELSE
	SET @MaxVaerdi = @Vaerdi1
	
RETURN @MaxVaerdi
END
GO
SELECT ufn_Max(2, 7)		-- fejl mangler schema

SELECT dbo.ufn_Max(2, 7)
GO
ALTER FUNCTION dbo.ufn_Max
	(@Vaerdi1		INT = 200,
	 @Vaerdi2		INT = 5000)
RETURNS INT
AS
BEGIN
	DECLARE @MaxVaerdi INT

	IF @Vaerdi1 < @Vaerdi2
		SET @MaxVaerdi = @Vaerdi2;
	ELSE
		SET @MaxVaerdi = (SELECT MAX(Postnr) FROM dbo.Postopl);
	
	RETURN @MaxVaerdi;
END
GO
SELECT dbo.ufn_Max(DEFAULT, DEFAULT);
GO
CREATE TABLE dbo.Loen
(
	ID			INT NOT NULL PRIMARY KEY,
	LK			SMALLINT NOT NULL UNIQUE,
	MinLoen		INT NOT NULL,
	MaxLoen		INT NOT NULL,
	CONSTRAINT CK_Loen_MinLoen_MaxLoen CHECK (MinLoen < MaxLoen)
)
GO
INSERT INTO dbo.Loen VALUES
	(1, 20, 10000, 20000),
	(2, 34, 20000, 40000),
	(3, 56, 20000, 70000);
GO
CREATE FUNCTION dbo.ufn_Loen
(
	@LK			SMALLINT, 
	@Loen		INT
)
RETURNS SMALLINT
BEGIN
	DECLARE @LoenOK		SMALLINT

	IF EXISTS (SELECT * FROM Loen WHERE LK = @LK)
	BEGIN
		IF @Loen BETWEEN	(SELECT MinLoen FROM Loen WHERE LK = @LK) AND
							(SELECT MaxLoen FROM Loen WHERE LK = @LK)
			SET @LoenOK = 1;
		ELSE
			SET @LoenOK = 0;
	END
	ELSE 
		SET @LoenOK = -1;
	
	RETURN @LoenOK;
END;
GO
CREATE TABLE dbo.Medarbejder
(
	MedarbejderId		INT NOT NULL PRIMARY KEY,
	Lk					SMALLINT NOT NULL,
	Loen				INT NOT NULL,
	CONSTRAINT CK_Medarbejder_Loen CHECK (dbo.ufn_Loen (LK, Loen) = 1)
);
GO
INSERT INTO dbo.Medarbejder VALUES
	(1, 20, 15000),
	(2, 20, 10000),
	(3, 20, 20000),
	(4, 20, 20000),
	(5, 34, 25000),
	(6, 56, 40000),
	(7, 56, 60000);
GO
SELECT *
	FROM Medarbejder
GO
SELECT dbo.ufn_Loen(20, 20000);
SELECT dbo.ufn_Loen(20, 30000);
SELECT dbo.ufn_Loen(21, 20000);
GO
CREATE FUNCTION dbo.ufn_Medarbejder
(
	@MedarbjderId	INT
)
RETURNS TABLE

RETURN (SELECT *
		FROM Medarbejder
		WHERE MedarbejderId = @MedarbjderId);
GO		
SELECT *
	FROM ufn_Medarbejder(2);

SELECT *
	FROM dbo.ufn_Medarbejder(2) AS m INNER JOIN Loen ON m.Lk = Loen.LK;
GO
CREATE FUNCTION dbo.ufn_LoenData ()
RETURNS @l TABLE (	LK					INT NOT NULL PRIMARY KEY, 
					GennemsnitLoen		INT NOT NULL, 
					GennemsnitMedarb	INT NULL)
AS
BEGIN
	INSERT INTO @l(LK, GennemsnitLoen)
		SELECT LK, (MinLoen + MaxLoen) / 2
			FROM dbo.Loen;

	UPDATE @l	
		SET GennemsnitMedarb = (SELECT AVG(Loen) FROM dbo.Medarbejder WHERE l.LK = Medarbejder.Lk)
		FROM @l AS l INNER JOIN dbo.Medarbejder
				ON  l.lk = Medarbejder.Lk;

	UPDATE @l	
		SET GennemsnitMedarb = NULL
		WHERE LK IN (SELECT LK
						FROM dbo.Medarbejder
						GROUP BY LK
						HAVING COUNT(*) < 2);
RETURN;
END
GO
SELECT *
	FROM dbo.ufn_LoenData();
	
SELECT *
	FROM dbo.ufn_LoenData() AS l INNER JOIN Medarbejder ON l.lk = Medarbejder.lk;
