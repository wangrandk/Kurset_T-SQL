USE master
DROP DATABASE FunctionDB
GO
CREATE DATABASE FunctionDB
GO
USE FunctionDB
GO
CREATE FUNCTION dbo.fn_JUL2ISO (@JUL2ISO DECIMAL(8,0))
RETURNS DATE
AS
BEGIN
DECLARE @MonthDays	TABLE (
	Month			SMALLINT,
	Days			SMALLINT)

DECLARE @Date		DATE
DECLARE @Year		SMALLINT
DECLARE @Month		SMALLINT
DECLARE @Day		SMALLINT
DECLARE @DayOfYear	SMALLINT
 
INSERT INTO @MonthDays (Month, Days) VALUES
	(1, 31),
	(2, 28),
	(3, 31),
	(4, 30),
	(5, 31),
	(6, 30),
	(7, 31),
	(8, 31),
	(9, 30),
	(10, 31),
	(11, 30),
	(12, 31)

SET @Year = @JUL2ISO/1000
SET @DayOfYear = @JUL2ISO - (@Year * 1000)

IF @Year % 4 = 0
	UPDATE @MonthDays
		SET Days = 29
		WHERE Month = 2

SET @Month = 1
WHILE @DayOfYear > (SELECT Days FROM @MonthDays WHERE Month = @Month)
BEGIN
	SET @DayOfYear = @DayOfYear - (SELECT Days FROM @MonthDays WHERE Month = @Month)
	SET @Month = @Month + 1  
END
SET @Day = @DayOfYear

SET @Date = CAST(CAST(@Year AS VARCHAR(4)) + '-' + 
				 CAST(@Month AS VARCHAR(2)) + '-' +
				 CAST(@Day AS VARCHAR(2)) AS DATE)

RETURN @Date
END
GO
SELECT dbo.fn_JUL2ISO(2011001)
SELECT dbo.fn_JUL2ISO(2011031)
SELECT dbo.fn_JUL2ISO(2011032)
SELECT dbo.fn_JUL2ISO(2011060)
SELECT dbo.fn_JUL2ISO(2011061)
SELECT dbo.fn_JUL2ISO(2012366)
GO
CREATE FUNCTION dbo.fn_JUL2ISO2 (@JUL2ISO DECIMAL(8,0))
RETURNS DATE
AS
BEGIN
DECLARE @MonthDays	TABLE (
	Month			SMALLINT,
	DaysOfYear		SMALLINT)

DECLARE @Date		DATE
DECLARE @Year		SMALLINT
DECLARE @Month		SMALLINT
DECLARE @Day		SMALLINT
DECLARE @DayOfYear	SMALLINT
 
INSERT INTO @MonthDays (Month, DaysOfYear) VALUES
	(1,  0),
	(2,  31),
	(3,  59),
	(4,  90),
	(5,  120),
	(6,  151),
	(7,  181),
	(8,  212),
	(9,  243),
	(10, 273),
	(11, 304),
	(12, 334)
	
SET @Year = @JUL2ISO/1000
SET @DayOfYear = @JUL2ISO - (@Year * 1000)

IF @Year % 4 = 0				-- skud�r
	UPDATE @MonthDays
		SET DaysOfYear = DaysOfYear + 1
		WHERE Month > 2

SET @Month = (SELECT MAX(Month) 
				FROM @MonthDays 
				WHERE DaysOfYear < @DayOfYear)
SET @Day = @DayOfYear - (SELECT MAX(DaysOfYear) 
							FROM @MonthDays 
							WHERE DaysOfYear < @DayOfYear)

SET @Date = CAST(CAST(@Year AS VARCHAR(4)) + '-' + 
				 CAST(@Month AS VARCHAR(2)) + '-' +
				 CAST(@Day AS VARCHAR(2)) AS DATE)

RETURN @Date
END
GO
SELECT dbo.fn_JUL2ISO2(2011001)
SELECT dbo.fn_JUL2ISO2(2011031)
SELECT dbo.fn_JUL2ISO2(2011032)
SELECT dbo.fn_JUL2ISO2(2011060)
SELECT dbo.fn_JUL2ISO2(2011061)
SELECT dbo.fn_JUL2ISO2(2012366)
GO
DECLARE @i		INT
DECLARE @Date	DATE
DECLARE @Start	DATE
DECLARE @Slut	DATE

SET @i = 1
SET @Start = SYSDATETIME()
WHILE @i <= 100000
BEGIN
	SET @Date = dbo.fn_JUL2ISO(2012366)
	SET @i = @i + 1
END
SET @Slut = SYSDATETIME()
SELECT DATEDIFF(ms, @Start, @Slut)

SET @i = 1
SET @Start = SYSDATETIME()

WHILE @i <= 100000
BEGIN
	SET @Date = dbo.fn_JUL2ISO2(2012366)
	SET @i = @i + 1
END
SET @Slut = SYSDATETIME()
SELECT DATEDIFF(ms, @Start, @Slut)
GO
CREATE FUNCTION dbo.fn_ISO2JUL (@ISO2JUL DATE)
RETURNS DECIMAL(8,0)
AS
BEGIN
DECLARE @Year			SMALLINT
DECLARE @DayOfYear		SMALLINT
DECLARE @JULDate		DECIMAL(8,0)

SET @Year = YEAR(@ISO2JUL)
SET @DayOfYear = DATEPART(dayofyear, @ISO2JUL)

SET @JULDate = (@Year * 1000) + @DayOfYear
RETURN @JULDate
END
GO
SELECT dbo.fn_ISO2JUL (SYSDATETIME())
SELECT dbo.fn_ISO2JUL ('2011-1-1')
SELECT dbo.fn_ISO2JUL ('2011-2-28')
SELECT dbo.fn_ISO2JUL ('2012-2-29')
SELECT dbo.fn_ISO2JUL ('2011-12-31')
SELECT dbo.fn_ISO2JUL ('2012-12-31')
