USE master;
GO
DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
USE FunctionDB;
GO
CREATE FUNCTION dbo.DataRange 
	(
	@StartDate		DATE,
	@Enddate		DATE
)
RETURNS 
@Dates TABLE 
(
	Dato			DATE
)
AS
BEGIN;
WITH 
CTEDates (DateRange)
AS
(
SELECT @StartDate AS Dato
UNION ALL
SELECT DATEADD(DAY, 1, DateRange)
	FROM CTEDates
	WHERE DateRange <=
		 DATEADD(DAY, -1, @Enddate)
)
INSERT INTO @Dates
	SELECT *
		FROM CTEDates

OPTION (MAXRECURSION 0)
RETURN 
END;
GO
-- Danner tabeller til brug ved test
SELECT	Dato, 
		CAST('x1x1x1x1x1' AS CHAR(2000)) AS Txt
	INTO dbo.t1
	FROM  dbo.DataRange('1998-4-5', '2010-11-25')
	
SELECT	Dato, 
		CAST('y1y1y1y1y1' AS CHAR(2000)) AS Txt
	INTO dbo.t2
	FROM  dbo.DataRange('1987-4-5', '2005-06-25')

SELECT	Dato, 
		CAST('z1z1z1z1z1' AS CHAR(2000)) AS Txt
	INTO dbo.t3
	FROM  dbo.DataRange('1991-4-5', '2014-02-28')

SELECT	Dato, 
		CAST('u1u1u1u1u1' AS CHAR(2000)) AS Txt
	INTO dbo.t4
	FROM  dbo.DataRange('1998-4-5', '2010-11-25')

SELECT	Dato, 
		CAST('v1v1v1v1v1' AS CHAR(2000)) AS Txt
	INTO dbo.t5
	FROM  dbo.DataRange('1994-6-13', '2010-10-15')
GO
INSERT INTO dbo.t3
	SELECT	Dato, 
			CAST('z2z2z2z2z2' AS CHAR(2000)) AS Txt
		FROM  dbo.DataRange('1995-3-18', '2008-04-02')

INSERT INTO dbo.t3
	SELECT	Dato, 
			CAST('z3z3z3z3z3' AS CHAR(2000)) AS Txt
		FROM  dbo.DataRange('1995-3-18', '2017-04-02')

INSERT INTO dbo.t4
	SELECT	Dato, 
			CAST('u2u2u2u2u2' AS CHAR(2000)) AS Txt
		FROM  dbo.DataRange('1999-12-31', '2015-04-23')
GO 10
SELECT
	(SELECT COUNT(*) FROM dbo.t1) AS t1,
	(SELECT COUNT(*) FROM dbo.t2) AS t3,
	(SELECT COUNT(*) FROM dbo.t3) AS t3,
	(SELECT COUNT(*) FROM dbo.t4) AS t4,
	(SELECT COUNT(*) FROM dbo.t5) AS t5
GO
CREATE FUNCTION dbo.fn_MaxDato()
RETURNS DATE
AS
BEGIN
DECLARE @Dato TABLE 
(
	Dato		DATE
);

INSERT INTO @Dato
	SELECT MAX(Dato) 
		FROM dbo.t1

INSERT INTO @Dato	
	SELECT MAX(Dato)
		FROM dbo.t2
		WHERE Dato > (SELECT MAX(Dato) 
						FROM @Dato)

INSERT INTO @Dato	
	SELECT MAX(Dato)
		FROM dbo.t3
		WHERE Dato > (SELECT MAX(Dato) 
						FROM @Dato)

INSERT INTO @Dato	
	SELECT MAX(Dato)
		FROM dbo.t4
		WHERE Dato > (SELECT MAX(Dato) 
						FROM @Dato)

INSERT INTO @Dato	
	SELECT MAX(Dato)
		FROM dbo.t5
		WHERE Dato > (SELECT MAX(Dato) 
						FROM @Dato)

RETURN (SELECT MAX(Dato) 
			FROM @Dato)
END;
GO
SET STATISTICS TIME ON
SELECT MAX(Dato)
	FROM (	SELECT Dato FROM dbo.t1
			UNION ALL
			SELECT Dato FROM dbo.t2
			UNION ALL
			SELECT Dato FROM dbo.t3
			UNION ALL
			SELECT Dato FROM dbo.t4
			UNION ALL
			SELECT Dato FROM dbo.t5
		) AS t

SELECT MAX(Dato)
	FROM (	SELECT MAX(Dato) FROM dbo.t1
			UNION ALL
			SELECT MAX(Dato) FROM dbo.t2
			UNION ALL
			SELECT MAX(Dato) FROM dbo.t3
			UNION ALL
			SELECT MAX(Dato) FROM dbo.t4
			UNION ALL
			SELECT MAX(Dato) FROM dbo.t5
		) AS t(Dato)
GO
SELECT dbo.fn_MaxDato()
SET STATISTICS TIME OFF
GO
CREATE NONCLUSTERED INDEX nc_t1_Dato ON dbo.t1(Dato)
CREATE NONCLUSTERED INDEX nc_t2_Dato ON dbo.t2(Dato)
CREATE NONCLUSTERED INDEX nc_t3_Dato ON dbo.t3(Dato)
CREATE NONCLUSTERED INDEX nc_t4_Dato ON dbo.t4(Dato)
CREATE NONCLUSTERED INDEX nc_t5_Dato ON dbo.t5(Dato)
GO
SET STATISTICS TIME ON
SELECT MAX(Dato)
	FROM (	SELECT Dato FROM dbo.t1
			UNION ALL
			SELECT Dato FROM dbo.t2
			UNION ALL
			SELECT Dato FROM dbo.t3
			UNION ALL
			SELECT Dato FROM dbo.t4
			UNION ALL
			SELECT Dato FROM dbo.t5
		) AS t

SELECT MAX(Dato)
	FROM (	SELECT MAX(Dato) FROM dbo.t1
			UNION ALL
			SELECT MAX(Dato) FROM dbo.t2
			UNION ALL
			SELECT MAX(Dato) FROM dbo.t3
			UNION ALL
			SELECT MAX(Dato) FROM dbo.t4
			UNION ALL
			SELECT MAX(Dato) FROM dbo.t5
		) AS t(Dato)
GO
SELECT dbo.fn_MaxDato()
SET STATISTICS TIME OFF
