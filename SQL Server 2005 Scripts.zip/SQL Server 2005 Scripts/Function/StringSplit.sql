USE master
GO
DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB
ON PRIMARY
	(NAME = FunctionDB_sys,
	 FILENAME = 'c:\Databaser\FunctionDB_sys.mdf',
     SIZE = 5MB,
     MAXSIZE = 5MB,
     FILEGROWTH = 10%),

FILEGROUP FunctionDB_FILEGROUP_1
	(NAME = FunctionDB_fg1_1,
	 FILENAME = 'c:\Databaser\FunctionDB_fg1_1.ndf',
     SIZE = 20MB,
     MAXSIZE = 50MB,
     FILEGROWTH = 10%)

LOG ON
	(NAME = FunctionDB_log,
	 FILENAME = 'c:\Databaser\FunctionDB.ldf',
     SIZE = 20MB,
     MAXSIZE = 50MB,
     FILEGROWTH = 10%);
GO
ALTER DATABASE FunctionDB MODIFY FILEGROUP FunctionDB_FILEGROUP_1 DEFAULT;
GO
USE FunctionDB;
GO
CREATE FUNCTION dbo.ufn_ParseStringTSQLLoop (@string NVARCHAR(MAX),@separator CHAR(1))
RETURNS @parsedString TABLE
(
	Id		INT NOT NULL IDENTITY,
	String	NVARCHAR(MAX)
)
AS 
BEGIN
DECLARE @position int
   
SET @position = 1;
SET @string = @string + @separator;

WHILE CHARINDEX(@separator,@string,@position) <> 0
BEGIN
	INSERT INTO @parsedString(String)
		SELECT LTRIM(RTRIM(SUBSTRING(@string, @position, CHARINDEX(@separator,@string,@position) - @position)));

	SET @position = CHARINDEX(@separator,@string,@position) + 1;
END;

RETURN;
END
GO
SELECT *
	FROM dbo.ufn_ParseStringTSQLLoop ('abc,def,ghi', ',');

SELECT *
	FROM dbo.ufn_ParseStringTSQLLoop ('abc,    def,     ghi', ',');

SELECT *
	FROM dbo.ufn_ParseStringTSQLLoop ('abc,,,   def,     ghi', ',');
GO
CREATE TABLE dbo.Testdata
(
	Id			INT NOT NULL IDENTITY,
	String		NVARCHAR(MAX) NOT NULL
);
GO
SET NOCOUNT ON
DECLARE @i			INT = 10000;
DECLARE @j			INT;
DECLARE @k			INT;
DECLARE @l			INT;

DECLARE @String		NVARCHAR(MAX);
DECLARE @Alfabet	NVARCHAR(29) = 'abcdefghijklmnopqrstuvwxyz���';

WHILE @i > 0
BEGIN
	SET @String = ''

	SET @j = DATEPART(MILLISECOND, SYSDATETIME()) % 20 + 1;
	WHILE @j > 1
	BEGIN
		SET @k = DATEPART(MILLISECOND, SYSDATETIME()) % 29 + 1
		SET @l = DATEPART(SECOND, SYSDATETIME()) % 20 +  1;
		SET @String = @String + ',' + SUBSTRING(@Alfabet, @k, @l);

		SET @j -= 1;

		WAITFOR DELAY '00:00:00.007';
	END;
	INSERT INTO dbo.Testdata(String)
		VALUES(SUBSTRING(@String, 2, LEN(@String)))

	SET @i -= 1;
END;
SET NOCOUNT OFF
GO
SET STATISTICS TIME ON;
SELECT *
	FROM dbo.Testdata
GO
SELECT *
	FROM dbo.Testdata CROSS APPLY dbo.ufn_ParseStringTSQLLoop(String, ',');
SET STATISTICS TIME OFF;
GO
