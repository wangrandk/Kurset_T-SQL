USE master
DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
USE FunctionDB
GO
CREATE FUNCTION dbo.ufn_Navn (@Fornavn VARCHAR(20) = NULL, @Efternavn VARCHAR(20))
RETURNS VARCHAR(30)
AS
BEGIN

	IF @Fornavn IS NULL
		RETURN @Efternavn
	ELSE
		IF LEN(@Fornavn) + LEN(@Efternavn) < 30
			RETURN @Fornavn + ' ' + @Efternavn;
		ELSE
			RETURN LEFT(@Fornavn, 1) + '. ' + @Efternavn;

	RETURN 99;
END;
GO
SELECT dbo.ufn_Navn('Hans', 'Olsen');
GO
SELECT dbo.ufn_Navn(DEFAULT, 'Olsen');
GO
DECLARE @Navn		VARCHAR(30);

EXEC @Navn = dbo.ufn_Navn @Fornavn = 'Jens Ole', @Efternavn = 'Jensen';
SELECT @Navn;
GO
DECLARE @Navn		VARCHAR(30);

EXEC @Navn = dbo.ufn_Navn  @Efternavn = 'Jensen';
SELECT @Navn;