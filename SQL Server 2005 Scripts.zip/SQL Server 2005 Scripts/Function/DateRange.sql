USE master;
GO
DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
USE FunctionDB;
GO
CREATE FUNCTION dbo.DataRange 
	(
	@Increment		VARCHAR(10),
	@StartDate		DATE,
	@Enddate		DATE
)
RETURNS 
@Dates TABLE 
(
	Dato			DATE
)
AS
BEGIN;
WITH 
CTEDates (DateRange)
AS
(
SELECT @StartDate AS Dato
UNION ALL
SELECT 
		CASE 
			WHEN @Increment IN ('DAY', 'D') THEN DATEADD(DAY, 1, DateRange)
			WHEN @Increment IN ('WEEK', 'W') THEN DATEADD(WEEK, 1, DateRange)
			WHEN @Increment IN ('MONTH', 'M') THEN DATEADD(MONTH, 1, DateRange)
			WHEN @Increment IN ('YEAR', 'Y') THEN DATEADD(YEAR, 1, DateRange)
		END
	FROM CTEDates
	WHERE DateRange <=
		CASE 
			WHEN @Increment IN ('DAY', 'D') THEN DATEADD(DAY, -1, @Enddate)
			WHEN @Increment IN ('WEEK', 'W') THEN DATEADD(WEEK, -1, @Enddate)
			WHEN @Increment IN ('MONTH', 'M') THEN DATEADD(MONTH, -1, @Enddate)
			WHEN @Increment IN ('YEAR', 'Y') THEN DATEADD(YEAR, -1, @Enddate)
		END
)
INSERT INTO @Dates
	SELECT *
		FROM CTEDates

OPTION (MAXRECURSION 0)
RETURN 
END;
GO
-- Dan data til test
WITH 
AktuelleDatoer (Dato)
AS (
SELECT Dato
	FROM (VALUES	(CAST('2014-04-01' AS DATE)),
					(CAST('2014-04-02' AS DATE)),
					(CAST('2014-04-04' AS DATE)),
					(CAST('2014-04-05' AS DATE)),
					(CAST('2014-04-11' AS DATE)),
					(CAST('2014-04-14' AS DATE)),
					(CAST('2014-04-25' AS DATE)),
					(CAST('2014-04-30' AS DATE)) ) AS Datoer(Dato)
)
SELECT *
	INTO AktuelleDatoer
	FROM AktuelleDatoer;
GO
SELECT *
	FROM dbo.DataRange('DAY', (SELECT MIN(Dato) FROM AktuelleDatoer), (SELECT MAX(Dato) FROM AktuelleDatoer )) AS Datoer


SELECT *
	FROM dbo.DataRange('WEEK', (SELECT MIN(Dato) FROM AktuelleDatoer), (SELECT MAX(Dato) FROM AktuelleDatoer )) AS Datoer

GO
SELECT *
	FROM dbo.DataRange('DAY', (SELECT MIN(Dato) FROM AktuelleDatoer), (SELECT MAX(Dato) FROM AktuelleDatoer )) AS Datoer
EXCEPT
SELECT *
	FROM AktuelleDatoer
	ORDER BY Dato
