USE master;
DROP DATABASE FunctionDB;
GO
CREATE DATABASE FunctionDB;
GO
USE FunctionDB
CREATE TABLE dbo.Postopl 
(
	Postnr					SMALLINT NOT NULL PRIMARY KEY,	
	ByNavn					VARCHAR (30) NOT NULL
);
CREATE TABLE dbo.Kunde 
(
	KundeId					INT	NOT NULL PRIMARY KEY IDENTITY,
	Navn					VARCHAR (30) NOT NULL,
	Adresse					VARCHAR (30) NOT NULL,
	Postnr					SMALLINT NOT NULL 
							CONSTRAINT fk_postopl_kunde FOREIGN KEY REFERENCES postopl (Postnr)
);
CREATE TABLE dbo.Ordre 
(
	OrderId					INT	NOT NULL PRIMARY KEY IDENTITY,
	Bestillingsdato			DATE NOT NULL DEFAULT (SYSDATETIME()),
	Leveringsdato			DATE NULL,
	KundeId					INT NULL 
							CONSTRAINT fk_kunde_ordre FOREIGN KEY REFERENCES kunde (KundeId)
);
CREATE TABLE dbo.Ordrelinie 
(
	OrderId					INT	NOT NULL
							CONSTRAINT fk_ordre_ordrelinie FOREIGN KEY REFERENCES ordre (OrderId),
	VareId					INT	NOT NULL,
	AntalEnheder			SMALLINT NOT NULL,
	CONSTRAINT pk_ordrelinie PRIMARY KEY (OrderId,VareId)
);
GO
SET NOCOUNT ON;
INSERT INTO dbo.Postopl VALUES 
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(9000, 'Aalborg');

INSERT INTO dbo.Kunde VALUES 
	('Jens Hansen', 'Nygade 3', 2000),
	('Ole Larsen', 'Vestergade 4', 9000),
	('Karen Olsen', 'Borgergade 13', 9000),
	('Karl Nielsen', 'S�ndergade 67', 8000);

INSERT INTO dbo.Ordre (Leveringsdato, KundeId) VALUES 
	(DATEADD(DAY, 10, SYSDATETIME()), 2),
	(DATEADD(DAY, 22, SYSDATETIME()), 1),
	(DATEADD(DAY, 2, SYSDATETIME()), 2),
	(DATEADD(DAY, 11, SYSDATETIME()), 3),
	(DATEADD(DAY, 16, SYSDATETIME()), 2);

INSERT INTO dbo.Ordrelinie VALUES 
	(1, 3, 2),
	(1, 6, 8),
	(2, 3, 4),
	(3, 1, 1),
	(3, 2, 2),
	(4, 4, 3),
	(5, 2, 6),
	(5, 6, 1),
	(5, 7, 1);
SET NOCOUNT OFF;

SELECT DISTINCT Vareid
	INTO dbo.Vare
	FROM dbo.Ordrelinie;
GO
CREATE FUNCTION ufn_vare 
(
	@KundeId INT, 
	@VareId INT
)
RETURNS @vare TABLE (
	OrderId			VARCHAR(100) NOT NULL,
	AntalEnheder	INT NULL)
AS
BEGIN 
	DECLARE @OrderId		VARCHAR(100);
	DECLARE @AntalEnheder	INT;

	SELECT @OrderId = ISNULL(@OrderId, '') + CAST(ordrelinie.OrderId AS VARCHAR(10)) + ', ',
		@AntalEnheder = ISNULL(@AntalEnheder, 0) + AntalEnheder
		FROM ordrelinie INNER JOIN ordre ON ordrelinie.OrderId = ordre.OrderId
						INNER JOIN kunde ON ordre.KundeId = kunde.KundeId
		WHERE kunde.KundeId = @KundeId and
			  ordrelinie.VareId = @VareId;

	INSERT INTO @vare VALUES 
		(LEFT(@OrderId, LEN(@OrderId) - 1), @AntalEnheder);
	RETURN;
END;
GO
SELECT * 
	FROM ufn_vare(2,2);
GO
CREATE FUNCTION ufn_ordrelinie_kunde (@KundeId INT)
RETURNS @ordrelinie TABLE (
	OrderId			VARCHAR(100) NOT NULL,
	VareId			INT NOT NULL,
	AntalEnheder	INT NOT NULL)
AS
BEGIN
	INSERT INTO @ordrelinie
		SELECT	OrderId,
				VareId,	
				AntalEnheder
		FROM (SELECT VareId  
				FROM ordrelinie INNER JOIN ordre ON ordrelinie.OrderId = ordre.OrderId
				WHERE ordre.KundeId = @KundeId
				GROUP BY VareId) AS varetbl OUTER APPLY ufn_vare(@KundeId, varetbl.VareId);
	
	RETURN;
END
GO
SELECT * 
	FROM ufn_ordrelinie_kunde(2);
--OrderId, VareId, AntalEnheder


SELECT * 
	FROM ufn_ordrelinie_kunde(2) AS ok INNER JOIN dbo.Vare ON ok.VareId = Vare.VareId;
	