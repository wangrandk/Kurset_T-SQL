USE master
GO
DROP DATABASE FunctionDB
GO
CREATE DATABASE FunctionDB
GO
USE FunctionDB
GO
CREATE TABLE dbo.Kunderabat
(
	Rabatkode		SMALLINT NOT NULL 
					CONSTRAINT PK_Kunderabat PRIMARY KEY,
	Rabatgrp		VARCHAR(20) NOT NULL
					CONSTRAINT UQ_Kunderabar__Rabatgrp UNIQUE,
	Rabatpct		SMALLINT NOT NULL
					CONSTRAINT CK_Rabatkode__Rabatpct CHECK (Rabatpct BETWEEN 0 AND 25),
);

CREATE TABLE dbo.Kunde
(
	Kundeid			INT NOT NULL
					CONSTRAINT PK_Kunde PRIMARY KEY,
	Kundenavn		VARCHAR(40) NOT NULL,
	Rabatkode		SMALLINT NOT NULL
					CONSTRAINT FK_Kunde_Kunderabat FOREIGN KEY REFERENCES dbo.Kunderabat(Rabatkode)
);

CREATE TABLE dbo.Medarbejder
(
	Medarbejderid	INT NOT NULL
					CONSTRAINT PK_Medarbejder PRIMARY KEY,
	Medarbejderavn	VARCHAR(40) NOT NULL,
	Kundeid			INT NULL
					CONSTRAINT FK_Medarbejder_Kunde FOREIGN KEY REFERENCES dbo.Kunde(Kundeid)
);
GO
INSERT INTO dbo.Kunderabat VALUES
	(1, 'Almindelig', 0),
	(2, 'Storkunde', 10),
	(3, 'Firma', 15),
	(99, 'Medarbejder', 25);

INSERT INTO dbo.Kunde VALUES
	(1, 'Andersen & S�n', 3),
	(2, 'Jens Olsen', 1),
	(3, 'T�mmermesteren', 1),
	(4,	'Hans Jensen', 2);	

INSERT INTO dbo.Medarbejder VALUES
	(1, 'Ane Hansen', NULL),
	(2, 'Hans Peter Jensen', 4),
	(3, 'Jens Olsen', 2);
GO
CREATE FUNCTION dbo.ufn_Kunde ()
RETURNS @Kunde TABLE
(
	Kundeid			INT NOT NULL,
	Rabatpct		SMALLINT NOT NULL
)
AS
BEGIN
	INSERT INTO @Kunde (Kundeid, Rabatpct)
		SELECT	Kunde.Kundeid,  
				Kunderabat.Rabatpct
			FROM dbo.Kunde INNER JOIN dbo.Kunderabat ON Kunde.Rabatkode = Kunderabat.Rabatkode;
	
	UPDATE @Kunde
		SET Rabatpct = (SELECT Rabatpct 
							FROM dbo.Kunderabat 
							WHERE Rabatgrp = 'Medarbejder')
		WHERE Kundeid IN (SELECT Kundeid 
							FROM dbo.Medarbejder 
							WHERE Kundeid IS NOT NULL)
	
	RETURN;
END;
GO
SELECT *
	FROM dbo.ufn_Kunde() AS Kunde;	
	
SELECT *
	FROM dbo.ufn_Kunde() AS KundeRabat INNER JOIN dbo.Kunde ON KundeRabat.Kundeid = Kunde.Kundeid;

SELECT *
	FROM dbo.ufn_Kunde() AS KundeRabat INNER JOIN dbo.Medarbejder 
					ON KundeRabat.Kundeid = Medarbejder.Kundeid;
GO
ALTER FUNCTION dbo.ufn_Kunde (@Kundeid		INT)
RETURNS @Kunde TABLE
(
	Kundeid			INT NOT NULL,
	Rabatpct		SMALLINT NOT NULL
)
AS
BEGIN
	INSERT INTO @Kunde (Kundeid, Rabatpct)
		SELECT	Kunde.Kundeid,  
				Kunderabat.Rabatpct
			FROM dbo.Kunde INNER JOIN dbo.Kunderabat ON Kunde.Rabatkode = Kunderabat.Rabatkode
			WHERE Kunde.KundeID = @KundeID;
	
	UPDATE @Kunde
		SET Rabatpct = (SELECT Rabatpct 
							FROM dbo.Kunderabat 
							WHERE Rabatgrp = 'Medarbejder')
		WHERE Kundeid IN (SELECT Kundeid 
							FROM dbo.Medarbejder 
							WHERE Kundeid IS NOT NULL) AND
			Kundeid = @KundeID
	
	RETURN;
END;
GO
SELECT *
	FROM dbo.ufn_Kunde(4) AS KundeRabat INNER JOIN dbo.Kunde 
			ON KundeRabat.Kundeid = Kunde.Kundeid;

SELECT *
	FROM dbo.ufn_Kunde(1) AS KundeRabat INNER JOIN dbo.Kunde 
			ON KundeRabat.Kundeid = Kunde.Kundeid;
SELECT *
	FROM dbo.Medarbejder OUTER APPLY dbo.ufn_Kunde(Medarbejder.Kundeid) AS KundeRabat;
