USE master;
DROP DATABASE PartitionDB;
GO
CREATE DATABASE PartitionDB
ON PRIMARY
	(NAME = PartitionDB_sys,
	 FILENAME = 'c:\Databaser\PartitionDB_sys.mdf',
     SIZE = 5MB),

FILEGROUP PartitionDB_fg1
	(NAME = PartitionDB_fg1,
	 FILENAME = 'c:\Databaser\PartitionDB_fg1.ndf',
     SIZE = 2MB),
	
FILEGROUP PartitionDB_fg2
	(NAME = PartitionDB_fg2,
	 FILENAME = 'c:\Databaser\PartitionDB_fg2.ndf',
     SIZE = 2MB),
	
FILEGROUP PartitionDB_fg3
	(NAME = PartitionDB_fg3,
	 FILENAME = 'c:\Databaser\PartitionDB_fg3.ndf',
     SIZE = 2MB),
	
FILEGROUP PartitionDB_fg4
	(NAME = PartitionDB_fg4,
	 FILENAME = 'c:\Databaser\PartitionDB_fg4.ndf',
     SIZE = 2MB)

LOG ON
	(NAME = PartitionDB_log,
	 FILENAME = 'c:\Databaser\PartitionDB.ldf',
     SIZE = 2MB);
GO
USE PartitionDB;
CREATE PARTITION FUNCTION partition_function (DATETIME)
	AS RANGE RIGHT FOR VALUES ('2016-11-2', '2016-11-3', '2016-11-4');
GO
CREATE PARTITION scheme partition_scheme
	AS PARTITION partition_function TO (PartitionDB_fg1, 
										PartitionDB_fg2, 
										PartitionDB_fg3, 
										PartitionDB_fg4);
GO
CREATE TABLE dbo.PartitionTable
(
	Id			INT NOT NULL IDENTITY, 
	Navn		CHAR(10) NOT NULL,
	Tid			DATETIME NOT NULL
)
ON partition_scheme (Tid);
GO
--hvilken partition tilh�rer en given v�rdi
SELECT '2016-11-2' AS value, $partition.partition_function ('2016-11-2') AS partition
UNION ALL
SELECT '2016-11-1', $partition.partition_function ('2016-11-1')
UNION ALL
SELECT '2016-11-1 23:59:59:997', $partition.partition_function ('2016-11-1 23:59:59:997')
UNION ALL
SELECT '2016-11-1 23:59:59:999', $partition.partition_function ('2016-11-1 23:59:59:999')
GO
INSERT INTO dbo.PartitionTable VALUES 
	('Ole', '2016-11-1'),
	('Per', '2016-11-2'),
	('Ida', '2016-11-3'),
	('Ane', '2016-11-4'),
	('Mie', '2016-11-5'),
	('Eva', '2016-11-6'),
	('Ole', '2016-11-7');
GO
SELECT	$partition.partition_function(Tid) AS partition, 
		COUNT(*) AS antal
	FROM dbo.PartitionTable
	GROUP BY $partition.partition_function(Tid)
	ORDER BY partition;
GO
ALTER DATABASE PartitionDB
	ADD FILEGROUP PartitionDB_fg5;
GO
ALTER DATABASE PartitionDB
	ADD FILE
		(NAME = PartitionDB_fg5,
		 FILENAME = 'c:\Databaser\PartitionDB_fg5.ndf',
		 SIZE = 2MB)
	TO FILEGROUP PartitionDB_fg5;
GO 
ALTER PARTITION scheme partition_scheme
	NEXT used PartitionDB_fg5;
GO
ALTER PARTITION FUNCTION partition_function ()
	SPLIT RANGE ('2016-11-5');
GO
SELECT	$partition.partition_function(Tid) AS partition, 
		COUNT(*) AS antal
	FROM dbo.PartitionTable
	GROUP BY $partition.partition_function(Tid)
	ORDER BY partition;
GO
ALTER PARTITION FUNCTION partition_function ()
	MERGE RANGE ('2016-11-2');
GO
SELECT	$partition.partition_function(Tid) AS partition, 
		COUNT(*) AS antal
	FROM dbo.PartitionTable
	GROUP BY $partition.partition_function(Tid)
	ORDER BY partition;
GO
SELECT * 
	FROM sys.filegroups;
SELECT * 
	FROM sys.allocation_units;
SELECT * 
	FROM sys.partitions 
	WHERE object_id = object_id('PartitionTable');
GO
CREATE TABLE dbo.PartitionTable_slet 
(
	Id			INT NOT NULL IDENTITY, 
	Navn		CHAR(10) NOT NULL,
	Tid			DATETIME NOT NULL
)
ON PartitionDB_fg1;
GO
SELECT * 
	FROM dbo.PartitionTable;
SELECT * 
	FROM dbo.PartitionTable_slet;
GO
ALTER TABLE dbo.PartitionTable SWITCH 
	PARTITION 1 TO dbo.PartitionTable_slet;
GO
SELECT * 
	FROM dbo.PartitionTable;
SELECT * 
	FROM dbo.PartitionTable_slet;
GO
DROP TABLE dbo.PartitionTable_slet;
