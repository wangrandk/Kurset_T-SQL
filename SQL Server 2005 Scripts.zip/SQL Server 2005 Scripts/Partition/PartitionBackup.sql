USE master;
DROP DATABASE PartitionDB;
GO
CREATE DATABASE PartitionDB
ON PRIMARY
	(NAME = PartitionDB_sys,
	 FILENAME = 'c:\Databaser\PartitionDB_sys.mdf',
     SIZE = 5MB),

FILEGROUP PartitionDB_fg1
	(NAME = PartitionDB_fg1,
	 FILENAME = 'c:\Databaser\PartitionDB_fg1.ndf',
     SIZE = 2MB),
	
FILEGROUP PartitionDB_fg2
	(NAME = PartitionDB_fg2,
	 FILENAME = 'c:\Databaser\PartitionDB_fg2.ndf',
     SIZE = 2MB),
	
FILEGROUP PartitionDB_fg3
	(NAME = PartitionDB_fg3,
	 FILENAME = 'c:\Databaser\PartitionDB_fg3.ndf',
     SIZE = 2MB),
	
FILEGROUP PartitionDB_fg4
	(NAME = PartitionDB_fg4,
	 FILENAME = 'c:\Databaser\PartitionDB_fg4.ndf',
     SIZE = 2MB)

LOG ON
	(NAME = PartitionDB_log,
	 FILENAME = 'c:\Databaser\PartitionDB.ldf',
     SIZE = 2MB);
GO
USE PartitionDB;
CREATE PARTITION FUNCTION partition_function (DATETIME)
	AS RANGE RIGHT FOR VALUES ('2016-2-2', '2016-2-3', '2016-2-4');
GO
CREATE PARTITION scheme partition_schema
	AS PARTITION partition_function TO (PartitionDB_fg1, 
										PartitionDB_fg2, 
										PartitionDB_fg3, 
										PartitionDB_fg4);
GO
CREATE TABLE dbo.PartitionTable 
(
	Id			INT NOT NULL IDENTITY, 
	Navn		VARCHAR(10) NOT NULL,
	Tid			DATETIME NOT NULL
)
ON partition_schema (Tid);
GO
INSERT INTO dbo.PartitionTable VALUES 
	('Ole', '2016-2-1'),
	('Per', '2016-2-2'),
	('Ida', '2016-2-3'),
	('Ane', '2016-2-4'),
	('Mie', '2016-2-5'),
	('Eva', '2016-2-6'),
	('Ole', '2016-2-7');
GO
SELECT * 
	FROM dbo.PartitionTable;
GO
BACKUP DATABASE PartitionDB 
	TO DISK = 'c:\rod\PartitionDB.bak' 
	WITH FORMAT;
GO
BACKUP LOG PartitionDB 
	TO DISK = 'c:\rod\PartitionDB_log.bak' 
	WITH FORMAT;
GO
USE master;
DROP DATABASE PartitionDB;
GO
RESTORE DATABASE PartitionDB 
	FILEGROUP='primary' 
	FROM DISK = 'c:\rod\PartitionDB.bak'  
	WITH PARTIAL, NORECOVERY;

RESTORE DATABASE PartitionDB 
	FILEGROUP='PartitionDB_fg4' 
	FROM DISK = 'c:\rod\PartitionDB.bak' 
	WITH NORECOVERY;

RESTORE LOG PartitionDB 
	FROM DISK = 'c:\rod\PartitionDB_log.bak' 
	WITH RECOVERY;
GO
USE PartitionDB;
SELECT * 
	FROM dbo.PartitionTable 
	WHERE id = 7;			-- fejler, da der ikke refereres til partition-kolonne
GO
SELECT * 
	FROM dbo.PartitionTable 
	WHERE Tid >= '2016-2-4';

SELECT * 
	FROM dbo.PartitionTable 
	WHERE	Tid >= '2016-2-4' AND 
			ID > 5;
GO
SELECT * 
	FROM sys.database_files;
GO
USE master
RESTORE DATABASE PartitionDB 
	FILEGROUP='PartitionDB_fg1' 
	FROM DISK = 'c:\rod\PartitionDB.bak'  
	WITH NORECOVERY;

RESTORE LOG PartitionDB 
	FROM DISK = 'c:\rod\PartitionDB_log.bak' 
	WITH RECOVERY;
GO
USE partitionDB;
UPDATE dbo.PartitionTable 
	SET Tid = '2016-2-9';
GO
UPDATE dbo.PartitionTable 
	SET Tid = '2016-2-9'
	WHERE Tid = '2016-2-1';
