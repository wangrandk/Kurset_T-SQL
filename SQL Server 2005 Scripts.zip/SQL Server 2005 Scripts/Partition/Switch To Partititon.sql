USE master;
DROP DATABASE PartitionDB;
GO
CREATE DATABASE PartitionDB;
GO
USE PartitionDB;
GO
CREATE TABLE dbo.Person
(
	ID			INT			NOT NULL IDENTITY
				CONSTRAINT PK_Person PRIMARY KEY ,
	Navn		VARCHAR(20) NOT NULL
); 
GO
SET NOCOUNT ON;
GO
INSERT INTO dbo.Person (Navn) VALUES ('Ole Olsen');
GO 1000
ALTER DATABASE PartitionDB  
	ADD FILEGROUP PartitionDB_fg1; 

ALTER DATABASE PartitionDB
	ADD FILE
		(NAME = PartitionDb_fg1,
		 FILENAME = 'c:\databaser\PartitionDb_fg1.ndf',
		 SIZE = 10MB)
	TO FILEGROUP PartitionDb_fg1;
GO  
ALTER DATABASE PartitionDB  
	ADD FILEGROUP PartitionDB_fg2; 

ALTER DATABASE PartitionDB
	ADD FILE
		(NAME = PartitionDb_fg2,
		 FILENAME = 'c:\databaser\PartitionDb_fg2.ndf',
		 SIZE = 10MB)
	TO FILEGROUP PartitionDb_fg2;
GO 
ALTER DATABASE PartitionDB  
	ADD FILEGROUP PartitionDB_fg3; 

ALTER DATABASE PartitionDB
	ADD FILE
		(NAME = PartitionDb_fg3,
		 FILENAME = 'c:\databaser\PartitionDb_fg3.ndf',
		 SIZE = 10MB)
	TO FILEGROUP PartitionDb_fg3;
GO  
ALTER DATABASE PartitionDB  
	ADD FILEGROUP PartitionDB_fg4; 

ALTER DATABASE PartitionDB
	ADD FILE
		(NAME = PartitionDb_fg4,
		 FILENAME = 'c:\databaser\PartitionDb_fg4.ndf',
		 SIZE = 10MB)
	TO FILEGROUP PartitionDb_fg4;
GO  
ALTER DATABASE PartitionDB  
	ADD FILEGROUP PartitionDB_fg5; 

ALTER DATABASE PartitionDB
	ADD FILE
		(NAME = PartitionDb_fg5,
		 FILENAME = 'c:\databaser\PartitionDb_fg5.ndf',
		 SIZE = 10MB)
	TO FILEGROUP PartitionDb_fg5;
GO  
ALTER DATABASE PartitionDB  
	ADD FILEGROUP PartitionDB_fg6; 

ALTER DATABASE PartitionDB
	ADD FILE
		(NAME = PartitionDb_fg6,
		 FILENAME = 'c:\databaser\PartitionDb_fg6.ndf',
		 SIZE = 10MB)
	TO FILEGROUP PartitionDb_fg6;
GO  
CREATE PARTITION FUNCTION RangeFuncPartitionDB (INT)  
	AS RANGE LEFT FOR VALUES ( 200, 400, 600, 800);  
GO  
CREATE PARTITION SCHEME RangeSchemePartitionDB  
	AS PARTITION RangeFuncPartitionDB  
	TO (PartitionDb_fg1, 
		PartitionDb_fg2,
		PartitionDb_fg3,
		PartitionDb_fg4,
		PartitionDb_fg5);  
GO  
ALTER PARTITION SCHEME RangeSchemePartitionDB  
	NEXT USED PartitionDb_fg6;  
GO
ALTER PARTITION FUNCTION RangeFuncPartitionDB () 
	SPLIT RANGE (1000);  
GO
ALTER TABLE dbo.Person DROP CONSTRAINT PK_Person;
GO
--ALTER TABLE dbo.Person ADD CONSTRAINT PK_Person PRIMARY KEY NONCLUSTERED (ID);
GO
CREATE UNIQUE CLUSTERED INDEX CL_Person_ID		
	ON dbo.Person(ID)
	ON RangeSchemePartitionDB(ID);
GO
SELECT	 $partition.RangeFuncPartitionDB(ID) AS PartitionNo, 
		COUNT(*) AS Antal
	FROM dbo.Person
	GROUP BY $partition.RangeFuncPartitionDB(ID)
	ORDER BY PartitionNo;
GO
INSERT INTO dbo.Person (Navn) VALUES ('Ida Hansen');
GO 325
SELECT	 $partition.RangeFuncPartitionDB(ID) AS PartitionNo, 
		COUNT(*) AS Antal
	FROM dbo.Person
	GROUP BY $partition.RangeFuncPartitionDB(ID)
	ORDER BY PartitionNo;
GO
ALTER DATABASE PartitionDB  
	ADD FILEGROUP PartitionDB_fg7; 

ALTER DATABASE PartitionDB
	ADD FILE
		(NAME = PartitionDb_fg7,
		 FILENAME = 'c:\databaser\PartitionDb_fg7.ndf',
		 SIZE = 10MB)
	TO FILEGROUP PartitionDb_fg7;
GO 
ALTER PARTITION SCHEME RangeSchemePartitionDB  
	NEXT USED PartitionDb_fg7;  
GO
ALTER PARTITION FUNCTION RangeFuncPartitionDB () 
	SPLIT RANGE (1200);
GO
SELECT	 $partition.RangeFuncPartitionDB(ID) AS PartitionNo, 
		COUNT(*) AS Antal
	FROM dbo.Person
	GROUP BY $partition.RangeFuncPartitionDB(ID)
	ORDER BY PartitionNo;
GO
