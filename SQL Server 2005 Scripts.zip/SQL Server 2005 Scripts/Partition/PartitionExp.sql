USE MASTER;
DROP DATABASE FileGrpExp;
GO
CREATE DATABASE FileGrpExp
ON PRIMARY
	(NAME = FileGrpExp_sys,
	 FILENAME = 'c:\Databaser\FileGrpExp_sys.mdf',
     SIZE = 5MB),

FILEGROUP FileGrpExp_fg1
	(NAME = FileGrpExp_fg1,
	 FILENAME = 'c:\Databaser\FileGrpExp_fg1.ndf',
     SIZE = 10MB),
	
FILEGROUP FileGrpExp_fg2
	(NAME = FileGrpExp_fg2,
	 FILENAME = 'c:\Databaser\FileGrpExp_fg2.ndf',
     SIZE = 10MB),
	
FILEGROUP FileGrpExp_fg3
	(NAME = FileGrpExp_fg3,
	 FILENAME = 'c:\Databaser\FileGrpExp_fg3.ndf',
     SIZE = 10MB)

LOG ON
	(NAME = FileGrpExp_log,
	 FILENAME = 'c:\Databaser\FileGrpExp.ldf',
     SIZE = 25MB);
GO
USE FileGrpExp;
CREATE PARTITION FUNCTION pf_Person (VARCHAR(2))
	AS RANGE LEFT FOR VALUES ('10', '20');
GO
CREATE PARTITION SCHEME ps_Person
	AS PARTITION pf_Person
	TO (FileGrpExp_fg1, FileGrpExp_fg2, FileGrpExp_fg3);
GO
CREATE TABLE dbo.Person
(
	ID			INT NOT NULL IDENTITY,
	Navn		VARCHAR(30) NOT NULL,
	Cprnr		CHAR(10) NOT NULL CHECK(Cprnr LIKE'[0-3][0-9][01][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' AND
										CAST(LEFT(Cprnr, 2) AS SMALLINT) BETWEEN 1 AND 31),
	CprnrDag	AS LEFT(Cprnr, 2) PERSISTED
) ON ps_Person(CprnrDag)
GO
INSERT INTO Person (Navn, Cprnr) VALUES
	('Ida', '0111951234'),
	('Ida', '0211951234'),
	('Ida', '0311951234'),
	('Ida', '0411951234'),
	('Ida', '0511951234'),
	('Ida', '0611951234'),
	('Ida', '0711951234'),
	('Ida', '0811951234'),
	('Ida', '0911951234'),
	('Ida', '1011951234'),
	('Ida', '1111951234'),
	('Ida', '1211951234'),
	('Ida', '1311951234'),
	('Ida', '1411951234'),
	('Ida', '1511951234'),
	('Ida', '1611951234'),
	('Ida', '1711951234'),
	('Ida', '1811951234'),
	('Ida', '1911951234'),
	('Ida', '2011951234'),
	('Ida', '2111951234'),
	('Ida', '2211951234'),
	('Ida', '2311951234'),
	('Ida', '2411951234'),
	('Ida', '2511951234'),
	('Ida', '2611951234'),
	('Ida', '2711951234'),
	('Ida', '2811951234'),
	('Ida', '2911951234'),
	('Ida', '3011951234'),
	('Ida', '3111951234')
GO
SELECT	$partition.pf_Person(CprnrDag) AS Partition, 
		COUNT(*) AS Antal
	FROM Person 
	GROUP BY $partition.pf_Person(CprnrDag)
	ORDER BY Partition
GO
USE MASTER;
DROP DATABASE FileGrpExp;
GO
CREATE DATABASE FileGrpExp
ON PRIMARY
	(NAME = FileGrpExp_sys,
	 FILENAME = 'c:\Databaser\FileGrpExp_sys.mdf',
     SIZE = 5MB),

FILEGROUP FileGrpExp_fg1
	(NAME = FileGrpExp_fg1,
	 FILENAME = 'c:\Databaser\FileGrpExp_fg1.ndf',
     SIZE = 10MB),
	
FILEGROUP FileGrpExp_fg2
	(NAME = FileGrpExp_fg2,
	 FILENAME = 'c:\Databaser\FileGrpExp_fg2.ndf',
     SIZE = 10MB),
	
FILEGROUP FileGrpExp_fg3
	(NAME = FileGrpExp_fg3,
	 FILENAME = 'c:\Databaser\FileGrpExp_fg3.ndf',
     SIZE = 10MB),
	
FILEGROUP FileGrpExp_fg4
	(NAME = FileGrpExp_fg4,
	 FILENAME = 'c:\Databaser\FileGrpExp_fg4.ndf',
     SIZE = 10MB)

LOG ON
	(NAME = FileGrpExp_log,
	 FILENAME = 'c:\Databaser\FileGrpExp.ldf',
     SIZE = 25MB);
GO
USE FileGrpExp;
CREATE PARTITION FUNCTION pf_Person (VARCHAR(2))
	AS RANGE LEFT FOR VALUES (NULL, '10', '20');
GO
CREATE PARTITION SCHEME ps_Person
	AS PARTITION pf_Person
	TO (FileGrpExp_fg1, FileGrpExp_fg2, FileGrpExp_fg3, FileGrpExp_fg4);
GO
CREATE TABLE dbo.Person
(
	ID			INT			NOT NULL IDENTITY,
	Navn		VARCHAR(30) NOT NULL,
	Cprnr		CHAR(10)	NULL CHECK(Cprnr LIKE'[0-3][0-9][01][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' AND
										CAST(LEFT(Cprnr, 2) AS SMALLINT) BETWEEN 1 AND 31),
	CprnrDag	AS LEFT(Cprnr, 2) PERSISTED
) ON ps_Person(CprnrDag)
GO
INSERT INTO Person (Navn, Cprnr) VALUES
	('Ida', '0111951234'),
	('Ida', '0211951234'),
	('Ida', '0311951234'),
	('Ida', '0411951234'),
	('Ida', '0511951234'),
	('Ida', '0611951234'),
	('Ida', '0711951234'),
	('Ida', '0811951234'),
	('Ida', '0911951234'),
	('Ida', '1011951234'),
	('Ida', '1111951234'),
	('Ida', '1211951234'),
	('Ida', '1311951234'),
	('Ida', '1411951234'),
	('Ida', '1511951234'),
	('Ida', '1611951234'),
	('Ida', '1711951234'),
	('Ida', '1811951234'),
	('Ida', '1911951234'),
	('Ida', '2011951234'),
	('Ida', '2111951234'),
	('Ida', '2211951234'),
	('Ida', '2311951234'),
	('Ida', '2411951234'),
	('Ida', '2511951234'),
	('Ida', '2611951234'),
	('Ida', '2711951234'),
	('Ida', '2811951234'),
	('Ida', '2911951234'),
	('Ida', '3011951234'),
	('Ida', '3111951234'),
	('Ole', NULL),
	('Ole', NULL)
GO
SELECT $partition.pf_Person(CprnrDag) AS Partition, COUNT(*) AS Antal
	FROM Person 
	GROUP BY $partition.pf_Person(CprnrDag)
	ORDER BY Partition
GO