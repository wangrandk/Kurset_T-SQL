USE master;
DROP DATABASE PartitionDB;
GO
CREATE DATABASE PartitionDB
ON PRIMARY
	(NAME = PartitionDB_sys,
	FILENAME = 'c:\Databaser\PartitionDB.mdf',
	SIZE = 5MB),
FILEGROUP DataFg
	(NAME = PartitionDB_DataFg,
	FILENAME = 'c:\Databaser\PartitionDB_DataFg.ndf',
	SIZE = 40MB)
LOG ON
	(NAME = PartitionDB_log,
	FILENAME = 'c:\Databaser\PartitionDB.ldf',
	SIZE = 20MB);
GO
USE PartitionDB;
GO
CREATE PARTITION FUNCTION pfn_MaanedsData (DATETIME2(0)) 
	AS RANGE RIGHT FOR VALUES (
				'2016-05-01', '2016-06-01', '2016-07-01', '2016-08-01', 
				'2016-09-01', '2016-10-01', '2016-11-01', '2016-12-01', 
				'2017-01-01', '2017-02-01', '2017-03-01', '2017-04-01');
GO
CREATE PARTITION FUNCTION pfn_MaanedsDataSlet (DATETIME2(0)) 
	AS RANGE RIGHT FOR VALUES (
							'2016-05-01',
							'2016-06-01');
GO
CREATE PARTITION SCHEME MaanedsData 
	AS PARTITION pfn_MaanedsData 
	ALL TO (DataFg);
GO
CREATE PARTITION SCHEME MaanedsDataSlet 
	AS PARTITION pfn_MaanedsDataSlet 
	ALL TO (DataFg);
GO
CREATE TABLE dbo.PartitionTable 
(
	Id			INT				NOT NULL,
	Slutdato	DATETIME2(0)	NOT NULL
) 
ON MaanedsData (Slutdato);
GO
CREATE CLUSTERED INDEX cl_PartitionTable_Slutdato
	ON dbo.PartitionTable (Slutdato) ON MaanedsData (Slutdato);
GO
ALTER TABLE dbo.PartitionTable WITH NOCHECK ADD 
	CONSTRAINT pk_PartitionTable PRIMARY KEY  NONCLUSTERED 
	(Id, Slutdato)  ON MaanedsData (Slutdato)  
GO
CREATE TABLE dbo.PartitionTable_slet 
(
   Id			INT				NOT NULL,
   Slutdato		DATETIME2(0)	NOT NULL
  ) 
ON MaanedsDataSlet (Slutdato);
GO
CREATE CLUSTERED INDEX cl_PartitionTable_slet_Slutdato 
	ON dbo.PartitionTable_slet(Slutdato) ON  MaanedsDataSlet (Slutdato);
GO
ALTER TABLE dbo.PartitionTable_slet WITH NOCHECK ADD 
	CONSTRAINT pk_cdr_slet PRIMARY KEY NONCLUSTERED 
	(Id, Slutdato) ON MaanedsDataSlet (Slutdato);
GO
SELECT * 
	FROM sys.partition_range_values
	WHERE function_id IN (SELECT function_id 
							FROM sys.partition_functions
							WHERE name = 'pfn_MaanedsData');

SELECT * 
	FROM sys.partition_range_values
	WHERE function_id IN (SELECT function_id 
							FROM sys.partition_functions
							WHERE name = 'pfn_MaanedsDataSlet');
GO
CREATE PROCEDURE proc_add_partition_right 
AS
BEGIN
	DECLARE @day DATETIME2(0)

	SET @day = CAST((SELECT TOP 1 VALUE 
						FROM sys.partition_range_values
						WHERE function_id = 
							(SELECT function_id 
								FROM sys.partition_functions
								WHERE name = 'pfn_MaanedsData')
						ORDER BY boundary_id DESC) AS DATETIME2(0))

	SET @day = DATEADD(MONTH, 1, @day);

	ALTER PARTITION SCHEME MaanedsData 
		NEXT USED DataFg;
	ALTER PARTITION FUNCTION pfn_MaanedsData() 
		SPLIT RANGE (@day);
END;
GO
CREATE PROCEDURE proc_del_partition_left
AS
BEGIN
	ALTER PARTITION SCHEME MaanedsData 
		NEXT USED DataFg;
	ALTER PARTITION SCHEME MaanedsDataSlet 
		NEXT USED DataFg;

	DECLARE @day			DATETIME2(0)
	DECLARE @month_next2	DATETIME2(0)
	DECLARE @scratch		VARCHAR(2000)

	SET @day = CAST((SELECT TOP 1 VALUE 
						FROM sys.partition_range_values
						WHERE function_id = 
							(SELECT function_id 
								FROM sys.partition_functions
								WHERE name = 'pfn_MaanedsData')
					ORDER BY boundary_id) AS DATETIME2(0))

	SET @month_next2  = DATEADD(MONTH, 2, @day)

	ALTER PARTITION FUNCTION pfn_MaanedsDataSlet() 
		SPLIT RANGE (@month_next2);
	ALTER TABLE dbo.PartitionTable 
		SWITCH PARTITION 2 TO dbo.PartitionTable_slet PARTITION 2;
	ALTER PARTITION FUNCTION pfn_MaanedsData() 
		MERGE RANGE (@day);
	ALTER PARTITION FUNCTION pfn_MaanedsDataSlet() 
		MERGE RANGE (@day);

--	kommenteret ud for at vise data i dbo.PartitionTable_slet
--	TRUNCATE TABLE dbo.PartitionTable_slet;		
END;
GO
-- Inds�ttelse af data
INSERT INTO dbo.PartitionTable (Id, Slutdato)
	SELECT	1, 
			CAST(value AS DATETIME2(0)) 
		FROM sys.partition_range_values
		WHERE function_id = (SELECT function_id 
								FROM sys.partition_functions
								WHERE name = 'pfn_MaanedsData');
GO
INSERT INTO dbo.PartitionTable
	SELECT	ID + (SELECT MAX(Id) FROM dbo.PartitionTable),
			DATEADD(DAY, 2, Slutdato)
		FROM dbo.PartitionTable;
	
INSERT INTO dbo.PartitionTable
	SELECT	ID + (SELECT MAX(Id) FROM dbo.PartitionTable),
			DATEADD(DAY, 3, Slutdato)
		FROM dbo.PartitionTable;	
GO 3
SELECT	YEAR(Slutdato) AS Aar,
		MONTH(Slutdato) AS Maaned,
		COUNT(*) 
	FROM dbo.PartitionTable
	GROUP BY YEAR(Slutdato), MONTH(Slutdato)
	ORDER BY Aar, Maaned;

SELECT	YEAR(Slutdato) AS Aar,
		MONTH(Slutdato) AS Maaned,
		COUNT(*) 
	FROM dbo.PartitionTable_slet
	GROUP BY YEAR(Slutdato), MONTH(Slutdato)
	ORDER BY Aar, Maaned;

SELECT * 
	FROM dbo.PartitionTable;
SELECT *
	FROM dbo.PartitionTable_slet;
GO
EXEC proc_add_partition_right;
EXEC proc_del_partition_left;
GO
SELECT	YEAR(Slutdato) AS Aar,
		MONTH(Slutdato) AS Maaned,
		COUNT(*) 
	FROM dbo.PartitionTable
	GROUP BY YEAR(Slutdato), MONTH(Slutdato)
	ORDER BY Aar, Maaned;

SELECT	YEAR(Slutdato) AS Aar,
		MONTH(Slutdato) AS Maaned,
		COUNT(*) 
	FROM dbo.PartitionTable_slet
	GROUP BY YEAR(Slutdato), MONTH(Slutdato)
	ORDER BY Aar, Maaned;

SELECT * 
	FROM dbo.PartitionTable_slet;
GO
SELECT * 
	FROM sys.partition_range_values
	WHERE function_id IN (SELECT function_id 
							FROM sys.partition_functions
							WHERE name = 'pfn_MaanedsData');

SELECT * 
	FROM sys.partition_range_values
	WHERE function_id IN (SELECT function_id 
							FROM sys.partition_functions
							WHERE name = 'pfn_MaanedsDataSlet');
GO
SELECT	YEAR(Slutdato) AS Aar,
		MONTH(Slutdato) AS Maaned,
		COUNT(*) 
	FROM dbo.PartitionTable
	GROUP BY YEAR(Slutdato), MONTH(Slutdato)
	ORDER BY Aar, Maaned;

SELECT	YEAR(Slutdato) AS Aar,
		MONTH(Slutdato) AS Maaned,
		COUNT(*) 
	FROM dbo.PartitionTable_slet
	GROUP BY YEAR(Slutdato), MONTH(Slutdato)
	ORDER BY Aar, Maaned;
GO
-- Inds�ttelse af data i den nye partition/maaned
INSERT INTO dbo.PartitionTable (Id, Slutdato)
	SELECT	1, 
			CAST(MAX(Value) AS DATETIME2(0)) 
		FROM sys.partition_range_values
		WHERE function_id = (SELECT function_id 
								FROM sys.partition_functions
								WHERE name = 'pfn_MaanedsData');
GO
TRUNCATE TABLE dbo.PartitionTable_slet;
GO
EXEC proc_add_partition_right;
EXEC proc_del_partition_left;
GO
SELECT	YEAR(Slutdato) AS Aar,
		MONTH(Slutdato) AS Maaned,
		COUNT(*) 
	FROM dbo.PartitionTable
	GROUP BY YEAR(Slutdato), MONTH(Slutdato)
	ORDER BY Aar, Maaned;

SELECT	YEAR(Slutdato) AS Aar,
		MONTH(Slutdato) AS Maaned,
		COUNT(*) 
	FROM dbo.PartitionTable_slet
	GROUP BY YEAR(Slutdato), MONTH(Slutdato)
	ORDER BY Aar, Maaned;

SELECT * 
	FROM dbo.PartitionTable_slet;
GO
EXEC proc_add_partition_right;
EXEC proc_del_partition_left;

SELECT * 
	FROM sys.partition_range_values
	WHERE function_id IN (SELECT function_id 
							FROM sys.partition_functions
							WHERE name = 'pfn_MaanedsData');

SELECT * 
	FROM sys.partition_range_values
	WHERE function_id IN (SELECT function_id 
							FROM sys.partition_functions
							WHERE name = 'pfn_MaanedsDataSlet');
