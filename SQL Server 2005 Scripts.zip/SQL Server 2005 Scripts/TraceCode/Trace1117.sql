USE master
GO
IF EXISTS(SELECT * FROM sys.databases where name='Trace1117DB')
	DROP DATABASE [Trace1117DB]
GO
CREATE DATABASE [Trace1117DB]
ON  PRIMARY
	(NAME = N'Trace1117DB', 
	FILENAME = N'C:\Databaser\Trace1117DB.mdf',
	SIZE = 3072KB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 2048KB),

FILEGROUP fg1
	(NAME = N'Trace1117DB_fg1_1',
	FILENAME = N'C:\Databaser\Trace1117DB_fg1_1.ndf',
	SIZE = 1024KB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 2048KB),

	(NAME = N'Trace1117DB_fg1_2',
	FILENAME = N'C:\Databaser\Trace1117DB_fg1_2.ndf',
	SIZE = 1024KB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 2048KB),

	(NAME = N'Trace1117DB_fg1_3',
	FILENAME = N'C:\Databaser\Trace1117DB_fg1_3.ndf',
	SIZE = 1024KB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 2048KB),

FILEGROUP fg2
	(NAME = N'Trace1117DB_fg2_1',
	FILENAME = N'C:\Databaser\Trace1117DB_fg2_1.ndf',
	SIZE = 1024KB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 2048KB),

	(NAME = N'Trace1117DB_fg2_2',
	FILENAME = N'C:\Databaser\Trace1117DB_fg2_2.ndf',
	SIZE = 1024KB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 2048KB),

	(NAME = N'Trace1117DB_fg2_3',
	FILENAME = N'C:\Databaser\Trace1117DB_fg2_3.ndf',
	SIZE = 1024KB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 2048KB)

LOG ON
	(NAME = N'Trace1117DB_log',
	FILENAME = N'C:\Databaser\Trace1117DB_log.ldf',
	SIZE = 1024KB,
	MAXSIZE = 2048GB,
	FILEGROWTH = 10%)
GO
USE [Trace1117DB]
GO
DBCC TRACEOFF (1117)
GO
SELECT name, (size*8)/1024 'Size in MB' 
	FROM [Trace1117DB].sys.database_files
GO
CREATE TABLE t1 (
	name	CHAR(8000))
ON fg1
GO
INSERT t1 
	VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
GO 500
SELECT name, (size*8)/1024 'Size in MB' 
	FROM [Trace1117DB].sys.database_files
GO
DBCC TRACEON (1117)
GO
SELECT name, (size*8)/1024 'Size in MB' 
	FROM [Trace1117DB].sys.database_files
GO
CREATE TABLE t2 (
	name	CHAR(8000))
ON fg2
GO
INSERT t2
	VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
GO 500
SELECT name, (size*8)/1024 'Size in MB' 
	FROM [Trace1117DB].sys.database_files
GO