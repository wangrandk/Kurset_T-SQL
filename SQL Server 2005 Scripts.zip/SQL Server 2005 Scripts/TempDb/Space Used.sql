SELECT *
	FROM sys.dm_db_file_space_usage;
GO
SELECT *
	FROM sys.dm_db_task_space_usage;
GO
SELECT session_id, 
	  SUM(user_objects_alloc_page_count) AS user_internal_objects_alloc_page_count,
      SUM(user_objects_dealloc_page_count) AS user_internal_objects_dealloc_page_count,
      SUM(internal_objects_alloc_page_count) AS task_internal_objects_alloc_page_count,
      SUM(internal_objects_dealloc_page_count) AS task_internal_objects_dealloc_page_count 
    FROM sys.dm_db_task_space_usage 
    GROUP BY session_id;
GO
CREATE TABLE #t 
(
	id		INT, 
	txt		VARCHAR(2000)
);
GO
INSERT INTO #t VALUES
	(1, REPLICATE('x', 2000)),
	(2, REPLICATE('x', 2000)),
	(3, REPLICATE('x', 2000)),
	(4, REPLICATE('x', 2000)),
	(5, REPLICATE('x', 2000));
GO
SELECT 
	  SUM(user_objects_alloc_page_count) AS user_internal_objects_alloc_page_count,
      SUM(user_objects_dealloc_page_count) AS user_internal_objects_dealloc_page_count,
      SUM(internal_objects_alloc_page_count) AS task_internal_objects_alloc_page_count,
      SUM(internal_objects_dealloc_page_count) AS task_internal_objects_dealloc_page_count 
    FROM sys.dm_db_task_space_usage 
    WHERE session_id = @@SPID;
GO
DROP TABLE #t;
