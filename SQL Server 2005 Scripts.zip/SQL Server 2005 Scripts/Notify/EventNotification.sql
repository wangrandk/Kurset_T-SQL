USE AdventureWorks2008
GO
-- Create the queue to receive messages
CREATE QUEUE NotifyQueue
GO

--Create a service on the queue that references
--the event notifications contract.
CREATE SERVICE NotifyService ON QUEUE NotifyQueue
([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]);
GO

--Create a route on the service to define the address 
--to which Service Broker sends messages for the service.
CREATE ROUTE NotifyRoute WITH SERVICE_NAME = 'NotifyService', ADDRESS = 'LOCAL';

--Create a database-scoped event notification
CREATE EVENT NOTIFICATION Notify_ALTER_T1
ON DATABASE
FOR CREATE_TABLE
TO SERVICE 'NotifyService',
    '8140a771-3c4b-4479-8ac0-81008ab17984';

--Create a server-scoped event notification
CREATE EVENT NOTIFICATION Notify_ALTER_DB
ON SERVER
FOR ALTER_DATABASE
TO SERVICE 'NotifyService',
    '8140a771-3c4b-4479-8ac0-81008ab17984';
	
--Alter a database table
USE AdventureWorks2008
GO
ALTER TABLE Sales.CreditCard ADD IsDebitCard BINARY NULL
	
--Alter a database
ALTER DATABASE AdventureWorksDW2008
COLLATE SQL_Latin1_General_CP1_CI_AS 
GO

--Get information about ALTER TABLE notifications
SELECT * FROM sys.event_notifications
WHERE name = 'Notify_ALTER_T1'

--Get information about ALTER DATABASE notifications
SELECT * FROM sys.server_event_notifications
WHERE name = 'Notify_ALTER_DB'
GO
ALTER TABLE Sales.CreditCard DROP COLUMN IsDebitCard

DROP EVENT NOTIFICATION Notify_ALTER_DB
ON SERVER

DROP EVENT NOTIFICATION Notify_ALTER_T1
ON DATABASE

DROP ROUTE NotifyRoute

DROP SERVICE NotifyService

DROP QUEUE NotifyQueue