USE master
DROP DATABASE TestDB
GO
CREATE DATABASE TestDB
GO
USE TestDB
GO
CREATE FUNCTION dbo.KoverterMellemTalsytemer (@i		INT,  @Talsystem		INT = 2)
RETURNS VARCHAR(200)
AS
BEGIN 
DECLARE @HexString		VARCHAR(200) = ''
DECLARE @Cifre TABLE (
	Vaerdi		SMALLINT, 
	Ciffer		CHAR(1)) 
	
INSERT INTO @Cifre VALUES
	(0, '0'),
	(1, '1'),
	(2, '2'),
	(3, '3'),
	(4, '4'),
	(5, '5'),
	(6, '6'),
	(7, '7'),
	(8, '8'),
	(9, '9'),
	(10, 'A'),
	(11, 'B'),
	(12, 'C'),
	(13, 'D'),
	(14, 'E'),
	(15, 'F')

IF @Talsystem > 16 OR @Talsystem IS NULL
	SET @HexString = NULL
ELSE
BEGIN
	WHILE @i > @Talsystem  - 1
	BEGIN
		SET @HexString = (SELECT Ciffer FROM @Cifre WHERE Vaerdi = @i % @Talsystem) + @HexString

		SET @i /= @Talsystem
	END

	SET @HexString = (SELECT Ciffer FROM @Cifre WHERE Vaerdi = @i) + @HexString
END

RETURN @HexString
END
GO
SELECT 255, dbo.KoverterMellemTalsytemer(255, 2)
SELECT 1, dbo.KoverterMellemTalsytemer(1, 2)
SELECT 8, dbo.KoverterMellemTalsytemer(8, 2)
SELECT 15, dbo.KoverterMellemTalsytemer(15, 2)
SELECT 1024, dbo.KoverterMellemTalsytemer(1024, 2)
SELECT 1023, dbo.KoverterMellemTalsytemer(1023, 2)
SELECT 0, dbo.KoverterMellemTalsytemer(0, 2)
SELECT NULL, dbo.KoverterMellemTalsytemer(NULL, 2)
SELECT 12, dbo.KoverterMellemTalsytemer(12, NULL)

SELECT 255, dbo.KoverterMellemTalsytemer(255, 16)
SELECT 255, dbo.KoverterMellemTalsytemer(255, 2)
