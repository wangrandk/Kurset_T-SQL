DECLARE @t TABLE (
	id		INT NOT NULL PRIMARY KEY identity,
	navn	VARCHAR(20) NOT NULL)

INSERT INTO @t VALUES ('ole')
INSERT INTO @t VALUES ('ane')
INSERT INTO @t VALUES ('ida')

SELECT * FROM @t
GO
DECLARE @t TABLE (
	id		INT NOT NULL PRIMARY KEY identity,
	navn	VARCHAR(20) NOT NULL)

INSERT INTO @t (navn)
	SELECT 'ole'
	UNION ALL
	SELECT 'ib'
	UNION ALL
	SELECT 'tine'	

SELECT * FROM @t
GO
SELECT * FROM tempdb.information_schema.TABLEs
GO
DECLARE @t TABLE (
	id		INT NOT NULL PRIMARY KEY identity,
	navn	VARCHAR(20) NOT NULL)

SELECT * FROM tempdb.information_schema.TABLEs
GO
DECLARE @t1 TABLE (
	id		INT NOT NULL PRIMARY KEY identity,
	navn	VARCHAR(20) NOT NULL)

IF (SELECT COUNT(*) FROM @t1) = 0
BEGIN
	DECLARE @t2 TABLE (
		id		INT NOT NULL PRIMARY KEY identity,
		navn	VARCHAR(20) NOT NULL)
--	INSERT INTO @t3 VALUES ('bo')
	PRINT 'true'
END
ELSE
BEGIN
	DECLARE @t3 TABLE (
		id		INT NOT NULL PRIMARY KEY identity,
		navn	VARCHAR(20) NOT NULL)

	INSERT INTO @t2 VALUES ('bo')
	PRINT 'false'
END 

SELECT * FROM tempdb.information_schema.TABLEs
GO