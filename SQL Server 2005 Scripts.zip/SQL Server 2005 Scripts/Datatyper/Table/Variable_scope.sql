DECLARE @i	INT
SET @i = 2

IF @i > 2
BEGIN
	DECLARE @true	INT
	SET @true = 10
	--SET @false = 12
END
ELSE
BEGIN
	DECLARE @false	INT
	SET @true = 10
	SET @false = 12
END