DECLARE @b	BIT;

SET @b = 1;
IF @b			-- fejl
	PRINT 'true'
ELSE
	PRINT 'false';
GO
DECLARE @b	BIT;

SET @b = 1;
IF @b = 1
	PRINT 'true'
ELSE
	PRINT 'false';
GO
DECLARE @b	BIT;

SET @b = 1;
IF @b = 11
	PRINT 'true'
ELSE
	PRINT 'false';
GO
DECLARE @b	BIT;

SET @b = 1;
IF @b = 'false'
	PRINT 'true'
ELSE
	PRINT 'false';
GO
DECLARE @b	BIT;

SET @b = 1;
IF @b = 'FALSE'
	PRINT 'true'
ELSE
	PRINT 'false';
GO
