DECLARE @b	BIT
SET @b = 0
PRINT @b
SET @b = 1
PRINT @b
GO
DECLARE @b	BIT
SET @b = 12
PRINT @b
SET @b = -7
PRINT @b
GO
DECLARE @b	BIT  -- fejl
SET @b = true
SET @b = false
GO
DECLARE @b	BIT
SET @b = 'TRUE'
PRINT @b
SET @b = 'FALSE'
PRINT @b
GO
DECLARE @b	BIT
SET @b = 'true'
PRINT @b
SET @b = 'false'
PRINT @b
SET @b = 'xxxxx'
PRINT @b
GO
DECLARE @b	BIT
SET @b = 0
PRINT @b
SET @b += 1
PRINT @b
SET @b += 1
PRINT @b
SET @b += CAST(1.5 AS DECIMAL(5, 2))
PRINT @b
