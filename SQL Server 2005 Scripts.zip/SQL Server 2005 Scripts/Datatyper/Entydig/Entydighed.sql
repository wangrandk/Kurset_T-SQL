USE master;
DROP DATABASE DatatypeDB;
GO
CREATE DATABASE DatatypeDB;
GO
USE DatatypeDB;
GO
CREATE TABLE dbo.t 
(
	Id			INT IDENTITY(1, 1),
	Guid		UNIQUEIDENTIFIER DEFAULT NEWID(),
	Seqguid		UNIQUEIDENTIFIER DEFAULT NEWSEQUENTIALID(),
	Rv			ROWVERSION,							-- tidligere TIMESTAMP
	Navn		VARCHAR(20),
	Koen		CHAR(1) CHECK (Koen IN ('K', 'M'))
);
GO
INSERT INTO dbo.t (Navn, Koen) VALUES 
	('Ole', 'M'),
	('Ida','K'),
	('Lars', 'M');
GO
SELECT * 
	FROM dbo.t;
GO
SELECT * 
	FROM dbo.t;

UPDATE dbo.t 
	SET Navn = 'Ida Marie' 
	WHERE Id = 2;

INSERT INTO dbo.t (Navn, Koen) VALUES 
	('Hanne', 'K')

SELECT * 
	FROM dbo.t;
GO
DECLARE @Rv		ROWVERSION;
DECLARE @Navn	VARCHAR (20);

SELECT	@Navn = Navn, 
		@Rv = Rv 
	FROM dbo.t 
	WHERE Id = 1;

UPDATE dbo.t 
	SET Navn = 'Ole Erik' 
	WHERE	Id = 1 AND 
			Rv = @Rv;

IF @@ROWCOUNT = 0
	THROW 72345, 'Forkomst er opdateret siden l�sning', 1;

SELECT	* 
	FROM dbo.t
GO
DECLARE @Rv		ROWVERSION;
DECLARE @Navn	VARCHAR (20);

SELECT	@Navn = Navn, 
		@Rv = Rv 
	FROM dbo.t 
	WHERE Id = 3;

UPDATE dbo.t 
	SET Navn = Navn + Navn
	WHERE Id = 3;

SELECT * 
	FROM dbo.t 
	WHERE Rv = @Rv

UPDATE dbo.t
	SET Navn = 'Lars Ole' 
	OUTPUT DELETED.*, INSERTED.*
	WHERE	Id = 3 AND 
			Rv = @Rv;

IF @@ROWCOUNT = 0
	THROW 72345, 'Forkomst er opdateret siden l�sning', 1;

SELECT * 
	FROM dbo.t;
GO
CREATE TABLE dbo.t2 
(
	Id			INT IDENTITY,
	guid		UNIQUEIDENTIFIER DEFAULT NEWID(),
	seqguid		UNIQUEIDENTIFIER DEFAULT NEWSEQUENTIALID(),
	Rv			ROWVERSION,
	Navn		VARCHAR(20)
)
GO
INSERT INTO dbo.t2 (Navn) VALUES 
	('Ole'),
	('Ida'),
	('Lars');
GO
SELECT * 
	FROM dbo.t2
GO
SELECT	CAST(seqguid as VARBINARY(16)),
		*
	FROM dbo.t2
GO
CREATE TABLE dbo.t3
(
	ID			INT NOT NULL IDENTITY
);
GO
INSERT INTO dbo.t3 DEFAULT VALUES;
GO
SET IDENTITY_INSERT dbo.t3 ON;
GO
INSERT INTO dbo.t3 (Id) VALUES
	(1),
	(2);
GO
SET IDENTITY_INSERT dbo.t3 OFF;
GO
SELECT *
	FROM dbo.t3
GO
INSERT INTO dbo.t3 DEFAULT VALUES;
GO
SELECT *
	FROM dbo.t3