USE master
DROP DATABASE IntegerDB
GO
CREATE DATABASE IntegerDB
GO
USE IntegerDB
GO
-- tinyint
DECLARE @ti TINYINT
SET @ti = 100
SET @ti = @ti * 25 / 100
PRINT @ti
GO
-- smallint
DECLARE @si SMALLINT
SET @si = 20000
SET @si = @si * 25 / 100
SELECT @si

DECLARE @s2 SMALLINT
DECLARE @s3 SMALLINT
SET @s2 = 20000
SET @s3 = 20000
SELECT @s2 + @s3
SELECT CAST(@s2 AS INT) + @S3
GO
-- int
DECLARE @i INT
SET @i = 1000000000
SET @i = @i * 25 / 100
PRINT @i

DECLARE @i INT
SET @i = 1000000000
SET @i = @i / 100 * 25
PRINT @i
GO
-- bigint
DECLARE @bi BIGINT
SET @bi = 1000000000
SET @bi = @bi * 25 / 100
PRINT @bi
GO
DECLARE @bi BIGINT
SET @bi = 1000000000000000000
SET @bi = @bi * 25 / 100
PRINT @bi
