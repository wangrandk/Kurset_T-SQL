DECLARE @BeloebMoney			MONEY = 0
DECLARE @BeloebDecimal			DECIMAL(11,2) = 0

DECLARE @BeloebMoneySum1		MONEY = 0
DECLARE @BeloebDecimalSum1		DECIMAL(11,2) = 0

DECLARE @BeloebMoneySum2		MONEY = 0
DECLARE @BeloebDecimalSum2		DECIMAL(11,2) = 0

DECLARE @i						INT = 1
DECLARE @AntalForskelle1		INT = 0
DECLARE @AntalForskelle2		INT = 0

DECLARE @IntervalMoney			MONEY = 0.01
DECLARE @IntervalDecimal		DECIMAL(9,2) = 0.01
--DECLARE @IntervalMoney		MONEY = 1
--DECLARE @IntervalDecimal		DECIMAL(9,2) = 1

DECLARE @MomsPct				SMALLINT = 25
DECLARE @AfgiftPct				SMALLINT = 13

WHILE @i <= 1000000
BEGIN
	SET @BeloebMoney += @IntervalMoney
	SET @BeloebDecimal += @IntervalDecimal
	
	IF	(@BeloebMoney / 100 * @AfgiftPct) / 100 * @MomsPct <> (@BeloebDecimal / 100 * @AfgiftPct) / 100 * @MomsPct 
	BEGIN
		SET @AntalForskelle1 += 1
	END
	
	IF	(@BeloebMoney * @AfgiftPct / 100) * @MomsPct / 100 <> (@BeloebDecimal * @AfgiftPct / 100) * @MomsPct / 100 
	BEGIN
		SET @AntalForskelle2 += 1
	END
	
	SET @BeloebMoneySum1 += (@BeloebMoney / 100 * @AfgiftPct) / 100 * @MomsPct
	SET @BeloebMoneySum2 += (@BeloebMoney * @AfgiftPct / 100) * @MomsPct / 100
	SET @BeloebDecimalSum1 += (@BeloebDecimal / 100 * @AfgiftPct) / 100 * @MomsPct
	SET @BeloebDecimalSum2 += (@BeloebDecimal * @AfgiftPct / 100) * @MomsPct / 100

	SET @i += 1
END
PRINT @AntalForskelle1
PRINT @AntalForskelle2
PRINT @BeloebMoneySum1
PRINT @BeloebMoneySum2
PRINT @BeloebDecimalSum1
PRINT @BeloebDecimalSum2
