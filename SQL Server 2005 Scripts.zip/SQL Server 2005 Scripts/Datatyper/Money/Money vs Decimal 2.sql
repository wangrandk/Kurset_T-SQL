DECLARE		@mon1_1		MONEY = 100;
DECLARE		@mon2_1		MONEY = 339;
DECLARE		@mon3_1		MONEY = 10000;
DECLARE		@mon4_1		MONEY;
 
DECLARE		@mon1_2		MONEY = 100;
DECLARE		@mon2_2		MONEY = 339;
DECLARE		@mon3_2		MONEY = 10000;
DECLARE		@mon4_2		MONEY;

DECLARE		@num1_1		DECIMAL(19,4) = 100;
DECLARE		@num2_1		DECIMAL(19,4) = 339;
DECLARE		@num3_1		DECIMAL(19,4) = 10000;
DECLARE		@num4_1		DECIMAL(19,4);

DECLARE		@num1_2		DECIMAL(19,4) = 100;
DECLARE		@num2_2		DECIMAL(19,4) = 339;
DECLARE		@num3_2		DECIMAL(19,4) = 10000;
DECLARE		@num4_2		DECIMAL(19,4);

SET @mon4_1 = @mon1_1 * @mon3_1 / @mon2_1;
SET @mon4_2 = @mon1_2 / @mon2_2 * @mon3_2;

SET @num4_1 = @num1_1 * @num3_1 / @num2_1;
SET @num4_2 = @num1_2 / @num2_2 * @num3_2;

SELECT	@mon4_1 AS money1,
		@mon4_2 AS money2,
		@num4_1 AS num1,
		@num4_2 AS num2;