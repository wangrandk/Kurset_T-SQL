DECLARE @beloeb_money	SMALLMONEY
DECLARE @beloeb_dec		DECIMAL(8,2)
DECLARE @i				INT
DECLARE @antal_fejl		INT

SET @i = 1
SET @antal_fejl = 0
WHILE @i < 100000
BEGIN
	SET @beloeb_money = @i * 1.13 * 1.25
	SET @beloeb_dec = @i * 1.13 * 1.25
	IF CAST(@beloeb_money AS DECIMAL(11,2)) <> @beloeb_dec 
	BEGIN
		PRINT CAST(@i AS VARCHAR(20))
		PRINT CAST(@beloeb_money AS VARCHAR(20))
		PRINT CAST( @beloeb_dec AS VARCHAR(20))
		SET @antal_fejl = @antal_fejl + 1
	END 
	SET @i = @i + 1
END
PRINT @antal_fejl
