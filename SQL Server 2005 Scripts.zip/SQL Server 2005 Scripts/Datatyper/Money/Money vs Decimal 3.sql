DECLARE @m			MONEY = 1;
DECLARE @tax		DECIMAL(4,2) = 25;
DECLARE @error		INT = 0;

WHILE @m < 1000
BEGIN
	IF @m / 100 * @tax <> @m * @tax / 100 
	BEGIN
		IF @error % 100000 = 1
		BEGIN
			PRINT @m / 100 * @tax;
			PRINT @m * @tax / 100;
		end;
		SET @error += 1;
	END;

	SET @m += 0.001;
END;
SELECT @error;
GO
DECLARE @m			DECIMAL(18,4) = 1;
DECLARE @tax		DECIMAL(4,2) = 25;
DECLARE @error		INT = 0;

WHILE @m < 1000
BEGIN
	IF @m / 100 * @tax <> @m * @tax / 100 
	BEGIN
		IF @error % 100000 = 1
		BEGIN
			PRINT @m / 100 * @tax;
			PRINT @m * @tax / 100;
		end;
		SET @error += 1;
	END;

	SET @m += 0.001;
END;
SELECT @error;
