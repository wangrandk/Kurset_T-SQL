USE master;
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
GO
CREATE FUNCTION dbo.fn_PaaskeSoendag (@Aar SMALLINT) 
RETURNS DATE 
AS 
	BEGIN
	DECLARE @c		INT;
	DECLARE @n		INT;
	DECLARE @k		INT;
	DECLARE @i		INT;
	DECLARE @j		INT;
	DECLARE @l		INT;
	DECLARE @m		INT;
	DECLARE @d		INT;
	DECLARE @Paaske DATE; 

	SET @c = (@Aar / 100);
	SET @n = @Aar - 19 * (@Aar / 19); 
	SET @k = (@c - 17) / 25;
	SET @i = @c - @c / 4 - ( @c - @k) / 3 + 19 * @n + 15;
	SET @i = @i - 30 * ( @i / 30 );
	SET @i = @i - (@i / 28) * (1 - (@i / 28) * (29 / (@i + 1)) * ((21 - @n) / 11)); 
	SET @j = @Aar + @Aar / 4 + @i + 2 - @c + @c / 4;
	SET @j = @j - 7 * (@j / 7);
	SET @l = @i - @j;
	SET @m = 3 + (@l + 40) / 44; 
	SET @d = @l + 28 - 31 * ( @m / 4 ); 

	SET @Paaske = CAST(CAST(@Aar AS VARCHAR(5)) + '-' + 
					   CAST(@m AS VARCHAR(2)) + '-' + 
					   CAST(@d AS VARCHAR(2)) AS DATE);

	RETURN @Paaske;
END;
GO
SET DATEFIRST 7;
GO
CREATE FUNCTION dbo.fn_FastelavnsTirsdag (@Aar SMALLINT) 
RETURNS DATE 
AS 
BEGIN 
	DECLARE @Paaske		DATE;
	DECLARE @Count		SMALLINT;
	DECLARE @Fastelavn	DATE;

	SET @Paaske = (SELECT dbo.fn_PaaskeSoendag(@Aar)); 
	SET @Count = 0;
	SET @Fastelavn = @Paaske;

	WHILE @Count < 40 
	BEGIN 
		IF DATEPART(dw,@Fastelavn) <> 1 
		BEGIN 
			SET @Count = @Count + 1; 
		END;
		SET @Fastelavn = DATEADD(DAY,-1,@Fastelavn);
	END;

	RETURN @Fastelavn; 
END;
GO
DECLARE @Aar		SMALLINT = 2015;
SELECT dbo.fn_PaaskeSoendag(@Aar), DATENAME(dw, dbo.fn_PaaskeSoendag(@Aar));
SELECT dbo.fn_FastelavnsTirsdag(@Aar), DATENAME(dw, dbo.fn_FastelavnsTirsdag(@Aar));
