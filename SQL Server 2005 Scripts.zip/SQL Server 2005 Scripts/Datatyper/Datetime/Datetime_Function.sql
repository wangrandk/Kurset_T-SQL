USE master;
DROP DATABASE DatetimeDB;
GO
CREATE DATABASE DatetimeDB;
GO
USE DatetimeDB;
GO
CREATE TABLE dbo.t 
(
	id		INT NOT NULL PRIMARY KEY IDENTITY, 
	dt		DATETIME
);
GO
INSERT INTO dbo.t VALUES ('2014-12-31');
INSERT INTO dbo.t VALUES ('2015-01-01');
GO
SELECT DATEDIFF(YEAR, 
				(SELECT dt FROM dbo.t WHERE id = 1),
				(SELECT dt FROM dbo.t WHERE id = 2)); 
GO
SELECT DATEDIFF(MONTH, 
				(SELECT dt FROM dbo.t WHERE id = 1),
				(SELECT dt FROM dbo.t WHERE id = 2));
GO
SELECT DATEDIFF(DAY, 
				(SELECT dt FROM dbo.t WHERE id = 1),
				(SELECT dt FROM dbo.t WHERE id = 2));
GO
