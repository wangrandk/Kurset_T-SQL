USE master
DROP DATABASE DatatypeDB
GO
CREATE DATABASE DatatypeDB
GO
USE DatatypeDB
GO
DECLARE @txt	TEXT	-- fejl, kan ikke bruges som lokal variabel
SET @txt = 'xxxxxxxxxxxxxxxxxxxxxxx'
GO
CREATE PROC usp_t 
@txt TEXT
as
SELECT @txt as TEXTdata
GO
EXEC usp_t 'xxxxxxxxxxxxxxxxxxxxxxx'