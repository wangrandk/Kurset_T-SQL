USE master
DROP DATABASE DatatypeDB
GO
CREATE DATABASE DatatypeDB
GO
USE DatatypeDB
create TABLE t (
	id			INT NOT NULL PRIMARY KEY identity,
	txt1		VARCHAR(MAX),
	txt2		VARCHAR(MAX),
	txt3		VARCHAR(MAX),
	txt4		VARCHAR(MAX))
GO
INSERT INTO t VALUES (REPLICATE ('fyldtekst1', 100),REPLICATE ('fyldtekst2', 100),
                      REPLICATE ('fyldtekst3', 100),REPLICATE ('fyldtekst4', 100))
GO
SELECT * FROM t
GO
INSERT INTO t VALUES (REPLICATE ('fyldtekst1', 500),REPLICATE ('fyldtekst2', 400),
                      REPLICATE ('fyldtekst3', 400),REPLICATE ('fyldtekst4', 300))
GO
SELECT LEN(txt1) + LEN(txt2) + LEN(txt3) + LEN(txt4) 
FROM t
GO
INSERT INTO t VALUES (REPLICATE ('fyldtekst1', 5000),REPLICATE ('fyldtekst2', 4000),
                      REPLICATE ('fyldtekst3', 4000),REPLICATE ('fyldtekst4', 3000))
GO
SELECT LEN(txt1) + LEN(txt2) + LEN(txt3) + LEN(txt4) 
FROM t
GO
SELECT LEN(txt1) 
FROM t
GO
SELECT SUBSTRING(txt1,1, 20), SUBSTRING(txt2,1, 20), SUBSTRING(txt2,1, 20), SUBSTRING(txt2,1, 20)
FROM t
GO
SELECT SUBSTRING(txt1,1000, 20), SUBSTRING(txt2,1000, 20), SUBSTRING(txt3,1000, 20), SUBSTRING(txt4,1000, 20)
FROM t
GO
SELECT SUBSTRING(txt1,10000, 20), SUBSTRING(txt2,10000, 20), SUBSTRING(txt3,10000, 20), SUBSTRING(txt4,10000, 20)
FROM t
GO
DECLARE @i INT
DECLARE @str VARCHAR(MAX)
SET @i = 1
SET @str = ''
while @i <= 10000
BEGIN
	SET @str = @str + right('0000000000' + CAST (@i as VARCHAR(10)), 9) + '-'
	PRINT LEN(@str)
    SET @i = @i + 1
END
INSERT INTO t VALUES(@str, @str, @str, @str)

SELECT LEN(txt1) + LEN(txt2) + LEN(txt3) + LEN(txt4) 
FROM t
GO
SELECT SUBSTRING(txt1,10000, 20), SUBSTRING(txt2,10000, 20), SUBSTRING(txt3,10000, 20), SUBSTRING(txt4,10000, 20)
FROM t
GO
INSERT INTO t VALUES (REPLICATE (CAST('fyldtekst1' as VARCHAR(MAX)), 5000),REPLICATE ('fyldtekst2', 4000),
                      REPLICATE ('fyldtekst3', 4000),REPLICATE ('fyldtekst4', 3000))
GO