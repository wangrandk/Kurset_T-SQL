USE master;
GO
DROP DATABASE DatatypeDB;
GO
CREATE DATABASE DatatypeDB
ON PRIMARY (
	NAME = 'DatatypeDB', 
	FILENAME = 'C:\Databaser\DatatypeDB.mdf', 
	SIZE = 1000MB, 
	MAXSIZE = UNLIMITED, 
	FILEGROWTH = 100MB)
LOG ON ( 
	NAME = 'DatatypeDB_log', 
	FILENAME = 'C:\Databaser\DatatypeDB_log.LDF', 
	SIZE = 500MB,
	MAXSIZE = UNLIMITED, 
	FILEGROWTH = 10%);
GO
USE DatatypeDB;
CREATE TABLE dbo.t 
(
	Id			INT NOT NULL PRIMARY KEY IDENTITY,
	Txt1		VARCHAR(8000),
	Txt2		VARCHAR(8000), 
	Txt3		VARCHAR(8000)
);
GO
CREATE TABLE dbo.t1 
(
	Id			INT NOT NULL PRIMARY KEY,
	Txt1		VARCHAR(8000)
);

CREATE TABLE dbo.t2 
(
	Id			INT NOT NULL PRIMARY KEY,
	Txt2		VARCHAR(8000)
);

CREATE TABLE dbo.t3 
(
	Id			INT NOT NULL PRIMARY KEY,
	Txt3		VARCHAR(8000)
);
GO
INSERT INTO dbo.t
	VALUES (REPLICATE ('0123456789', 700),
			REPLICATE ('0123456789', 600), 
			REPLICATE ('0123456789', 500));
GO
SET STATISTICS IO ON;
SELECT * 
	FROM dbo.t;

SELECT Txt1
	FROM dbo.t;

SELECT Txt2
	FROM dbo.t;

SELECT Txt3
	FROM dbo.t

SET STATISTICS IO OFF
GO
SET NOCOUNT ON
DECLARE @i		INT = 1

WHILE @i <= 5
BEGIN
	INSERT INTO dbo.t (Txt1, Txt2, Txt3)
		SELECT Txt1, Txt2, Txt3 
			FROM dbo.t

	INSERT INTO dbo.t (Txt1, Txt2, Txt3)
		SELECT Txt3, Txt2, Txt1 
			FROM dbo.t;

	INSERT INTO dbo.t (Txt1, Txt2, Txt3)
		SELECT Txt3, Txt1, Txt3 
			FROM dbo.t;

	SET @i = @i + 1;
END;
SELECT COUNT(*) 
	FROM dbo.t;
GO
INSERT INTO dbo.t1
	SELECT Id, Txt1
		FROM dbo.t;
		
INSERT INTO dbo.t2
	SELECT Id, Txt2
		FROM dbo.t;
		
INSERT INTO dbo.t3
	SELECT Id, Txt3
		FROM dbo.t;

SET NOCOUNT OFF;
GO
--JOIN AF 2 TABELLER
SET STATISTICS TIME ON;
SET STATISTICS IO ON;
GO
DBCC DROPCLEANBUFFERS;
PRINT 'Id, Txt1, Txt2 ***************** 1 TABEL *****************';
SELECT Id, Txt1, Txt2 
	FROM dbo.t;
--DBCC DROPCLEANBUFFERS
PRINT 'Id, Txt1, Txt2 ***************** 2 TABELLER *****************';
SELECT t1.*, t2.Txt2 
	FROM dbo.t1 INNER JOIN dbo.t2 ON t1.Id = t2.Id;

SELECT ISNULL(t1.ID, t2.ID) AS ID, t1.Txt1, t2.Txt2 
	FROM dbo.t1 FULL JOIN dbo.t2 ON t1.Id = t2.Id;
GO
-- DATA FRA TXT1-KOLONNE
DBCC DROPCLEANBUFFERS;
PRINT 'Id, Txt1 ***************** DEL AF TABEL *****************';
SELECT Id, Txt1 
	FROM dbo.t;
DBCC DROPCLEANBUFFERS;
PRINT 'Id, Txt1 ***************** 1 tabel *****************';
SELECT Id, Txt1 
	FROM dbo.t1;
GO
-- DATA FRA TXT2-KOLONNE
DBCC DROPCLEANBUFFERS
PRINT 'Id, Txt2 ***************** DEL AF TABEL *****************';
SELECT Id, Txt2 
	FROM dbo.t;
DBCC DROPCLEANBUFFERS;
PRINT 'Id, Txt2 ***************** 1 tabel *****************';
SELECT Id, Txt2 
	FROM dbo.t2;
GO
-- DATA FRA TXT3-KOLONNE
DBCC DROPCLEANBUFFERS;
PRINT 'Id, Txt2 ***************** DEL AF TABEL *****************';
SELECT Id, Txt3 
	FROM dbo.t;
DBCC DROPCLEANBUFFERS;
PRINT 'Id, Txt2 ***************** 1 tabel *****************';
SELECT Id, Txt3 
	FROM dbo.t3;
GO
--JOIN AF 3 TABELLER - INNER JOIN
DBCC DROPCLEANBUFFERS;
PRINT 'Id, Txt1, Txt2, Txt3 ***************** 1 TABEL *****************';
SELECT Id, Txt1, Txt2, Txt3 
	FROM dbo.t;
DBCC DROPCLEANBUFFERS;
PRINT 'Id, Txt1, Txt2, Txt3 INNER JOIN ***************** 3 TABELLER *****************';
SELECT t1.Id, Txt1, Txt2, Txt3  
	FROM dbo.t1 INNER JOIN dbo.t2 ON t1.Id = t2.Id
				INNER JOIN dbo.t3 ON t1.Id = t3.Id;
GO
--JOIN AF 3 TABELLER - FULL JOIN
DBCC DROPCLEANBUFFERS;
PRINT 'Id, Txt1, Txt2, Txt3 - FULL JOIN ***************** 3 TABELLER *****************';
SELECT t1.Id, Txt1, Txt2, Txt3 
	FROM dbo.t1 FULL JOIN dbo.t2 ON t1.Id = t2.Id
				FULL JOIN dbo.t3 ON t1.Id = t3.Id;
GO
SET STATISTICS TIME, IO OFF;
GO
DROP TABLE ExecTime;

CREATE TABLE ExecTime (
		ID				INT NOT NULL PRIMARY KEY IDENTITY,
		AVGTime			BIGINT,
		SQLText			NVARCHAR(MAX))
GO
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO
SELECT t.Id, t.Txt1, t.Txt2
	FROM dbo.t;
GO 4
INSERT INTO ExecTime
	SELECT	AvgCPUTime,
			Statement_Text
	FROM (
		SELECT query_stats.query_hash AS QueryHash, 
			SUM(query_stats.total_worker_time) / SUM(query_stats.execution_count) AS AvgCPUTime,
			MIN(query_stats.statement_text) AS Statement_Text
		FROM 
			(SELECT QS.*, 
			SUBSTRING(ST.text, (QS.statement_start_offset/2) + 1,
			((CASE statement_end_offset 
				WHEN -1 THEN DATALENGTH(ST.text)
				ELSE QS.statement_end_offset END 
					- QS.statement_start_offset)/2) + 1) AS statement_text
			FROM sys.dm_exec_query_stats AS QS
							 CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST) as query_stats
		GROUP BY query_stats.query_hash) AS x
	WHERE	Statement_Text LIKE 'SELECT t%';
GO	
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO
SELECT t1.*, t2.Txt2 
	FROM dbo.t1 INNER JOIN dbo.t2 ON t1.Id = t2.Id;
GO 4

INSERT INTO ExecTime
	SELECT	AvgCPUTime,
			Statement_Text
	FROM (
		SELECT query_stats.query_hash AS QueryHash, 
			SUM(query_stats.total_worker_time) / SUM(query_stats.execution_count) AS AvgCPUTime,
			MIN(query_stats.statement_text) AS Statement_Text
		FROM 
			(SELECT QS.*, 
			SUBSTRING(ST.text, (QS.statement_start_offset/2) + 1,
			((CASE statement_end_offset 
				WHEN -1 THEN DATALENGTH(ST.text)
				ELSE QS.statement_end_offset END 
					- QS.statement_start_offset)/2) + 1) AS statement_text
			FROM sys.dm_exec_query_stats AS QS
							 CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST) as query_stats
		GROUP BY query_stats.query_hash) AS x
	WHERE	Statement_Text LIKE 'SELECT t%';
GO 
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO
SELECT t.Id, t.Txt1 
	FROM dbo.t;
GO 4	

INSERT INTO ExecTime
	SELECT	AvgCPUTime,
			Statement_Text
	FROM (
		SELECT query_stats.query_hash AS QueryHash, 
			SUM(query_stats.total_worker_time) / SUM(query_stats.execution_count) AS AvgCPUTime,
			MIN(query_stats.statement_text) AS Statement_Text
		FROM 
			(SELECT QS.*, 
			SUBSTRING(ST.text, (QS.statement_start_offset/2) + 1,
			((CASE statement_end_offset 
				WHEN -1 THEN DATALENGTH(ST.text)
				ELSE QS.statement_end_offset END 
					- QS.statement_start_offset)/2) + 1) AS statement_text
			FROM sys.dm_exec_query_stats AS QS
							 CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST) as query_stats
		GROUP BY query_stats.query_hash) AS x
	WHERE	Statement_Text LIKE 'SELECT t%';
GO
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO
SELECT t1.Id, t1.Txt1 
	FROM dbo.t1;
GO 4	

INSERT INTO ExecTime
	SELECT	AvgCPUTime,
			Statement_Text
	FROM (
		SELECT query_stats.query_hash AS QueryHash, 
			SUM(query_stats.total_worker_time) / SUM(query_stats.execution_count) AS AvgCPUTime,
			MIN(query_stats.statement_text) AS Statement_Text
		FROM 
			(SELECT QS.*, 
			SUBSTRING(ST.text, (QS.statement_start_offset/2) + 1,
			((CASE statement_end_offset 
				WHEN -1 THEN DATALENGTH(ST.text)
				ELSE QS.statement_end_offset END 
					- QS.statement_start_offset)/2) + 1) AS statement_text
			FROM sys.dm_exec_query_stats AS QS
							 CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST) as query_stats
		GROUP BY query_stats.query_hash) AS x
	WHERE	Statement_Text LIKE 'SELECT t%';
GO
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO
SELECT t.Id, t.Txt2 
	FROM dbo.t;
GO 4

INSERT INTO ExecTime
	SELECT	AvgCPUTime,
			Statement_Text
	FROM (
		SELECT query_stats.query_hash AS QueryHash, 
			SUM(query_stats.total_worker_time) / SUM(query_stats.execution_count) AS AvgCPUTime,
			MIN(query_stats.statement_text) AS Statement_Text
		FROM 
			(SELECT QS.*, 
			SUBSTRING(ST.text, (QS.statement_start_offset/2) + 1,
			((CASE statement_end_offset 
				WHEN -1 THEN DATALENGTH(ST.text)
				ELSE QS.statement_end_offset END 
					- QS.statement_start_offset)/2) + 1) AS statement_text
			FROM sys.dm_exec_query_stats AS QS
							 CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST) as query_stats
		GROUP BY query_stats.query_hash) AS x
	WHERE	Statement_Text LIKE 'SELECT t%';
GO
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO
SELECT t2.Id, t2.Txt2 
	FROM dbo.t2;
GO 4

INSERT INTO ExecTime
	SELECT	AvgCPUTime,
			Statement_Text
	FROM (
		SELECT query_stats.query_hash AS QueryHash, 
			SUM(query_stats.total_worker_time) / SUM(query_stats.execution_count) AS AvgCPUTime,
			MIN(query_stats.statement_text) AS Statement_Text
		FROM 
			(SELECT QS.*, 
			SUBSTRING(ST.text, (QS.statement_start_offset/2) + 1,
			((CASE statement_end_offset 
				WHEN -1 THEN DATALENGTH(ST.text)
				ELSE QS.statement_end_offset END 
					- QS.statement_start_offset)/2) + 1) AS statement_text
			FROM sys.dm_exec_query_stats AS QS
							 CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST) as query_stats
		GROUP BY query_stats.query_hash) AS x
	WHERE	Statement_Text LIKE 'SELECT t%';
GO
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO
SELECT t.Id, t.Txt3 
	FROM dbo.t;
GO 4

INSERT INTO ExecTime
	SELECT	AvgCPUTime,
			Statement_Text
	FROM (
		SELECT query_stats.query_hash AS QueryHash, 
			SUM(query_stats.total_worker_time) / SUM(query_stats.execution_count) AS AvgCPUTime,
			MIN(query_stats.statement_text) AS Statement_Text
		FROM 
			(SELECT QS.*, 
			SUBSTRING(ST.text, (QS.statement_start_offset/2) + 1,
			((CASE statement_end_offset 
				WHEN -1 THEN DATALENGTH(ST.text)
				ELSE QS.statement_end_offset END 
					- QS.statement_start_offset)/2) + 1) AS statement_text
			FROM sys.dm_exec_query_stats AS QS
							 CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST) as query_stats
		GROUP BY query_stats.query_hash) AS x
	WHERE	Statement_Text LIKE 'SELECT t%';
GO
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO
SELECT t3.Id, t3.Txt3 
	FROM dbo.t3;
GO 4

INSERT INTO ExecTime
	SELECT	AvgCPUTime,
			Statement_Text
	FROM (
		SELECT query_stats.query_hash AS QueryHash, 
			SUM(query_stats.total_worker_time) / SUM(query_stats.execution_count) AS AvgCPUTime,
			MIN(query_stats.statement_text) AS Statement_Text
		FROM 
			(SELECT QS.*, 
			SUBSTRING(ST.text, (QS.statement_start_offset/2) + 1,
			((CASE statement_end_offset 
				WHEN -1 THEN DATALENGTH(ST.text)
				ELSE QS.statement_end_offset END 
					- QS.statement_start_offset)/2) + 1) AS statement_text
			FROM sys.dm_exec_query_stats AS QS
							 CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST) as query_stats
		GROUP BY query_stats.query_hash) AS x
	WHERE	Statement_Text LIKE 'SELECT t%';
GO
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO
SELECT t.Id, t.Txt1, t.Txt2, t.Txt3 
	FROM dbo.t;
GO 4

INSERT INTO ExecTime
	SELECT	AvgCPUTime,
			Statement_Text
	FROM (
		SELECT query_stats.query_hash AS QueryHash, 
			SUM(query_stats.total_worker_time) / SUM(query_stats.execution_count) AS AvgCPUTime,
			MIN(query_stats.statement_text) AS Statement_Text
		FROM 
			(SELECT QS.*, 
			SUBSTRING(ST.text, (QS.statement_start_offset/2) + 1,
			((CASE statement_end_offset 
				WHEN -1 THEN DATALENGTH(ST.text)
				ELSE QS.statement_end_offset END 
					- QS.statement_start_offset)/2) + 1) AS statement_text
			FROM sys.dm_exec_query_stats AS QS
							 CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST) as query_stats
		GROUP BY query_stats.query_hash) AS x
	WHERE	Statement_Text LIKE 'SELECT t%';
GO
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO
SELECT t1.Id, t1.Txt1, t2.Txt2, t3.Txt3  
	FROM dbo.t1 INNER JOIN dbo.t2 ON t1.Id = t2.Id
				INNER JOIN dbo.t3 ON t1.Id = t3.Id;
GO 4

INSERT INTO ExecTime
	SELECT	AvgCPUTime,
			Statement_Text
	FROM (
		SELECT query_stats.query_hash AS QueryHash, 
			SUM(query_stats.total_worker_time) / SUM(query_stats.execution_count) AS AvgCPUTime,
			MIN(query_stats.statement_text) AS Statement_Text
		FROM 
			(SELECT QS.*, 
			SUBSTRING(ST.text, (QS.statement_start_offset/2) + 1,
			((CASE statement_end_offset 
				WHEN -1 THEN DATALENGTH(ST.text)
				ELSE QS.statement_end_offset END 
					- QS.statement_start_offset)/2) + 1) AS statement_text
			FROM sys.dm_exec_query_stats AS QS
							 CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST) as query_stats
		GROUP BY query_stats.query_hash) AS x
	WHERE	Statement_Text LIKE 'SELECT t%';
GO
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO
SELECT t1.Id, t1.Txt1, t2.Txt2, t3.Txt3
	FROM dbo.t1 FULL JOIN dbo.t2 ON t1.Id = t2.Id
				FULL JOIN dbo.t3 ON t1.Id = t3.Id;
GO 4

INSERT INTO ExecTime
	SELECT	AvgCPUTime,
			Statement_Text
	FROM (
		SELECT query_stats.query_hash AS QueryHash, 
			SUM(query_stats.total_worker_time) / SUM(query_stats.execution_count) AS AvgCPUTime,
			MIN(query_stats.statement_text) AS Statement_Text
		FROM 
			(SELECT QS.*, 
			SUBSTRING(ST.text, (QS.statement_start_offset/2) + 1,
			((CASE statement_end_offset 
				WHEN -1 THEN DATALENGTH(ST.text)
				ELSE QS.statement_end_offset END 
					- QS.statement_start_offset)/2) + 1) AS statement_text
			FROM sys.dm_exec_query_stats AS QS
							 CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST) as query_stats
		GROUP BY query_stats.query_hash) AS x
	WHERE	Statement_Text LIKE 'SELECT t%';
GO
DELETE
	FROM ExecTime
	WHERE SQLText LIKE 'SELECT TOP%';

SELECT SQLText, AVGTime/4 AS AVGTime
	FROM ExecTime
	ORDER BY ID;
