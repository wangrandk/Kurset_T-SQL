USE master;
DROP DATABASE FloatDB;
GO
CREATE DATABASE FloatDB;
GO
USE FloatDB;
GO
CREATE TABLE dbo.t 
(
		r		REAL
);
GO
INSERT INTO dbo.t VALUES(2000000);
INSERT INTO dbo.t VALUES(106);
GO
SELECT r * 25 / 100, r / 100 * 25, ROUND(r * 25 / 100, 0), ROUND(r / 100 * 25, 0)
	FROM dbo.t;
 
SELECT r * 25 / 100, r / 100 * 25, ROUND(r * 25 / 100, 10), ROUND(r / 100 * 25, 10)
	FROM dbo.t;
GO
DECLARE @r 						REAL;
DECLARE @i 						INT;
DECLARE @antal_real_minus		INT = 0;
DECLARE @antal_real_plus		INT = 0;
DECLARE @antal_real_ok			INT = 0;
DECLARE @antal_real_round_ok	INT = 0;
DECLARE @antal_real_round_minus	INT = 0;
DECLARE @antal_real_round_plus	INT = 0;
DECLARE @stop 					INT;

DECLARE @sum_div_multi			DECIMAL(19,5) = 0;
DECLARE @sum_multi_div			DECIMAL(19,5) = 0;
DECLARE @sum_div_multi_round	DECIMAL(19,5) = 0;
DECLARE @sum_multi_div_round	DECIMAL(19,5) = 0;

SET @i = 1;

SET @stop = 1000000;

WHILE @i <= @stop
BEGIN
	SET @r = @i;
	SET @r = @i / 100;
	
	SET @sum_div_multi += @r / 100 * 25;
	SET @sum_multi_div += @r * 25 / 100;
	SET @sum_div_multi_round += ROUND(@r / 100 * 25, 0);
	SET @sum_multi_div_round += ROUND(@r * 25 / 100, 0);
	
   	IF ROUND(@r * 25 / 100, 0) < ROUND(@r / 100 * 25, 0)
	BEGIN
	--	PRINT CAST(ROUND(@r * 25 / 100, 0) AS VARCHAR(30)) + '   ' + CAST(ROUND(@r / 100 * 25, 0) AS VARCHAR(30))
		SET  @antal_real_round_minus += 1
	END
	ELSE
   		IF ROUND(@r * 25 / 100, 0) > ROUND(@r / 100 * 25, 0)
		BEGIN
		--	PRINT CAST(ROUND(@r * 25 / 100, 0) AS VARCHAR(30)) + '   ' + CAST(ROUND(@r / 100 * 25, 0) AS VARCHAR(30))
			SET  @antal_real_round_plus += 1
		END
		ELSE
			SET @antal_real_round_ok += 1;
			
   	IF @r * 25 / 100 < @r / 100 * 25
	BEGIN
		--	PRINT CAST(ROUND(@r * 25 / 100, 0) AS VARCHAR(30)) + '   ' + CAST(ROUND(@r / 100 * 25, 0) AS VARCHAR(30))
		SET  @antal_real_minus += 1
	END
	ELSE
		IF @r * 25 / 100 > @r / 100 * 25
		BEGIN
		--	PRINT CAST(ROUND(@r * 25 / 100, 0) AS VARCHAR(30)) + '   ' + CAST(ROUND(@r / 100 * 25, 0) AS VARCHAR(30))
			SET  @antal_real_plus +=  1
		END
		ELSE
			SET @antal_real_ok += 1;
	
	SET @i = @i + 1;
END;
PRINT 'Antal (minus) : ' + CAST( @antal_real_minus AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10));
PRINT 'Antal (plus): ' + CAST( @antal_real_plus AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10));
PRINT 'Antal (lig med): ' + CAST( @antal_real_OK AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10)); 
PRINT '';
PRINT 'Antal (ROUND minus) : ' + CAST( @antal_real_round_minus AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10));
PRINT 'Antal (ROUND plus) : ' + CAST( @antal_real_round_plus AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10));
PRINT 'Antal (ROUND OK) : ' + CAST( @antal_real_round_ok AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10));
PRINT '';
PRINT 'Sum ved beregning r * 25 / 100 : ' + CAST(CAST(@sum_multi_div AS DECIMAL(19,5)) AS VARCHAR(20));
PRINT 'Sum ved beregning r / 100 * 25 : ' + CAST(CAST(@sum_div_multi AS DECIMAL(19,5)) AS VARCHAR(20));
PRINT 'Forskel : ' + CAST(CAST(@sum_multi_div AS DECIMAL(19,5)) - CAST(@sum_div_multi AS DECIMAL(19,5)) AS VARCHAR(20));
PRINT '';
PRINT 'Sum ved beregning ROUND(r * 25 / 100) : ' + CAST(CAST(@sum_multi_div_round AS DECIMAL(19,5)) AS VARCHAR(20));
PRINT 'Sum ved beregning ROUND(r / 100 * 25) : ' + CAST(CAST(@sum_div_multi_round AS DECIMAL(19,5)) AS VARCHAR(20));
PRINT 'Forskel (round) : ' + CAST(CAST(@sum_multi_div_round AS DECIMAL(19,5)) - CAST(@sum_div_multi_round AS DECIMAL(19,5)) AS VARCHAR(20));
GO
CREATE TABLE dbo.t2 
(
		r		DECIMAL(18,2)
); 
GO
INSERT INTO dbo.t2 VALUES(2000000);
INSERT INTO dbo.t2 VALUES(106);
GO
SELECT r * 25 / 100, r / 100 * 25, ROUND(r * 25 / 100, 0), ROUND(r / 100 * 25, 0)
	FROM dbo.t2;
 
SELECT r * 25 / 100, r / 100 * 25, ROUND(r * 25 / 100, 10), ROUND(r / 100 * 25, 10)
	FROM dbo.t2;
GO
CREATE TABLE dbo.t3 
(
		r		DECIMAL(28,12)
); 
GO
INSERT INTO dbo.t3 VALUES(2000000);
INSERT INTO dbo.t3 VALUES(106);
GO
SELECT r * 25 / 100, r / 100 * 25, ROUND(r * 25 / 100, 0), ROUND(r / 100 * 25, 0)
	FROM dbo.t3;
 
SELECT r * 25 / 100, r / 100 * 25, ROUND(r * 25 / 100, 10), ROUND(r / 100 * 25, 10)
	FROM dbo.t3;
GO
-- med decimal bliver resultatet ens
DECLARE @r 						DECIMAL(19,5);
DECLARE @i 						INT;
DECLARE @antal_real_minus		INT = 0;
DECLARE @antal_real_plus		INT = 0;
DECLARE @antal_real_ok			INT = 0;
DECLARE @antal_real_round_ok	INT = 0;
DECLARE @antal_real_round_minus	INT = 0;
DECLARE @antal_real_round_plus	INT = 0;
DECLARE @stop 					INT;

DECLARE @sum_div_multi			DECIMAL(19,5) = 0;
DECLARE @sum_multi_div			DECIMAL(19,5) = 0;
DECLARE @sum_div_multi_round	DECIMAL(19,5) = 0;
DECLARE @sum_multi_div_round	DECIMAL(19,5) = 0;

SET @i = 1;

SET @stop = 1000000;

WHILE @i <= @stop
BEGIN
	SET @r = @i;
	SET @r = @i / 100;
	
	SET @sum_div_multi += @r / 100 * 25;
	SET @sum_multi_div += @r * 25 / 100;
	SET @sum_div_multi_round += ROUND(@r / 100 * 25, 0);
	SET @sum_multi_div_round += ROUND(@r * 25 / 100, 0);
	
   	IF ROUND(@r * 25 / 100, 0) < ROUND(@r / 100 * 25, 0)
	BEGIN
	--	PRINT CAST(ROUND(@r * 25 / 100, 0) AS VARCHAR(30)) + '   ' + CAST(ROUND(@r / 100 * 25, 0) AS VARCHAR(30))
		SET  @antal_real_round_minus += 1;
	END
	ELSE
   		IF ROUND(@r * 25 / 100, 0) > ROUND(@r / 100 * 25, 0)
		BEGIN
		--	PRINT CAST(ROUND(@r * 25 / 100, 0) AS VARCHAR(30)) + '   ' + CAST(ROUND(@r / 100 * 25, 0) AS VARCHAR(30))
			SET  @antal_real_round_plus += 1;
		END
		ELSE
			SET @antal_real_round_ok += 1;
			
			
   	IF @r * 25 / 100 < @r / 100 * 25
	BEGIN
		--	PRINT CAST(ROUND(@r * 25 / 100, 0) AS VARCHAR(30)) + '   ' + CAST(ROUND(@r / 100 * 25, 0) AS VARCHAR(30))
		SET  @antal_real_minus += 1;
	END
	ELSE
		IF @r * 25 / 100 > @r / 100 * 25
		BEGIN
		--	PRINT CAST(ROUND(@r * 25 / 100, 0) AS VARCHAR(30)) + '   ' + CAST(ROUND(@r / 100 * 25, 0) AS VARCHAR(30))
			SET  @antal_real_plus +=  1;
		END
		ELSE
			SET @antal_real_ok += 1;
	
	SET @i = @i + 1;
END
PRINT 'Antal (minus) : ' + CAST( @antal_real_minus AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10));
PRINT 'Antal (plus): ' + CAST( @antal_real_plus AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10));
PRINT 'Antal (lig med): ' + CAST( @antal_real_OK AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10)); 
PRINT '';
PRINT 'Antal (ROUND minus) : ' + CAST( @antal_real_round_minus AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10));
PRINT 'Antal (ROUND plus) : ' + CAST( @antal_real_round_plus AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10));
PRINT 'Antal (ROUND OK) : ' + CAST( @antal_real_round_ok AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10));
PRINT '';
PRINT 'Sum ved beregning r * 25 / 100 : ' + CAST(CAST(@sum_multi_div AS DECIMAL(19,5)) AS VARCHAR(20));
PRINT 'Sum ved beregning r / 100 * 25 : ' + CAST(CAST(@sum_div_multi AS DECIMAL(19,5)) AS VARCHAR(20));
PRINT 'Forskel : ' + CAST(CAST(@sum_multi_div AS DECIMAL(19,5)) - CAST(@sum_div_multi AS DECIMAL(19,5)) AS VARCHAR(20));
PRINT '';
PRINT 'Sum ved beregning ROUND(r * 25 / 100) : ' + CAST(CAST(@sum_multi_div_round AS DECIMAL(19,5)) AS VARCHAR(20));
PRINT 'Sum ved beregning ROUND(r / 100 * 25) : ' + CAST(CAST(@sum_div_multi_round AS DECIMAL(19,5)) AS VARCHAR(20));
PRINT 'Forskel (round) : ' + CAST(CAST(@sum_multi_div_round AS DECIMAL(19,5)) - CAST(@sum_div_multi_round AS DECIMAL(19,5)) AS VARCHAR(20));
GO
-- test af performance ved brug af float contra decimal
WITH Data
AS
(
SELECT CAST(1 AS REAL) AS r, CAST(1 AS DECIMAL(19,5)) AS d
UNION ALL
SELECT CAST(r + 1 AS REAL), CAST(d + 1 AS DECIMAL(19,5))
	FROM Data
	WHERE d < 1000000
)
SELECT *
	INTO FloatDecimalData
	FROM Data
	OPTION(MAXRECURSION 0);
GO
SET STATISTICS TIME ON;

SELECT r / 100 * 25 AS r1, r * 25 / 100 AS r2, ROUND(r / 100 * 25, 0) AS r_round1, ROUND(r * 25 / 100, 0)  AS r_round2
	FROM FloatDecimalData;
GO
SELECT d / 100 * 25 AS d1, d * 25 / 100 AS d2, ROUND(d / 100 * 25, 0) AS d_round1, ROUND(d * 25 / 100, 0)  AS d_round2
	FROM FloatDecimalData;
	
SET STATISTICS TIME OFF;
GO
WITH Data
AS
(
SELECT CAST(10000000000000000 AS FLOAT) AS f, 1 AS AntalForekomst
UNION ALL
SELECT CAST(f + 1000 AS FLOAT), AntalForekomst + 1
	FROM Data
	WHERE AntalForekomst < 1000000
)
SELECT *
	INTO FloatDecimalData2
	FROM Data
	OPTION(MAXRECURSION 0);

GO
SELECT  TOP 1000 *
	FROM FloatDecimalData2;
GO
SELECT SUM(r/100*25), SUM(r*25/100), SUM(d/100*25), SUM(d*25/100)
	FROM FloatDecimalData;

SELECT SUM(f/100*25), SUM(f*25/100)
	FROM FloatDecimalData2;
