USE master
DROP DATABASE FloatDB
GO
CREATE DATABASE FloatDB
GO
USE FloatDB
GO
DECLARE @r 				REAL
DECLARE @i 				INT
DECLARE	@d11_2			DECIMAL(11,2)
DECLARE	@d13_4			DECIMAL(13,4)
DECLARE @antal_real 	INT
DECLARE @antal_int 		INT
DECLARE @antal_dec_2 	INT
DECLARE @antal_dec_4 	INT
DECLARE @stop 			INT

SET @i = 1
SET @antal_real = 0
SET @antal_int = 0
SET @antal_dec_2 = 0
SET @antal_dec_4 = 0

SET @stop = 100000

WHILE @i < @stop
BEGIN
	SET @r = @i
	SET @d11_2 = @i
	SET @d13_4 = @i

	IF ROUND(@d11_2 * 25 / 100, 0) <> ROUND(@d11_2 / 100 * 25, 0)
	BEGIN
		SET  @antal_dec_2 =  @antal_dec_2 + 1
	END

  	IF ROUND(@d13_4 * 25 / 100, 0) <> ROUND(@d13_4 / 100 * 25, 0)
	BEGIN
		SET  @antal_dec_4 =  @antal_dec_4 + 1
	END

	IF ROUND(@i * 25.0 / 100, 0) <> ROUND(@i / 100.0 * 25, 0)
	BEGIN
		SET  @antal_int =  @antal_int + 1
	END

	IF ROUND(@r * 25 / 100, 0) <> ROUND(@r / 100 * 25, 0)
	BEGIN
		SET  @antal_real =  @antal_real + 1
	END
	SET @i = @i + 1
END
PRINT 'Antal (REAL) : ' + CAST( @antal_real AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10)) 
PRINT 'Antal (INT)  : ' + CAST( @antal_int AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10))
PRINT 'Antal (dec(11,2))  : ' + CAST( @antal_dec_2 AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10))
PRINT 'Antal (dec(13,4))  : ' + CAST( @antal_dec_4 AS VARCHAR(10)) + ' af ' + CAST(@stop AS VARCHAR(10))
