-- deprecation - misbilligelse, b�n om forst�else
use master
go
drop database ProfilerDB
go
create database ProfilerDB
go
use ProfilerDB
create table t (
	id		int not null primary key identity,
	txt		varchar(20))
go
insert into t values ('xxxx')
insert into t values ('yyyy')
insert into t values ('zzzz')
insert into t values ('uuuu')
insert into t values ('vvvv')
go
backup database ProfilerDB to disk = 'c:\rod\ProfilerDB.bak' with format
go
backup log ProfilerDB with truncate_only
go
dbcc showcontig(t)
go
create index nc_t on t(txt) with SORT_IN_TEMPDB
go
exec sp_adduser 'Knud'
