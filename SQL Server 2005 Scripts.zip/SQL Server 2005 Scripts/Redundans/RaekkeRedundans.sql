USE master
DROP DATABASE RedundansDB
GO
CREATE DATABASE RedundansDB
GO
USE RedundansDB
CREATE TABLE Kunde (
	KundeId	INT NOT NULL PRIMARY KEY IDENTITY,
	Navn	VARCHAR(20) NOT NULL,
	Postnr	SMALLINT NOT NULL,
	Bynavn	VARCHAR(20) NOT NULL)
GO
CREATE TRIGGER ins_upd_Kunde ON Kunde
AFTER INSERT, UPDATE
AS
SET NOCOUNT ON
IF EXISTS (SELECT *
			FROM INSERTED INNER JOIN Kunde
					ON INSERTED.Postnr = Kunde.Postnr
			WHERE INSERTED.Bynavn <> Kunde.Bynavn)
BEGIN
	RAISERROR ('Bynavn er stavet forkert', 16, 1)
	ROLLBACK TRANSACTION
END
SET NOCOUNT OFF
GO
CREATE TABLE Kunde1 (
	KundeId	INT NOT NULL PRIMARY KEY IDENTITY,
	Navn	VARCHAR(20) NOT NULL,
	Postnr	SMALLINT NOT NULL,
	Bynavn	VARCHAR(20) NOT NULL)
GO
CREATE TRIGGER ins_upd_Kunde1 ON Kunde1
AFTER INSERT, UPDATE
AS
SET NOCOUNT ON
IF EXISTS (SELECT *
			FROM INSERTED INNER JOIN 
				(SELECT DISTINCT Postnr, Bynavn FROM Kunde1) AS Kunde1
					ON INSERTED.Postnr = Kunde1.Postnr
			WHERE INSERTED.Bynavn <> Kunde1.Bynavn)
BEGIN
	RAISERROR ('Bynavn er stavet forkert', 16, 1)
	ROLLBACK TRANSACTION
END
SET NOCOUNT OFF
GO
CREATE TABLE Kunde2 (
	KundeId	INT NOT NULL PRIMARY KEY IDENTITY,
	Navn	VARCHAR(20) NOT NULL,
	Postnr	SMALLINT NOT NULL,
	Bynavn	VARCHAR(20) NOT NULL)
GO
CREATE TRIGGER ins_upd_Kunde2 ON Kunde2
AFTER INSERT, UPDATE
AS
SET NOCOUNT ON
IF EXISTS (SELECT *
			FROM INSERTED INNER JOIN 
				(SELECT DISTINCT Postnr, Bynavn 
					FROM Kunde2
					WHERE Postnr IN (SELECT Postnr FROM INSERTED)) AS Kunde2
					ON INSERTED.Postnr = Kunde2.Postnr
			WHERE INSERTED.Bynavn <> Kunde2.Bynavn)
BEGIN
	RAISERROR ('Bynavn er stavet forkert', 16, 1)
	ROLLBACK TRANSACTION
END
SET NOCOUNT OFF
GO
INSERT INTO Kunde VALUES ('Ole', 8000, 'Aarhus C')
INSERT INTO Kunde VALUES ('Per', 8000, 'Aarhus C')
INSERT INTO Kunde VALUES ('Tom', 8000, 'Aarhus C')
INSERT INTO Kunde VALUES ('Ida', 9000, '�lborg')
INSERT INTO Kunde VALUES ('Ane', 9000, '�lborg')
GO 1000
SET IDENTITY_INSERT Kunde1 ON
INSERT INTO Kunde1(Kundeid, Navn, Postnr, Bynavn)
	SELECT Kundeid, Navn, Postnr, Bynavn FROM Kunde
SET IDENTITY_INSERT Kunde1 OFF

SET IDENTITY_INSERT Kunde2 ON
INSERT INTO Kunde2(Kundeid, Navn, Postnr, Bynavn)
	SELECT Kundeid, Navn, Postnr, Bynavn FROM Kunde
SET IDENTITY_INSERT Kunde2 OFF
GO
SELECT Bynavn, COUNT(*) 
	FROM Kunde
	GROUP BY Bynavn
GO
SET STATISTICS TIME ON

UPDATE Kunde SET Bynavn = 'Aalborg' 
	WHERE Bynavn = '�lborg'

UPDATE Kunde1 SET Bynavn = 'Aalborg' 
	WHERE Bynavn = '�lborg'

UPDATE Kunde2 SET Bynavn = 'Aalborg' 
	WHERE Bynavn = '�lborg'

SET STATISTICS TIME OFF
GO
