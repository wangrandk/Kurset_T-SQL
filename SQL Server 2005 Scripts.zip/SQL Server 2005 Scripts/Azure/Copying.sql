CREATE DATABASE CopyIndexDb AS COPY OF IndexDB
GO

SELECT *
	FROM  sys.dm_database_copies

SELECT *
	FROM sys.databases

