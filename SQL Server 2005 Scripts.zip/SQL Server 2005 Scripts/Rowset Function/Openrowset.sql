USE master;
GO
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE;
GO
EXEC sp_configure 'Ad Hoc Distributed Queries', 1;
RECONFIGURE;
GO
SELECT p.*
FROM OPENROWSET('SQLNCLI', 'Server=localhost;Trusted_Connection=yes;',
     'SELECT TOP 10 *
      FROM IndexDB.dbo.Person') AS p;
