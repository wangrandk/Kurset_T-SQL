USE master;
GO
EXEC sp_addlinkedserver 
	@server = N'ExcelDataSource', 
	@srvproduct=N'ExcelData', 
	@provider=N'Microsoft.ACE.OLEDB.12.0', 
	@datasrc=N'C:\SQL Server 2005 Scripts\Rowset Function\Book1.xlsx',
	@provstr=N'EXCEL 12.0' ;
GO
SELECT *
	FROM ExcelDataSource...Data;
GO
EXEC master.dbo.sp_dropserver @server=N'ExcelDataSource'
GO
