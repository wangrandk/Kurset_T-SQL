USE master
DROP DATABASE ApproleDB
GO
CREATE DATABASE ApproleDB
GO
USE ApproleDB
CREATE TABLE t1 (
	i	INT)
	
CREATE TABLE t2 (
	j	INT)
GO
INSERT INTO t1 VALUES (1), (2), (3)
INSERT INTO t2 VALUES (11), (12), (13)
GO
CREATE APPLICATION ROLE approle1 
    WITH PASSWORD = '987gbv876spyy5m2!' 
GO
CREATE APPLICATION ROLE approle2 
    WITH PASSWORD = '8365tgfah!klkj897'
GO
GRANT SELECT ON t1 TO approle1
GRANT SELECT ON t2 TO approle2
GO
DECLARE @cookie VARBINARY(8000);
EXEC sp_setapprole	@rolename = 'approle1', 
					@password = '987gbv876spyy5m2!',
					@fcreatecookie = true, 
					@cookie = @cookie OUTPUT;

SELECT SUSER_SNAME();
SELECT USER_NAME();
SELECT * FROM t1
SELECT * FROM t2
EXEC sp_unsetapprole @cookie;
GO
SELECT SUSER_SNAME();
SELECT USER_NAME();
SELECT ORIGINAL_LOGIN();
SELECT * FROM t1
SELECT * FROM t2

EXEC sp_setapprole 'approle2', '8365tgfah!klkj897'

SELECT USER_NAME()
SELECT * FROM t1
SELECT * FROM t2
GO