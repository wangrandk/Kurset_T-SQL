USE master
DROP DATABASE ViewDB
GO
CREATE DATABASE ViewDB
GO
use ViewDB
CREATE TABLE t (
	a		INT, 
	b		INT, 
	c		INT)
GO
INSERT INTO t VALUES 
	(1,2,3),
	(4,5,6)
GO
CREATE VIEW v1
AS
SELECT * FROM t
GO
CREATE VIEW v2
AS
SELECT a, b, c FROM t
GO
SELECT * FROM t
SELECT * FROM v1
SELECT * FROM v2
GO
ALTER TABLE t ADD d INT NOT NULL default 7
GO
SELECT * FROM t
SELECT * FROM v1
SELECT * FROM v2
GO
ALTER TABLE t DROP COLUMN b
GO
SELECT * FROM t
SELECT * FROM v1
SELECT * FROM v2
GO
DROP VIEW v1
DROP VIEW v2
GO
ALTER TABLE t ADD b INT NOT NULL default 8
GO
CREATE VIEW v1		--fejl
WITH SCHEMABINDING
AS
SELECT * 
	FROM t
GO
CREATE VIEW v2
WITH SCHEMABINDING
AS
SELECT a, b, c 
	FROM dbo.t
GO
ALTER TABLE t DROP COLUMN b		-- fejl
GO
ALTER TABLE t add e INT NOT NULL default 8
GO
SELECT * 
	FROM sys.columns 
	WHERE object_id in (SELECT object_id
							FROM sys.tables
							WHERE name = 't')
SELECT * 
	FROM sys.columns 
	WHERE object_id in (SELECT object_id 
							FROM sys.views
							WHERE name IN ('v1', 'v2')) 
