USE master;
DROP DATABASE UpdateViewDB;
GO
CREATE DATABASE UpdateViewDB;
GO
USE UpdateViewDB;
GO
CREATE TABLE dbo.Projektion
(
	Id			INT			NOT NULL PRIMARY KEY IDENTITY,
	Navn		VARCHAR(20)	NOT NULL,
	Gade		VARCHAR(20) NULL,
	Type		CHAR(1) DEFAULT 'C'
);
GO
INSERT INTO dbo.Projektion VALUES
	('Ane', 'Vestergade', 'A'),
	('Hans', '�stergade', 'B'),
	('Hanne', 'Torvet', 'A')
GO
CREATE VIEW dbo.vProjektion1 
AS
SELECT	Navn, 
		Type
    FROM dbo.Projektion;
GO
CREATE VIEW dbo.vProjektion2 
AS
SELECT	Navn
    FROM dbo.Projektion;
GO
INSERT INTO dbo.vProjektion1 VALUES 
	('Ida', 'D');
GO
SELECT * 
	FROM dbo.Projektion;
GO
INSERT INTO dbo.vProjektion2 
	VALUES ('Bo');
GO
SELECT * 
	FROM dbo.Projektion;
GO
UPDATE dbo.vProjektion1
	SET Navn = 'Ida Marie'
	WHERE Id = 4;
GO
UPDATE dbo.vProjektion1
	SET Navn = 'Ida Marie'
	WHERE Navn = 'Ida';
GO
SELECT * 
	FROM dbo.Projektion;
	