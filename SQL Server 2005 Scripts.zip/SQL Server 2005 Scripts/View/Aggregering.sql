USE master;
DROP DATABASE UpdateViewDB;
GO
CREATE DATABASE UpdateViewDB;
GO
USE UpdateViewDB;
GO
CREATE TABLE dbo.Aggrigering
(
	AggKol		CHAR(1) NOT NULL,
	AggVaerdi	INT NOT NULL
);
GO
INSERT INTO dbo.Aggrigering VALUES
	('A', 10),
	('A', 20),
	('A', 30),
	('A', 40),
	('B', 20),
	('B', 40);
GO
CREATE VIEW dbo.vAggrigering
AS
SELECT AggKol, SUM(AggVaerdi) AS ialt
	FROM Aggrigering
	GROUP BY AggKol;
GO
SELECT * 
	FROM dbo.vAggrigering;
GO
DELETE					-- Fejl
	FROM dbo.vAggrigering
 	WHERE AggKol = 'A';
