USE master;
DROP DATABASE UpdateViewDB;
GO
CREATE DATABASE UpdateViewDB;
GO
USE UpdateViewDB;
GO
CREATE TABLE dbo.Postopl
(	
	Postnr		SMALLINT NOT NULL PRIMARY KEY,
	Bynavn		VARCHAR(20)NOT NULL
);
GO
CREATE TABLE dbo.Person
(
	Id			INT NOT NULL PRIMARY KEY IDENTITY,
	Navn		VARCHAR(20) NOT NULL,
	Gade		VARCHAR(20) NOT NULL,
	Postnr		SMALLINT NOT NULL REFERENCES Postopl
);
GO
INSERT INTO dbo.Postopl VALUES
	(9000, 'Aalborg'),
	(8000, 'Aarhus C');
GO
INSERT INTO dbo.Person VALUES
	('Ane', 'Vestergade', 9000),
	('Hans', '�stergade', 8000),
	('Hanne', 'Torvet', 9000);
GO
CREATE VIEW dbo.Personopl1 
AS
SELECT	dbo.Person.*, 
		dbo.Postopl.Bynavn
    FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr;
GO
CREATE VIEW dbo.Personopl2 
AS
SELECT	dbo.Person.Id, 
		dbo.Person.Navn, 
		dbo.Person.Gade, 
		dbo.Postopl.*
    FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr;
GO
SELECT * 
	FROM dbo.Personopl1;
SELECT * 
	FROM dbo.Personopl2;
GO
INSERT INTO dbo.Personopl1 VALUES 
	(5, 'Bo', 'Nygade', 8000, 'Aarhus C');	-- fejl
GO
INSERT INTO dbo.Personopl1 VALUES 
	('Bo', 'Nygade', 8000);					-- fejl
GO
INSERT INTO dbo.Personopl1(Navn, Gade, Postnr) VALUES 
	('Bo', 'Nygade', 8000);
GO
SELECT * 
	FROM dbo.Person;
GO
INSERT INTO dbo.Personopl2(Navn, Gade, Postnr) VALUES 
	('Marie', 'N�rregade', 8000);  -- fejl
GO
INSERT INTO dbo.Personopl2(Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg');
GO
SELECT * 
	FROM dbo.Postopl;
GO
UPDATE dbo.Personopl2 
	SET Bynavn = 'Aalborg C' 
	WHERE Bynavn = 'Aalborg';
GO
UPDATE dbo.Personopl1 
	SET Bynavn = 'Aalborg' 
	WHERE Bynavn = 'Aalborg C';
GO
CREATE TABLE dbo.Kunde1
(
	Id			INT NOT NULL PRIMARY KEY IDENTITY,
	Navn		VARCHAR(30) NOT NULL
);

CREATE TABLE dbo.Kunde2
(
	Id			INT NOT NULL PRIMARY KEY REFERENCES dbo.Kunde1(Id),
	Gade		VARCHAR(30) NOT NULL,
	Postnr		SMALLINT NOT NULL
);
GO
CREATE VIEW dbo.Kunde
AS
SELECT	Kunde1.Id,
		Kunde1.Navn,
		Kunde2.Gade,
		Kunde2.Postnr
	FROM dbo.Kunde1 INNER JOIN dbo.Kunde2 ON Kunde1.Id = Kunde2.Id;
GO
CREATE TRIGGER ins_Kunde ON dbo.Kunde
INSTEAD OF INSERT
AS
SET NOCOUNT ON
--IF (SELECT COUNT(*)
--		FROM inserted) > 1
--BEGIN
--	RAISERROR('Kun 1 dbo.Kunde pr inds�telse', 16,1)
--	ROLLBACK TRANSACTION
--END

SELECT	Navn,
		Gade,
		Postnr
	INTO #k
	FROM inserted;

DECLARE @k TABLE
(
	Navn		VARCHAR(30) NULL,
	Gade		VARCHAR(30) NULL,
	Postnr		SMALLINT NULL
);
	 
WHILE EXISTS (SELECT * FROM #k)
BEGIN
	DELETE TOP (1)	
		FROM #k
		OUTPUT DELETED.* INTO @k;
		
	INSERT INTO dbo.Kunde1 (Navn)
		SELECT Navn	
		FROM @k;

	INSERT INTO dbo.Kunde2 (Id, Gade, Postnr)
		SELECT	SCOPE_IDENTITY(), 
				Gade, 
				Postnr
			FROM @k;
	DELETE 
		FROM @k;
END;
GO
CREATE TRIGGER del_Kunde ON dbo.Kunde
INSTEAD OF DELETE
AS
SET NOCOUNT ON
DELETE
	FROM dbo.Kunde2
	WHERE Id IN (SELECT Id 
					FROM deleted);

DELETE
	FROM dbo.Kunde1
	WHERE Id IN (SELECT Id 
					FROM deleted);		
GO
INSERT INTO dbo.Kunde (Navn, Gade, Postnr) VALUES
	('Ole', 'Nygade', 2000);
GO
SELECT *
	FROM dbo.Kunde;
SELECT *
	FROM dbo.Kunde1;
SELECT *
	FROM dbo.Kunde2;
GO
INSERT INTO dbo.Kunde (Navn, Gade, Postnr) VALUES
	('Ida', 'Torvet', 2000);
GO
DELETE 
	FROM dbo.Kunde
	WHERE Id = 1;
GO		
SELECT *
	FROM dbo.Kunde;
SELECT *
	FROM dbo.Kunde1;
SELECT *
	FROM dbo.Kunde2;	
GO
INSERT INTO dbo.Kunde (Navn, Gade, Postnr) VALUES
	('Hansen', 'Nygade', 8000),
	('Olsen', 'Torvet', 3000);
GO
SELECT *
	FROM dbo.Kunde;
SELECT *
	FROM dbo.Kunde1;
SELECT *
	FROM dbo.Kunde2;
