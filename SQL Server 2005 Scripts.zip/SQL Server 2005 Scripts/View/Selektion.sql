USE master;
DROP DATABASE UpdateViewDB;
GO
CREATE DATABASE UpdateViewDB;
GO
USE UpdateViewDB;
GO
CREATE TABLE dbo.Selektion
(
	Id			INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(20) NOT NULL,
	Type		CHAR(1)
);
GO
INSERT INTO dbo.Selektion VALUES
	(1, 'Ane', 'A'),
	(2, 'Hans', 'B'),
	(3, 'Hanne', 'A');
GO
CREATE VIEW dbo.vSelektion 
AS
SELECT	Id, 
		Navn, 
		Type
	FROM dbo.Selektion
	WHERE Type = 'B'

WITH CHECK OPTION;
GO
SELECT *
	FROM dbo.Selektion;

SELECT *
	FROM dbo.vSelektion;
GO
INSERT INTO dbo.vSelektion VALUES
	(4, 'Bo', 'B');
GO
INSERT INTO dbo.vSelektion VALUES
	(5, 'Ida', 'A');
GO
DELETE 
	FROM dbo.vSelektion 
	WHERE Id = 1;

SELECT @@ROWCOUNT;
GO
DELETE 
	FROM dbo.vSelektion
	WHERE Id = 2;

SELECT @@ROWCOUNT;
GO
SELECT *
	FROM dbo.Selektion;

UPDATE dbo.vSelektion
	SET Navn = 'hanne marie'
	WHERE Id = 3;
GO
UPDATE dbo.vSelektion
	SET Navn = 'ib bo'
	WHERE Id = 4;
GO
SELECT * 
	FROM dbo.Selektion;
GO
UPDATE dbo.vSelektion
	SET Type = 'B'
	WHERE Id = 1;
GO
UPDATE dbo.vSelektion
	SET Type = 'A'
	WHERE Id = 4;
GO
UPDATE dbo.vSelektion
	SET Type = 'B'
	WHERE Type = 'A';
-----------------------------------------------------------------
USE master;
DROP DATABASE UpdateViewDB;
GO
CREATE DATABASE UpdateViewDB;
GO
USE UpdateViewDB;
GO
CREATE TABLE dbo.Selektion
(
	Id			INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(20) NOT NULL,
	Type		CHAR(1)
);
GO
INSERT INTO dbo.Selektion VALUES
	(1, 'Ane', 'A'),
	(2, 'Hans', 'B'),
	(3, 'Hanne', 'A');
GO
CREATE VIEW dbo.vSelektion 
AS
SELECT Id, Navn, Type
	FROM dbo.Selektion
	WHERE Type = 'B';
--WITH CHECK OPTION
GO
INSERT INTO dbo.vSelektion VALUES
	(4, 'Bo', 'B');
GO
INSERT INTO dbo.vSelektion VALUES
	(5, 'Ida', 'A');
GO
SELECT * 
	FROM dbo.Selektion;
SELECT * 
	FROM dbo.vSelektion;
GO
DELETE 
	FROM dbo.vSelektion 
	WHERE Id = 1;
GO
DELETE 
	FROM dbo.vSelektion 
	WHERE Id = 2;
GO
SELECT *
	FROM dbo.Selektion;

UPDATE dbo.vSelektion
	SET Navn = 'Hanne Marie'
	WHERE Id = 3;
GO
UPDATE dbo.vSelektion
	SET Navn = 'Ib Bo'
	WHERE Id = 4;
GO
SELECT * 
	FROM dbo.Selektion;
GO
UPDATE dbo.vSelektion
	SET Type = 'B'
	WHERE Id = 1;
GO
UPDATE dbo.vSelektion
	SET Type = 'A'
	WHERE Id = 4;
GO
UPDATE dbo.vSelektion
	SET Type = 'B'
	WHERE Type = 'A';
GO
UPDATE dbo.vSelektion
	SET Type = 'A'
	WHERE Type = 'B';