USE master;
DROP DATABASE UpdateViewDB;
GO
CREATE DATABASE UpdateViewDB;
GO
USE UpdateViewDB;
GO
CREATE TABLE dbo.t1
(
	Id 			INT NOT NULL  PRIMARY KEY CHECK (Id < 100),
	Navn		VARCHAR(20)
);

CREATE TABLE dbo.t2
(
	Id 			INT NOT NULL  PRIMARY KEY CHECK (Id >= 100),
	Navn		VARCHAR(20)
);
GO
CREATE VIEW dbo.t 
AS
SELECT * 
	FROM dbo.t1
UNION ALL
SELECT * 
	FROM dbo.t2;
GO
INSERT INTO dbo.t VALUES
	(1,'Ida'),
	(2,'Hanne'),
	(3,'Ane'),

	(101,'Ib'),
	(102,'Bo');
GO
SELECT * 
	FROM dbo.t1;
SELECT * 
	FROM dbo.t2;
SELECT * 
	FROM dbo.t;
GO
DROP VIEW dbo.t;
DROP TABLE dbo.t1;
DROP TABLE dbo.t2;
GO
CREATE TABLE dbo.t1
(
	Id 				INT NOT NULL,
	Lokation		CHAR(1) NOT NULL CHECK (Lokation = 'A'),
	Navn			VARCHAR(20),
	PRIMARY KEY (Id, Lokation)
);
CREATE TABLE dbo.t2
	(
	Id 				INT NOT NULL,
	Lokation		CHAR(1) NOT NULL CHECK (Lokation = 'P'),
	Navn			VARCHAR(20),
	PRIMARY KEY (Id, Lokation)
);
GO
CREATE VIEW dbo.t
AS
SELECT * 
	FROM dbo.t1
UNION ALL
SELECT * 
	FROM dbo.t2;
GO
INSERT INTO dbo.t VALUES
	(1, 'A','Ida'),
	(2, 'A','Hanne'),
	(3, 'A','Ane'),
	(4, 'P','Ib'),
	(5, 'P','Bo');
GO
INSERT INTO dbo.t VALUES
	(5, 'K','Knud');
GO
SELECT * 
	FROM dbo.t1;
SELECT * 
	FROM dbo.t2;
SELECT * 
	FROM dbo.t;
GO
UPDATE dbo.t 
	SET Lokation = 'P' 
	WHERE Id = 1;
GO
SELECT * 
	FROM dbo.t1;
SELECT * 
	FROM dbo.t2;
GO
SELECT * 
	FROM dbo.t;

SELECT * 
	FROM dbo.t 
	WHERE Lokation = 'A';
GO
SELECT * 
	FROM dbo.t 
	WHERE Lokation = 'K';
GO
INSERT INTO dbo.t1 VALUES
	(5, 'A','Maren');
INSERT INTO dbo.t2 VALUES
	(12, 'P','�ge');
GO
INSERT INTO dbo.t2 VALUES
	(6, 'A','Maren');
INSERT INTO dbo.t1 VALUES
	(15, 'P','�ge');
GO
SELECT * 
	FROM dbo.t1;
SELECT * 
	FROM dbo.t2;
GO
---------------------fejl ---
USE master;
DROP DATABASE UpdateViewDB;
GO
CREATE DATABASE UpdateViewDB;
GO
USE UpdateViewDB;
GO
CREATE TABLE dbo.t1
(
	Id 			INT NOT NULL  PRIMARY KEY CHECK (Id <= 100),
	Navn		VARCHAR(20)
);
CREATE TABLE dbo.t2
(
	Id 			INT NOT NULL  PRIMARY KEY CHECK (Id >= 100),  -- overlap med dbo.t1
	Navn		VARCHAR(20)
);
GO
CREATE VIEW dbo.t 
AS
SELECT * 
	FROM dbo.t1
UNION ALL
SELECT * 
	FROM dbo.t2;
GO
INSERT INTO dbo.t VALUES
	(1,'Ida');

INSERT INTO dbo.t VALUES
	(100,'Hanne');
GO
SELECT *
	FROM sys.views;

SELECT *
	FROM INFORMATION_SCHEMA.views;

SELECT *
	FROM sys.objects
	WHERE type = 'V';
GO
-- forskelligt antal kolonner, fejler
DROP VIEW dbo.t;
DROP TABLE dbo.t1;
DROP TABLE dbo.t2;
GO
CREATE TABLE dbo.t1
(
	Id 				INT NOT NULL,
	Lokation		CHAR(1) NOT NULL CHECK (Lokation = 'A'),
	Navn			VARCHAR(20) NOT NULL,
	PRIMARY KEY (Id, Lokation)
);

CREATE TABLE t2
(
	Id 				INT NOT NULL,
	Lokation		CHAR(1) NOT NULL CHECK (Lokation = 'P'),
	Navn			VARCHAR(20) NOT NULL,
	Gade			VARCHAR(30) NULL
	PRIMARY KEY (Id, Lokation)
);
GO
CREATE VIEW dbo.t
AS
SELECT	Id, 
		Lokation, 
		Navn 
	FROM dbo.t1
UNION ALL
SELECT	Id, 
		Lokation, 
		Navn
	FROM dbo.t2;
GO
INSERT INTO dbo.t (Id, Lokation, Navn) VALUES
	(1, 'A','Ida'),
	(2, 'A','Hanne'),
	(3, 'A','Ane'),
	(4, 'P','Ib'),
	(5, 'P','Bo');
GO
CREATE VIEW dbo.tUpd
AS
SELECT	Id, 
		Lokation, 
		Navn, 
		NULL AS Gade
	FROM dbo.t1
UNION ALL
SELECT	Id, 
		Lokation, 
		Navn, 
		Gade
	FROM dbo.t2
GO
INSERT INTO dbo.tUpd (Id, Lokation, Navn) VALUES
	(1, 'A','Ida');

INSERT INTO dbo.tUpd (Id, Lokation, Navn) VALUES
	(5, 'P','Bo');
GO
-- index
DROP VIEW dbo.t;
DROP TABLE dbo.t1;
DROP TABLE dbo.t2;
GO
CREATE TABLE dbo.t1
(
	Id 				INT NOT NULL,
	Lokation		CHAR(1) NOT NULL CHECK (Lokation = 'A'),
	Navn			VARCHAR(20) NOT NULL,
	PRIMARY KEY (Id, Lokation)
);

CREATE TABLE t2
(
	Id 				INT NOT NULL,
	Lokation		CHAR(1) NOT NULL CHECK (Lokation = 'P'),
	Navn			VARCHAR(20) NOT NULL
	PRIMARY KEY (Id, Lokation)
);
GO
CREATE VIEW dbo.t
WITH SCHEMABINDING
AS
SELECT	Id, 
		Lokation, 
		Navn 
	FROM dbo.t1
UNION ALL
SELECT	Id, 
		Lokation, 
		Navn
	FROM dbo.t2;
GO
INSERT INTO dbo.t (Id, Lokation, Navn) VALUES
	(1, 'A','Ida'),
	(2, 'A','Hanne'),
	(3, 'A','Ane'),
	(4, 'A','Ole'),
	(5, 'A','Lars'),
	(6, 'A','Maren'),
	(14, 'P','Ib'),
	(15, 'P','Ole'),
	(16, 'P','Ole'),
	(17, 'P','Maren'),
	(18, 'P','Lars'),
	(19, 'P','Sanne');
GO
CREATE INDEX nc_t1_Navn ON dbo.t1(Navn);
CREATE INDEX nc_t2_Navn ON dbo.t2(Navn);
GO
SELECT *
	FROM dbo.t
	WHERE Navn = 'Ole';
GO
CREATE UNIQUE CLUSTERED INDEX nc_t_Lokation_Navn ON dbo.t(Lokation, Navn); -- fejl
