USE IndexDB;
GO
DROP VIEW dbo.vCount;
DROP VIEW dbo.vCount1;
GO
CREATE VIEW dbo.vCount
WITH SCHEMABINDING
AS
SELECT	COUNT_BIG(*) AS NumberOfPersons
	FROM dbo.Person;
GO
CREATE UNIQUE CLUSTERED INDEX cl_vCount_NumberOfPersons ON dbo.vCount(NumberOfPersons)
GO
SELECT COUNT(*)
	FROM dbo.Person;
	
SELECT *	
	FROM dbo.vCount;
GO
CREATE VIEW dbo.vCount1
WITH SCHEMABINDING
AS
SELECT	COUNT_BIG(*) AS NumberOfPersons,  
		COUNT_BIG(Koenkode) AS NumberOfKK, 
		COUNT_BIG(Postnr) AS NumberOfZipcodes
	FROM dbo.Person:
GO
CREATE UNIQUE CLUSTERED INDEX cl_vCount1_NumberOfPersons ON dbo.vCount1(NumberOfPersons);
CREATE NONCLUSTERED INDEX nc_vCount1_Other ON dbo.vCount1(NumberOfKK, NumberOfZipcodes);
GO
SELECT	COUNT(*), 
		COUNT(Postnr), 
		COUNT(KoenKode)
	FROM dbo.Person;
	
SELECT *	
	FROM dbo.vCount1;
