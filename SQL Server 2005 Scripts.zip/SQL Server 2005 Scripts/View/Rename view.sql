USE master
DROP DATABASE ViewDB
GO
CREATE DATABASE ViewDB
GO
use ViewDB
CREATE TABLE t (
	id		INT NOT NULL identity,
	a		INT NOT NULL,
	b		INT NOT NULL,
	c		INT NOT NULL)
GO
CREATE VIEW v
AS
	SELECT id, a, b
		FROM t
GO
-- rename view in object explore
SELECT *	
	FROM syscomments
SELECT * 
	FROM sys.views
GO
-- generate script for view in object explore
GO
--script
USE ViewDB
GO
/****** Object:  View [dbo].[v2]    Script Date: 04/24/2007 07:20:08 ******/
--fejler i SQL Server 2000
CREATE VIEW [dbo].[v2]
AS
	SELECT id, a, b
		FROM t

