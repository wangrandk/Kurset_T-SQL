USE master;
DROP DATABASE AttackDB;
GO
CREATE DATABASE AttackDB;
GO
USE AttackDB;
CREATE TABLE dbo.t1 
(
	Id			INT NOT NULL IDENTITY PRIMARY KEY,
	Navn		VARCHAR(20)
);
GO
INSERT INTO dbo.t1 VALUES 
	('Bo'),
	('Ib');
GO
CREATE PROC usp_t 
	@Navn VARCHAR(60)
AS
BEGIN
	DECLARE @sql	VARCHAR(2000);

	IF @Navn LIKE '%create%' or	@Navn like '%;%'
		THROW 65876, 'fejlagtig s�gekriterie', 1;
	ELSE
	BEGIN
		SET @sql = CONCAT('SELECT * FROM dbo.t1 WHERE Navn = ''', @Navn, '''');
		SELECT @sql;
		EXEC (@sql);
	END;
END;
GO
EXEC usp_t 'Bo'
GO
EXEC usp_t 'Bo''; DROP TABLE dbo.t1 --';
GO
SELECT * 
	FROM dbo.t1;
GO
CREATE TABLE dbo.t2 
(
	Id			INT NOT NULL IDENTITY PRIMARY KEY,
	Navn		VARCHAR(20)
);
GO
INSERT INTO t2 VALUES 
	('Bodil'),
	('Ane');
GO
EXEC usp_t 'Bo'' UNION ALL SELECT object_id, name FROM sys.objects  --'
GO
ALTER PROC usp_t 
	@Navn VARCHAR(60)
AS
BEGIN
	DECLARE @sql	VARCHAR(2000);

	IF @Navn LIKE '%create%' or	@Navn like '%;%'
		THROW 65876, 'fejlagtig s�gekriterie', 1;
	ELSE
	BEGIN
		SET @sql = CONCAT('SELECT * FROM dbo.t1 WHERE Navn = ''', @Navn, CHAR(10), '''');
		SELECT @sql;
		EXEC (@sql);
	END;
END;
GO
EXEC usp_t 'Bo'' UNION ALL SELECT object_id, name FROM sys.objects  --'
