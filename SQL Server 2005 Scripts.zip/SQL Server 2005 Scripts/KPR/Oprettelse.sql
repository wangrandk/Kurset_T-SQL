USE master
DROP DATABASE AlgebraDB
GO
CREATE DATABASE AlgebraDB
GO
USE AlgebraDB
CREATE TABLE Rettighed (
	RettighedID			CHAR(1) NOT NULL PRIMARY KEY,
	RettighedNavn		VARCHAR(20) NOT NULL)
			
CREATE TABLE Person (
	PersonID			INT NOT NULL PRIMARY KEY,
	Navn				VARCHAR(20) NOT NULL,
	DefaultRettighed	CHAR(1) REFERENCES Rettighed)

CREATE TABLE Katalog (
	KatalogID			INT NOT NULL PRIMARY KEY,
	KatalogSti			VARCHAR(255) NOT NULL)

CREATE TABLE KPR (
	PersonID			INT NOT NULL,
	KatalogID			INT NOT NULL,
	RettighedID			CHAR(1) NOT NULL,
	CONSTRAINT PK_KPR PRIMARY KEY (PersonID, KatalogID))
GO
INSERT INTO Rettighed VALUES
	('A','All'),
	('N','No access'),
	('R','Read'),
	('W','Write')

INSERT INTO Person VALUES
	(1,	'Ole','N'),
	(2,	'Per','W'),
	(3,	'Ida','W'),
	(4,	'Lars','R'),
	(5,	'Anne','R')

INSERT INTO Katalog VALUES
	(1,'c:\kat1'),
	(2,'c:\kat2'),
	(3,'c:\kat3'),
	(4,'c:\kat4'),
	(5,'c:\kat5')
	
INSERT INTO KPR VALUES 
	(1,1,'R'),
	(1,3,'W'),
	(2,1,'R'),
	(2,4,'R'),
	(2,5,'R'),
	(3,3,'N'),
	(3,5,'R'),
	(4,3,'A'),
	(5,1,'A'),
	(5,2,'A'),
	(5,3,'A'),
	(5,4,'W'),
	(5,5,'W')
GO
