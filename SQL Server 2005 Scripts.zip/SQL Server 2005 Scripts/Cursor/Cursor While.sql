USE IndexDB;
GO
DECLARE @Personid	INT, 
		@Navn		VARCHAR(50);
DECLARE	@Start		DATETIME2,
		@Slut		DATETIME2;

SET @Start = SYSDATETIME();

DECLARE Person_cursor CURSOR FOR 
	SELECT Personid, Fornavn + ' ' + Efternavn
		FROM dbo.Person;

OPEN Person_cursor;

FETCH NEXT 
	FROM Person_cursor 
	INTO @Personid, @Navn;

WHILE @@fetch_status = 0
BEGIN
	PRINT CAST(@Personid AS VARCHAR(10)) + '        ' +  @Navn;

	FETCH NEXT 
		FROM Person_cursor 
		INTO @Personid, @Navn;
END;
CLOSE Person_cursor;
DEALLOCATE Person_cursor;

SET @Slut = SYSDATETIME()
SELECT @Start, @Slut, DATEDIFF(MILLISECOND, @Start, @Slut)
---------------------------------------------------------------------------
GO
USE IndexDB;
GO
DECLARE @Personid	INT, 
		@Navn		VARCHAR(50);
DECLARE	@Start		DATETIME2,
		@Slut		DATETIME2;

SET @Start = SYSDATETIME();

SET @Personid = 0;

WHILE EXISTS (SELECT * 
				FROM dbo.Person 
				WHERE Personid > @Personid)
BEGIN
	SELECT @Personid = Personid, @Navn = Fornavn + ' ' + Efternavn
		FROM dbo.Person
		WHERE Personid = (SELECT MIN(Personid)
							FROM dbo.Person
							WHERE Personid > @Personid);

	PRINT CAST(@Personid AS VARCHAR(10)) + '        ' +  @Navn;
END;

SET @Slut = SYSDATETIME();

SELECT @Start, @Slut, DATEDIFF(MILLISECOND,@Start, @Slut);
