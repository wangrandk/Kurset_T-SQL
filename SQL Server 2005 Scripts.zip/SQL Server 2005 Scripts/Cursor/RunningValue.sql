USE IndexDb
DROP table RunningValue
GO
SELECT top 20000 IDENTITY (INT) AS id,postnr, postnr / ((personid % 27) + 1) AS value
	INTO RunningValue
	FROM person
	WHERE Personid % 29 = 25
GO
SELECT * 
	FROM Runningvalue
GO
DECLARE rc CURSOR 
FOR
SELECT id, Postnr, value
	FROM RunningValue
	ORDER BY postnr, id

DECLARE @postnr		SMALLINT
DECLARE @postnr_gl	SMALLINT
DECLARE @value		INT
DECLARE @id			INT
DECLARE @sum		bigINT

DECLARE @res TABLE (
	id			INT, 
	postnr		SMALLINT, 
	value		INT, 
	sum_value	INT)

OPEN rc
FETCH NEXT FROM rc INTO @id, @postnr, @value

SET @postnr_gl = @postnr
SET @sum = 0

WHILE @@fetch_status = 0
BEGIN
	IF @postnr_gl <> @postnr
	BEGIN
		SET @sum = 0
		SET @postnr_gl = @postnr
	end 
	SET @sum = @sum + @value
	INSERT INTO @res VALUES (@id, @postnr, @value, @sum)
	FETCH NEXT FROM rc INTO @id, @postnr, @value
END
CLOSE rc
DEALLOCATE rc 
SELECT * FROM @res order by postnr, id
GO
SELECT id, postnr, value, 
		(SELECT SUM(value) AS sum_value 
			FROM RunningValue AS rv2
			WHERE rv1.postnr = rv2.postnr and rv1.id >= rv2.id ) AS sum_value
	FROM RunningValue AS rv1
	ORDER BY postnr, id
GO
CREATE INDEX nc_rv ON RunningValue (postnr, Id) 
GO
SELECT id, postnr, value, 
		(SELECT sum(value) AS sum_value 
			FROM RunningValue AS rv2
			WHERE rv1.postnr = rv2.postnr and rv1.id >= rv2.id ) AS sum_value
	FROM RunningValue AS rv1
	ORDER BY postnr, id
GO
SELECT rv1.id, rv1.postnr, min(rv1.value) AS value,sum(rv2.value) AS sum_value 
	FROM RunningValue AS rv1 INNER JOIN RunningValue AS rv2 
		ON rv1.postnr = rv2.postnr AND rv1.id >= rv2.id
	GROUP BY rv1.postnr, rv1.id
	ORDER BY rv1.postnr, rv1.id
