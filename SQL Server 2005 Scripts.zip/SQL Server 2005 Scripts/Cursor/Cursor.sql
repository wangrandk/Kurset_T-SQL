USE master
DROP DATABASE CursorDB
GO
CREATE DATABASE CursorDB
GO
USE CursorDB
CREATE table postopl (
	postnr		SMALLINT	NOT NULL PRIMARY KEY,	
	bynavn		VARCHAR (30) NOT NULL)
CREATE table kunde (
	kundeid		INT	NOT NULL PRIMARY KEY IDENTITY,
	navn		VARCHAR (30) NOT NULL,
	adresse		VARCHAR (30) NOT NULL,
	postnr		SMALLINT NOT NULL 
				CONSTRAINT fk_postopl_kunde FOREIGN KEY REFERENCES postopl (postnr))
CREATE table ordre (
	ordreid		INT	NOT NULL PRIMARY KEY IDENTITY,
	bestildato	DATETIME NOT NULL default (getdate()),
	levdato		DATETIME NULL,
	kundeid		INT NULL 
				CONSTRAINT fk_kunde_ordre FOREIGN KEY REFERENCES kunde (kundeid))
CREATE table ordrelinie (
	ordreid		INT	NOT NULL
				CONSTRAINT fk_ordre_ordrelinie FOREIGN KEY REFERENCES ordre (ordreid),
	vareid		INT	NOT NULL,
	antalenh	SMALLINT NOT NULL,
	CONSTRAINT pk_ordrelinie PRIMARY KEY (ordreid,vareid))
GO
SET NOCOUNT ON
INSERT INTO postopl VALUES (2000, 'Frederiksberg')
INSERT INTO postopl VALUES (8000, '�rhus C')
INSERT INTO postopl VALUES (9000, 'Aalborg')

INSERT INTO kunde VALUES ('Jens Hansen', 'Nygade 3', 2000)
INSERT INTO kunde VALUES ('Ole Larsen', 'Vestergade 4', 9000)
INSERT INTO kunde VALUES ('Karen Olsen', 'Borgergade 13', 9000)
INSERT INTO kunde VALUES ('Karl Nielsen', 'S�ndergade 67', 8000)

INSERT INTO ordre (levdato, kundeid) VALUES (GETDATE() + 10, 2)
INSERT INTO ordre (levdato, kundeid) VALUES (GETDATE() + 2, 1)
INSERT INTO ordre (levdato, kundeid) VALUES (GETDATE() + 20, 2)
INSERT INTO ordre (levdato, kundeid) VALUES (GETDATE() + 4, 3)
INSERT INTO ordre (levdato, kundeid) VALUES (GETDATE() + 24, 2)

INSERT INTO ordrelinie VALUES (1, 3, 2)
INSERT INTO ordrelinie VALUES (1, 6, 8)
INSERT INTO ordrelinie VALUES (2, 3, 4)
INSERT INTO ordrelinie VALUES (3, 1, 1)
INSERT INTO ordrelinie VALUES (3, 2, 2)
INSERT INTO ordrelinie VALUES (4, 4, 3)
INSERT INTO ordrelinie VALUES (5, 2, 6)
INSERT INTO ordrelinie VALUES (5, 6, 1)
INSERT INTO ordrelinie VALUES (5, 7, 1)
SET NOCOUNT OFF
GO
SET NOCOUNT ON

DECLARE @kundeid	INT, 
		@navn		VARCHAR(50)

DECLARE kunde_cursor CURSOR FOR 
	SELECT kundeid, navn
		FROM kunde

OPEN kunde_cursor

FETCH NEXT FROM kunde_cursor INTO @kundeid, @navn

WHILE @@fetch_status = 0
BEGIN
	PRINT CAST(@kundeid AS VARCHAR(5)) + '        ' +  @navn
	FETCH NEXT FROM kunde_cursor INTO @kundeid, @navn
END
CLOSE kunde_cursor
DEALLOCATE kunde_cursor
GO
SET NOCOUNT ON

DECLARE @kundeid		INT, 
		@navn			VARCHAR(50),
		@ordreid		INT,
		@bestildato		DATETIME,
		@levdato		DATETIME

DECLARE kunde_cursor CURSOR FOR 
	SELECT kundeid, navn
		FROM kunde

OPEN kunde_cursor
FETCH NEXT FROM kunde_cursor INTO @kundeid, @navn

WHILE @@fetch_status = 0
BEGIN
	PRINT cast(@kundeid AS VARCHAR(5)) + '        ' +  @navn
	DECLARE ordre_cursor CURSOR FOR 
		SELECT ordreid, bestildato, levdato
			FROM ordre
			WHERE kundeid = @kundeid

	OPEN ordre_cursor	
	FETCH NEXT FROM ordre_cursor INTO @ordreid, @bestildato, @levdato
	WHILE @@fetch_status = 0
	begin
		PRINT '     ' + CAST(@ordreid AS VARCHAR(5)) + '     ' +
						CONVERT(VARCHAR(20),@bestildato, 102) + '     ' +
						CONVERT(VARCHAR(20),@levdato, 102)
		FETCH NEXT FROM ordre_cursor INTO @ordreid, @bestildato, @levdato
	END
	CLOSE ordre_cursor
	DEALLOCATE ordre_cursor
	FETCH NEXT FROM kunde_cursor INTO @kundeid, @navn
END
CLOSE kunde_cursor
DEALLOCATE kunde_cursor
