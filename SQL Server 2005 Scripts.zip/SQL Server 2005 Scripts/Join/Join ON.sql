USE master;
DROP DATABASE JoinDB;
GO
CREATE DATABASE JoinDB;
GO
USE JoinDB;
CREATE TABLE dbo.Kunde 
(
	KundeId		INT			NOT NULL PRIMARY KEY,
	Navn		VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Ordre 
(
	OrdreId		INT			NOT NULL PRIMARY KEY,
	Ordredato	DATETIME2	NOT NULL,
	KundeId		INT			NULL FOREIGN KEY REFERENCES dbo.Kunde(KundeId)
);
GO
SET NOCOUNT ON;
INSERT INTO dbo.Kunde VALUES 
	(1, 'Ole'),
	(2, 'Ida'),
	(3, 'Ane'),
	(4, 'Per');

INSERT INTO dbo.Ordre VALUES 
	(11, DATEADD(DAY, -24, SYSDATETIME()), 1),
	(12, DATEADD(DAY, -17, SYSDATETIME()), 2),
	(13, DATEADD(DAY, -17, SYSDATETIME()), 1),
	(14, DATEADD(DAY, -15, SYSDATETIME()), 3),
	(15, DATEADD(DAY, -12, SYSDATETIME()), NULL);
SET NOCOUNT OFF;
GO
SELECT *
	FROM dbo.Kunde INNER JOIN dbo.Ordre ON Kunde.KundeId = Ordre.KundeId;
GO
SELECT *
	FROM dbo.Kunde, dbo.Ordre
	WHERE Kunde.KundeId = Ordre.KundeId;
GO
SELECT *
	FROM dbo.Kunde LEFT JOIN dbo.Ordre ON Kunde.KundeId = Ordre.KundeId;
GO
SELECT *									-- fejl
	FROM dbo.Kunde LEFT JOIN dbo.Ordre ON 1 = 1
	WHERE Kunde.KundeId = Ordre.KundeId;
GO
SELECT *
	FROM dbo.Kunde LEFT JOIN dbo.Ordre ON Kunde.KundeId = Ordre.KundeId
	WHERE dbo.Kunde.Navn <> 'Ida';
GO
SELECT *									-- fejl
	FROM dbo.Kunde LEFT JOIN dbo.Ordre ON 1 = 1
	WHERE Kunde.KundeId = Ordre.KundeId AND
		  dbo.Kunde.Navn <> 'Ida';
GO
SELECT *
	FROM dbo.Kunde FULL JOIN dbo.Ordre ON Kunde.KundeId = Ordre.KundeId
GO
SELECT *									-- fejl
	FROM dbo.Kunde FULL JOIN dbo.Ordre ON 1 = 1
	WHERE Kunde.KundeId = Ordre.KundeId
