USE master;
GO
DROP DATABASE DistinctDB;
GO
CREATE DATABASE DistinctDB;
GO
USE DistinctDB;
CREATE TABLE dbo.t1
(
	ID		INT NOT NULL IDENTITY PRIMARY KEY,
	Txt		CHAR(200) NOT NULL,
);

CREATE TABLE dbo.t2
(
	ID		INT NOT NULL IDENTITY,
	Txt		CHAR(200) NOT NULL,
);

CREATE TABLE dbo.t3
(
	ID		INT NOT NULL IDENTITY PRIMARY KEY,
	Txt		CHAR(200) NOT NULL,
);
GO
DECLARE @i		INT = 1;
DECLARE @Loop	INT = 13;

INSERT INTO dbo.t1(Txt) VALUES
	(REPLICATE('x', 200));

INSERT INTO dbo.t2(Txt) VALUES
	(REPLICATE('y', 200));

INSERT INTO dbo.t3(Txt) VALUES
	(REPLICATE('z', 200));

WHILE @i < @Loop
BEGIN
	INSERT INTO dbo.t1 (Txt)
		SELECT Txt
			FROM dbo.t1;

	INSERT INTO dbo.t2(Txt)
		SELECT Txt
			FROM dbo.t2;

	INSERT INTO dbo.t3(Txt)
		SELECT Txt
			FROM dbo.t3;

	SET @i += 1;
END;

SELECT COUNT(*)
	FROM dbo.t1;
GO
SELECT DISTINCT *
	FROM dbo.t1;

SELECT DISTINCT *
	FROM dbo.t2;
GO
SELECT DISTINCT *
	FROM dbo.t1 INNER JOIN dbo.t2 ON t1.ID = t2.ID

SELECT DISTINCT *
	FROM dbo.t1 INNER JOIN dbo.t3 ON t1.ID = t3.ID

SELECT DISTINCT *
	FROM dbo.t1 INNER JOIN (SELECT *
								FROM dbo.t3
								WHERE ID > 2) AS t3
			ON t1.id = t3.id

SELECT DISTINCT *
	FROM dbo.t1 INNER JOIN (SELECT *
								FROM dbo.t3
								WHERE Txt LIKE '%zzz%zzz%') AS t3
			ON t1.id = t3.id

SELECT DISTINCT *
	FROM dbo.t1 INNER JOIN (SELECT	t3.*,
									t1.Txt AS t1Txt
								FROM dbo.t3 INNER JOIN dbo.t1 ON t3.ID = t1.ID
								WHERE t3.Txt LIKE '%zzz%zzz%') AS t4
			ON t1.ID = t4.ID
