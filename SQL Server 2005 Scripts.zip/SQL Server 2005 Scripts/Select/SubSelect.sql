USE master
DROP DATABASE SelectDB;
GO
CREATE DATABASE SelectDB;
GO
USE SelectDB;
CREATE TABLE Postopl 
(
	Postnr		SMALLINT NOT NULL PRIMARY KEY,
	Bynavn		VARCHAR(20) NOT NULL
);

CREATE TABLE Kunde 
(
	Kundeid		INT NOT NULL PRIMARY KEY IDENTITY,
	Navn		VARCHAR(30) NOT NULL,
	Adresse		VARCHAR(30) NOT NULL,
	Postnr		SMALLINT NOT NULL
);
GO
SET NOCOUNT ON;
INSERT INTO Postopl VALUES 
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(8200, 'Aarhus N'),
	(9000, 'Aalborg');

INSERT INTO Kunde VALUES 
	('Ane Jensen', 'Nygade 3', 8200),
	('Per Larsen', 'Vestergade 11', 9000),
	('Ib Olsen', '�stergade 4', 9000),
	('Lise Hansen', 'Torvet 2', 2000),
	('Karl Erik Poulsen', 'S�ndergade 56', 8000),
	('Pia Andersen', 'Vestergade 87', 2000),
	('Erik Iversen', 'Poulsgade 6', 8000),
	('Peter Andersen', 'N�rregade 9', 8000),
	('Tine Davidsen', 'Hovedvejen 245', 9990),
	('Ane Jensen', 'Larsensvej 39', 8200),
	('Per Larsen', 'Nyvej 2', 8000);
SET NOCOUNT ON
GO
SELECT * 
	FROM Kunde;

SELECT DISTINCT Postnr 
	FROM Kunde;

SELECT COUNT(*) AS AntalKunder 
	FROM Kunde;

SELECT Navn 
	FROM Kunde 
	WHERE Postnr = -1;
GO
SELECT	*, 
		(SELECT COUNT(*)  FROM Kunde) AS AntalKunder
	FROM Kunde INNER JOIN (SELECT Postnr, COUNT(*) AS AntalKunderPrPostnr
								FROM Kunde
								GROUP BY Postnr) AS AntalPrPost
		ON Kunde.Postnr = AntalPrPost.Postnr
	WHERE Kunde.Postnr IN (SELECT Postnr FROM Postopl WHERE Bynavn LIKE '�%');
GO
SELECT	*,
		(SELECT Bynavn FROM Postopl WHERE Postopl.Postnr = Kunde.Postnr) AS Bynavn	-- null for 6000
	FROM Kunde;
GO
SELECT *
	FROM Kunde
	WHERE Postnr BETWEEN (SELECT Postnr FROM Postopl WHERE Bynavn = 'Frederiksberg') AND
						 (SELECT Postnr FROM Postopl WHERE Bynavn = 'Aarhus C');
GO
SELECT *
	FROM Kunde AS Kunde_ydre
	WHERE Postnr = ALL (SELECT Postnr 
							FROM Kunde AS Kunde_indre 
							WHERE Kunde_ydre.Navn = Kunde_indre.Navn);
	ORDER BY Navn
GO
IF (SELECT COUNT(DISTINCT Postnr) FROM Kunde) > (SELECT COUNT(DISTINCT Kunde.Postnr) 
													FROM Kunde INNER JOIN Postopl
															ON Kunde.Postnr = Postopl.Postnr)
	PRINT 'Kunder med Postnr, der ikke findes i Postopl'
ELSE
	PRINT 'Alle Kunders Postnr findes i Postopl';
GO
DECLARE @Postnr SMALLINT;
SELECT @Postnr = Postnr 
	FROM Kunde;

SET @Postnr = (SELECT Postnr FROM Kunde);		-- fejler
GO
