USE master
DROP DATABASE RecursiveDB
GO
CREATE DATABASE RecursiveDB
GO
USE RecursiveDB
GO
CREATE TABLE Reservationer (
	Id				INT NOT NULL PRIMARY KEY IDENTITY,
	medarbejderId	INT	NOT NULL,
	starttId		SMALLDATETIME NOT NULL,
	sluttId			SMALLDATETIME NOT NULL,
	CONSTRAINT ck_starttId_sluttId CHECK (starttId < sluttId))
GO
INSERT INTO Reservationer VALUES 
	(1, '2006-11-15 00:00', '2006-11-15 09:00'),
	(1, '2006-11-15 10:00', '2006-11-15 11:30'),
	(1, '2006-11-15 12:00', '2006-11-15 12:30'),
	(1, '2006-11-15 15:00', '2006-11-15 17:00'),
	(1, '2006-11-15 17:45', '2006-11-15 20:00'),
	(1, '2006-11-15 20:45', '2006-11-15 21:30'),
	(1, '2006-11-15 23:00', '2006-11-15 23:59'),
	(2, '2006-11-15 00:00', '2006-11-15 09:00'),
	(2, '2006-11-15 12:00', '2006-11-15 12:30'),
	(2, '2006-11-15 12:30', '2006-11-15 13:15'),
	(2, '2006-11-15 16:00', '2006-11-15 23:59')
GO
----- version 2000
DECLARE @resinterval		SMALLINT
DECLARE @reservationstider	TABLE (
	 medarbejderId			SMALLINT NOT NULL,
	 startinterval			SMALLDATETIME  NOT NULL,
	 slutinterval			SMALLDATETIME  NOT NULL,
	 starttId				SMALLDATETIME  NOT NULL,
	 sluttId				SMALLDATETIME  NOT NULL)

SET @resinterval = 45

INSERT INTO @reservationstider
	SELECT	medarbejderId,
			sluttId, 
			(SELECT MIN(starttId) FROM Reservationer WHERE starttId >= res.sluttId AND medarbejderId = res.medarbejderId),
			sluttId,
			DATEADD(mi, @resinterval, sluttId)
		FROM Reservationer AS res
		WHERE	DATEADD(mi, @resinterval, sluttId) <= (SELECT MIN(starttId) FROM Reservationer WHERE starttId >= res.sluttId AND medarbejderId = res.medarbejderId) and
				(SELECT MIN(starttId) FROM Reservationer WHERE starttId >= res.sluttId AND medarbejderId = res.medarbejderId) is NOT NULL   

WHILE @@ROWCOUNT > 0
	INSERT INTO @reservationstider
		SELECT	medarbejderId,
				startinterval, 
				slutinterval, 
				sluttId, 
				DATEADD(mi, @resinterval, sluttId) 
			FROM @reservationstider AS res
			WHERE DATEADD(mi, @resinterval, sluttId) <= slutinterval AND 
				  sluttId not in (SELECT starttId FROM @reservationstider WHERE medarbejderId = res.medarbejderId)

SELECT * FROM @reservationstider order by medarbejderId, starttId
GO
----- version 2005
DECLARE @resinterval	SMALLINT
SET @resinterval = 45;

WITH reservationstider (medarbejderId, startinterval, slutinterval, starttId, sluttId)
AS
	(SELECT	medarbejderId,
			sluttId, 
			(SELECT MIN(starttId) FROM Reservationer WHERE starttId > res.sluttId AND medarbejderId = res.medarbejderId),
			sluttId,
			DATEADD(mi, @resinterval, sluttId)
		FROM Reservationer AS res
		WHERE	DATEADD(mi, @resinterval, sluttId) <= (SELECT MIN(starttId) FROM Reservationer WHERE starttId >= res.sluttId AND medarbejderId = res.medarbejderId) and
	 			(SELECT MIN(starttId) FROM Reservationer WHERE starttId >= res.sluttId AND medarbejderId = res.medarbejderId) is NOT NULL
	UNION ALL
		SELECT	medarbejderId,
				startinterval, 
				slutinterval, 
				sluttId, 
				DATEADD(mi, @resinterval, sluttId) 
			FROM reservationstider
			WHERE DATEADD(mi, @resinterval, sluttId) <= slutinterval)

SELECT * 
	FROM reservationstider 
	ORDER BY medarbejderId, starttId
