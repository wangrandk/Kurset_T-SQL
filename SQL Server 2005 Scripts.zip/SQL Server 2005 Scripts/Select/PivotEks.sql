USE IndexDB
GO
CREATE TABLE Person
(
	PersonID	INT IDENTITY(1,1) NOT NULL,
	ForNavn		VARCHAR(20) NOT NULL,
	EfterNavn	VARCHAR(20) NOT NULL,
	Gade		VARCHAR(30) NOT NULL,
	Postnr		SMALLINT NOT NULL
);
GO
SELECT *
	FROM Person
			PIVOT (COUNT(Postnr) FOR Postnr IN ([2000], [9000], [8000])) AS Pvt
	ORDER BY EfterNavn

SELECT Efternavn, [2000], [9000], [8000]
	FROM Person
			PIVOT (COUNT(Postnr) FOR Postnr IN ([2000], [9000], [8000])) AS Pvt
	ORDER BY EfterNavn

SELECT *
	FROM (SELECT EfterNavn, Postnr FROM Person) AS Person
			PIVOT (COUNT(Postnr) FOR Postnr IN ([2000], [9000], [8000])) AS Pvt
	ORDER BY EfterNavn
	
SELECT *
	FROM (SELECT Fornavn, EfterNavn, Postnr FROM Person WHERE Postnr IN (2000, 8000, 9000)) AS Person
			PIVOT (COUNT(Postnr) FOR Postnr IN ([2000], [9000], [8000])) AS Pvt
	ORDER BY EfterNavn
	
SELECT *
	FROM (SELECT Fornavn, EfterNavn, Postnr FROM Person) AS Person
			PIVOT (COUNT(Postnr) FOR Postnr IN ([2000], [9000], [8000])) AS Pvt
	ORDER BY Fornavn, EfterNavn

SELECT TOP 11 *
	FROM (SELECT EfterNavn, Postnr FROM Person) AS Person
			PIVOT (COUNT(EfterNavn) FOR EfterNavn IN (Andersen, Jensen, Hansen, Olsen )) AS pvt
	ORDER BY Postnr
GO
