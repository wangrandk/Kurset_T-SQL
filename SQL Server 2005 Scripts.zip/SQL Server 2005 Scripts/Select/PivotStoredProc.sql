USE master
DROP DATABASE PIVOTDB
GO
CREATE DATABASE PIVOTDB
GO
USE PIVOTDB
CREATE TABLE Kundesalg (
	--Id		INT NOT NULL PRIMARY KEY IDENTITY,
	KundeId		INT NOT NULL,
	Aar			SMALLINT NOT NULL,
	Beloeb		INT NOT NULL)
GO
SET NOCOUNT ON
DECLARE @Aar					SMALLINT
DECLARE @AntalTransaktioner		SMALLINT
DECLARE @MaxTransaktioner		SMALLINT

SET @Aar = YEAR(SYSDATETIME()) - 10

WHILE @Aar <= YEAR(SYSDATETIME())
BEGIN
	SET @AntalTransaktioner = 1
	SET @MaxTransaktioner = 1000

	WHILE @AntalTransaktioner <= @MaxTransaktioner
	BEGIN
		INSERT INTO Kundesalg 
			VALUES((@AntalTransaktioner * DATEPART(ms, GETDATE())) % 13 + 1 , @Aar, (@Aar % 43) * @AntalTransaktioner % 15)
		
		SET @AntalTransaktioner = @AntalTransaktioner + 1
		
		IF @AntalTransaktioner % 100 = 0
			WAITFOR DELAY '0:0:0:002'
	END
	SET @Aar = @Aar + 1
END
UPDATE Kundesalg
	SET beloeb = 12
	WHERE Beloeb = 0

SET NOCOUNT OFF

SELECT * 
	FROM Kundesalg
	ORDER BY KundeId, Aar
GO
CREATE PROCEDURE usp_PIVOT_Kundesalg
	@AntalAar	SMALLINT = 99,
	@Print		SMALLINT = 0
AS
DECLARE @PivotStr		VARCHAR(2000);
DECLARE @PivotSQL		NVARCHAR(4000);

WITH 
AarCTE
AS
(
SELECT DISTINCT TOP (@AntalAar) Aar
	FROM Kundesalg
	ORDER BY Aar DESC
),
AarCTE_Order
AS
(
SELECT TOP (@AntalAar) Aar
	FROM AarCTE
	ORDER BY Aar
)
SELECT @PivotStr = ISNULL(@PivotStr + ',[', '[') + CAST(Aar AS VARCHAR(5)) + ']'
	FROM AarCTE_Order

SET @PivotSQL = 'SELECT * FROM Kundesalg PIVOT (COUNT(Beloeb) FOR Aar IN ( ' + 
				@PivotStr + 
				')) AS Pvt ORDER BY KundeId'

IF @Print = 1
BEGIN
	PRINT @PivotStr
	PRINT @PivotSQL
END

EXEC sys.sp_executesql @PivotStrtatement = @PivotSQL;
GO
EXEC usp_PIVOT_Kundesalg
GO
EXEC usp_PIVOT_Kundesalg @AntalAar = 3, @Print = 1
GO
ALTER PROCEDURE usp_PIVOT_Kundesalg
	@AntalAar	SMALLINT = 99,
	@Print		SMALLINT = 0
AS
DECLARE @PivotStr		NVARCHAR(2000);
DECLARE @KolonneListe	NVARCHAR(2000);
DECLARE @PivotSQL		NVARCHAR(4000);
DECLARE @AktueltAar		SMALLINT = (SELECT DISTINCT TOP (1) Aar
										FROM Kundesalg
										ORDER BY Aar DESC);

WITH
KolonneCTE
AS
(
SELECT @AktueltAar AS Aar, CAST('Aktuelt �r' AS NVARCHAR(255)) AS Kolonnenavn
UNION ALL
SELECT CAST(Aar - 1 AS SMALLINT), CAST(N'Aktuelt �r - ' + CAST(@AktueltAar - Aar + 1 AS NVARCHAR(5)) AS NVARCHAR(255))
	FROM KolonneCTE
	WHERE Aar > @AktueltAar - @AntalAar + 1
),
AarCTE
AS
(
SELECT DISTINCT TOP (@AntalAar) Aar
	FROM Kundesalg
	ORDER BY Aar DESC
),
AarCTE_Order
AS
(
SELECT TOP (@AntalAar) AarCTE.Aar, Kolonnenavn
	FROM AarCTE INNER JOIN KolonneCTE ON AarCTE.Aar = KolonneCTE.Aar
	ORDER BY Aar
)
SELECT @KolonneListe =	ISNULL(@KolonneListe + ', [', '[') + CAST(Aar AS VARCHAR(5)) + '] AS [' +
						AarCTE_Order.Kolonnenavn + ']'
	FROM AarCTE_Order;

WITH 
AarCTE
AS
(
SELECT DISTINCT TOP (@AntalAar) Aar
	FROM Kundesalg
	ORDER BY Aar DESC
),
AarCTE_Order
AS
(
SELECT TOP (@AntalAar) Aar
	FROM AarCTE
	ORDER BY Aar
)
SELECT @PivotStr = ISNULL(@PivotStr + ', [', '[') + CAST(Aar AS VARCHAR(5)) + ']'
	FROM AarCTE_Order

SET @PivotSQL = N'SELECT ' + 
				@KolonneListe + 
				' FROM Kundesalg PIVOT (COUNT(Beloeb) FOR Aar IN ( ' + 
				@PivotStr + 
				N')) AS Pvt ORDER BY KundeId'

IF @Print = 1
BEGIN
	PRINT @PivotStr
	PRINT @KolonneListe
	PRINT @PivotSQL
END

EXEC sys.sp_executesql @PivotStrtatement = @PivotSQL;
GO
EXEC usp_PIVOT_Kundesalg @Print = 1
GO
EXEC usp_PIVOT_Kundesalg @AntalAar = 3, @Print = 1
GO
