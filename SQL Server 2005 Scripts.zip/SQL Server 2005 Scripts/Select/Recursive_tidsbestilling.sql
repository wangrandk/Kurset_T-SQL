USE master
DROP DATABASE RecursiveDB
GO
CREATE DATABASE RecursiveDB
GO
USE RecursiveDB
GO
CREATE TABLE Reservationer (
	Id			INT NOT NULL PRIMARY KEY IdENTITY,
	Starttid	SMALLDATETIME NOT NULL,
	Sluttid		SMALLDATETIME NOT NULL,
	CONSTRAINT ck_Starttid_Sluttid CHECK (Starttid < Sluttid))
go
INSERT INTO Reservationer VALUES 
	('2006-11-15 00:00', '2006-11-15 09:00'),
	('2006-11-15 10:00', '2006-11-15 11:30'),
	('2006-11-15 12:00', '2006-11-15 12:30'),
	('2006-11-15 12:30', '2006-11-15 13:15'),
	('2006-11-15 15:00', '2006-11-15 17:00'),
	('2006-11-15 17:45', '2006-11-15 20:00'),
	('2006-11-15 20:45', '2006-11-15 21:30'),
	('2006-11-15 23:00', '2006-11-16 00:00')
go
----- version 2000
DECLARE @ReservationsInterval		SMALLINT
DECLARE @reservationstIder			TABLE (
			StartInterval			SMALLDATETIME  NOT NULL,
			SlutInterval			SMALLDATETIME  NOT NULL,
			Starttid				SMALLDATETIME  NOT NULL,
			Sluttid					SMALLDATETIME  NOT NULL)

SET @ReservationsInterval = 45

INSERT INTO @reservationstIder
	SELECT	Sluttid, 
			(SELECT MIN(Starttid) 
				FROM Reservationer 
				WHERE Starttid >= res.Sluttid),
			Sluttid,
			DATEADD(mi, @ReservationsInterval, Sluttid)
		FROM Reservationer AS res
		WHERE DATEADD(mi, @ReservationsInterval, Sluttid) <= (SELECT MIN(Starttid) 
																FROM Reservationer 
																WHERE Starttid >= res.Sluttid) AND
			 (SELECT MIN(Starttid) 
				FROM Reservationer 
				WHERE Starttid >= res.Sluttid) IS NOT NULL   

WHILE @@ROWCOUNT > 0
	INSERT INTO @reservationstIder
		SELECT	StartInterval, 
				SlutInterval, 
				Sluttid, 
				DATEADD(mi, @ReservationsInterval, Sluttid) 
			FROM @reservationstIder
			WHERE DATEADD(mi, @ReservationsInterval, Sluttid) <= SlutInterval AND 
				  Sluttid NOT IN (SELECT Starttid 
									FROM @reservationstIder)

SELECT * 
	FROM @reservationstIder 
	ORDER BY Starttid
go
----- version 2005
DECLARE @ReservationsInterval	SMALLINT

SET @ReservationsInterval = 45;

WITH reservationstIder (StartInterval, SlutInterval, Starttid, Sluttid)
AS (
	SELECT	Sluttid, 
			(SELECT min(Starttid) 
				FROM Reservationer 
				WHERE Starttid >= res.Sluttid),
			Sluttid,
			DATEADD(mi, @ReservationsInterval, Sluttid)
		FROM Reservationer as res
		WHERE DATEADD(mi, @ReservationsInterval, Sluttid) <= (SELECT MIN(Starttid) 
																FROM Reservationer 
																WHERE Starttid >= res.Sluttid) AND
	 		  (SELECT MIN(Starttid) 
				FROM Reservationer 
				WHERE Starttid >= res.Sluttid) IS NOT NULL
	UNION ALL
		SELECT	StartInterval, 
				SlutInterval, 
				Sluttid, 
				DATEADD(mi, @ReservationsInterval, Sluttid) 
			FROM reservationstIder
			WHERE DATEADD(mi, @ReservationsInterval, Sluttid) <= SlutInterval
)
SELECT * 
	FROM reservationstIder 
	ORDER BY Starttid
