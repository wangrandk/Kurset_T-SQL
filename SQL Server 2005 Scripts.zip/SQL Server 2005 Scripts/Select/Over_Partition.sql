USE GroupingDB
GO
SET STATISTICS TIME ON
GO
DBCC DROPCLEANBUFFERS
SELECT Fornavn, Efternavn, Gade, Postnr, COUNT(*) OVER()  AS Antal
	FROM person
DBCC DROPCLEANBUFFERS
SELECT Fornavn, Efternavn, Gade, Postnr, (SELECT COUNT(*) FROM Person)
	FROM Person
GO
SET STATISTICS TIME OFF
GO
SET STATISTICS TIME ON
GO
DBCC DROPCLEANBUFFERS
SELECT Fornavn, Efternavn, Gade, Postnr, COUNT(*) OVER(PARTITION BY Postnr)  AS Antal
FROM person
DBCC DROPCLEANBUFFERS
SELECT Fornavn, Efternavn, Gade, Postnr, (SELECT COUNT(*) FROM Person AS PIndre WHERE Pindre.Postnr = PYdre.Postnr)
FROM Person AS PYdre
GO
SET STATISTICS TIME OFF
GO
DBCC DROPCLEANBUFFERS
SET STATISTICS TIME ON
SELECT Fornavn, Efternavn, Gade, Postnr, 
	COUNT(*) OVER(PARTITION BY Postnr)  AS AntalPostnr,
	COUNT(*) OVER(PARTITION BY Fornavn)  AS AntalFornavn,
	COUNT(*) OVER(PARTITION BY Efternavn)  AS AntalEfternavn,
	COUNT(*) OVER(PARTITION BY Gade)  AS AntalGade
FROM person
DBCC DROPCLEANBUFFERS
SELECT Fornavn, Efternavn, Gade, postnr, 
	(SELECT COUNT(*) FROM Person AS PIndre WHERE Pindre.Postnr = PYdre.Postnr),
	(SELECT COUNT(*) FROM Person AS PIndre WHERE Pindre.Fornavn = PYdre.Fornavn),
	(SELECT COUNT(*) FROM Person AS PIndre WHERE Pindre.Efternavn = PYdre.Efternavn),
	(SELECT COUNT(*) FROM Person AS PIndre WHERE Pindre.Gade = PYdre.Gade)
FROM Person AS PYdre
SET STATISTICS TIME OFF
GO