USE master
DROP DATABASE PivotDB
GO
CREATE DATABASE PivotDB
GO
USE PivotDB
CREATE TABLE MaaleData (
	BatchID		INT NOT NULL,
	MaaleText	VARCHAR(20) NOT NULL,
	MaaleVaerdi	INT NOT NULL,
	MaaleTid	DATETIME NOT NULL DEFAULT(GETDATE()))
GO
INSERT INTO MaaleData (BatchID, MaaleText, MaaleVaerdi) VALUES 
	(1, 'A', 20),
	(1, 'A', 43),
	(1, 'A', 31),
	(1, 'A', 17),
	(1, 'A', 56),

	(1, 'B', 63),

	(1, 'C', 37),
	(1, 'C', 28),
	(1, 'C', 69),

	(2, 'A', 55),

	(2, 'B', 14),
	(2, 'B', 33),
	(2, 'B', 20),
	(2, 'B', 13),

	(2, 'C', 22),
	(2, 'C', 15),
	(2, 'C', 47)
GO
SELECT  *
	FROM (SELECT MaaleText, MaaleVaerdi, 
				ROW_NUMBER() OVER (PARTITION BY BatchID, MaaleText ORDER BY  MaaleTid) AS	Lbnr
			FROM MaaleData)  AS MD
       PIVOT (SUM(MaaleVaerdi) FOR MaaleText IN ([A], [B], [C])) AS MaaleDataPVT
	ORDER BY Lbnr	
GO
SELECT *
	FROM 
		(SELECT 
				(SELECT COUNT(*) 
					FROM MaaleData AS MD_Count
					WHERE MD_A.MaaleTid >= MD_Count.MaaleTid AND
						  MD_Count.MaaleText = 'A') AS Lbnr,
				MaaleVaerdi AS A
			FROM MaaleData AS MD_A
			WHERE MaaleText = 'A') AS MD_A
		FULL OUTER JOIN 
		(SELECT 
				(SELECT COUNT(*) 
					FROM MaaleData AS MD_Count
					WHERE MD_B.MaaleTid >= MD_Count.MaaleTid AND
						  MD_Count.MaaleText = 'B') AS Lbnr,
				MaaleVaerdi AS B
			FROM MaaleData AS MD_B
			WHERE MaaleText = 'B') AS MD_B	
		ON MD_A.Lbnr = MD_B.Lbnr 
		FULL OUTER JOIN
		(SELECT
				(SELECT COUNT(*) 
					FROM MaaleData AS MD_Count
					WHERE MD_C.MaaleTid >= MD_Count.MaaleTid AND
						  MD_Count.MaaleText = 'C') AS Lbnr,
				MaaleVaerdi AS C
			FROM MaaleData AS MD_C
			WHERE MaaleText = 'C') AS MD_C
		ON MD_B.Lbnr = MD_C.Lbnr OR MD_A.Lbnr = MD_C.Lbnr
ORDER BY MD_A.lbnr
GO
SELECT  *
	FROM (SELECT MaaleText
			FROM MaaleData)  AS MD
       PIVOT (MAX(MaaleText) FOR MaaleText IN ([A], [B], [C])) AS MaaleDataPVT
