USE master
GO
DROP DATABASE SortDB
GO
CREATE DATABASE SortDB
GO
USE SortDB
CREATE TABLE dbo.t (
	ID				INT NOT NULL,
	SortData		CHAR(1) NOT NULL)

CREATE TABLE dbo.SortOrden (
	SortData		CHAR(1) NOT NULL PRIMARY KEY,
	SortOrdenValue	INT)
GO
INSERT INTO dbo.t VALUES 
	(1, 'A'),
	(2, 'A'),
	(3, 'B'),
	(4, 'B'),
	(5, 'D'),
	(6, 'C'),
	(7, 'C'),
	(8, 'D'),
	(9, 'D');

INSERT INTO dbo.SortOrden VALUES 
	('A', 2),
	('B', 1),
	('C', 3),
	('D', 4);

GO
SELECT *
	FROM dbo.t
	ORDER BY (SELECT SortOrdenValue
				FROM dbo.SortOrden
				WHERE SortOrden.SortData = t.SortData)
GO
SELECT *, (SELECT SortOrdenValue
				FROM dbo.SortOrden
				WHERE SortOrden.SortData = t.SortData) AS SortKol
	FROM dbo.t
	ORDER BY SortKol
GO
