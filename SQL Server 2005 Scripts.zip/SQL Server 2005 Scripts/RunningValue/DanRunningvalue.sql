USE master
GO
DROP DATABASE RunningvalueDB
GO
CREATE DATABASE RunningvalueDB
GO
USE RunningvalueDB
CREATE TABLE MdTotal (
	Id			INT NOT NULL PRIMARY KEY IDENTITY,
	KategoriID	CHAR(1) NOT NULL,
	Beloeb		INT NOT NULL,
	Aar			SMALLINT NOT NULL,
	Md			SMALLINT NOT NULL,
	CONSTRAINT UQ_MdTotal__Aar_Md UNIQUE (KategoriID, Aar, Md))
GO
SET NOCOUNT ON
DECLARE @Aar	SMALLINT = 1200
DECLARE @Md		SMALLINT

WHILE @Aar <= YEAR(SYSDATETIME())
BEGIN
	SET @Md = 1
	WHILE @Md <= 12
	BEGIN
		INSERT INTO MdTotal (KategoriID, Aar, Md, Beloeb) 
			VALUES ('A', @Aar, @Md, 100)   --bel�b altid 100
		SET @Md += 1
	END
	SET @Aar += 1	
END
INSERT INTO MdTotal (KategoriID, Aar, Md, Beloeb)
	SELECT 'B', Aar, Md, Beloeb
		FROM MdTotal
		WHERE KategoriID = 'A'
		
INSERT INTO MdTotal (KategoriID, Aar, Md, Beloeb)
	SELECT 'C', Aar, Md, Beloeb
		FROM MdTotal
		WHERE KategoriID = 'A'

INSERT INTO MdTotal (KategoriID, Aar, Md, Beloeb)
	SELECT 'D', Aar, Md, Beloeb
		FROM MdTotal
		WHERE KategoriID = 'A'
		
SET NOCOUNT OFF
GO
SELECT *
	FROM MdTotal
GO
SET STATISTICS IO ON
SET STATISTICS TIME ON
SELECT	Mt1.Aar, 
		Mt1.Md, 
		MIN(Mt1.Beloeb) AS Beloeb, 
		SUM(Mt2.Beloeb) AS Runningvalue 
	FROM MdTotal AS Mt1 INNER JOIN MdTotal AS Mt2
				ON	Mt1.Aar = Mt2.Aar AND
					Mt1.KategoriID = Mt2.KategoriID AND
					Mt1.Md >= Mt2.Md
	GROUP BY Mt1.Aar, Mt1.Md
	ORDER BY Mt1.Aar, Mt1.Md
GO
SELECT	Aar, 
		Md, 
		Beloeb,
		(SELECT SUM(Beloeb) 
			FROM MdTotal AS MT_inner 
			WHERE	MT_inner.Aar = MT_outer.Aar AND
					MT_inner.KategoriID = MT_outer.KategoriID AND
					MT_inner.Md <= MT_outer.Md) AS Runningvalue 
	FROM MdTotal AS MT_outer
	ORDER BY Aar, Md
GO
SET STATISTICS TIME OFF
SET STATISTICS IO OFF
