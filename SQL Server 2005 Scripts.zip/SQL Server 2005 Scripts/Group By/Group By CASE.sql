USE master
GO 
DROP DATABASE GroupByDB;
GO
CREATE DATABASE GroupByDB;
GO
USE GroupByDB;
CREATE TABLE dbo.Kunde 
(
	KundeID			INT NOT NULL PRIMARY KEY,
	Kundenavn		VARCHAR(30) NOT NULL,
	SidsteDato		DATE NOT NULL
);

CREATE TABLE dbo.Ordre 
(
	OrdreID			INT NOT NULL PRIMARY KEY,
	Beloeb			INT NOT NULL,
	KundeID			INT NOT NULL REFERENCES Kunde
);
GO
INSERT INTO dbo.Kunde VALUES
	(1, 'Jens Hansen', DATEADD(DAY, -1120, SYSDATETIME())),
	(2, 'Hanne Larsen', DATEADD(DAY, -534, SYSDATETIME ())),
	(3, 'Ole Olsen', DATEADD(DAY, -278, SYSDATETIME())),
	(4, 'Ida Jensen', DATEADD(DAY, -13, SYSDATETIME())),
	(5, 'Ane Carlsen', DATEADD(DAY, -4, SYSDATETIME()));

	
INSERT INTO dbo.Ordre VALUES
	(1, 25, 2),
	(2, 35, 1),
	(3, 17, 4),	
	(4, 43, 5),
	(5, 18, 4),
	(6, 13, 3),
	(7, 19, 2),	
	(8, 11, 4),
	(9, 25, 5),
	(10, 14, 5),
	(11, 78, 1),	
	(12, 19, 3);
GO
SELECT CASE 
			WHEN DATEDIFF(DAY, Kunde.SidsteDato, SYSDATETIME()) < 200 THEN CAST(Kunde.KundeID AS VARCHAR(10)) + ' - ' + Kundenavn
			ELSE 'Gamle kunder'
	   END AS KundeData, AVG(Beloeb) AS Gennemsnit
	FROM dbo.Kunde INNER JOIN dbo.Ordre ON Kunde.KundeID = Ordre.KundeID
	GROUP BY	CASE 
					WHEN DATEDIFF(DAY, Kunde.SidsteDato, SYSDATETIME()) < 200 THEN CAST(Kunde.KundeID AS VARCHAR(10)) + ' - ' + Kundenavn
					ELSE 'Gamle kunder'
				 END
	ORDER BY 1;
GO
SELECT	IIF(DATEDIFF(DAY, Kunde.SidsteDato, SYSDATETIME()) < 200,
			CAST(Kunde.KundeID AS VARCHAR(10)) + ' - ' + Kundenavn,
			'Gamle kunder') AS KundeData, 
		AVG(Beloeb) AS Gennemsnit
	FROM dbo.Kunde INNER JOIN dbo.Ordre ON Kunde.KundeID = Ordre.KundeID
	GROUP BY	IIF(DATEDIFF(DAY, Kunde.SidsteDato, SYSDATETIME()) < 200,
					CAST(Kunde.KundeID AS VARCHAR(10)) + ' - ' + Kundenavn,
					'Gamle kunder')
	ORDER BY 1;
GO
WITH Grpdata
AS
(
SELECT CASE 
			WHEN DATEDIFF(DAY, Kunde.SidsteDato, SYSDATETIME()) < 200 THEN CAST(Kunde.KundeID AS VARCHAR(10)) + ' - ' + Kundenavn
			ELSE 'Gamle kunder'
	   END AS KundeData, 
	   Beloeb
	FROM dbo.Kunde INNER JOIN dbo.Ordre ON Kunde.KundeID = Ordre.KundeID
)
SELECT KundeData, AVG(Beloeb) AS Gennemsnit
	FROM Grpdata
	GROUP BY KundeData
	ORDER BY KundeData;
