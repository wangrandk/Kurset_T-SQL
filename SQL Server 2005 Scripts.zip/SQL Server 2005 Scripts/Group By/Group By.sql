USE MASTER
DROP DATABASE GroupByDB
GO
CREATE DATABASE GroupByDB
GO
USE GroupByDB
CREATE TABLE GrpTable (
	GrpId		INT NULL,
	Antal		INT NULL)
GO
INSERT INTO GrpTable VALUES 
	(1, 1),
	(1, 2),
	(1, 2),

	(4, 3),
	(4, 4),
	(4, 3),
	(4, 4),

	(NULL, 2),
	(NULL, 3),

	(5, NULL),
	(5, NULL),

	(6, NULL),
	(6, 4)
GO
SELECT *
	FROM GrpTable
GO
SELECT GrpId, SUM(Antal) AS SumAntal
	FROM GrpTable
	GROUP BY GrpId
GO
SELECT *
	FROM GrpTable

SELECT GrpId, SUM(Antal) AS SumAntal
	FROM GrpTable
	WHERE Antal > 2
	GROUP BY GrpId
GO
SELECT *
	FROM GrpTable

SELECT GrpId, AVG(Antal) AS AvgAntal, SUM(Antal)/COUNT(*) AS S_Stj, SUM(Antal)/COUNT(Antal) AS S_A
	FROM GrpTable
	GROUP BY GrpId
GO
SELECT GrpId, AVG(Antal * 1.0) AS AvgAntal, SUM(Antal * 1.0)/COUNT(*) AS S_Stj, SUM(ANTAL * 1.0)/COUNT(Antal * 1.0) AS S_A
	FROM GrpTable
	GROUP BY GrpId
GO
SELECT GrpId, SUM(Antal) AS SumAntal
	FROM GrpTable
	WHERE Antal > 2
	GROUP BY ALL GrpId
GO
SELECT GrpId, SUM(Antal) AS SumAntal, COUNT(*) 
	FROM GrpTable
	GROUP BY GrpId
	HAVING COUNT(*) > 2
GO
SELECT *
	FROM (SELECT GrpId, SUM(Antal) AS SumAntal
			FROM GrpTable
			GROUP BY GrpId) AS GrpTable
	WHERE SumAntal > 4
GO
SELECT GrpId, SUM(Antal) AS SumAntal, COUNT(*)  AS C_Stjerne, COUNT(Antal) AS C_Antal
	FROM GrpTable
	GROUP BY GrpId
GO
SELECT	*,
		SUM(Antal) OVER ( PARTITION BY GrpID) AS Sum,
		COUNT(Antal) OVER ( PARTITION BY GrpID) AS Count
	FROM GrpTable
GO
SELECT GrpID, SUM(Antal) --Fejl
	FROM GrpTable
GO
CREATE TABLE GrpTable2 (
	GrpId1		INT NULL,
	GrpId2		INT NULL,
	Antal		INT NULL)
GO
INSERT INTO GrpTable2 VALUES 
	(1, 10, 1),
	(1, 10, 2),
	(1, 10, 2),
	(1, 20, 2),
	(1, 20, 2),
	(1, 20, 2),

	(2, 10, 1),
	(2, 10, 2),
	(2, 10, 2),
	(2, 20, 2),
	(2, 20, 2),
	(2, 30, 2),

	(NULL, 20, 202),
	(2, NULL, 911),
	(NULL, NULL, 1234)
GO
SELECT GrpID1, GrpID2, SUM(Antal) AS SumAntal
	FROM GrpTable2
	GROUP BY GrpId1, GrpId2
GO
SELECT GrpID1, GrpID2, SUM(Antal) AS SumAntal
	FROM GrpTable2
	GROUP BY ROLLUP (GrpId1, GrpId2)

SELECT GrpID1, GrpID2, SUM(Antal) AS SumAntal
	FROM (SELECT ISNULL(GrpID1, 99) AS GrpID1, ISNULL(GrpID2, 99) AS GrpID2, Antal
			FROM GrpTable2) AS GrpTable2
	GROUP BY ROLLUP (GrpId1, GrpId2)
GO
SELECT GrpID1, GrpID2, SUM(Antal) AS SumAntal
	FROM GrpTable2
	GROUP BY CUBE (GrpId1, GrpId2)

SELECT GrpID1, GrpID2, SUM(Antal) AS SumAntal
	FROM (SELECT ISNULL(GrpID1, 99) AS GrpID1, ISNULL(GrpID2, 99) AS GrpID2, Antal
			FROM GrpTable2) AS GrpTable2
	GROUP BY CUBE (GrpId1, GrpId2)
GO
SELECT GrpID1, GrpID2,Antal
	FROM GrpTable2
	COMPUTE SUM(Antal), COUNT(Antal)
GO
SELECT GrpID1, GrpID2,Antal
	FROM GrpTable2
	ORDER BY GrpId1
	COMPUTE SUM(Antal), COUNT(Antal) BY GrpID1
GO
