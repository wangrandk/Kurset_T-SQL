DECLARE @t TABLE(Deptno INT, Empname VARCHAR(20))
INSERT INTO @t VALUES
	(10, 'Niladri'),
	(20, 'Jeeva'),
	(30, 'Deepak'),
	(30, 'Priyanka'),
	(20, 'Arina'),
	(30, 'Mare4'),
	(30, 'Mare1'),
	(30, 'Mare2'),
	(30, 'Mare6'),
	(30, 'Mare3')

SET STATISTICS TIME ON;
WITH t_recursive 
AS
(
SELECT Deptno, Empname, CAST(Empname AS VARCHAR(MAX)) AS EmpnameListe
	FROM @t AS t_outer
	WHERE	Empname = (SELECT MIN(Empname) FROM @t AS t_inner WHERE t_inner.Deptno = t_outer.Deptno)
UNION ALL
SELECT t_recursive.Deptno, t.Empname, t_recursive.EmpnameListe + ', ' + t.Empname
	FROM t_recursive INNER JOIN @t AS t ON	t_recursive.Deptno = t.Deptno AND 
									t.Empname >= ANY (SELECT Empname 
														FROM @t AS t_inner 
														WHERE t_inner.Empname > t_recursive.Empname) 
)
SELECT t1.Deptno, t1.EmpnameListe, *
	FROM t_recursive AS t1
	WHERE LEN(EmpnameListe) = (SELECT MAX(LEN(EmpnameListe)) FROM t_recursive AS t2 WHERE t1.Deptno = t2.Deptno)
;

WITH 
t_number 
AS
(
SELECT Deptno, Empname, ROW_NUMBER() OVER (PARTITION BY Deptno ORDER BY Empname) AS GrpRowNumber
	FROM @t
),
t_recursive
AS
(
SELECT Deptno, CAST(Empname AS VARCHAR(MAX)) AS Empname, GrpRowNumber
	FROM t_number
	WHERE GrpRowNumber = 1
UNION ALL
SELECT t_recursive.Deptno, t_recursive.Empname + ', ' + t_number.Empname, t_number.GrpRowNumber
	FROM t_recursive INNER JOIN t_number ON t_recursive.Deptno = t_number.Deptno AND t_recursive.GrpRowNumber + 1 = t_number.GrpRowNumber
)
SELECT Deptno, Empname
	FROM t_recursive
	WHERE GrpRowNumber = (SELECT MAX(GrpRowNumber) FROM t_recursive AS t_inner WHERE t_inner.Deptno = t_recursive.Deptno)
	ORDER BY Deptno;
	
SET STATISTICS TIME ON;
