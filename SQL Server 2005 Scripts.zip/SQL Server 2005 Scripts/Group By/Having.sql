USE master
DROP DATABASE AggDB
GO
CREATE DATABASE AggDB
GO
USE AggDB
CREATE TABLE dbo.Medarbejder 
(
	ID			INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR (20) NOT NULL,
	Afdeling	VARCHAR(5) NULL,
	Loen		INT NOT NULL
);
GO
INSERT INTO Medarbejder VALUES 
	(1, 'Hanne', 'Dir', 80000), 
	(2, 'Per', '�ko', 50000),
	(3, 'Ole', 'Prod', 45000),
	(4, 'Ane', 'Udv', 60000),
	(5, 'Ib', '�ko', 30000),
	(6, '�se', '�ko', 30000),
	(7, 'Tom', 'Udv', 40000),
	(8, 'Maren', 'Udv', 25000), 
	(9, 'Fie', 'Prod', 22000),
	(10, 'Carl', 'Prod', 24000),
	(11, 'Knud', 'Prod', 22000),
	(12, 'Lars', 'Prod', 26000),
	(13, 'Anne', NULL, 0),
	(14, 'Sanne', NULL, 0);
GO
SELECT Afdeling, SUM(Loen), AVG(Loen)
	FROM Medarbejder
	GROUP BY Afdeling;
GO
SELECT Afdeling, SUM(Loen), AVG(Loen)
	FROM Medarbejder
	WHERE Afdeling <> 'Dir'
	GROUP BY Afdeling;

SELECT Afdeling, SUM(Loen), AVG(Loen)
	FROM Medarbejder
	GROUP BY Afdeling
	HAVING Afdeling <> 'Dir';

SELECT Afdeling, SUM(Loen), AVG(Loen)
	FROM Medarbejder
	WHERE Afdeling IS NOT NULL
	GROUP BY Afdeling
	HAVING COUNT(*) > 1 AND AVG(Loen) < 50000;
GO
CREATE TABLE dbo.GruppeAntal 
(
	Afdeling		VARCHAR(5) NOT NULL PRIMARY KEY,
	Antal			INT NOT NULL
);
GO	
INSERT INTO GruppeAntal VALUES 
	('Dir', 2),
	('Prod', 4),
	('Udv', 2),
	('�ko', 3);
GO
SELECT	Afdeling, 
		COUNT(*) AS Antal
	FROM dbo.Medarbejder
	GROUP BY Afdeling
	HAVING COUNT(*) >= (SELECT Antal 
							FROM dbo.GruppeAntal
							WHERE Medarbejder.Afdeling = GruppeAntal.Afdeling)
GO