USE TestDB
GO
DROP TABLE dbo.Person;
GO
CREATE TABLE dbo.Person
(
	ID			INT NOT NULL IDENTITY,
	Age			SMALLINT
);
GO
INSERT INTO dbo.Person VALUES
	(2), (10), (11), (12), (13), (14), (15), (18), (19), (20), 
	(23), (31), (47), (55), (56), (58), (64), (69), (70), (71);
GO
SELECT	*, 
		(Age / 10) + 1 AS Grp,
		(Age / 10) * 10 AS AgeRangeStart,
		((Age /10) + 1) * 10 - 1 AS AgeRangeSlut
	FROM dbo.Person;
GO
INSERT INTO dbo.Person VALUES
	(102), (110), (111);
GO
SELECT AgeRange, COUNT(*)
	FROM
		(SELECT	*, 
				(Age / 10) + 1 AS Grp,
				'[' + CAST((Age / 10) * 10 AS VARCHAR(3)) + ' - ' +
				CAST(((Age /10) + 1) * 10 - 1 AS VARCHAR(3)) + ']'  AS AgeRange
			FROM dbo.Person) AS PersonGrp
	GROUP BY AgeRange, Grp
	ORDER BY Grp;