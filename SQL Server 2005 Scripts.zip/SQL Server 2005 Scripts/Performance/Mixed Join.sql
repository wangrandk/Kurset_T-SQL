USE BIDB
GO
SET STATISTICS TIME ON

SELECT *
	FROM (DataWarehouse.Kunde	INNER JOIN DataWarehouse.Postopl ON Kunde.Postnr = Postopl.Postnr
								INNER JOIN DataWarehouse.Kundetypekode ON Kunde.Kundetype = Kundetypekode.Kundetype
								LEFT JOIN DataWarehouse.Koen ON Kunde.Koen = Koen.Koen)
		 FULL JOIN
		 (DataWarehouse.Ordre	INNER JOIN DataWarehouse.Vare ON Ordre.VareSkey = Vare.VareSkey)
		 ON Kunde.KundeSkey = Ordre.KundeSkey

SELECT *
	FROM DataWarehouse.Kunde	INNER JOIN DataWarehouse.Postopl ON Kunde.Postnr = Postopl.Postnr
								INNER JOIN DataWarehouse.Kundetypekode ON Kunde.Kundetype = Kundetypekode.Kundetype
								LEFT JOIN DataWarehouse.Koen ON Kunde.Koen = Koen.Koen
								FULL JOIN DataWarehouse.Ordre	ON Kunde.KundeSkey = Ordre.KundeSkey
								LEFT JOIN DataWarehouse.Vare ON Ordre.VareSkey = Vare.VareSkey
		 	 
SET STATISTICS TIME OFF


(1551864 row(s) affected)
 SQL Server Execution Times:   CPU time = 42447 ms,  elapsed time = 76395 ms.

(1551864 row(s) affected)
 SQL Server Execution Times:   CPU time = 45040 ms,  elapsed time = 75562 ms.
 