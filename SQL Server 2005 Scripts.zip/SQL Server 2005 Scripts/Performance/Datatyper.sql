USE IndexDB;
GO

SELECT	PersonID,
		Postnr,
		CAST(Postnr AS VARCHAR(10)) AS PostnrVARCHAR,
		CAST(Postnr AS CHAR(5)) AS PostnrCHAR,
		CAST(Postnr AS DECIMAL(9)) AS PostnrDEC,
		CAST(Postnr AS REAL) AS PostnrREAL,
		CAST(Postnr AS INT) AS PostnrINT
	INTO PostnrDataType
	FROM dbo.Person
GO
SET STATISTICS TIME ON

SELECT	PostnrDataType.PersonID,
		PostnrDataType.Postnr,
		Postopl.Bynavn
	FROM dbo.PostnrDataType INNER JOIN dbo.Postopl ON PostnrDataType.Postnr = Postopl.Postnr

SET STATISTICS TIME OFF
GO
SET STATISTICS TIME ON

SELECT	PostnrDataType.PersonID,
		PostnrDataType.Postnr,
		Postopl.Bynavn
	FROM dbo.PostnrDataType INNER JOIN dbo.Postopl ON PostnrDataType.PostnrVARCHAR = Postopl.Postnr

SET STATISTICS TIME OFF
GO
SET STATISTICS TIME ON

SELECT	PostnrDataType.PersonID,
		PostnrDataType.Postnr,
		Postopl.Bynavn
	FROM dbo.PostnrDataType INNER JOIN dbo.Postopl ON PostnrDataType.PostnrCHAR = Postopl.Postnr

SET STATISTICS TIME OFF
GO
SET STATISTICS TIME ON

SELECT	PostnrDataType.PersonID,
		PostnrDataType.Postnr,
		Postopl.Bynavn
	FROM dbo.PostnrDataType INNER JOIN dbo.Postopl ON PostnrDataType.PostnrDEC = Postopl.Postnr

SET STATISTICS TIME OFF
GO
SET STATISTICS TIME ON

SELECT	PostnrDataType.PersonID,
		PostnrDataType.Postnr,
		Postopl.Bynavn
	FROM dbo.PostnrDataType INNER JOIN dbo.Postopl ON PostnrDataType.PostnrREAL = Postopl.Postnr

SET STATISTICS TIME OFF
GO
SET STATISTICS TIME ON

SELECT	PostnrDataType.PersonID,
		PostnrDataType.Postnr,
		Postopl.Bynavn
	FROM dbo.PostnrDataType INNER JOIN dbo.Postopl ON PostnrDataType.PostnrINT = Postopl.Postnr

SET STATISTICS TIME OFF
GO
-- SMALLINT - SMALLINT
(4411617 row(s) affected)

 SQL Server Execution Times:
   CPU time = 14790 ms,  elapsed time = 95467 ms.

-- VARCHAR - SMALLINT
(4411617 row(s) affected)

 SQL Server Execution Times:
   CPU time = 18191 ms,  elapsed time = 95993 ms.


-- CHAR - SMALLINT
(4411617 row(s) affected)

 SQL Server Execution Times:
   CPU time = 17719 ms,  elapsed time = 92281 ms.

-- DEC - SMALLINT
(4411617 row(s) affected)

 SQL Server Execution Times:
   CPU time = 19734 ms,  elapsed time = 96464 ms.

-- REAL - SMALLINT
(4411617 row(s) affected)

 SQL Server Execution Times:
   CPU time = 16819 ms,  elapsed time = 94614 ms.

-- INT - SMALLINT
(4411617 row(s) affected)

 SQL Server Execution Times:
   CPU time = 16754 ms,  elapsed time = 93998 ms.

GO
SET STATISTICS TIME ON

SELECT	PostnrDataType.PersonID,
		PostnrDataType.Postnr,
		Postopl.Bynavn
	FROM dbo.PostnrDataType INNER JOIN dbo.Postopl ON PostnrDataType.PostnrVARCHAR = CAST(Postopl.Postnr AS VARCHAR(10))

SET STATISTICS TIME OFF
GO
SET STATISTICS TIME ON

SELECT	PostnrDataType.PersonID,
		PostnrDataType.Postnr,
		Postopl.Bynavn
	FROM dbo.PostnrDataType INNER JOIN dbo.Postopl ON PostnrDataType.PostnrCHAR = CAST(Postopl.Postnr AS CHAR(5))

SET STATISTICS TIME OFF
GO
SET STATISTICS TIME ON

SELECT	PostnrDataType.PersonID,
		PostnrDataType.Postnr,
		Postopl.Bynavn
	FROM dbo.PostnrDataType INNER JOIN dbo.Postopl ON PostnrDataType.PostnrDEC = CAST(Postopl.Postnr AS DECIMAL(9))

SET STATISTICS TIME OFF
GO
GO
SET STATISTICS TIME ON

SELECT	PostnrDataType.PersonID,
		PostnrDataType.Postnr,
		Postopl.Bynavn
	FROM dbo.PostnrDataType INNER JOIN dbo.Postopl ON PostnrDataType.PostnrREAL = CAST(Postopl.Postnr AS REAL)

SET STATISTICS TIME OFF
GO
SET STATISTICS TIME ON

SELECT	PostnrDataType.PersonID,
		PostnrDataType.Postnr,
		Postopl.Bynavn
	FROM dbo.PostnrDataType INNER JOIN dbo.Postopl ON PostnrDataType.PostnrINT = Postopl.Postnr

SET STATISTICS TIME OFF
GO
-- VARCHAR
(4411617 row(s) affected)

 SQL Server Execution Times:
   CPU time = 16629 ms,  elapsed time = 96308 ms.

-- CHAR
(4411617 row(s) affected)

 SQL Server Execution Times:
   CPU time = 17675 ms,  elapsed time = 100652 ms.

-- DECIAML
(4411617 row(s) affected)

 SQL Server Execution Times:
   CPU time = 19094 ms,  elapsed time = 93974 ms.

-- FLOAT
(4411617 row(s) affected)

 SQL Server Execution Times:
   CPU time = 15726 ms,  elapsed time = 95121 ms.

-- INT
(4411617 row(s) affected)

 SQL Server Execution Times:
   CPU time = 14914 ms,  elapsed time = 93590 ms.
GO