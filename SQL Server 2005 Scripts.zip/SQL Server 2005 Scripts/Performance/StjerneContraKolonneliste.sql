USE Index2DB
GO
SET STATISTICS IO ON
SET STATISTICS TIME ON

DBCC DROPCLEANBUFFERS
SELECT *
	FROM Person

DBCC DROPCLEANBUFFERS
SELECT	PersonID, 
		Fornavn, 
		Efternavn, 
		Gade, 
		Postnr, 
		Koenkode, 
		Landekode, 
		Tlfnr, 
		Persontype
	FROM Person

DBCC DROPCLEANBUFFERS
SELECT	PersonID, 
		Fornavn, 
		Efternavn, 
		Gade, 
		Postnr 
	FROM Person
	
SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO



(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 125320, physical reads 3, read-ahead reads 125305, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 20030 ms,  elapsed time = 223012 ms.


(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 125320, physical reads 3, read-ahead reads 125305, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 5335 ms,  elapsed time = 135089 ms.


(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 125320, physical reads 3, read-ahead reads 125305, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 4508 ms,  elapsed time = 109062 ms.


