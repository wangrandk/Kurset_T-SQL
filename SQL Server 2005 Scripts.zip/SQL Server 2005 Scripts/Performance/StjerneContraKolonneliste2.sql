USE IndexDB;
GO
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

DBCC DROPCLEANBUFFERS;

SELECT *
	FROM dbo.Person;

DBCC DROPCLEANBUFFERS;

SELECT PersonID
      ,Fornavn
      ,Efternavn
      ,Gade
      ,Postnr
      ,Koenkode
      ,Landekode
      ,Tlfnr
      ,Persontype
      ,LandekodeTlfnr
      ,Navn
  FROM dbo.Person

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO

-- INDEXDB
-- kun de udtrukne kolonner

(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 31664, physical reads 1, read-ahead reads 31647, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 9033 ms,  elapsed time = 144738 ms.


(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 31664, physical reads 1, read-ahead reads 31647, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 9531 ms,  elapsed time = 141994 ms.


-- INDEX2DB
-- NULL


(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 125320, physical reads 3, read-ahead reads 125305, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 22964 ms,  elapsed time = 222715 ms.


(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 125320, physical reads 3, read-ahead reads 125305, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 12559 ms,  elapsed time = 143899 ms.


-- INDEX3DB
-- flere filer


(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 125320, physical reads 3, read-ahead reads 125312, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 21560 ms,  elapsed time = 224345 ms.


(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 125320, physical reads 3, read-ahead reads 125312, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 10030 ms,  elapsed time = 145522 ms.



-- INDEX4DB
-- default values

(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 125320, physical reads 3, read-ahead reads 125305, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 27379 ms,  elapsed time = 293524 ms.


(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 125320, physical reads 3, read-ahead reads 125305, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 9890 ms,  elapsed time = 138928 ms.


-- INDEX5DB
-- autogrow


(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 125320, physical reads 3, read-ahead reads 125301, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 22277 ms,  elapsed time = 224593 ms.


(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 125320, physical reads 3, read-ahead reads 125301, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 10108 ms,  elapsed time = 142395 ms.
GO
USE Index2DB;
GO
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

DBCC DROPCLEANBUFFERS;

SELECT PersonID
      ,Fornavn
      ,Efternavn
      ,Gade
      ,Postnr
      ,Koenkode
      ,Landekode
      ,Tlfnr
      ,Persontype
      ,LandekodeTlfnr
      ,Navn
  FROM dbo.Person
GO
CREATE NONCLUSTERED INDEX nc_Perspn_PersonID_1_2_3_4_5_6_7_8_9_10 
	ON Person (PersonID)
	INCLUDE (  Fornavn
			  ,Efternavn
			  ,Gade
			  ,Postnr
			  ,Koenkode
			  ,Landekode
			  ,Tlfnr
			  ,Persontype
			  ,LandekodeTlfnr
			  ,Navn)
GO
DBCC DROPCLEANBUFFERS;

SELECT PersonID
      ,Fornavn
      ,Efternavn
      ,Gade
      ,Postnr
      ,Koenkode
      ,Landekode
      ,Tlfnr
      ,Persontype
      ,LandekodeTlfnr
      ,Navn
  FROM dbo.Person

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
-- f�r index

(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 125320, physical reads 3, read-ahead reads 125305, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 10468 ms,  elapsed time = 136158 ms.

-- efter index

(4411617 row(s) affected)
Table 'Person'. Scan count 1, logical reads 45002, physical reads 1, read-ahead reads 45023, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 8392 ms,  elapsed time = 139735 ms.
