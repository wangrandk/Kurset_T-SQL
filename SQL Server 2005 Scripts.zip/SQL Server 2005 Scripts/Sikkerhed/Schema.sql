USE master
DROP DATABASE SecurityDB;
GO
CREATE DATABASE SecurityDB;
GO
USE SecurityDB;
GO
CREATE SCHEMA Privat AUTHORIZATION [dbo];
GO
CREATE SCHEMA Motor AUTHORIZATION [dbo];
GO
CREATE TABLE dbo.kunde 
(
	Kundeid		INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(30) NOT NULL
);
 
CREATE TABLE Privat.Forsikring 
(
	Forsid		INT NOT NULL PRIMARY KEY,
	Beskrivelse	VARCHAR(20) NOT NULL,
	Kundeid		INT FOREIGN KEY REFERENCES kunde(kundeid)
);

CREATE TABLE Motor.Forsikring 
(
	Forsid		int not null primary key,
	Beskrivelse	varchar(20) not null,
	Kundeid		int foreign key references kunde(kundeid)
);
GO
CREATE LOGIN Ida WITH PASSWORD = 'Id2Id!!!!!';
GO
CREATE LOGIN Hans WITH PASSWORD = 'Han2Has!!!!!';
GO
--drop user Ida
--drop user Hans
GO
CREATE USER Ida WITH DEFAULT_SCHEMA = Privat;
CREATE USER Hans WITH DEFAULT_SCHEMA = Motor;
GO
INSERT INTO dbo.Kunde VALUES
	(1, 'Jens Hansen'),
	(2, 'Ole Olsen'),
	(3, 'Ane S�rensen');

INSERT INTO Motor.Forsikring VALUES 
	(1, 'Min Volvo', 2),
	(1, 'Min Hjem', 3);
GO
GRANT SELECT ON SCHEMA :: Privat TO Ida;
GO
GRANT SELECT ON SCHEMA :: Motor TO Hans;
GO
CREATE TABLE Privat.Skader 
(
	SkadesId	INT NOT NULL PRIMARY KEY,
	Beskrivelse	VARCHAR(20) NOT NULL,
	Forsid		INT NOT NULL FOREIGN KEY REFERENCES Privat.Forsikring(Forsid)
)
GO
INSERT INTO Privat.Skader VALUES (1, 'Alt stj�let', 1);
GO
GRANT SELECT ON SCHEMA :: dbo TO Ida;
GO
GRANT SELECT ON SCHEMA :: dbo TO Hans;
GO
REVOKE SELECT ON SCHEMA :: Privat FROM Ida;
REVOKE SELECT ON SCHEMA :: dbo FROM Ida;
REVOKE SELECT ON SCHEMA :: Motor FROM Hans;
REVOKE SELECT ON SCHEMA :: dbo FROM Hans;
GO
CREATE ROLE PrivatAnsat;
GO
GRANT DELETE, SELECT, INSERT, UPDATE ON SCHEMA::Privat TO PrivatAnsat;
GRANT SELECT ON SCHEMA::dbo TO PrivatAnsat;
GO
ALTER ROLE PrivatAnsat  ADD MEMBER Ida;
GO
GRANT SELECT ON SCHEMA :: Motor TO PrivatAnsat;
GO
CREATE PROC Privat.usp_ForsSkader
AS
SELECT * 
	FROM Privat.Forsikring INNER JOIN Privat.Skader 
		ON Privat.Forsikring.Forsid = Privat.Skader.Forsid;
GO
EXEC Privat.usp_ForsSkader;
GO
REVOKE SELECT ON SCHEMA :: Privat FROM PrivatAnsat;
GO
GRANT EXECUTE ON Privat.usp_ForsSkader TO PrivatAnsat;
GO
CREATE VIEW Privat.vForsSkader
AS
SELECT * 
	FROM Privat.Forsikring  AS F INNER JOIN Privat.Skader AS S
		 ON Privat.Forsikring.Forsid = Privat.Skader.Forsid;
go
GRANT SELECT ON vForsSkader TO PrivatAnsat;
GO
CREATE PROC dbo.usp_ForsSkader
AS
SELECT * 
	FROM Forsikring INNER JOIN Skader 
		 ON Forsikring.Forsid = Skader.Forsid;
GO
GRANT EXECUTE ON dbo.usp_ForsSkader TO Ida;
GO
REVOKE EXECUTE ON dbo.usp_ForsSkader FROM Ida;
GO
CREATE USER xxx WITHOUT LOGIN;
GO
ALTER PROC dbo.usp_ForsSkader
WITH EXECUTE AS 'xxx'
AS
SELECT USER_NAME()
SELECT SUSER_SNAME()
SELECT * 
	FROM Motor.Forsikring;
GO
GRANT EXECUTE ON dbo.usp_ForsSkader TO xxx;
GRANT EXECUTE ON dbo.usp_ForsSkader TO Ida;
GRANT SELECT ON Privat.Forsikring TO xxx;
GRANT SELECT ON Privat.Skader TO xxx;

DENY SELECT ON Motor.Forsikring TO Ida;
DENY SELECT ON Motor.Forsikring TO xxx;

REVOKE EXECUTE ON dbo.usp_ForsSkader FROM Ida;
REVOKE EXECUTE ON dbo.usp_ForsSkader FROM xxx;
REVOKE SELECT on Privat.Forsikring FROM xxx;
REVOKE SELECT on Privat.Skader FROM xxx;
GO
DROP LOGIN Ida;
DROP LOGIN Hans;
