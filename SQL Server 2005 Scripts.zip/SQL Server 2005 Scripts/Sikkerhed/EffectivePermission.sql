USE IndexDB
GO
SELECT *
	FROM sys.fn_my_permissions('dbo.Person', 'Objects');

SELECT *
	FROM sys.fn_my_permissions('dbo', 'Schema');