USE master;
DROP DATABASE SecurityDB;
GO
CREATE DATABASE SecurityDB;
GO
USE SecurityDB;
CREATE TABLE dbo.Kunde 
(
	Kundeid		int not null primary key,
	Navn		varchar(30) not null
);

CREATE TABLE dbo.Ordre
(
	Ordreid		INT NOT NULL PRIMARY KEY IDENTITY,
	Kundeid		INT NOT NULL
				CONSTRAINT fk_Ordre_Kunde FOREIGN KEY REFERENCES Kunde (Kundeid)
);
GO
INSERT INTO Kunde (Kundeid, navn) VALUES
	(1, 'Ane'),
	(2, 'Hans');

INSERT INTO Ordre (Kundeid) VALUES 
	(1),
	(2),
	(1),
	(1),
	(2);
GO
CREATE LOGIN bruger1
	WITH PASSWORD = 'brr1!!!!!', 
	DEFAULT_DATABASE = SecurityDB, 
	CHECK_POLICY = OFF;
GO
CREATE USER bruger1
	WITH DEFAULT_SCHEMA = dbo;
GO
GRANT INSERT ON Ordre TO bruger1;
GO
SELECT USER_NAME();
GO
-- CHANGE CONNECTION
SELECT USER_NAME();
GO
INSERT INTO Ordre (Kundeid) VALUES 
	(2);
GO
DROP LOGIN bruger1;

