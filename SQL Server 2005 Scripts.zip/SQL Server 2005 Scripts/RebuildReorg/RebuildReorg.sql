USE master
DROP DATABASE RebuildReorgDB;
GO
CREATE DATABASE RebuildReorgDB;
GO
USE RebuildReorgDB
CREATE TABLE dbo.t 
(
	id		INT NOT NULL,
	txt		CHAR(798) NOT NULL
);
GO
SET NOCOUNT ON
DECLARE @i		INT;
DECLARE @txt	CHAR(798);

SET @i = 1;
SET @txt = REPLICATE('x', 798);
WHILE @i <= 400
BEGIN
	INSERT INTO dbo.t VALUES (@i, @txt);

	SET @i += 1
END
SET NOCOUNT OFF;
GO
CREATE CLUSTERED INDEX cl_id ON dbo.t(id) WITH FILLFACTOR = 50;
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('t'), NULL, NULL, 'detailed');
go
SELECT id 
	FROM dbo.t 
	WHERE id % 10 = 1;

DELETE 
	FROM dbo.t 
	WHERE id % 10 = 1;

SELECT id 
	FROM dbo.t 
	WHERE id % 10 = 2;

DELETE 
	FROM dbo.t 
	WHERE id % 10 = 2;

SELECT id 
	FROM dbo.t 
	WHERE id % 10 = 3;

DELETE 
	FROM dbo.t 
	WHERE id % 10 = 3;

SELECT COUNT(*) 
	FROM dbo.t
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(db_id(), object_id('t'), NULL, NULL, 'detailed')
GO
ALTER INDEX cl_id ON dbo.t REORGANIZE
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(db_id(), object_id('t'), NULL, NULL, 'detailed')
go
SELECT id 
	FROM dbo.t 
	WHERE id % 10 = 6;

DELETE 
	FROM dbo.t 
	WHERE id % 10 = 6;

SELECT id 
	FROM dbo.t 
	WHERE id % 10 = 7;

DELETE 
	FROM dbo.t 
	WHERE id % 10 = 7;

SELECT id 
	FROM dbo.t 
	WHERE id % 10 = 8;
DELETE FROM dbo.t WHERE id % 10 = 8;

SELECT COUNT(*) 
	FROM dbo.t;
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(db_id(), object_id('t'), NULL, NULL, 'detailed');
GO
ALTER INDEX cl_id ON t REORGANIZE;
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(db_id(), object_id('t'), NULL, NULL, 'detailed');
GO
-----------------------------------------------------------------------------
TRUNCATE TABLE dbo.t;
GO
SET NOCOUNT ON;
DECLARE @i		int;
DECLARE @txt	char(798);

SET @i = 2;
SET @txt = REPLICATE('x', 798);
WHILE @i <= 800
BEGIN
	INSERT INTO dbo.t VALUES (@i, @txt);
	SET @i += 2;
END;
SET NOCOUNT OFF;
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(db_id(), object_id('t'), NULL, NULL, 'detailed');
GO
ALTER INDEX cl_id ON t REBUILD;
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(db_id(), object_id('t'), NULL, NULL, 'detailed');
GO
SET NOCOUNT ON;
DECLARE @i		INT;
DECLARE @txt	CHAR(798);

SET @i = 3;
SET @txt = replicate('x', 798);
WHILE @i <= 800
BEGIN
	INSERT INTO dbo.t values (@i, @txt);
	SET @i = @i + 20;
END;
SET NOCOUNT OFF;
GO
SELECT COUNT(*) 
	FROM dbo.t;
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(db_id(), object_id('t'), NULL, NULL, 'detailed');
GO
ALTER INDEX cl_id ON t REORGANIZE;
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(db_id(), object_id('t'), NULL, NULL, 'detailed');
GO
SELECT id 
	FROM dbo.t 
	WHERE id % 20 = 14;

DELETE 
	FROM dbo.t 
	WHERE id % 20 = 14;

SELECT id 
	FROM dbo.t 
	WHERE id % 20 = 16;

DELETE 
	FROM dbo.t 
	WHERE id % 20 = 16;
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(db_id(), object_id('t'), NULL, NULL, 'detailed');
GO
ALTER INDEX cl_id ON t REORGANIZE;
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(db_id(), object_id('t'), NULL, NULL, 'detailed');
go
