USE IndexDB;
GO
SELECT	file_id,
		name, 
		size as SizeInPages,
		FILEPROPERTY(name, 'SpaceUsed') as SpaceUsedInPages,
		physical_name
	FROM sys.database_files;
GO
SELECT *
	FROM sys.database_files;
GO
