-- Demo:			Flytning af tempdb filer
--					...
-- Filnavn:			MoveTempDB.sql
-- Foruds�tninger:	1) <foruds�tning nr. 1>
--					...
-- Rev. den/af:		16.10.2014/TR
-- --------------------------------------------------------------
-- Etabl�r demo-milj�
-- ------------------
USE master;
-- Aktiv�r muligheden for at afvikle eksterne programmer
-- vha. af EXEC xp_cmdshell
EXEC sp_configure 'show advanced options', 1;
GO
RECONFIGURE;
GO
EXEC sp_configure 'xp_cmdshell', 1;
GO
RECONFIGURE;
GO
-- Opret hj�lpekatalog
EXEC xp_cmdshell 'mkdir C:\Temp_SQLDemo\';
GO

-- Check aktuel placering af tempdb filer
EXEC SP_helpDB TempDB;
GO
-- eller
SELECT name, physical_name AS CurrentLocation, state_desc
	FROM sys.master_files
	WHERE database_id = DB_ID('TempDB');
-- eller
-- 1) SSMS | h�jreklik tempdb | Properties | Files

-- Flyt tempdb filer
-- ------------------------------------------------------------------
-- Juster FileName-property for tempdb
ALTER DATABASE tempdb
	MODIFY FILE(NAME = tempdev, FILENAME ='C:\Temp_SQLDemo\tempdb.mdf');
GO
ALTER DATABASE tempdb
	MODIFY FILE(NAME = templog, FILENAME ='C:\Temp_SQLDemo\templog.ldf');
GO
-- Filer i nyt katalog?
EXEC xp_cmdshell 'dir C:\Temp_SQLDemo\*';
GO
-- Restart SQL Server Instance
SHUTDOWN;
-- Start SQL Server Instance i SSMS
-- 1) h�jeklik node for instance | Start
-- Check om tempdb filer er flyttet
-- 1) Reconnect Query Window
EXEC xp_cmdshell 'dir C:\Temp_SQLDemo\*';
GO

-- Oprydning
-- ---------
-- Evt. flytning til default placering
-- SQL Server 2012
ALTER DATABASE tempdb
	MODIFY FILE(NAME = tempdev, FILENAME ='C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\tempdev.mdf');
GO
ALTER DATABASE tempdb
	MODIFY FILE(NAME = templog, FILENAME ='C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\templog.ldf');
GO
-- SQL Server 2014
ALTER DATABASE tempdb
	MODIFY FILE(NAME = tempdev, FILENAME ='C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\tempdev.mdf');
GO
ALTER DATABASE tempdb
	MODIFY FILE(NAME = templog, FILENAME ='C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\templog.ldf');
GO
SHUTDOWN;
GO
-- Start SQL Server Instance i SSMS
-- 1) h�jeklik node for instance | Start
-- Check flytning
SELECT name, physical_name AS CurrentLocation, state_desc
	FROM sys.master_files
	WHERE database_id = DB_ID('TempDB');
GO
-- Sletning fra demo-katalog
EXEC xp_cmdshell 'del C:\Temp_SQLDemo\temp*.*';