use IndexDb
go
select *
from sys.fn_listextendedproperty(NULL, NULL, NULL, NULL, NULL, NULL, NULL);
go
select *
from sys.fn_listextendedproperty(NULL, 'schema', 'dbo', 'table', 'postopl', NULL, NULL);
go
select *
from dbo.sysdiagrams
go
select * from sys.extended_properties
go
