USE master
GO
DROP  DATABASE TestDB
GO
CREATE DATABASE TestDB
GO
USE TestDB
CREATE TABLE dbo.t 
(
	ID		INT NOT NULL IDENTITY,
	Postnr	INT NULL
);
GO
INSERT INTO dbo.t VALUES 
	(2000), (3000), (4000), (5000)
GO
SELECT *
	FROM dbo.t
	WHERE Postnr IN (2000, 3000)
GO
SELECT *
	FROM dbo.t
	WHERE Postnr NOT IN (2000, 3000)
GO
INSERT INTO dbo.t VALUES 
	(NULL)
GO
SELECT *
	FROM dbo.t
	WHERE Postnr IN (2000, 3000)
GO
SELECT *
	FROM dbo.t
	WHERE Postnr NOT IN (2000, 3000)
GO
SELECT *
	FROM dbo.t
	WHERE Postnr IN (SELECT Postnr 
						FROM dbo.t 
						WHERE ID > 2)
GO
SELECT *
	FROM dbo.t
	WHERE Postnr NOT IN (SELECT Postnr 
							FROM dbo.t 
							WHERE ID > 2)
	
SELECT *
	FROM dbo.t
	WHERE NOT Postnr IN (SELECT Postnr 
							FROM dbo.t 
							WHERE ID > 2)
	
SELECT *
	FROM dbo.t
	WHERE Postnr NOT IN (SELECT Postnr 
							FROM dbo.t 
							WHERE ID > 2 AND Postnr IS NOT NULL)
GO
SELECT *
	FROM dbo.t AS ty
	WHERE EXISTS (SELECT Postnr 
					FROM dbo.t AS ti 
					WHERE ti.ID > 2 AND ty.Postnr = ti.Postnr)
	
SELECT *
	FROM dbo.t AS ty
	WHERE NOT EXISTS (SELECT Postnr 
						FROM dbo.t AS ti 
						WHERE ti.ID > 2 AND ty.Postnr = ti.Postnr)
