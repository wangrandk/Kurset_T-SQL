USE master;
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
CREATE TABLE dbo.Medarbejder	
(
	MId			INT			NOT NULL PRIMARY KEY IDENTITY,
	Loen		INT			NOT NULL,
	Afdid		CHAR(1)		NOT NULL
);
GO
INSERT INTO dbo.Medarbejder VALUES 
	(10, 'a'),
	(20, 'a'),
	(20, 'b'),
	(40, 'b'),
	(15, 'b');
GO
INSERT INTO dbo.Medarbejder
	SELECT Loen, Afdid
		FROM dbo.Medarbejder;
GO
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;

SELECT	*,
		(SELECT AVG(Loen) AS AfdAvg 
				FROM dbo.Medarbejder AS mafd 
				WHERE m1.Afdid = mafd.Afdid) AS AfdAvg,
		(SELECT AVG(Loen) AS fAvg 
			FROM dbo.Medarbejder) AS fAvg
	FROM dbo.Medarbejder AS m1;
GO
DBCC DROPCLEANBUFFERS;
SELECT	*,
		(SELECT AVG(Loen) AS fAvg 
			FROM dbo.Medarbejder) AS fAvg
	FROM dbo.Medarbejder INNER JOIN (SELECT Afdid, AVG(Loen) AS AfdAvg 
										FROM dbo.Medarbejder 
										GROUP BY Afdid) AS AfdAvg
        ON Medarbejder.Afdid = AfdAvg.Afdid
GO
DBCC DROPCLEANBUFFERS;
SELECT *
	FROM dbo.Medarbejder INNER JOIN (SELECT Afdid, AVG(Loen) AS AfdAvg 
											FROM dbo.Medarbejder 
											GROUP BY Afdid) AS AfdAvg
        ON Medarbejder.Afdid = AfdAvg.Afdid
						CROSS JOIN (SELECT AVG(Loen) AS fAvg 
										FROM dbo.Medarbejder) AS fAvg;

SET STATISTICS TIME OFF;
GO
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;

SELECT	*,
		(SELECT AVG(Loen) AS fAvg 
				FROM dbo.Medarbejder) AS fAvg
	FROM dbo.Medarbejder AS m1;

DBCC DROPCLEANBUFFERS;

SELECT *
	FROM dbo.Medarbejder CROSS JOIN (SELECT AVG(Loen) AS fAvg 
										FROM dbo.Medarbejder) AS fAvg;

SET STATISTICS TIME OFF;
