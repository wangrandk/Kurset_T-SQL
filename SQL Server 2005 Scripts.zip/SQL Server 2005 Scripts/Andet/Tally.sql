USE master;
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE Testdb;
GO
SELECT 20 AS Antaldage
	INTO dbo.DageInterval;

DROP TABLE IF EXISTS dbo.DimDate
GO
CREATE TABLE dbo.DimDate
(
	DimDateID	INT�� NOT NULL PRIMARY KEY,
	DateValue	DATE��NOT NULL UNIQUE,
)
GO
SET STATISTICS TIME ON;

DECLARE @StartDate DATE = '2016-11-27';
DECLARE�@EndDate�� DATE = DATEADD(DAY, (SELECT Antaldage 
											FROM dbo.DageInterval), @StartDate);
�
WITH��N10(n)���� 
AS 
(
SELECT 1 
	FROM (VALUES�(0),(1),(2),(3),(4),(5),(6),(7),(8),(9)) v(n)
),
N100(n)
AS 
(
SELECT 1 
	FROM N10, N10 n
),
N10000(n)�
AS 
(
SELECT 1 
	FROM N100, N100 n
), 
N100000(n) 
AS 
(
SELECT 1 
	FROM N10, N10000 n
),
N
AS 
(
SELECT	TOP (DATEDIFF(DAY, @startdate,��@enddate) + 1) 
		ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) - 1 AS n
	FROM N100000
)
INSERT INTO dbo.DimDate(DimDateID, DateValue)
	SELECT	CAST(CONVERT(CHAR(8),InsertDate, 112) AS INT),
			InsertDate
		FROM N CROSS APPLY (SELECT DATEADD(DAY, n, @Startdate)) d(InsertDate);
GO
SET STATISTICS TIME OFF;
GO
DROP TABLE IF EXISTS dbo.DimDate;
GO
CREATE TABLE dbo.DimDate
(
	DimDateID	INT�� NOT NULL PRIMARY KEY,
	DateValue	DATE��NOT NULL UNIQUE
);
GO
SET STATISTICS TIME ON;

DECLARE @StartDate DATE = '2016-11-27';
DECLARE�@EndDate�� DATE = DATEADD(DAY, (SELECT Antaldage 
											FROM dbo.DageInterval), @StartDate);
�
DECLARE	@Id			INT = 1;
�
WITH Datoer
AS
(
SELECT	@Id ID, 
		@StartDate AS Dato
UNION ALL
SELECT	ID + 1,
		DATEADD(DAY, 1, Dato)
	FROM Datoer
	WHERE Dato <= @EndDate
)
INSERT INTO dbo.DimDate(DimDateID, DateValue)
	SELECT *
		FROM Datoer	
	OPTION (MAXRECURSION 0);	
GO
SET STATISTICS TIME OFF;
