 USE IndexDB
 GO
 CREATE INDEX nc_person_Fornavn ON dbo.Person(Fornavn) 
	INCLUDE (Efternavn, Gade, Postnr);
 GO
 SELECT		Fornavn,
			Efternavn,
			Gade,
			Postnr
	FROM dbo.Person
	WHERE Fornavn IN
	('Anne Mette','Anne Marie', 'Allan','Annette', 'Andreas', 
	 'August','Arne', 'Andreas', 'Asger', 'Allan',
	 'Anneline', 'Albert', 'Augusta', 'Andrea', 'Bo');
GO
SELECT		Fornavn,
			Efternavn,
			Gade,
			Postnr
	FROM dbo.Person
	WHERE Fornavn IN
	('Anne Mette','Anne Marie', 'Allan','Annette', 'Andreas', 
	 'August','Arne', 'Andreas', 'Asger', 'Allan',
	 'Anneline', 'Albert', 'Augusta', 'Andrea', 'Bo',
	 'Birte');
GO
SET STATISTICS TIME ON;

SELECT		Fornavn,
			Efternavn,
			Gade,
			Postnr
	FROM dbo.Person
	WHERE Fornavn IN
	('Anne Mette','Anne Marie', 'Allan','Annette', 'Aage', 
	 'August','Arne', 'Andreas', 'Asger', 'Allan',
	 'Anneline', 'Albert', 'Augusta', 'Andrea', 'Bo',
	 'Birte', 'Birthe', 'Bente', 'Bettina', 'Bjarke', 
	 'Bent', 'B�rge', 'Bjarne',	'Brian', 'Bruno',
	 'Benno', 'Carl', 'Carina', 'Carla', 'Claus', 
	 'Claes', 'Curt', 'Christa', 'Christian', 'Charlotte',
	 'Christina', 'Dorte', 'Dorthe', 'David', 'Daniel', 
	 'Doris', 'Dan', 'Dagmar', 'Dagny', 'Dennis', 
	 'Ditte', 'Diana', 'Erik', 'Eva', 'Emma', 
	 'Ebba', 'Ebbe', 'Ellen', 'Edvard', 'Edward', 
	 'Egon', 'Esben', 'Elisabeth', 'Egil', 'Esther', 
	 'Frank', 'Frederikke', 'Flemming', 'Frede', 
	 'Frode', 'Frida', 'Finn', 'Findus', 'Franz');
GO
SELECT		Person.Fornavn,
			Person.Efternavn,
			Person.Gade,
			Person.Postnr
	FROM dbo.Person INNER JOIN 
	(VALUES
	 ('Anne Mette'), ('Anne Marie'), ('Allan'), ('Annette'), ('Aage'), 
	 ('August'), ('Arne'), ('Andreas'), ('Asger'), ('Allan'), 
	 ('Anneline'), ('Albert'), ('Augusta'), ('Andrea'), ('Bo'), 
	 ('Birte'), ('Birthe'), ('Bente'), ('Bettina'), ('Bjarke'), 
	 ('Bent'), ('B�rge'), ('Bjarne'), (	'Brian'), ('Bruno'), 
	 ('Benno'), ('Carl'), ('Carina'), ('Carla'), ('Claus'), 
	 ('Claes'), ('Curt'), ('Christa'), ('Christian'), ('Charlotte'), 
	 ('Christina'), ('Dorte'), ('Dorthe'), ('David'), ('Daniel'), 
	 ('Doris'), ('Dan'), ('Dagmar'), ('Dagny'), ('Dennis'), 
	 ('Ditte'), ('Diana'), ('Erik'), ('Eva'), ('Emma'), 
	 ('Ebba'), ('Ebbe'), ('Ellen'), ('Edvard'), ('Edward'), 
	 ('Egon'), ('Esben'), ('Elisabeth'), ('Egil'), ('Esther'), 
	 ('Frank'), ('Frederikke'), ('Flemming'), ('Frede'), 
	 ('Frode'), ('Frida'), ('Finn'), ('Findus'), ('Franz')) AS F(Fornavn)
	ON Person.Fornavn = F.Fornavn;
GO
DECLARE @F TABLE
(
	Fornavn			VARCHAR(20)
)

INSERT INTO @F VALUES
	('Anne Mette'), ('Anne Marie'), ('Allan'), ('Annette'), ('Aage'), 
	 ('August'), ('Arne'), ('Andreas'), ('Asger'), ('Allan'), 
	 ('Anneline'), ('Albert'), ('Augusta'), ('Andrea'), ('Bo'), 
	 ('Birte'), ('Birthe'), ('Bente'), ('Bettina'), ('Bjarke'), 
	 ('Bent'), ('B�rge'), ('Bjarne'), (	'Brian'), ('Bruno'), 
	 ('Benno'), ('Carl'), ('Carina'), ('Carla'), ('Claus'), 
	 ('Claes'), ('Curt'), ('Christa'), ('Christian'), ('Charlotte'), 
	 ('Christina'), ('Dorte'), ('Dorthe'), ('David'), ('Daniel'), 
	 ('Doris'), ('Dan'), ('Dagmar'), ('Dagny'), ('Dennis'), 
	 ('Ditte'), ('Diana'), ('Erik'), ('Eva'), ('Emma'), 
	 ('Ebba'), ('Ebbe'), ('Ellen'), ('Edvard'), ('Edward'), 
	 ('Egon'), ('Esben'), ('Elisabeth'), ('Egil'), ('Esther'), 
	 ('Frank'), ('Frederikke'), ('Flemming'), ('Frede'), 
	 ('Frode'), ('Frida'), ('Finn'), ('Findus'), ('Franz');

SELECT		Person.Fornavn,
			Person.Efternavn,
			Person.Gade,
			Person.Postnr
	FROM dbo.Person INNER JOIN @F AS F
	ON Person.Fornavn = F.Fornavn;
GO
-- Eksekveringsplaner
SELECT		Fornavn,
			Efternavn,
			Gade,
			Postnr
	FROM dbo.Person
	WHERE Fornavn IN
	('Steen', 'Anne Mette', 'Allan', 'Ole', 'Aage', 'August', 'Peter', 
	'Allan', 'Hans', 'Albert', 'Maren', 'Bo', 'Lars', 'Asger', 
	'Birthe', 'Augusta', 'Bettina', 'Bjarke', 'Anne Marie', 'Arne');

SELECT		Fornavn,
			Efternavn,
			Gade,
			Postnr
	FROM dbo.Person
	WHERE Fornavn IN
	('Steen', 'Steen', 'Steen', 'Ole', 'Ole', 'Ole', 'Ole', 
	'Ane', 'Ane', 'Steen', 'Bo', 'Bo', 'Bo', 
	'Bo', 'Bo', 'Bo', 'Bo', 'Steen', 'Ole');
GO

