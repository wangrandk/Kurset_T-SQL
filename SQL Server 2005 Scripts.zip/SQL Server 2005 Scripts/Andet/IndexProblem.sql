USE master
DROP DATABASE ProblemDB
GO
CREATE DATABASE ProblemDB
GO
USE ProblemDB
CREATE TABLE OrdreHoved (
	OrdreId			INT NOT NULL PRIMARY KEY)
CREATE TABLE OrdreLinie (
	OrdreId			INT NOT NULL,
	VareId			INT NOT NULL,
	EnhedsPris		DECIMAL(9,2) NOT NULL,
	RabatPct		SMALLINT NOT NULL DEFAULT (0),		
	AntalEnheder	SMALLINT NOT NULL,
	CONSTRAINT pk_OrdreLinie PRIMARY KEY (OrdreId, VareId) )
GO
set nocount on
INSERT INTO OrdreHoved VALUES (1)
INSERT INTO OrdreHoved VALUES (2)
INSERT INTO OrdreHoved VALUES (3)

INSERT INTO OrdreLinie VALUES (1, 210, 12.00, 10, 20)
INSERT INTO OrdreLinie VALUES (1, 311, 14.00,  8, 20)
INSERT INTO OrdreLinie VALUES (1, 134, 16.00,  6, 10)
INSERT INTO OrdreLinie VALUES (1, 196, 18.00,  4, 10)

INSERT INTO OrdreLinie VALUES (2, 561, 12.00, 10, 15)
INSERT INTO OrdreLinie VALUES (2,  98, 14.00,  8, 8)

INSERT INTO OrdreLinie VALUES (3, 711, 18.00, 10, 10)
INSERT INTO OrdreLinie VALUES (3, 154, 30.00,  6, 10)
SET NOCOUNT OFF
GO
CREATE INDEX nc_OrdreLinie_AntalEnheder_EnhedsPris ON OrdreLinie(AntalEnheder, EnhedsPris)
CREATE INDEX nc_OrdreLinie_AntalEnheder_RabatPct ON OrdreLinie(AntalEnheder, RabatPct)
GO
SELECT	OrdreId,
		(SELECT top 1 EnhedsPris
			FROM OrdreLinie
			WHERE OrdreHoved.OrdreId = OrdreLinie.OrdreId
			ORDER BY AntalEnheder DESC) AS EnhedsPris,
		(SELECT top 1 RabatPct
			FROM OrdreLinie
			WHERE OrdreHoved.OrdreId = OrdreLinie.OrdreId
			ORDER BY AntalEnheder DESC) AS RabatPct
	FROM OrdreHoved
