SET NOCOUNT ON
DECLARE @tables			TABLE (tablename	SYSNAME)
DECLARE @tablename		SYSNAME
DECLARE @topcount		INT
DECLARE @sql			NVARCHAR(1000)

SET @topcount = 10;

INSERT INTO @tables
	SELECT name
		FROM sys.tables 
		WHERE name NOT IN ('dtproperties', 'sysdiagrams');

SET @tablename = '';

WHILE EXISTS (SELECT * FROM @tables WHERE tablename > @tablename)
BEGIN	
	SET @tablename = (SELECT TOP 1 tablename
						FROM @tables 
						WHERE tablename > @tablename 
						ORDER BY tablename);
	SELECT @tablename;

	SET @sql = CONCAT('SELECT TOP (', @topcount , ') * FROM ', @tablename);
	EXEC sp_executesql @sql;
END;

SET NOCOUNT OFF;
