USE IndexDB
GO
DROP TABLE dbo.Person2;
DROP TABLE dbo.Person3;
GO
SELECT dbo.PersonId, Efternavn COLLATE Danish_Norwegian_CS_AS AS Efternavn
	INTO dbo.Person2
	FROM dbo.Person;
GO
SELECT dbo.PersonId, Efternavn
	INTO dbo.Person3
	FROM dbo.Person;
GO
CREATE UNIQUE CLUSTERED INDEX pk_Person2_PersonId ON dbo.Person2(PersonId);
CREATE UNIQUE CLUSTERED INDEX pk_Person3_PersonId ON dbo.Person3(PersonId);
GO
SET STATISTICS TIME ON;
SET STATISTICS IO ON;
DBCC DROPCLEANBUFFERS;
GO
SELECT * 
	FROM  dbo.Person INNER JOIN dbo.Person2 
				ON Person.PersonId = Person2.PersonId
	WHERE Person.Efternavn COLLATE Danish_Norwegian_CS_AS = Person2.Efternavn;
GO
DBCC DROPCLEANBUFFERS;
GO
SELECT * 
	FROM  dbo.Person INNER JOIN dbo.Person3 
		ON Person.PersonId = Person3.PersonId
	WHERE Person.Efternavn = Person3.Efternavn;
GO
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
