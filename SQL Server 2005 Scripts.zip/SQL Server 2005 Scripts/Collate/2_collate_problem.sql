USE master;
DROP DATABASE CollateDB;
-- DROP TABLE #t1;
-- DROP TABLE #t2;
GO
CREATE DATABASE CollateDB COLLATE  French_CS_AS;
GO
USE CollateDB;
GO
CREATE TABLE dbo.t
(
	Navn  VARCHAR(20)
);
GO
SET NOCOUNT ON;

INSERT INTO dbo.t VALUES
	('�ge'),
	('Ida'),
	('�jvind'),
	('Anne'),
	('Zara'),
	('�gir');

SET NOCOUNT OFF;
GO
SELECT * 
	FROM  dbo.t 
	ORDER BY Navn;
GO
CREATE TABLE #t1
(
	Navn  VARCHAR(20)
);
GO
INSERT INTO #t1
	SELECT * 
		FROM dbo.t;
GO
SELECT Navn
	INTO #t2
	FROM dbo.t;
GO
SELECT * 
	FROM dbo.t 
	ORDER BY Navn;

SELECT * 
	FROM #t1 
	ORDER BY Navn;

SELECT * 
	FROM #t2 
	ORDER BY Navn;
GO
DROP TABLE dbo.t;
DROP TABLE #t1;
DROP TABLE #t2;
GO
--eksempel 2
CREATE TABLE dbo.t
(
	Navn_def VARCHAR(20),
    Navn_da  VARCHAR(20) COLLATE Danish_Norwegian_CS_AS,
    Navn_fr  VARCHAR(20) COLLATE French_CS_AS
);
GO
SET NOCOUNT ON;

INSERT INTO dbo.t VALUES
	('�ge', '�ge', '�ge'),
	('Ida', 'Ida', 'Ida'),
	('�jvind', '�jvind', '�jvind'),
	('Anne', 'Anne', 'Anne'),
	('Zara', 'Zara', 'Zara'),
	('�gir', '�gir', '�gir');

SET NOCOUNT OFF;
GO
SELECT * 
	FROM dbo.t
	ORDER BY Navn_def;

SELECT * 
	FROM dbo.t
	ORDER BY Navn_da;

SELECT * 
	FROM dbo.t
	ORDER BY Navn_fr;

SELECT * 
	FROM dbo.t
	WHERE Navn_da = Navn_fr;			--fejl
GO
SELECT * 
	FROM dbo.t
	WHERE Navn_da COLLATE French_CS_AS = Navn_fr;
GO
SELECT * 
	FROM dbo.t
	WHERE Navn_fr BETWEEN 'Ida' AND '�ge'
	ORDER BY Navn_fr;

SELECT * 
	FROM dbo.t
	WHERE Navn_da BETWEEN 'Ida' AND '�ge'
	ORDER BY Navn_da;

SELECT MIN(Navn_fr), MIN(Navn_da),  MAX(Navn_fr), MAX(Navn_da)
	FROM dbo.t

SELECT *
	FROM sys.columns 
	WHERE object_id = OBJECT_ID ('dbo.t');
GO
--eksempel 3
DROP TABLE dbo.t;
GO
CREATE TABLE dbo.t
(
	Navn  VARCHAR(20)
);
GO
SET NOCOUNT ON;

INSERT INTO dbo.t VALUES
	('�ge'),
	('Ida'),
	('�jvind'),
	('Anne');

SET NOCOUNT OFF;
GO
CREATE TABLE #t1
(
	Navn  VARCHAR(20)
);
GO
INSERT INTO #t1
	SELECT * 
		FROM dbo.t;
GO
SELECT * 
	FROM dbo.t INNER JOIN #t1 ON t.Navn = #t1.Navn;
GO
