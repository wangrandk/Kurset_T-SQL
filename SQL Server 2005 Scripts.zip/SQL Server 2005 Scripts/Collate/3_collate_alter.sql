USE master;
DROP DATABASE CollateDB;
GO
CREATE DATABASE CollateDB COLLATE Danish_Norwegian_cs_as;
GO
USE CollateDB;
GO
CREATE TABLE dbo.t1
(
	Navn  VARCHAR(20)
);
GO
SET NOCOUNT ON;
INSERT INTO dbo.t1 VALUES
	('�ge'),
	('Ida'),
	('�jvind'),
	('Anne'),
	('Zara'),
	('�gir');

SET NOCOUNT OFF;
GO
SELECT * 
	FROM  dbo.t1 
	ORDER BY Navn;
GO
ALTER DATABASE CollateDB  COLLATE French_cs_as;
GO
SELECT * 
	FROM  dbo.t1 
	ORDER BY Navn;

SELECT *
	FROM sys.columns
	WHERE object_id = OBJECT_ID('t1');
GO
CREATE TABLE dbo.t2
(
	Navn  VARCHAR(20)
);
GO
INSERT INTO dbo.t2
    SELECT * 
		FROM  dbo.t1;
GO
SELECT * 
	FROM  dbo.t1 
	ORDER BY Navn;

SELECT * 
	FROM  dbo.t2 
	ORDER BY Navn;
GO
ALTER TABLE dbo.t1 ALTER COLUMN Navn VARCHAR(20) COLLATE Danish_Norwegian_cs_as;
GO
CREATE INDEX IX_t1_Navn ON dbo.t1(Navn);
GO
ALTER TABLE dbo.t1 ALTER COLUMN Navn VARCHAR(20) COLLATE French_cs_as;
