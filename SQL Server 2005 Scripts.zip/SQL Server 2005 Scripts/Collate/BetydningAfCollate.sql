USE master;
DROP DATABASE CollateDB;
GO
CREATE DATABASE CollateDB COLLATE French_CS_AS;
GO
USE CollateDB;
GO
CREATE TABLE dbo.Quiz 
(
        Ident			INT IDENTITY PRIMARY KEY,
        Colname1		VARCHAR(127) COLLATE Latin1_General_CI_AS NOT NULL,
        Colname2		VARCHAR(127) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
        Tblname			VARCHAR(127) NOT NULL,
        EmptyField		CHAR(100) NOT NULL DEFAULT ' '
);            
GO
INSERT INTO dbo.Quiz(Colname1, Colname2, Tblname)
	SELECT 
        a.name, 
        a.name, 
        OBJECT_NAME(a.OBJECT_ID)
	FROM  sys.columns a CROSS JOIN sys.columns b;
GO
CREATE INDEX name1_ix ON dbo.Quiz(Colname1);
CREATE INDEX name2_ix ON dbo.Quiz(Colname2);
GO
DECLARE @d		DATETIME2, 
        @c		INT, 
        @res	INT
        
SELECT @res = COUNT(DISTINCT Tblname) 
	FROM  dbo.Quiz 
	WHERE Colname1 = 'object_id';
 
SELECT @d = SYSDATETIME();
SELECT @c = 500;

WHILE @c > 0
BEGIN
        SELECT @res =  COUNT(DISTINCT Tblname) 
			FROM  dbo.Quiz 
			WHERE Colname1 = 'object_id';
 
        SELECT @c = @c - 1;
END;
PRINT 'Exeuction time1: ' + LTRIM(STR(DATEDIFF(ms, @d, SYSDATETIME()))) + ' ms.';
GO
DECLARE @d		DATETIME2, 
        @c		INT, 
        @res	INT;
        
SELECT @res = COUNT(DISTINCT Tblname) 
	FROM  dbo.Quiz 
	WHERE Colname2 = 'object_id';
 
SELECT @d = SYSDATETIME();
SELECT @c = 500;

WHILE @c > 0
BEGIN
        SELECT @res = COUNT(DISTINCT Tblname) 
		    FROM  dbo.Quiz 
			WHERE Colname2 = 'object_id';
 
        SELECT @c = @c - 1;
END; 
PRINT 'Exeuction time2: ' + LTRIM(STR(DATEDIFF(ms, @d, SYSDATETIME()))) + ' ms.';
GO
DECLARE @d		DATETIME2, 
        @c		INT, 
        @res	INT;
        
SELECT @res = COUNT(DISTINCT Tblname) 
	FROM  dbo.Quiz 
	WHERE Colname1 = N'object_id';
 
SELECT @d = SYSDATETIME();
SELECT @c = 500;

WHILE @c > 0
BEGIN
        SELECT @res = COUNT(DISTINCT Tblname) 
	        FROM  dbo.Quiz 
		    WHERE Colname1 = N'object_id';
 
        SELECT @c = @c - 1;
END;
PRINT 'Exeuction time3: ' + 
        LTRIM(STR(DATEDIFF(ms, @d, SYSDATETIME()))) + ' ms.';
GO
DECLARE @d		DATETIME2, 
        @c		INT, 
        @res	INT;
        
SELECT @res = COUNT(DISTINCT Tblname) 
	FROM  dbo.Quiz 
	WHERE Colname2 = N'object_id';
 
SELECT @d = SYSDATETIME();
SELECT @c = 500;

WHILE @c > 0
BEGIN
        SELECT @res = COUNT(DISTINCT Tblname) 
			FROM  dbo.Quiz 
			WHERE Colname2 = N'object_id';
 
        SELECT @c = @c - 1;
END   
PRINT 'Exeuction time4: ' + LTRIM(STR(DATEDIFF(ms, @d, SYSDATETIME()))) + ' ms.';
GO
