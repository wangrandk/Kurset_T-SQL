USE master;
DROP DATABASE CollateDB;
GO
CREATE DATABASE CollateDB COLLATE French_CS_AS;
GO
USE CollateDB;
GO
CREATE TABLE dbo.t
(
	Navn1		VARCHAR(20) COLLATE Danish_Norwegian_CI_AS NOT NULL,
	Navn2		VARCHAR(20) NOT NULL
);
GO
SELECT SERVERPROPERTY('Collation');
SELECT DATABASEPROPERTYEX(db_name(), 'Collation');

SELECT *
	FROM sys.columns
	WHERE object_id = OBJECT_ID('dbo.t');
