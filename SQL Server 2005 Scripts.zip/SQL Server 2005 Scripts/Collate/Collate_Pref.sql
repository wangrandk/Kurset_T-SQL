USE master;
DROP DATABASE CollateDB;
GO
CREATE DATABASE CollateDB;
GO
SELECT *
	FROM  fn_helpcollations()
	WHERE name LIKE '%pref%';
GO
USE CollateDB;
CREATE TABLE dbo.t
(
	ID		INT NOT NULL IDENTITY PRIMARY KEY,
	a		VARCHAR(10) COLLATE SQL_Danish_Pref_CP1_CI_AS NOT NULL,
	b		VARCHAR(10) COLLATE Danish_Norwegian_CI_AS NOT NULL,
	a_tw	AS TERTIARY_WEIGHTS(a),
	b_tw	AS TERTIARY_WEIGHTS(b)
);
GO
iNSERT INTO t VALUES
	('abc', 'abc'),
	('ABC', 'ABC'),
	('Abc', 'Abc'),
	('ABc', 'ABc')
GO
SELECT *
	FROM dbo.t;
GO
SELECT *
	FROM dbo.t
	ORDER BY a;

SELECT *
	FROM dbo.t
	ORDER BY b;
