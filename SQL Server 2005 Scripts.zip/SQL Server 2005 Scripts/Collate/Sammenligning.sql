USE CollateDB;
GO
SELECT ASCII('A' COLLATE Danish_Norwegian_CS_AS) AS 'A',
	   ASCII('Z' COLLATE Danish_Norwegian_CS_AS) AS 'Z',
	   ASCII('�' COLLATE Danish_Norwegian_CS_AS) AS '�',
	   ASCII('�' COLLATE Danish_Norwegian_CS_AS) AS '�',
	   ASCII('�' COLLATE Danish_Norwegian_CS_AS) AS '�'
UNION ALL
SELECT ASCII('A' COLLATE French_CS_AS),
	   ASCII('Z' COLLATE French_CS_AS),
	   ASCII('�' COLLATE French_CS_AS),
	   ASCII('�' COLLATE French_CS_AS),
	   ASCII('�' COLLATE French_CS_AS);

IF '�' COLLATE Danish_Norwegian_CS_AS < '�' COLLATE Danish_Norwegian_CS_AS
	SELECT 'Sand'
ELSE
	SELECT 'Falsk';

IF '�' COLLATE French_CS_AS < '�' COLLATE French_CS_AS
	SELECT 'Sand'
ELSE
	SELECT 'Falsk';

SELECT *
	FROM 
		(VALUES ('A'), ('Z'), ('�'), ('�'), ('�')) AS t(CharValueDanish)
	ORDER BY CharValueDanish COLLATE Danish_Norwegian_CS_AS;

SELECT *
	FROM 
		(VALUES ('A'), ('Z'), ('�'), ('�'), ('�')) AS t(CharValueFrench)
	ORDER BY CharValueFrench COLLATE French_CS_AS;
