USE master;
DROP DATABASE CollateDB;
GO
CREATE DATABASE CollateDB;
GO
USE CollateDB;
CREATE TABLE dbo.t
(
	Navn VARCHAR(30)
);
GO
INSERT INTO dbo.t VALUES
	('ole'),
	('�ge'),
	('aage'),
	('�ge'),
	('aage'),
	('�ge'),
	('aage'),
	('�ge'),
	('aage'),
	('�ge'),
	('�jvind'),
	('�jvind'),
	('�gir'),
	('anne');
GO
SELECT * 
	FROM dbo.t
	ORDER BY Navn;

SELECT * 
	FROM dbo.t
	ORDER BY Navn COLLATE Danish_Norwegian_ci_ai;
GO
DROP TABLE dbo.t;
GO
CREATE TABLE dbo.t
(
	Navn	VARCHAR(30) COLLATE Danish_Norwegian_ci_ai
);
GO
INSERT INTO dbo.t VALUES
	('ole'),
	('�ge'),
	('aage'),
	('�ge'),
	('�jvind'),
	('�gir'),
	('anne');
GO
SELECT * 
	FROM dbo.t;

SELECT * 
	FROM dbo.t
	ORDER BY Navn;
GO
DROP TABLE dbo.t;
GO
CREATE TABLE dbo.t
(
	Navn	VARCHAR(30) COLLATE Danish_Norwegian_cs_ai
);
GO
INSERT INTO dbo.t VALUES
	('ole'),
	('�ge'),
	('�ge'),
	('aage'),
	('Aage'),
	('�ge'),
	('�ge'),
	('�ge'),
	('�ge'),
	('�jvind'),
	('�jvind'),
	('�gir'),
	('anne');
GO
SELECT * 
	FROM dbo.t;

SELECT * 
	FROM dbo.t
	ORDER BY Navn
GO
DROP TABLE dbo.t;
GO
CREATE TABLE dbo.t
(
	Navn VARCHAR(30) COLLATE Danish_Norwegian_cs_ai
);
GO
INSERT INTO dbo.t VALUES
	('rene'),
	('ren�'),
	('all�'),
	('alle'),
	('all�'),
	('alle'),
	('�n'),
	('een'),
	('Een'),
	('�n');
GO
SELECT * 
	FROM dbo.t;

SELECT * 
	FROM dbo.t
	ORDER BY Navn
GO
DROP TABLE dbo.t;
GO
CREATE TABLE dbo.t
(
	Navn		VARCHAR(30) COLLATE Danish_Norwegian_cs_as
);
GO
INSERT INTO dbo.t VALUES
	('rene'),
	('ren�'),
	('all�'),
	('alle'),
	('all�'),
	('alle'),
	('�n'),
	('een'),
	('Een'),
	('�n');
GO
SELECT * 
	FROM dbo.t;

SELECT * 
	FROM dbo.t
	ORDER BY Navn;
GO
DROP TABLE dbo.t;
GO
CREATE TABLE dbo.t
(
	Navn		VARCHAR(30) COLLATE Danish_Norwegian_ci_ai
);
GO
INSERT INTO dbo.t VALUES
	('rene'),
	('ren�'),
	('all�'),
	('alle'),
	('�n'),
	('een'),
	('Een'),
	('�n');
GO
SELECT * 
	FROM dbo.t;

SELECT * 
	FROM dbo.t
	ORDER BY Navn;
GO
USE master;
DROP DATABASE CollateDB;
GO
CREATE DATABASE CollateDB COLLATE Danish_Norwegian_cs_as;;
GO
USE CollateDB;
CREATE TABLE dbo.t
(
	Navn	VARCHAR(30)
);
GO
INSERT INTO dbo.t VALUES
	('rene'),
	('ren�');
GO
SELECT * 
	FROM dbo.t;
GO
SELECT * 
	FROM  DBO.T;		-- fejler pga. case
