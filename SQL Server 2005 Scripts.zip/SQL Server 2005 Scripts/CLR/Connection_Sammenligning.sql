USE CLRDB
GO
CREATE PROC tsp_Connect_Context
AS
SELECT * 
	FROM Kunde
GO
[Microsoft.SqlServer.Server.SqlProcedure]
    public static void msp_Connect_Context()
    {
        using(SqlConnection sqlConn = 
                        new SqlConnection("Context Connection=true"))
       {
           sqlConn.Open();
           SqlCommand sqlCmd = sqlConn.CreateCommand();
           sqlCmd.CommandText = "SELECT * FROM Kunde";
           SqlContext.Pipe.EXECuteAndSend(sqlCmd);
       }
    }
GO    
CREATE PROC tsp_looptekst
AS
DECLARE @i	INT
SET @i = 0
WHILE @i < 300000
BEGIN
	SET @i = @i + 1
	PRINT 'Dato : ' + cast(GETDATE() AS VARCHAR(20))
END
GO
--[Microsoft.SqlServer.Server.SqlProcedure]
--    public static void msp_looptekst()
--    {
--        int i = 0;
--        while (i < 300000)
--        {
--            i++;
--            SqlContext.Pipe.Send("Dato : " + Convert.ToString(System.DateTime.Now));
--        }
--    }
GO
DROP TABLE Kunde
GO
SELECT top 2000 *
	into Kunde
	FROM IndexDB.dbo.Person
GO
DECLARE @start	datetime
DECLARE @end	datetime
SET @start = GETDATE()
EXEC msp_Connect_Context
SET @end = GETDATE()
SELECT 'C#' AS Sprog, DATEDIFF(ms, @start, @end) AS Tid
GO
DECLARE @start	datetime
DECLARE @end	datetime
SET @start = GETDATE()
EXEC tsp_Connect_Context
SET @end = GETDATE()
SELECT 'TSQL' AS Sprog, DATEDIFF(ms, @start, @end) AS Tid
GO
