USE master;
DROP DATABASE IF EXISTS CLRDB;
GO
CREATE DATABASE CLRDB;
GO
USE CLRDB;  
GO  
DROP TYPE IF EXISTS TestDataType;  
GO  
DROP AGGREGATE IF EXISTS WeightedAvg;  
GO 
DROP ASSEMBLY IF EXISTS ClrDLL;  
GO  
CREATE ASSEMBLY ClrDLL FROM 'C:\Rod\ClrWAvg\ClassLibrary1\obj\Debug\ClassLibrary1.dll';  
GO  
CREATE AGGREGATE WeightedAvg 
	(	@value		INT, 
		@weight		INT) RETURNS DECIMAL(11,2)  
	EXTERNAL NAME ClrDLL.[ClassLibrary1.WeightedAvg];  
GO  
CREATE TYPE TestDataType AS TABLE 
(
	ItemValue		INT, 
	ItemWeight		INT
);  
GO  
DECLARE @TestData AS TestDataType;  

INSERT INTO @TestData VALUES
	(1, 4), 
	(6, 1),
	(4, 3),
	(5, 2),
	(9, 2);  

SELECT dbo.WeightedAvg(ItemValue, ItemWeight) 
	FROM @TestData;  
GO  
CREATE TYPE TestDataType2 AS TABLE 
(
	GrId			INT,
	ItemValue		INT, 
	ItemWeight		INT
);
GO  
DECLARE @TestData AS TestDataType2;  

INSERT INTO @TestData VALUES
	(1, 1, 4), 
	(1, 6, 1),
	(1, 4, 3),
	(1, 5, 2),
	(2, 9, 2),
	(2, 7, 2);  

SELECT dbo.WeightedAvg(ItemValue, ItemWeight) 
	FROM @TestData
	GROUP BY GrId;


SELECT CAST(SUM(ItemValue * ItemWeight) AS DECIMAL(11,2))/SUM(ItemWeight) 
	FROM @TestData
	GROUP BY GrId;
GO
DECLARE @TestData AS TestDataType2;  

INSERT INTO @TestData VALUES
	(1, 1, 4), 
	(1, 6, 1),
	(1, 4, 3),
	(1, 5, 2),
	(2, 9, 2),
	(2, 7, 2),
	(3, NULL, 4),
	(3, 5, 2);  

SELECT dbo.WeightedAvg(ItemValue, ItemWeight) 
	FROM @TestData
	GROUP BY GrId;


SELECT CAST(SUM(ItemValue * ItemWeight) AS DECIMAL(11,2))/SUM(IIF (ItemValue IS NULL, 0, ItemWeight)) 
	FROM @TestData
	GROUP BY GrId;
