USE master
DROP DATABASE SelectDB
GO
CREATE DATABASE SelectDB
GO
USE SelectDB
CREATE TABLE LoenModtagerData (
	ID			INT NOT NULL PRIMARY KEY IDENTITY,
	Loen		INT NOT NULL)
GO
DECLARE @i	INT
SET @i = 1
WHILE @i <= 100
BEGIN
	INSERT INTO LoenModtagerData VALUES (@i * 1000 )
	SET @i = @i + 1
END
GO
SELECT *
	FROM LoenModtagerData
GO
SELECT MAX(Loen) AS NedreKvartil
	FROM (SELECT *, NTILE(4) OVER (ORDER BY Loen) AS Inddeling
			FROM LoenModtagerData) AS LoenModtagerData 
	WHERE Inddeling = 1
GO
SELECT MAX(Loen) AS Median
	FROM (SELECT *, NTILE(4) OVER (ORDER BY Loen) AS Inddeling
			FROM LoenModtagerData) AS LoenModtagerData 
	WHERE Inddeling = 2
GO
SELECT MAX(Loen) AS OevreKvartil
	FROM (SELECT *, NTILE(4) OVER (ORDER BY Loen) AS Inddeling
			FROM LoenModtagerData) AS LoenModtagerData 
	WHERE Inddeling = 3
GO
SELECT MAX(Loen) AS OevreKvartil, Inddeling
	FROM (SELECT *, NTILE(4) OVER (ORDER BY Loen) AS Inddeling
			FROM LoenModtagerData) AS LoenModtagerData 
	GROUP BY Inddeling
	HAVING Inddeling <= 3
GO
SELECT MAX(Loen)
	FROM (SELECT TOP (25) PERCENT *
			FROM c
			ORDER BY Loen) AS Loen
UNION ALL
SELECT MAX(Loen)
	FROM (SELECT TOP (50) PERCENT *
			FROM LoenModtagerData
			ORDER BY Loen) AS Loen
UNION ALL
SELECT MAX(Loen)
	FROM (SELECT TOP (75) PERCENT *
			FROM LoenModtagerData
			ORDER BY Loen) AS Loen
