USE Master
DROP DATABASE GroupDB
GO
CREATE DATABASE GroupDB
GO
USE GroupDB
CREATE TABLE Afdeling (
	AfdelingsId		INT NOT NULL PRIMARY KEY,
	AfdelingsNavn	VARCHAR(30) NOT NULL,
	ChefId			INT NULL)	
	
CREATE TABLE Medarbejder (
	MedarbejderId	INT NOT NULL PRIMARY KEY,
	MedarbejderNavn	VARCHAR(30) NOT NULL,
	Loen			INT NULL,
	AfdelingsId		INT NULL 
					CONSTRAINT FK_Medarbejder_Afdeling_AnsatI 
					FOREIGN KEY REFERENCES Afdeling)
GO
ALTER TABLE Afdeling ADD CONSTRAINT FK_Afdeling_Medarbejder_Chef
					FOREIGN KEY (ChefId) REFERENCES Medarbejder(Medarbejderid)
GO
INSERT INTO Afdeling VALUES (1, 'Direktion', NULL)
INSERT INTO Afdeling VALUES (2, 'Administration', NULL)
INSERT INTO Afdeling VALUES (3, 'Produktion', NULL)
INSERT INTO Afdeling VALUES (4, 'Salg', NULL)

INSERT INTO Medarbejder VALUES (1, 'Hans Olsen', 100000, 1)
INSERT INTO Medarbejder VALUES (2, 'Ida Jensen', 40000, 2)
INSERT INTO Medarbejder VALUES (3, 'Sanne Larsen', 50000, 3)
INSERT INTO Medarbejder VALUES (4, 'Peter Olsen', 45000, 4)
INSERT INTO Medarbejder VALUES (5, 'Bo Pedersen', 35000, 2)
INSERT INTO Medarbejder VALUES (6, 'Dorte Knudsen', 24000, 3)
INSERT INTO Medarbejder VALUES (7, 'Hans Olsen', 30000, 3)
INSERT INTO Medarbejder VALUES (8, 'Jens Olsen', 26000, 3)
INSERT INTO Medarbejder VALUES (9, 'Peter Olsen', 32000, 4)

UPDATE Afdeling SET ChefId = 1 WHERE AfdelingsId = 1
UPDATE Afdeling SET ChefId = 2 WHERE AfdelingsId = 2
UPDATE Afdeling SET ChefId = 3 WHERE AfdelingsId = 3
UPDATE Afdeling SET ChefId = 2 WHERE AfdelingsId = 4
GO
SELECT *
	FROM Medarbejder

SELECT *
	FROM Afdeling
GO
SELECT	*,
		(SELECT AVG(Loen) FROM Medarbejder) AS AvgAlle,
		(SELECT SUM(Loen) FROM Medarbejder) AS SumAlle
	FROM dbo.Medarbejder AS M INNER JOIN 
										(SELECT		AfdelingsId, 
													AVG(Loen) AS AfdAvgLoen, 
													SUM(Loen) AS AfdSumLoen, 
													MAX(Loen) AS AfdMaxLoen
											FROM Medarbejder
											GROUP BY AfdelingsId) AS AvgAfd
			ON M.AfdelingsId = AvgAfd.AfdelingsId
	WHERE M.AfdelingsId IN (SELECT AfdelingsId 
								FROM Afdeling
								WHERE ChefId IN (2, 4))

--SELECT select-liste
--FROM tabel-liste
--WHERE where-betingelse
--GROUP BY group-by-liste
--HAVING having-betingelse
--ORDER BY order-by-liste 
GO
SELECT	*, 
		(SELECT AVG(Loen) FROM Medarbejder) AS AvgAlle
	FROM dbo.Medarbejder

SELECT *, (SELECT TOP 1 Loen FROM Medarbejder WHERE AfdelingsId = 2)
	FROM dbo.Medarbejder

SELECT	*, 
		(SELECT Loen FROM Medarbejder WHERE MedarbejderId = 123) AS  M123
	FROM dbo.Medarbejder
GO
SELECT	*,
		(SELECT AVG(Loen) FROM Medarbejder WHERE AfdelingsId = 5) AS AVG,
		(SELECT COUNT(Loen) FROM Medarbejder WHERE AfdelingsId = 5) AS COUNT
	FROM dbo.Medarbejder
GO
SELECT *,
		Loen - AvgLoen AS Diff
	FROM dbo.Medarbejder AS M INNER JOIN 
				(SELECT AfdelingsId, AVG(Loen) AS AvgLoen
					FROM Medarbejder
					GROUP BY AfdelingsId) AS AvgAfd
			ON M.AfdelingsId = AvgAfd.AfdelingsId

SELECT	*,	
		(SELECT AVG(Loen) AS AvgLoen
			FROM Medarbejder AS M_Avg
			WHERE M_Avg.AfdelingsId = M.AfdelingsId) AS AfdAvg,
		Loen - (SELECT AVG(Loen) AS AvgLoen
					FROM Medarbejder AS M_Avg
					WHERE M_Avg.AfdelingsId = M.AfdelingsId) AS Diff
	FROM dbo.Medarbejder AS M
GO
SELECT *
	FROM Medarbejder

SELECT *
	FROM Medarbejder AS M
	WHERE Loen < (SELECT AVG(Loen)
					FROM Medarbejder AS M_Avg
					WHERE M.AfdelingsId = M_Avg.AfdelingsID)

SELECT *
	FROM Medarbejder
	WHERE AfdelingsId = ANY (SELECT AfdelingsId
								FROM Afdeling
						 		WHERE ChefId = 2)

SELECT *
	FROM Medarbejder
	WHERE AfdelingsId IN (SELECT AfdelingsId
								FROM Afdeling
						 		WHERE ChefId = 2)

SELECT *
	FROM Medarbejder
	WHERE Loen BETWEEN  (SELECT MIN(Loen) * 1.50
							FROM Medarbejder)   AND
						(SELECT MAX(Loen) * 0.50
							FROM Medarbejder)
GO
CREATE TABLE LoenIntervaller (
	Id			INT NOT NULL PRIMARY KEY,
	Kategori	CHAR(1) NOT NULL,
	MinLoen		INT NOT NULL,
	MaxLoen		INT NOT NULL)
GO
INSERT INTO LoenIntervaller VALUES (1, 'A', 0, 28000)
INSERT INTO LoenIntervaller VALUES (2, 'B', 28001, 48000)
INSERT INTO LoenIntervaller VALUES (3, 'C', 48001, 999999)
GO
SELECT AVG(Loen) AS AvgKat, SUM(Loen) AS SumKat,			-- fejl
	(SELECT Kategori 
			FROM LoenIntervaller 
			WHERE Loen BETWEEN MinLoen AND MaxLoen) AS Kategori
	FROM Medarbejder
	GROUP BY (SELECT Kategori 
				FROM LoenIntervaller 
				WHERE Loen BETWEEN MinLoen AND MaxLoen)

SELECT Kategori, AVG(Loen) AS AvgKat, SUM(Loen) AS SumKat
	FROM 	
		(SELECT Loen, (SELECT Kategori 
							FROM LoenIntervaller 
							WHERE Loen BETWEEN MinLoen AND MaxLoen) AS Kategori
			FROM Medarbejder) AS MedarbLoenKategori
	GROUP BY Kategori
GO
CREATE TABLE GroupByAntalAfdeling (
	AfdelingsId	INT NOT NULL PRIMARY KEY,
	GrpAntal	INT NOT NULL)
GO
INSERT INTO GroupByAntalAfdeling VALUES (1, 1)
INSERT INTO GroupByAntalAfdeling VALUES (2, 3)
INSERT INTO GroupByAntalAfdeling VALUES (3, 5)
INSERT INTO GroupByAntalAfdeling VALUES (4, 2)
GO
SELECT AfdelingsId, COUNT(*) AS Antal
	FROM Medarbejder AS M
	GROUP BY AfdelingsId
	HAVING COUNT(*) >= (SELECT GrpAntal 
							FROM GroupByAntalAfdeling AS GBA
							WHERE M.AfdelingsId = GBA.AfdelingsId)
GO
SELECT *
	FROM Medarbejder AS M
	ORDER BY (SELECT SUM(Loen) 
				FROM Medarbejder AS M_Order 
				WHERE M.AfdelingsId = M_Order.AfdelingsId) DESC, Loen
GO
DROP TABLE LoenIntervaller
GO
CREATE TABLE LoenIntervaller (
	Id			INT NOT NULL PRIMARY KEY,
	Kategori	CHAR(1) NOT NULL,
	MinLoen		INT NOT NULL,
	MaxLoen		INT NOT NULL)
GO
INSERT INTO LoenIntervaller VALUES (1, 'A', 0, 28000)
INSERT INTO LoenIntervaller VALUES (2, 'B', 28001, 48000)
INSERT INTO LoenIntervaller VALUES (3, 'C', 48001, 90000)
GO

SELECT MedarbejderId, Loen, (SELECT Kategori 
				FROM LoenIntervaller 
				WHERE Loen BETWEEN MinLoen AND MaxLoen) AS Kategori
	FROM Medarbejder

SELECT MedarbejderId, Loen, 
		ISNULL((SELECT Kategori 
						FROM LoenIntervaller 
						WHERE Loen BETWEEN MinLoen AND MaxLoen), 'UNKNOWN') AS Kategori
	FROM Medarbejder

SELECT MedarbejderId, Loen, ISNULL(CAST((SELECT Kategori 
				FROM LoenIntervaller 
				WHERE Loen BETWEEN MinLoen AND MaxLoen) AS VARCHAR(10)), 'UNKNOWN') AS Kategori
	FROM Medarbejder

