-----------------------------------------------------------------------------------------------------
-- Costum Rollup
CREATE SCHEMA CustRollup
GO
CREATE TABLE CustRollup.KontoPlan (
	Kontonr		INT NOT NULL PRIMARY KEY,
	Navn		VARCHAR(30) NOT NULL,
	UnaryOp		CHAR(1) NOT NULL,
	ParentKonto	INT NULL REFERENCES CustRollup.KontoPlan)

CREATE TABLE CustRollup.Tid (
	DatoId		INT NOT NULL PRIMARY KEY,
	Dato		DATE NOT NULL,
	Aar			AS YEAR(Dato),
	Maaned		AS MONTH(Dato),
	DagMaaned	AS DAY(Dato))

CREATE TABLE CustRollup.Fact (
	Kontonr		INT NOT NULL REFERENCES CustRollup.KontoPlan,
	DatoId		INT NOT NULL REFERENCES CustRollup.Tid,
	Beloeb		INT NOT NULL)
GO
INSERT INTO CustRollup.KontoPlan VALUES (0, 'Til r�dighed', '+', NULL)

INSERT INTO CustRollup.KontoPlan VALUES (1, 'L�n og bank', '+', 0)
INSERT INTO CustRollup.KontoPlan VALUES (11, 'L�n', '+', 1)
INSERT INTO CustRollup.KontoPlan VALUES (12, 'Skat, ATP, mv', '-', 1)
INSERT INTO CustRollup.KontoPlan VALUES (13, 'Renter', '+', 1)
INSERT INTO CustRollup.KontoPlan VALUES (120, 'Renteindt�gter', '+', 13)
INSERT INTO CustRollup.KontoPlan VALUES (121, 'Renteudgifter', '-', 13)

INSERT INTO CustRollup.KontoPlan VALUES (1000, 'Faste udgifter', '-', 0)
INSERT INTO CustRollup.KontoPlan VALUES (10001, 'Husleje', '+', 1000)
INSERT INTO CustRollup.KontoPlan VALUES (10002, 'Bil', '+', 1000)
INSERT INTO CustRollup.KontoPlan VALUES (10003, 'Avis', '+', 1000)

DECLARE @Starttid	DATETIME
SET @Starttid = DATEADD(YEAR, -1, SYSDATETIME());

WITH DatoDim (Id, Dato) 
AS
(SELECT 1 AS Id, @Starttid AS Dato
 UNION ALL
 SELECT Id + 1, Dato + 1
	FROM DatoDim
	WHERE Dato <= @Starttid + 365)
INSERT INTO CustRollup.Tid
	SELECT * 
		FROM DatoDim
OPTION(MAXRECURSION 0)

INSERT INTO CustRollup.Fact 
	SELECT 11, DatoId, 25000
		FROM CustRollup.Tid 
		WHERE DAY(Dato) = 1

INSERT INTO CustRollup.Fact 
	SELECT 12, DatoId, 8000
		FROM CustRollup.Tid 
		WHERE DAY(Dato) = 1

INSERT INTO CustRollup.Fact 
	SELECT 120, DatoId, 300 + DatoId * 3
		FROM CustRollup.Tid 
		WHERE DAY(Dato) = 5

INSERT INTO CustRollup.Fact 
	SELECT 121, DatoId, 500 + DatoId * 4
		FROM CustRollup.Tid 
		WHERE DAY(Dato) = 2

INSERT INTO CustRollup.Fact 
	SELECT 10001, DatoId, 7000
		FROM CustRollup.Tid 
		WHERE DAY(Dato) = 2

INSERT INTO CustRollup.Fact 
	SELECT 10002, DatoId, 100 + (DatoId % 4) * 4
		FROM Tid 
		WHERE DATEPART(WEEKDAY, Dato) IN (1, 2, 7)

INSERT INTO CustRollup.Fact 
	SELECT 10003, DatoId, 400
		FROM CustRollup.Tid 
		WHERE DAY(Dato) = 1
GO
