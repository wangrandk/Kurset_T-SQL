USE master
GO
DROP DATABASE BISSISDB
GO
CREATE DATABASE BISSISDB
GO
USE BISSISDB
CREATE TABLE Postopl ( 
	PostNr 			SMALLINT NOT NULL 
					CONSTRAINT PK_Postopl PRIMARY KEY (PostNr),
	Bynavn 			VARCHAR (20) NOT NULL)
	
CREATE TABLE Kunde (
	KundeID			INT NOT NULL 
					CONSTRAINT PK_Kunde PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL FOREIGN KEY REFERENCES Postopl)
	
CREATE TABLE Vare (
	VareID			INT NOT NULL
					CONSTRAINT PK_Vare PRIMARY KEY,
	VareNavn		VARCHAR(30) NOT NULL)

CREATE TABLE Fact2009 (
	FactID			INT NOT NULL IDENTITY
					CONSTRAINT PK_Fact2009 PRIMARY KEY,
	Kundeid			INT	NOT NULL FOREIGN KEY REFERENCES Kunde,
	Vareid			INT	NOT NULL FOREIGN KEY REFERENCES Vare,
	AntalEnheder	INT NOT NULL)

CREATE TABLE KundeNye (
	KundeID			INT NOT NULL 
					CONSTRAINT PK_KundeNye PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL FOREIGN KEY REFERENCES Postopl)
	
CREATE TABLE VareNye (
	VareID			INT NOT NULL
					CONSTRAINT PK_VareNye PRIMARY KEY,
	VareNavn		VARCHAR(30) NOT NULL)

CREATE TABLE Fact2009Nye (
	FactID			INT NOT NULL IDENTITY
					CONSTRAINT PK_Fact2009Nye PRIMARY KEY,
	Kundeid			INT	NOT NULL FOREIGN KEY REFERENCES Kunde,
	Vareid			INT	NOT NULL FOREIGN KEY REFERENCES Vare,
	AntalEnheder	INT NOT NULL)

CREATE TABLE Fact2009NyeDim (
	FactID			INT NOT NULL IDENTITY
					CONSTRAINT PK_Fact2009NyeDim PRIMARY KEY,
	Kundeid			INT	NOT NULL, -- FOREIGN KEY REFERENCES Kunde,
	Vareid			INT	NOT NULL, -- FOREIGN KEY REFERENCES Vare,
	AntalEnheder	INT NOT NULL)

GO
INSERT INTO Postopl VALUES 
	(1127, 'K�benhavn K'),
	(1001, 'K�benhavn K'),
	(2000, 'Frederiksberg')

INSERT INTO Kunde VALUES
	(1, 'Ole Jensen', 1127),
	(2, 'Karl Hansen', 1001),
	(3, 'Per Larsen', 1127),
	(4, 'Lars Jense', 2000),
	(5, 'Knud Andersen', 2000)

INSERT INTO Vare VALUES 
	(1, '�ble'),
	(2, 'Appelsin'),
	(3, 'Blomme'),
	(4, 'Jordb�r'),
	(5, 'Kiwi'),
	(6, 'Vandmelon'),
	(7, 'Fersken'),
	(8, 'Honningmelon')

INSERT INTO Fact2009 VALUES
	(1, 3, 2),
	(1, 1, 1),
	(2, 3, 1),
	(2, 5, 2),
	(3, 5, 4),
	(3, 8, 1),
	(3, 7, 4),
	(4, 1, 3),
	(4, 6, 1),
	(4, 2, 3)
GO
INSERT INTO Fact2009Nye VALUES
	(1, 3, 200),
	(1, 1, 100),
	(4, 2, 100),
	(5, 5, 200),
	(3, 4, 400),
	(3, 8, 100)
GO
INSERT INTO KundeNye VALUES
	(6, 'Lotte Jensen', 1127),
	(7, 'Maren Pedersen', 1001)

INSERT INTO VareNye VALUES 
	(9, 'Sukker'),
	(10, 'Mel')
	
INSERT INTO Fact2009NyeDim VALUES
	(1, 4, 2000),
	(1, 9, 1000),
	(6, 10, 100),
	(7, 2, 200),
	(7, 9, 400)
GO
