DECLARE @StartTime		DATETIME
DECLARE @EndTime		DATETIME

SET @StartTime = CAST(FLOOR(CAST(GETDATE() - 1999 AS DECIMAL(11,2))) AS DateTime)
SET @EndTime = CAST(FLOOR(CAST(GETDATE() AS DECIMAL(11,2))) AS DATETIME);

WITH TimeLoop (Time)
AS 
(
SELECT @StartTime
UNION ALL
SELECT Time + 1
	FROM TimeLoop
	WHERE Time + 1 <= @EndTime
)
SELECT Time, year(time) , datepart(dy , Time)
	FROM TimeLoop
	OPTION (MAXRECURSION 2000); 
