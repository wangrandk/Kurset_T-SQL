USE master
DROP DATABASE DWDB
GO
CREATE DATABASE DWDB
GO
USE DWDB
CREATE TABLE Kunde (
	Kundeid_s			INT NOT NULL PRIMARY KEY IDENTITY,
	Kundeid_b			INT NOT NULL,
	Navn				VARCHAR(30) NOT NULL,
	Gade				VARCHAR(30) NOT NULL,
	Postnr				SMALLINT NOT NULL,
	Bynavn				VARCHAR(20) NOT NULL,
	Dato_fra			SMALLDATETIME NOT NULL,
	Dato_til			SMALLDATETIME null) 

CREATE TABLE Vare (
	VareID_s			INT NOT NULL IDENTITY
						CONSTRAINT PK_Vare PRIMARY KEY,
	VareID_b			INT NOT NULL,
	VareNavn			VARCHAR(30) NOT NULL,
	VejledendePris		DECIMAL(9,2) null,
	SubKategoriNavn		VARCHAR(30) NOT NULL,
	KategoriNavn		VARCHAR(30) NOT NULL)


CREATE TABLE Salgskanal (
	SalgskanalID_s		SMALLINT NOT NULL 
						CONSTRAINT PK_Salgskanal PRIMARY KEY IDENTITY,
	SalgskanalID_b		SMALLINT NOT NULL,
	SalgskanalNavn		VARCHAR(30) NOT NULL)

CREATE TABLE Ordre (
	Ordreid				INT NOT NULL 
						CONSTRAINT PK_Ordre PRIMARY KEY)

CREATE TABLE Tid (
	Tidid				INT NOT NULL PRIMARY KEY IDENTITY,
	Dato				SMALLDATETIME)

CREATE TABLE Fact (
	SalgskanalID_s		SMALLINT NOT NULL,
	Tidid_bestilling	INT NOT NULL,
	Tidid_leverering	INT NOT NULL,
	Tidid_betaling		INT null,
	VareID_s			INT NOT NULL,
	KundeID_s			INT null,
	OrdreID_s			INT NOT NULL,
	AntalEnheder		SMALLINT NOT NULL,
	Rabatpct			SMALLINT NOT NULL,
	VejledendePris		DECIMAL(9,2) null)

CREATE UNIQUE CLUSTERED INDEX cl_fact 
	ON Fact (SalgskanalID_s, Tidid_bestil, Tidid_lever, Tidid_betal,
			 VareID_s, KundeID_s, OrdreID_s)

