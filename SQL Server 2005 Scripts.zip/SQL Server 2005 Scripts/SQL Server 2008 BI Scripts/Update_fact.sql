USE BIDB
GO
DROP VIEW vStage
DROP TABLE fact
DROP TABLE stage1
DROP TABLE stage2
GO
CREATE TABLE fact
 (i int, j int, v1 int, v2 int)

CREATE TABLE stage1
 (i int, j int, v1 int)

CREATE TABLE stage2
 (i int, j int, v2 int)
GO
INSERT INTO fact VALUES (1,1,10,100)
INSERT INTO fact VALUES (2,2,20,200)

INSERT INTO stage1 VALUES (1,1,13)
INSERT INTO stage1 VALUES (2,2,17)
INSERT INTO stage1 VALUES (3,3,30)

INSERT INTO stage2 VALUES(1,1,113)
INSERT INTO stage2 VALUES(3,3,300)
INSERT INTO stage2 VALUES(4,4,400)
GO
SELECT * FROM FACT

SELECT	ISNULL(stage1.i, stage2.i) AS i, 
		ISNULL(stage1.j, stage2.j) AS j, 
		ISNULL(stage1.v1, 0) AS v1, 
		ISNULL(stage2.v2, 0) AS v2
   FROM stage1 FULL JOIN stage2 ON stage1.i = stage2.i and stage1.j = stage2.j


UPDATE fact
    SET fact.v1 = fact.v1 + stage.v1, fact.v2 = fact.v2 + stage.v2
    FROM fact INNER JOIN (SELECT stage1.i, stage1.j, ISNULL(stage1.v1, 0) AS v1, ISNULL(stage2.v2, 0)as v2
   							FROM stage1 FULL JOIN stage2 on stage1.i = stage2.i AND stage1.j = stage2.j
   							WHERE EXISTS (SELECT * FROM fact
                        					where fact.i = stage1.i AND
                              					  fact.j = stage1.j)) AS stage
          on fact.i = stage.i and fact.j = stage.j

INSERT INTO fact
SELECT ISNULL(stage1.i, stage2.i), ISNULL(stage1.j, stage2.j), ISNULL(stage1.v1, 0), ISNULL(stage2.v2, 0)
   FROM stage1 FULL JOIN stage2 ON stage1.i = stage2.i AND stage1.j = stage2.j
   WHERE NOT EXISTS (SELECT * FROM fact
                        where fact.i = stage1.i AND
                              fact.j = stage1.j)

GO
SELECT * FROM fact
--view
DROP VIEW vStage
DROP TABLE fact
DROP TABLE stage1
DROP TABLE stage2
GO
CREATE TABLE fact
 (i INT, j INT, v1 INT, v2 INT)

CREATE TABLE stage1
 (i INT, j INT, v1 INT)

CREATE TABLE stage2
 (i INT, j INT, v2 INT)
GO
INSERT INTO fact VALUES (1,1,10,100)
INSERT INTO fact VALUES (2,2,20,200)

INSERT INTO stage1 VALUES (1,1,13)
INSERT INTO stage1 VALUES (2,2,17)
INSERT INTO stage1 VALUES (3,3,30)

INSERT INTO stage2 VALUES(1,1,113)
INSERT INTO stage2 VALUES(3,3,300)
INSERT INTO stage2 VALUES(4,4,400)
GO
CREATE VIEW vStage AS
SELECT	ISNULL(stage1.i, stage2.i) AS i,
		ISNULL(stage1.j, stage2.j) AS j,
		ISNULL(stage1.v1, 0) AS v1,
		ISNULL(stage2.v2, 0) AS v2
   FROM stage1 FULL JOIN stage2 ON stage1.i = stage2.i AND stage1.j = stage2.j


UPDATE fact
    SET fact.v1 = fact.v1 + vStage.v1, fact.v2 = fact.v2 + vStage.v2
    FROM fact INNER JOIN (SELECT *
   							FROM vStage
   							WHERE EXISTS (SELECT * 
   												FROM fact
                       							WHERE fact.i = vStage.i AND
                           							fact.j = vStage.j)) AS vStage
          ON fact.i = vStage.i AND fact.j = vStage.j

INSERT INTO fact
SELECT *
   FROM vStage
   WHERE NOT EXISTS (SELECT * 
						FROM fact
                        WHERE fact.i = vStage.i AND
                              fact.j = vStage.j)
GO
SELECT * 
	FROM fact
