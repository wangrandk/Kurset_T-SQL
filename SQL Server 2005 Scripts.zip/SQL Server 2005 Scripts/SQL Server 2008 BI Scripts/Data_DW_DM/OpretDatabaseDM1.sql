--- Datamart 1
USE master
GO
IF EXISTS (SELECT * FROM master.sys.databases WHERE name = 'BIDB_DM1')
	DROP DATABASE BIDB_DM1
GO
CREATE DATABASE BIDB_DM1
ON PRIMARY
	(NAME = N'BIDB_DM1_Sys',
	FILENAME = N'c:\Databaser\BIDB_DM1_Data.MDF', 
	SIZE = 5,
	FILEGROWTH = 10%),
FILEGROUP DataFG
	(NAME = N'BIDB_DM1_Data1',
	FILENAME = N'c:\Databaser\BIDB_DM1_DataFG_Fil1.NDF', 
	SIZE = 200,
	FILEGROWTH = 25%),
	(NAME = N'BIDB_DM1_Data2', 
	FILENAME = N'c:\Databaser\BIDB_DM1_DataFG_Fil2.NDF', 
	SIZE = 200,
	FILEGROWTH = 25%),
	(NAME = N'BIDB_DM1_Data3', 
	FILENAME = N'c:\Databaser\BIDB_DM1_DataFG_Fil3.NDF', 
	SIZE = 200,
	FILEGROWTH = 25%),
	(NAME = N'BIDB_DM1_Data4', 
	FILENAME = N'c:\Databaser\BIDB_DM1_DataFG_Fil4.NDF', 
	SIZE = 200,
	FILEGROWTH = 25%)
LOG ON 
	(NAME = N'BIDB_DM1_Log',
	FILENAME = N'c:\Databaser\BIDB_DM1_Log.LDF', 
	SIZE = 100,
	FILEGROWTH = 100)
GO
USE BIDB_DM1
GO
ALTER DATABASE BIDB_DM1 SET RECOVERY SIMPLE
GO
ALTER DATABASE BIDB_DM1 MODIFY FILEGROUP DataFG DEFAULT
GO
CREATE SCHEMA Datamart
GO
SELECT	IDENTITY(INT, 1, 1) AS SalgId, 
		KundeSkey AS Kunde, 
		MedarbejderID AS Medarbejder, 
		SalgskanalSkey AS Salgskanal, 
		VareSkey AS Vare, 
		LeveringsDato,
		BestillingsDato,
		Antalenheder,
		Antalenheder * Enhedspris AS Prisialt
	INTO Datamart.FactKundeSalgAktueltAar
	FROM BIDB.DataWarehouse.Kundesalg
	WHERE YEAR(BestillingsDato) = YEAR(SYSDATETIME())

SELECT	IDENTITY(INT, 1, 1) AS SalgId, 
		KundeSkey AS Kunde, 
		MedarbejderID AS Medarbejder, 
		SalgskanalSkey AS Salgskanal, 
		VareSkey AS Vare, 
		LeveringsDato,
		BestillingsDato,
		Antalenheder, 
		Antalenheder * Enhedspris AS Prisialt
	INTO Datamart.FactKundeSalgSidsteAar
	FROM BIDB.DataWarehouse.Kundesalg
	WHERE YEAR(BestillingsDato) = YEAR(SYSDATETIME()) - 1
	
SELECT	IDENTITY(INT, 1, 1) AS SalgId,
		KundeSkey AS Kunde, 
		MedarbejderID AS Medarbejder, 
		SalgskanalSkey AS Salgskanal, 
		VareSkey AS Vare, 
		LeveringsDato,
		BestillingsDato,
		Antalenheder, 
		Antalenheder * Enhedspris AS Prisialt
	INTO Datamart.FactKundeSalgMinus2
	FROM BIDB.DataWarehouse.Kundesalg
	WHERE YEAR(BestillingsDato) = YEAR(SYSDATETIME()) - 2
		
SELECT	IDENTITY(INT, 1, 1) AS SalgId,
		KundeSkey AS Kunde, 
		MedarbejderID AS Medarbejder, 
		SalgskanalSkey AS Salgskanal, 
		VareSkey AS Vare, 
		LeveringsDato,
		BestillingsDato,
		Antalenheder, 
		Antalenheder * Enhedspris AS Prisialt
	INTO Datamart.FactKundeSalgMinus3
	FROM BIDB.DataWarehouse.Kundesalg
	WHERE YEAR(BestillingsDato) = YEAR(SYSDATETIME()) - 3

SELECT	IDENTITY(INT, 1, 1) AS SalgId,
		KundeSkey AS Kunde, 
		MedarbejderID AS Medarbejder, 
		SalgskanalSkey AS Salgskanal, 
		VareSkey AS Vare, 
		LeveringsDato,
		BestillingsDato,
		Antalenheder, 
		Antalenheder * Enhedspris AS Prisialt
	INTO Datamart.FactKundeSalgOevrigeAar
	FROM BIDB.DataWarehouse.Kundesalg
	WHERE YEAR(BestillingsDato) < YEAR(SYSDATETIME()) - 3 

ALTER TABLE Datamart.FactKundeSalgSidsteAar 
	ADD CONSTRAINT PK_FactKundeSalgSidsteAar PRIMARY KEY (SalgID)
ALTER TABLE Datamart.FactKundeSalgAktueltAar 
	ADD CONSTRAINT PK_FactKundeSalgAktueltAar PRIMARY KEY (SalgID)
ALTER TABLE Datamart.FactKundeSalgMinus2 
	ADD CONSTRAINT PK_FactKundeSalgMinus2 PRIMARY KEY (SalgID)
ALTER TABLE Datamart.FactKundeSalgMinus3 
	ADD CONSTRAINT PK_FactKundeSalgMinus3 PRIMARY KEY (SalgID)
ALTER TABLE Datamart.FactKundeSalgOevrigeAar 
	ADD CONSTRAINT PK_FactKundeSalgOevrigeAar PRIMARY KEY (SalgID)

CREATE INDEX IX_ALTER_FactKundeSalgSidsteAar_Kunde ON Datamart.FactKundeSalgSidsteAar(Kunde)
CREATE INDEX IX_ALTER_FactKundeSalgAktueltAar_Kunde ON Datamart.FactKundeSalgAktueltAar(Kunde)
CREATE INDEX IX_ALTER_FactKundeSalgMinus2_Kunde ON Datamart.FactKundeSalgMinus2(Kunde)
CREATE INDEX IX_ALTER_FactKundeSalgMinus3_Kunde ON Datamart.FactKundeSalgMinus3(Kunde)
CREATE INDEX IX_ALTER_FactKundeSalgOevrigeAar_Kunde ON Datamart.FactKundeSalgOevrigeAar(Kunde)

CREATE INDEX IX_ALTER_FactKundeSalgSidsteAar_Medarbejder ON Datamart.FactKundeSalgSidsteAar(Medarbejder)
CREATE INDEX IX_ALTER_FactKundeSalgAktueltAar_Medarbejder ON Datamart.FactKundeSalgAktueltAar(Medarbejder)
CREATE INDEX IX_ALTER_FactKundeSalgMinus2_Medarbejder ON Datamart.FactKundeSalgMinus2(Medarbejder)
CREATE INDEX IX_ALTER_FactKundeSalgMinus3_Medarbejder ON Datamart.FactKundeSalgMinus3(Medarbejder)
CREATE INDEX IX_ALTER_FactKundeSalgOevrigeAar_Medarbejder ON Datamart.FactKundeSalgOevrigeAar(Medarbejder)

CREATE INDEX IX_ALTER_FactKundeSalgSidsteAar_Salgskanal ON Datamart.FactKundeSalgSidsteAar(Salgskanal)
CREATE INDEX IX_ALTER_FactKundeSalgAktueltAar_Salgskanal ON Datamart.FactKundeSalgAktueltAar(Salgskanal)
CREATE INDEX IX_ALTER_FactKundeSalgMinus2_Salgskanal ON Datamart.FactKundeSalgMinus2(Salgskanal)
CREATE INDEX IX_ALTER_FactKundeSalgMinus3_Salgskanal ON Datamart.FactKundeSalgMinus3(Salgskanal)
CREATE INDEX IX_ALTER_FactKundeSalgOevrigeAar_Salgskanal ON Datamart.FactKundeSalgOevrigeAar(Salgskanal)

CREATE INDEX IX_ALTER_FactKundeSalgSidsteAar_Vare ON Datamart.FactKundeSalgSidsteAar(Vare)
CREATE INDEX IX_ALTER_FactKundeSalgAktueltAar_Vare ON Datamart.FactKundeSalgAktueltAar(Vare)
CREATE INDEX IX_ALTER_FactKundeSalgMinus2_Vare ON Datamart.FactKundeSalgMinus2(Vare)
CREATE INDEX IX_ALTER_FactKundeSalgMinus3_Vare ON Datamart.FactKundeSalgMinus3(Vare)
CREATE INDEX IX_ALTER_FactKundeSalgOevrigeAar_Vare ON Datamart.FactKundeSalgOevrigeAar(Vare)

CREATE INDEX IX_ALTER_FactKundeSalgSidsteAar_LeveringsDato ON Datamart.FactKundeSalgSidsteAar(LeveringsDato)
CREATE INDEX IX_ALTER_FactKundeSalgAktueltAar_LeveringsDato ON Datamart.FactKundeSalgAktueltAar(LeveringsDato)
CREATE INDEX IX_ALTER_FactKundeSalgMinus2_LeveringsDato ON Datamart.FactKundeSalgMinus2(LeveringsDato)
CREATE INDEX IX_ALTER_FactKundeSalgMinus3_LeveringsDato ON Datamart.FactKundeSalgMinus3(LeveringsDato)
CREATE INDEX IX_ALTER_FactKundeSalgOevrigeAar_LeveringsDato ON Datamart.FactKundeSalgOevrigeAar(LeveringsDato)

CREATE INDEX IX_ALTER_FactKundeSalgSidsteAar_BestillingsDato ON Datamart.FactKundeSalgSidsteAar(BestillingsDato)
CREATE INDEX IX_ALTER_FactKundeSalgAktueltAar_BestillingsDato ON Datamart.FactKundeSalgAktueltAar(BestillingsDato)
CREATE INDEX IX_ALTER_FactKundeSalgMinus2_BestillingsDato ON Datamart.FactKundeSalgMinus2(BestillingsDato)
CREATE INDEX IX_ALTER_FactKundeSalgMinus3_BestillingsDato ON Datamart.FactKundeSalgMinus3(BestillingsDato)
CREATE INDEX IX_ALTER_FactKundeSalgOevrigeAar_BestillingsDato ON Datamart.FactKundeSalgOevrigeAar(BestillingsDato)
GO
SELECT	Kunde.KundeSkey AS Kunde, 
		Kunde.Navn + ' - ' + CAST(Kunde.KundeSkey AS VARCHAR(10)) AS KundeNavn, 
		Kunde.Postnr, CAST(Kunde.Postnr AS VARCHAR(5)) + ' ' + Bynavn AS Bynavn,
		Region.DelRegionID AS DelRegion, 
		Region.DelRegionsnavn, 
		Region.DelRegionSort,
		Region.Regionsnavn AS Region,
		Kunde.Kundetype, 
		Kundetypekode.KundetypeTxt,
		Kunde.Koen, 
		Koen.KoenText
	INTO Datamart.Kunde
	FROM BIDB.DataWarehouse.Kunde	
						INNER JOIN BIDB.DataWarehouse.Postopl ON Kunde.Postnr = Postopl.Postnr
						INNER JOIN BIDB.DataWarehouse.Region ON Postopl.DelRegionID = Region.DelRegionID
						LEFT JOIN BIDB.DataWarehouse.Koen ON Kunde.Koen = Koen.Koen
						LEFT JOIN BIDB.DataWarehouse.Kundetypekode ON Kunde.Kundetype = Kundetypekode.Kundetype
GO
ALTER TABLE Datamart.Kunde ADD CONSTRAINT PK_Kunde PRIMARY KEY (Kunde)
ALTER TABLE Datamart.Kunde ADD CONSTRAINT UQ_Kunde_Navn UNIQUE (KundeNavn)

ALTER TABLE Datamart.FactKundeSalgSidsteAar ALTER COLUMN Kunde INT NULL
ALTER TABLE Datamart.FactKundeSalgAktueltAar ALTER COLUMN Kunde INT NULL
ALTER TABLE Datamart.FactKundeSalgMinus2 ALTER COLUMN Kunde INT NULL
ALTER TABLE Datamart.FactKundeSalgMinus3 ALTER COLUMN Kunde INT NULL
ALTER TABLE Datamart.FactKundeSalgOevrigeAar ALTER COLUMN Kunde INT NULL
GO
ALTER TABLE Datamart.FactKundeSalgSidsteAar ADD CONSTRAINT FK_Kunde_FactKundeSalgSidsteAar
		FOREIGN KEY (Kunde) REFERENCES Datamart.Kunde(Kunde)
		
ALTER TABLE Datamart.FactKundeSalgAktueltAar ADD CONSTRAINT FK_Kunde_FactKundeSalgAktueltAar
		FOREIGN KEY (Kunde) REFERENCES Datamart.Kunde(Kunde)

ALTER TABLE Datamart.FactKundeSalgMinus2 ADD CONSTRAINT FK_Kunde_FactKundeSalgMinus2
		FOREIGN KEY (Kunde) REFERENCES Datamart.Kunde(Kunde)
	
ALTER TABLE Datamart.FactKundeSalgMinus3 ADD CONSTRAINT FK_Kunde_FactKundeSalgMinus3
		FOREIGN KEY (Kunde) REFERENCES Datamart.Kunde(Kunde)
	
ALTER TABLE Datamart.FactKundeSalgOevrigeAar ADD CONSTRAINT FK_Kunde_FactKundeSalgOevrigeAar
		FOREIGN KEY (Kunde) REFERENCES Datamart.Kunde(Kunde)
GO
SELECT	SalgskanalId AS SalgsKanal, 
		SalgskanalNavn, 
		SorteringsOrden
	INTO Datamart.Salgskanal
	FROM BIDB.DataWarehouse.Salgskanal
GO
ALTER TABLE Datamart.Salgskanal ADD CONSTRAINT PK_Salgskanal PRIMARY KEY (Salgskanal)
ALTER TABLE Datamart.Salgskanal ADD CONSTRAINT UQ_Salgskanal_SalgskanalNavn UNIQUE (SalgskanalNavn)

ALTER TABLE Datamart.FactKundeSalgSidsteAar ADD CONSTRAINT FK_Salgskanal_FactKundeSalgSidsteAar
		FOREIGN KEY (Salgskanal) REFERENCES Datamart.Salgskanal(Salgskanal)
		
ALTER TABLE Datamart.FactKundeSalgAktueltAar ADD CONSTRAINT FK_Salgskanal_FactKundeSalgAktueltAar
		FOREIGN KEY (Salgskanal) REFERENCES Datamart.Salgskanal(Salgskanal)

ALTER TABLE Datamart.FactKundeSalgMinus2 ADD CONSTRAINT FK_Salgskanal_FactKundeSalgMinus2
		FOREIGN KEY (Salgskanal) REFERENCES Datamart.Salgskanal(Salgskanal)
		
ALTER TABLE Datamart.FactKundeSalgMinus3 ADD CONSTRAINT FK_Salgskanal_FactKundeSalgMinus3
		FOREIGN KEY (Salgskanal) REFERENCES Datamart.Salgskanal(Salgskanal)
		
ALTER TABLE Datamart.FactKundeSalgOevrigeAar ADD CONSTRAINT FK_Salgskanal_FactKundeSalgOevrigeAar
		FOREIGN KEY (Salgskanal) REFERENCES Datamart.Salgskanal(Salgskanal)
GO
SELECT	Vare.VareSkey AS Vare, 
		Vare.Varenavn, 
		Vare.VejledendePris,
		Vare.IndkoebsType,
		SubKategori.SubKategoriID AS SubKategori, 
		SubKategori.SubKategoriNavn,
		Kategori.KategoriID AS Kategori, 
		Kategori.KategoriNavn
	INTO Datamart.Vare
	FROM BIDB.DataWarehouse.Vare 
				INNER JOIN BIDB.DataWarehouse.Subkategori ON Vare.SubkategoriSkey = SubKategori.SubKategoriSkey
				INNER JOIN BIDB.DataWarehouse.Kategori ON SubKategori.KategoriSkey = Kategori.KategoriSkey
GO
ALTER TABLE Datamart.Vare ADD CONSTRAINT PK_Vare PRIMARY KEY (Vare)
ALTER TABLE Datamart.Vare ADD CONSTRAINT UQ_Vare_Varenavn UNIQUE (Varenavn)

ALTER TABLE Datamart.FactKundeSalgSidsteAar ADD CONSTRAINT FK_Vare_FactKundeSalgSidsteAar
		FOREIGN KEY (Vare) REFERENCES Datamart.Vare(Vare)
		
ALTER TABLE Datamart.FactKundeSalgAktueltAar ADD CONSTRAINT FK_Vare_FactKundeSalgAktueltAar
		FOREIGN KEY (Vare) REFERENCES Datamart.Vare(Vare)

ALTER TABLE Datamart.FactKundeSalgMinus2 ADD CONSTRAINT FK_Vare_FactKundeSalgMinus2
		FOREIGN KEY (Vare) REFERENCES Datamart.Vare(Vare)
		
ALTER TABLE Datamart.FactKundeSalgMinus3 ADD CONSTRAINT FK_Vare_FactKundeSalgMinus3
		FOREIGN KEY (Vare) REFERENCES Datamart.Vare(Vare)
		
ALTER TABLE Datamart.FactKundeSalgOevrigeAar ADD CONSTRAINT FK_Vare_FactKundeSalgOevrigeAar
		FOREIGN KEY (Vare) REFERENCES Datamart.Vare(Vare)
GO
SELECT	MedarbejderID AS Medarbejder, 
		Fornavn + ' ' + Efternavn + ' - ' + CAST(MedarbejderID AS VARCHAR(5)) AS Navn, 
		ChefId
	INTO Datamart.Medarbejder
	FROM BIDB.DataWarehouse.Medarbejder
GO
ALTER TABLE Datamart.Medarbejder ADD CONSTRAINT PK_Medarbejder PRIMARY KEY (Medarbejder)
ALTER TABLE Datamart.Medarbejder ADD CONSTRAINT UQ_Medarbejder_Navn UNIQUE (Navn)

ALTER TABLE Datamart.Medarbejder ADD CONSTRAINT FK_Medarbejder_Medarbejder_ChefID
		FOREIGN KEY (ChefID) REFERENCES Datamart.Medarbejder(Medarbejder)

ALTER TABLE Datamart.FactKundeSalgSidsteAar ADD CONSTRAINT FK_Medarbejder_FactKundeSalgSidsteAar
		FOREIGN KEY (Medarbejder) REFERENCES Datamart.Medarbejder(Medarbejder)
		
ALTER TABLE Datamart.FactKundeSalgAktueltAar ADD CONSTRAINT FK_Medarbejder_FactKundeSalgAktueltAar
		FOREIGN KEY (Medarbejder) REFERENCES Datamart.Medarbejder(Medarbejder)

ALTER TABLE Datamart.FactKundeSalgMinus2 ADD CONSTRAINT FK_Medarbejder_FactKundeSalgMinus2
		FOREIGN KEY (Medarbejder) REFERENCES Datamart.Medarbejder(Medarbejder)
		
ALTER TABLE Datamart.FactKundeSalgMinus3 ADD CONSTRAINT FK_Medarbejder_FactKundeSalgMinus3
		FOREIGN KEY (Medarbejder) REFERENCES Datamart.Medarbejder(Medarbejder)
		
ALTER TABLE Datamart.FactKundeSalgOevrigeAar ADD CONSTRAINT FK_Medarbejder_FactKundeSalgOevrigeAar
		FOREIGN KEY (Medarbejder) REFERENCES Datamart.Medarbejder(Medarbejder)
GO
SELECT	TidSkey AS Tid, 
		CAST(Dato AS DATE) AS Dato, 
		Aar,
		Aar * 100 + KvartalsNr AS KvartalsNr,
		'Kvartal ' + CAST(KvartalsNr AS VARCHAR(5)) + ' - ' + CAST(Aar AS VARCHAR(5)) AS KvartalsNavn, 
		Aar * 100 + MaanedsNr AS MaanedsNr, 
		MaanedsNavn + ' ' + CAST(Aar AS VARCHAR(5)) AS MaanedsNavn, 
		DagNrIMaaned, 
		DagnrIUge, 
		DagNavn
	INTO Datamart.Kalender
	FROM BIDB.DataWarehouse.Tid
	WHERE Dato BETWEEN	(SELECT MIN(BestillingsDato) FROM Datamart.FactKundeSalgOevrigeAar) AND
						(SELECT MAX(LeveringsDato) FROM Datamart.FactKundeSalgAktueltAar)
GO
ALTER TABLE Datamart.Kalender ADD CONSTRAINT PK_Kalender PRIMARY KEY (Tid)
ALTER TABLE Datamart.Kalender ADD CONSTRAINT UQ_Kalender_dato UNIQUE(Dato)

ALTER TABLE Datamart.FactKundeSalgSidsteAar ADD CONSTRAINT FK_Kalender_FactKundeSalgSidsteAar_LeveringsDato
		FOREIGN KEY (LeveringsDato) REFERENCES Datamart.Kalender(Dato)

ALTER TABLE Datamart.FactKundeSalgSidsteAar ADD CONSTRAINT FK_Kalender_FactKundeSalgSidsteAar_BestillingsDato
		FOREIGN KEY (BestillingsDato) REFERENCES Datamart.Kalender(Dato)

ALTER TABLE Datamart.FactKundeSalgAktueltAar ADD CONSTRAINT FK_Kalender_FactKundeSalgAktueltAar_LeveringsDato
		FOREIGN KEY (LeveringsDato) REFERENCES Datamart.Kalender(Dato)
		
ALTER TABLE Datamart.FactKundeSalgAktueltAar ADD CONSTRAINT FK_Kalender_FactKundeSalgAktueltAar_BestillingsDato
		FOREIGN KEY (BestillingsDato) REFERENCES Datamart.Kalender(Dato)
		
ALTER TABLE Datamart.FactKundeSalgMinus2 ADD CONSTRAINT FK_Kalender_FactKundeSalgMinus2_LeveringsDato
		FOREIGN KEY (LeveringsDato) REFERENCES Datamart.Kalender(Dato)
		
ALTER TABLE Datamart.FactKundeSalgMinus2 ADD CONSTRAINT FK_Kalender_FactKundeSalgMinus2_BestillingsDato
		FOREIGN KEY (BestillingsDato) REFERENCES Datamart.Kalender(Dato)

ALTER TABLE Datamart.FactKundeSalgMinus3 ADD CONSTRAINT FK_Kalender_FactKundeSalgMinus3_LeveringsDato
		FOREIGN KEY (LeveringsDato) REFERENCES Datamart.Kalender(Dato)
		
ALTER TABLE Datamart.FactKundeSalgMinus3 ADD CONSTRAINT FK_Kalender_FactKundeSalgMinus3_BestillingsDato
		FOREIGN KEY (BestillingsDato) REFERENCES Datamart.Kalender(Dato)

ALTER TABLE Datamart.FactKundeSalgOevrigeAar ADD CONSTRAINT FK_Kalender_FactKundeSalgOevrigeAar_LeveringsDato
		FOREIGN KEY (LeveringsDato) REFERENCES Datamart.Kalender(Dato)
		
ALTER TABLE Datamart.FactKundeSalgOevrigeAar ADD CONSTRAINT FK_Kalender_FactKundeSalgOevrigeAar_BestillingsDato
		FOREIGN KEY (BestillingsDato) REFERENCES Datamart.Kalender(Dato)	
GO
SELECT	VareSkey AS Vare,
		SalgskanalID AS SalgsKanal,
		Aar,
		MaanedsNr,
		AntalEnheder
	INTO Datamart.SalgsBudget
	FROM BIDB.DataWarehouse.SalgsBudget INNER JOIN BIDB.DataWarehouse.Salgskanal ON SalgsBudget.SalgskanalSkey = Salgskanal.SalgskanalSkey
GO

ALTER TABLE Datamart.SalgsBudget ADD CONSTRAINT FK_SalgsBudget_Vare
		FOREIGN KEY (Vare) REFERENCES Datamart.Vare(Vare)	

ALTER TABLE Datamart.SalgsBudget ADD CONSTRAINT FK_SalgsBudget_SalgsKanal
		FOREIGN KEY (SalgsKanal) REFERENCES Datamart.Salgskanal(SalgsKanal)

GO
UPDATE Datamart.FactKundeSalgAktueltAar
	SET Salgskanal = 0
	WHERE Salgskanal IS NULL

UPDATE Datamart.FactKundeSalgSidsteAar
	SET Salgskanal = 0
	WHERE Salgskanal IS NULL

UPDATE Datamart.FactKundeSalgMinus2
	SET Salgskanal = 0
	WHERE Salgskanal IS NULL

UPDATE Datamart.FactKundeSalgMinus3
	SET Salgskanal = 0
	WHERE Salgskanal IS NULL

UPDATE Datamart.FactKundeSalgOevrigeAar
	SET Salgskanal = 0
	WHERE Salgskanal IS NULL
GO
-- vis alle tabeller og antal forekomster
USE BIDB_DM1
GO
SET NOCOUNT ON
DECLARE @TableName		SYSNAME
DECLARE @SchemaName		SYSNAME
DECLARE @Antal			INT
DECLARE @SQLString		NVARCHAR(500);

DECLARE @t TABLE(
	ID					INT NOT NULL IDENTITY,
	Object_id			INT NOT NULL,
	TableName			SYSNAME NOT NULL,
	SchemaName			SYSNAME NOT NULL,
	AntalForekomster	INT NULL,
	Brugt				CHAR(1) DEFAULT('N'))

INSERT INTO @t (Object_id, TableName, SchemaName)
	SELECT t.object_id, t.name, s.name 
		FROM sys.tables as t INNER JOIN sys.schemas as s 
			ON t.schema_id = s.schema_id
		ORDER BY t.name

WHILE EXISTS (SELECT * FROM @t WHERE Brugt = 'N')
BEGIN
	SELECT	@TableName = TableName, 
			@SchemaName = SchemaName
		FROM @t
		WHERE ID = (SELECT MIN(ID) 
						FROM @t 
						WHERE Brugt = 'N')
		
	SET @SQLString = 'SET @Antal = (SELECT COUNT(*) FROM ' + @SchemaName + '.' + @TableName + ')'
	EXECUTE sp_executesql @SqlString, N'@Antal INT OUTPUT', @Antal OUTPUT

	UPDATE @t
		SET AntalForekomster = @Antal, Brugt = 'Y'
		WHERE	TableName = @TableName AND 
				SchemaName = @SchemaName
END
SELECT TableName, SchemaName, AntalForekomster 
	FROM @t
	ORDER BY SchemaName, TableName
GO
