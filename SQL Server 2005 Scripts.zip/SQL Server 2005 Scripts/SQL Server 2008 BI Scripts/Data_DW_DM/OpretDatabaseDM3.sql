--- Datamart 3
USE master
GO
IF EXISTS (SELECT * FROM master.sys.databases WHERE name = 'BIDB_DM3')
	DROP DATABASE BIDB_DM3
GO
CREATE DATABASE BIDB_DM3
ON PRIMARY
	(NAME = N'BIDB_DM3_Sys', 
	FILENAME = N'c:\Databaser\BIDB_DM3_Data.MDF', 
	SIZE = 5,
	FILEGROWTH = 10%),
FILEGROUP DataFG
	(NAME = N'BIDB_DM3_Data1', 
	FILENAME = N'c:\Databaser\BIDB_DM3_DataFG_Fil1.NDF', 
	SIZE = 10,
	FILEGROWTH = 25%)
LOG ON 
	(NAME = N'BIDB_DM3_Log',
	FILENAME = N'c:\Databaser\BIDB_DM3_Log.LDF', 
	SIZE = 10,
	FILEGROWTH = 10)
GO
USE BIDB_DM3
GO
ALTER DATABASE BIDB_DM3 SET RECOVERY SIMPLE
GO
ALTER DATABASE BIDB_DM3 MODIFY FILEGROUP DataFG DEFAULT
GO
CREATE SCHEMA Datamart
GO
SELECT	CAST(Dato AS DATE) AS Tid,
		CAST(DATEPART(week, Dato) AS VARCHAR(5)) + ' - ' + CAST(Aar AS VARCHAR(5)) AS Uge,
		DagnrIUge, 
		DagNavn
	INTO Datamart.Tid
	FROM BIDB.DataWarehouse.Tid
	WHERE	Dato >= DATEADD(m, -12,SYSDATETIME()) AND 
			Dato <= SYSDATETIME()
			
SELECT	Vare.VareSkey AS Vare,
		Vare.Varenavn,
		Vare.SubKategoriSkey AS Subkategori,
		SubKategorinavn,
		Vare.Vejledendepris
	INTO Datamart.Vare
	FROM BIDB.DataWarehouse.Vare	
				INNER JOIN BIDB.DataWarehouse.Subkategori ON Vare.SubKategoriSkey = Subkategori.SubkategoriSkey
	WHERE IndkoebsType = 'I'
GO
SELECT	LeveringsDato,
		VareSkey AS Vare, 
		Region.RegionsNavn AS Region,
		SUM(KundeSalg.AntalEnheder) AS AntalEnheder,
		SUM(KundeSalg.AntalEnheder * KundeSalg.Enhedspris) AS PrisIalt
	INTO Datamart.KundeSalg
	FROM BIDB.DataWarehouse.KundeSalg	
				INNER JOIN BIDB.DataWarehouse.Kunde ON KundeSalg.KundeSkey = Kunde.KundeSkey
				INNER JOIN BIDB.DataWarehouse.Postopl ON Kunde.Postnr = Postopl.Postnr
				INNER JOIN BIDB.DataWarehouse.Region ON Postopl.DelRegionID = Region.DelRegionID
	WHERE	LeveringsDato IN (SELECT Tid FROM Datamart.Tid) AND
			VareSkey IN (SELECT Vare FROM Datamart.Vare)
	GROUP BY LeveringsDato, VareSkey, Regionsnavn
GO
ALTER TABLE Datamart.Tid 
		ALTER COLUMN Tid DATE NOT NULL
GO
ALTER TABLE Datamart.Tid 		
	ADD CONSTRAINT PK__Datamart_Tid PRIMARY KEY (Tid)
ALTER TABLE Datamart.Vare 
	ADD CONSTRAINT PK__Datamart_Vare PRIMARY KEY (Vare)
ALTER TABLE Datamart.Kundesalg 
	ADD CONSTRAINT PK__Datamart_KundeSalg PRIMARY KEY (LeveringsDato, Vare, Region)
ALTER TABLE Datamart.Kundesalg 
	ADD CONSTRAINT FK__Datamart_KundeSalg_Vare 
	FOREIGN KEY (Vare) REFERENCES Datamart.Vare(Vare)
ALTER TABLE Datamart.Kundesalg 
	ADD CONSTRAINT FK__Datamart_KundeSalg_Tid
	FOREIGN KEY (LeveringsDato) REFERENCES Datamart.Tid(Tid)
GO
-- vis alle tabeller og antal forekomster
USE BIDB_DM3
GO
SET NOCOUNT ON
DECLARE @TableName		SYSNAME
DECLARE @SchemaName		SYSNAME
DECLARE @Antal			INT
DECLARE @SQLString		NVARCHAR(500);

DECLARE @t TABLE(
	ID					INT NOT NULL IDENTITY,
	Object_id			INT NOT NULL,
	TableName			SYSNAME NOT NULL,
	SchemaName			SYSNAME NOT NULL,
	AntalForekomster	INT NULL,
	Brugt				CHAR(1) DEFAULT('N'))

INSERT INTO @t (Object_id, TableName, SchemaName)
	SELECT t.object_id, t.name, s.name 
		FROM sys.tables as t INNER JOIN sys.schemas as s 
			ON t.schema_id = s.schema_id
		ORDER BY t.name

WHILE EXISTS (SELECT * FROM @t WHERE Brugt = 'N')
BEGIN
	SELECT	@TableName = TableName, 
			@SchemaName = SchemaName
		FROM @t
		WHERE ID = (SELECT MIN(ID) FROM @t WHERE Brugt = 'N')
		
	SET @SQLString = 'SET @Antal = (SELECT COUNT(*) FROM ' + @SchemaName + '.' + @TableName + ')'
	EXECUTE sp_executesql @SqlString, N'@Antal INT OUTPUT', @Antal OUTPUT

	UPDATE @t
		SET AntalForekomster = @Antal, Brugt = 'Y'
		WHERE	TableName = @TableName AND 
				SchemaName = @SchemaName
END
SELECT TableName, SchemaName, AntalForekomster 
	FROM @t
	ORDER BY SchemaName, TableName
GO
