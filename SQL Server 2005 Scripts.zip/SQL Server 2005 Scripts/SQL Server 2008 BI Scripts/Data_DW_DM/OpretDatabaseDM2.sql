--- Datamart 2
USE master
GO
IF EXISTS (SELECT * FROM master.sys.databases WHERE name = 'BIDB_DM2')
DROP DATABASE BIDB_DM2
GO
CREATE DATABASE BIDB_DM2
ON PRIMARY
	(NAME = N'BIDB_DM2_Sys', 
	FILENAME = N'c:\Databaser\BIDB_DM2_Data.MDF', 
	SIZE = 40,
	FILEGROWTH = 10%),
FILEGROUP DataFG
	(NAME = N'BIDB_DM2_Data1', 
	FILENAME = N'c:\Databaser\BIDB_DM2_DataFG_Fil1.NDF', 
	SIZE = 100,
	FILEGROWTH = 25%)
LOG ON 
	(NAME = N'BIDB_DM2_Log',
	FILENAME = N'c:\Databaser\BIDB_DM2_Log.LDF', 
	SIZE = 50,
	FILEGROWTH = 10)
GO
USE BIDB_DM2
GO
ALTER DATABASE BIDB_DM2 SET RECOVERY SIMPLE
GO
ALTER DATABASE BIDB_DM2 MODIFY FILEGROUP DataFG DEFAULT
GO
CREATE SCHEMA Datamart
GO
SELECT	MedarbejderID AS Medarbejder, 
		Fornavn +  ' ' + Efternavn + ' - ' + CAST(MedarbejderID AS VARCHAR(10)) AS Navn,
		ChefId
	INTO Datamart.Medarbejder
	FROM BIDB.DataWarehouse.Medarbejder
	WHERE MedarbejderID IN (SELECT MedarbejderID FROM BIDB.DataWarehouse.KundeSalg)

SELECT	Vare.VareSkey AS Vare, 
		Vare.Varenavn, 
		Vare.VejledendePris,
		SubKategori.SubKategoriID AS Subkategori, 
		SubKategori.SubKategoriNavn,
		Kategori.KategoriID AS Kategori, 
		Kategori.KategoriNavn
	INTO Datamart.Vare
	FROM BIDB.DataWarehouse.Vare	INNER JOIN BIDB.DataWarehouse.Subkategori ON Vare.SubkategoriSkey = SubKategori.SubKategoriSkey
									INNER JOIN BIDB.DataWarehouse.Kategori ON SubKategori.KategoriSkey = Kategori.KategoriSkey
SELECT	BKunde.KundeBkey AS Kunde,
		NyesteKundeOpl.Navn,
		NyesteKundeOpl.Koen,
		NyesteKundeOpl.Kundetype,
		NyesteKundeOpl.Postnr
	INTO Datamart.Kunde
	FROM (SELECT DISTINCT KundeBkey 
			FROM BIDB.DataWarehouse.Kunde
			WHERE EXISTS (SELECT *
							FROM BIDB.DataWarehouse.KundeSalg
							WHERE Kunde.KundeSkey = KundeSalg.KundeSkey)) AS BKunde
			CROSS APPLY 
			(SELECT TOP 1 Navn + ' - ' + CAST(KundeBKey AS VARCHAR(10)) AS Navn, 
					Kundetype,
					Koen,
					Postnr 
				FROM BIDB.DataWarehouse.Kunde
				WHERE	BKunde.KundeBkey = Kunde.KundeBkey AND 
						GaeldendeTil IS NULL) AS NyesteKundeOpl
GO
SELECT	KundeSalg.VareSkey AS Vare,
		MedarbejderID AS Medarbejder,
		Kunde.KundeBkey AS Kunde,
		SUM(KundeSalg.AntalEnheder) AS AntalEnheder
	INTO Datamart.KundeSalg
	FROM BIDB.DataWarehouse.KundeSalg INNER JOIN BIDB.DataWarehouse.Kunde ON KundeSalg.KundeSkey = Kunde.KundeSkey
	GROUP BY KundeSalg.VareSkey, MedarbejderID, Kunde.KundeBkey
GO
ALTER TABLE Datamart.Medarbejder 
	ADD CONSTRAINT PK__Datamart_Medarbejder PRIMARY KEY (Medarbejder)
ALTER TABLE Datamart.Vare 
	ADD CONSTRAINT PK__Datamart_Vare PRIMARY KEY (Vare)
ALTER TABLE Datamart.Kunde 
	ADD CONSTRAINT PK__Datamart_Kunde PRIMARY KEY (Kunde)
ALTER TABLE Datamart.Kundesalg 
	ADD CONSTRAINT PK__Datamart_KundeSalg UNIQUE (Medarbejder, Vare, Kunde)
ALTER TABLE Datamart.Kundesalg 
	ADD CONSTRAINT FK__Datamart_KundeSalg_Vare 
	FOREIGN KEY (Vare) REFERENCES Datamart.Vare(Vare)
ALTER TABLE Datamart.Kundesalg 
	ADD CONSTRAINT FK__Datamart_KundeSalg_Medarbejder
	FOREIGN KEY (Medarbejder) REFERENCES Datamart.Medarbejder(Medarbejder)
ALTER TABLE Datamart.Kundesalg 
	ADD CONSTRAINT FK__Datamart_KundeSalg_Kunde
	FOREIGN KEY (Kunde) REFERENCES Datamart.Kunde(Kunde)
GO
-- vis alle tabeller og antal forekomster
USE BIDB_DM2
GO
SET NOCOUNT ON
DECLARE @TableName		SYSNAME
DECLARE @SchemaName		SYSNAME
DECLARE @Antal			INT
DECLARE @SQLString		NVARCHAR(500);

DECLARE @t TABLE(
	ID					INT NOT NULL IDENTITY,
	Object_id			INT NOT NULL,
	TableName			SYSNAME NOT NULL,
	SchemaName			SYSNAME NOT NULL,
	AntalForekomster	INT NULL,
	Brugt				CHAR(1) DEFAULT('N'))

INSERT INTO @t (Object_id, TableName, SchemaName)
	SELECT t.object_id, t.name, s.name 
		FROM sys.tables as t INNER JOIN sys.schemas as s 
			ON t.schema_id = s.schema_id
		ORDER BY t.name

WHILE EXISTS (SELECT * FROM @t WHERE Brugt = 'N')
BEGIN
	SELECT	@TableName = TableName, 
			@SchemaName = SchemaName
		FROM @t
		WHERE ID = (SELECT MIN(ID) FROM @t WHERE Brugt = 'N')
		
	SET @SQLString = 'SET @Antal = (SELECT COUNT(*) FROM ' + @SchemaName + '.' + @TableName + ')'
	EXECUTE sp_executesql @SqlString, N'@Antal INT OUTPUT', @Antal OUTPUT

	UPDATE @t
		SET AntalForekomster = @Antal, Brugt = 'Y'
		WHERE TableName = @TableName AND SchemaName = @SchemaName
END
SELECT TableName, SchemaName, AntalForekomster 
	FROM @t
	ORDER BY SchemaName, TableName
GO
