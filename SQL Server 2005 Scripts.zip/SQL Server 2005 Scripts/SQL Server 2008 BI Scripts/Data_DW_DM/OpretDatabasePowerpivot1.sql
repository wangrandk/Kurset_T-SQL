--- Datamart PowerPivot1
USE master
GO
IF EXISTS (SELECT * FROM master.sys.databases WHERE name = 'BIDBPowerPivot1')
	DROP DATABASE BIDBPowerPivot1
GO
CREATE DATABASE BIDBPowerPivot1
ON PRIMARY
	(NAME = N'BIDBPowerPivot1_Sys',
	FILENAME = N'c:\Databaser\BIDBPowerPivot1_Data.MDF', 
	SIZE = 5,
	FILEGROWTH = 10%),
FILEGROUP DataFG
	(NAME = N'BIDBPowerPivot1_Data1',
	FILENAME = N'c:\Databaser\BIDBPowerPivot1_DataFG_Fil1.NDF', 
	SIZE = 150,
	FILEGROWTH = 25%),

	(NAME = N'BIDBPowerPivot1_Data2', 
	FILENAME = N'c:\Databaser\BIDBPowerPivot1_DataFG_Fil2.NDF', 
	SIZE = 150,
	FILEGROWTH = 25%),

	(NAME = N'BIDBPowerPivot1_Data3', 
	FILENAME = N'c:\Databaser\BIDBPowerPivot1_DataFG_Fil3.NDF', 
	SIZE = 150,
	FILEGROWTH = 25%),

	(NAME = N'BIDBPowerPivot1_Data4', 
	FILENAME = N'c:\Databaser\BIDBPowerPivot1_DataFG_Fil4.NDF', 
	SIZE = 150,
	FILEGROWTH = 25%)

LOG ON 
	(NAME = N'BIDBPowerPivot1_Log',
	FILENAME = N'c:\Databaser\BIDBPowerPivot1_Log.LDF', 
	SIZE = 100,
	FILEGROWTH = 100)
GO
USE BIDBPowerPivot1
GO
ALTER DATABASE BIDBPowerPivot1 SET RECOVERY SIMPLE
GO
ALTER DATABASE BIDBPowerPivot1 MODIFY FILEGROUP DataFG DEFAULT
GO
CREATE SCHEMA Datamart
GO
SELECT	IDENTITY(INT, 1, 1) AS SalgId, 
		KundeSkey AS Kunde, 
		MedarbejderID AS Medarbejder, 
		SalgskanalId AS Salgskanal, 
		VareSkey AS Vare, 
		LeveringsDato,
		BestillingsDato,
		Antalenheder,
		Antalenheder * Enhedspris AS Prisialt
	INTO Datamart.FactKundeSalg
	FROM BIDB.DataWarehouse.Kundesalg INNER JOIN BIDB.DataWarehouse.Salgskanal 
			ON BIDB.DataWarehouse.Kundesalg.SalgskanalSkey = BIDB.DataWarehouse.Salgskanal.SalgskanalSkey
			
ALTER TABLE Datamart.FactKundeSalg
	ADD CONSTRAINT PK_FactKundeSalg PRIMARY KEY (SalgID)

CREATE INDEX IX_FactKundeSalg_Kunde ON Datamart.FactKundeSalg(Kunde)

CREATE INDEX IX_FactKundeSalg_Medarbejder ON Datamart.FactKundeSalg(Medarbejder)

CREATE INDEX IX_FactKundeSalg_Salgskanal ON Datamart.FactKundeSalg(Salgskanal)

CREATE INDEX IX_FactKundeSalg_Vare ON Datamart.FactKundeSalg(Vare)

CREATE INDEX IX_FactKundeSalg_LeveringsDato ON Datamart.FactKundeSalg(LeveringsDato)

CREATE INDEX IX_FactKundeSalg_BestillingsDato ON Datamart.FactKundeSalg(BestillingsDato)
GO
SELECT	Kunde.KundeSkey AS Kunde, 
		Kunde.Navn + ' - ' + CAST(Kunde.KundeSkey AS VARCHAR(10)) AS KundeNavn, 
		Kunde.Postnr, CAST(Kunde.Postnr AS VARCHAR(5)) + ' ' + Bynavn AS Bynavn,
		Region.DelRegionID AS DelRegion, 
		Region.DelRegionsnavn, 
		Region.DelRegionSort,
		Region.Regionsnavn AS Region,
		Kundetypekode.Kundetype, 
		Koen.Koen
	INTO Datamart.Kunde
	FROM BIDB.DataWarehouse.Kunde	
						INNER JOIN BIDB.DataWarehouse.Postopl ON Kunde.Postnr = Postopl.Postnr
						INNER JOIN BIDB.DataWarehouse.Region ON Postopl.DelRegionID = Region.DelRegionID
						LEFT JOIN BIDB.DataWarehouse.Koen ON Kunde.Koen = Koen.Koen
						LEFT JOIN BIDB.DataWarehouse.Kundetypekode ON Kunde.Kundetype = Kundetypekode.Kundetype
GO
ALTER TABLE Datamart.Kunde ADD CONSTRAINT PK_Kunde PRIMARY KEY (Kunde)
ALTER TABLE Datamart.Kunde ADD CONSTRAINT UQ_Kunde_Navn UNIQUE (KundeNavn)

ALTER TABLE Datamart.FactKundeSalg ALTER COLUMN Kunde INT NULL

SELECT	Koen,
		KoenText
	INTO Datamart.Koen
	FROM BIDB.DataWarehouse.Koen
	
ALTER TABLE Datamart.Koen ADD CONSTRAINT PK_Koen PRIMARY KEY (Koen)

ALTER TABLE Datamart.Kunde ADD CONSTRAINT FK_Kunde_Koen
		FOREIGN KEY (Koen) REFERENCES Datamart.Koen(Koen)

SELECT	Kundetype,
		Kundetypetxt
	INTO Datamart.Kundetype
	FROM BIDB.DataWarehouse.Kundetypekode
	
ALTER TABLE Datamart.Kundetype ADD CONSTRAINT PK_Kundetype PRIMARY KEY (Kundetype)

ALTER TABLE Datamart.Kunde ADD CONSTRAINT FK_Kunde_Kundetype
		FOREIGN KEY (Kundetype) REFERENCES Datamart.Kundetype(Kundetype)

CREATE INDEX IX_Kunde_Koen ON Datamart.Kunde(Koen)

CREATE INDEX IX_Kunde_Kundetype ON Datamart.Kunde(Kundetype)
GO
ALTER TABLE Datamart.FactKundeSalg ADD CONSTRAINT FK_Kunde_FactKundeSalg
		FOREIGN KEY (Kunde) REFERENCES Datamart.Kunde(Kunde)
GO
SELECT	SalgskanalId AS SalgsKanal, 
		SalgskanalNavn, 
		SorteringsOrden
	INTO Datamart.Salgskanal
	FROM BIDB.DataWarehouse.Salgskanal
GO
ALTER TABLE Datamart.Salgskanal ADD CONSTRAINT PK_Salgskanal PRIMARY KEY (Salgskanal)
ALTER TABLE Datamart.Salgskanal ADD CONSTRAINT UQ_Salgskanal_SalgskanalNavn UNIQUE (SalgskanalNavn)

ALTER TABLE Datamart.FactKundeSalg ADD CONSTRAINT FK_Salgskanal_FactKundeSalg
		FOREIGN KEY (Salgskanal) REFERENCES Datamart.Salgskanal(Salgskanal)
GO
SELECT	Vare.VareSkey AS Vare, 
		Vare.Varenavn, 
		Vare.VejledendePris,
		Vare.IndkoebsType,
		SubKategori.SubKategoriID AS SubKategori, 
		SubKategori.SubKategoriNavn,
		Kategori.KategoriID AS Kategori, 
		Kategori.KategoriNavn
	INTO Datamart.Vare
	FROM BIDB.DataWarehouse.Vare 
				INNER JOIN BIDB.DataWarehouse.Subkategori ON Vare.SubkategoriSkey = SubKategori.SubKategoriSkey
				INNER JOIN BIDB.DataWarehouse.Kategori ON SubKategori.KategoriSkey = Kategori.KategoriSkey
GO
ALTER TABLE Datamart.Vare ADD CONSTRAINT PK_Vare PRIMARY KEY (Vare)
ALTER TABLE Datamart.Vare ADD CONSTRAINT UQ_Vare_Varenavn UNIQUE (Varenavn)

ALTER TABLE Datamart.FactKundeSalg ADD CONSTRAINT FK_Vare_FactKundeSalg
		FOREIGN KEY (Vare) REFERENCES Datamart.Vare(Vare)
GO
SELECT	MedarbejderID AS Medarbejder, 
		Fornavn + ' ' + Efternavn + ' - ' + CAST(MedarbejderID AS VARCHAR(5)) AS Navn, 
		ChefId
	INTO Datamart.Medarbejder
	FROM BIDB.DataWarehouse.Medarbejder
GO
ALTER TABLE Datamart.Medarbejder ADD CONSTRAINT PK_Medarbejder PRIMARY KEY (Medarbejder)
ALTER TABLE Datamart.Medarbejder ADD CONSTRAINT UQ_Medarbejder_Navn UNIQUE (Navn)

ALTER TABLE Datamart.Medarbejder ADD CONSTRAINT FK_Medarbejder_Medarbejder_ChefID
		FOREIGN KEY (ChefID) REFERENCES Datamart.Medarbejder(Medarbejder)

ALTER TABLE Datamart.FactKundeSalg ADD CONSTRAINT FK_Medarbejder_FactKundeSalg
		FOREIGN KEY (Medarbejder) REFERENCES Datamart.Medarbejder(Medarbejder)
GO
SELECT	TidSkey AS Tid, 
		CAST(Dato AS DATE) AS Dato, 
		Aar,
		Aar * 100 + KvartalsNr AS KvartalsNr,
		'Kvartal ' + CAST(KvartalsNr AS VARCHAR(5)) + ' - ' + CAST(Aar AS VARCHAR(5)) AS KvartalsNavn, 
		Aar * 100 + MaanedsNr AS MaanedsNr, 
		MaanedsNavn + ' ' + CAST(Aar AS VARCHAR(5)) AS MaanedsNavn, 
		DagNrIMaaned, 
		DagnrIUge, 
		DagNavn
	INTO Datamart.Kalender
	FROM BIDB.DataWarehouse.Tid
	WHERE Dato BETWEEN	(SELECT MIN(BestillingsDato) FROM Datamart.FactKundeSalg) AND
						(SELECT MAX(LeveringsDato) FROM Datamart.FactKundeSalg)
GO
ALTER TABLE Datamart.Kalender ADD CONSTRAINT PK_Kalender PRIMARY KEY (Tid)
ALTER TABLE Datamart.Kalender ADD CONSTRAINT UQ_Kalender_dato UNIQUE(Dato)

ALTER TABLE Datamart.FactKundeSalg ADD CONSTRAINT FK_Kalender_FactKundeSalg_LeveringsDato
		FOREIGN KEY (LeveringsDato) REFERENCES Datamart.Kalender(Dato)

ALTER TABLE Datamart.FactKundeSalg ADD CONSTRAINT FK_Kalender_FactKundeSalg_BestillingsDato
		FOREIGN KEY (BestillingsDato) REFERENCES Datamart.Kalender(Dato)
GO
SELECT	VareSkey AS Vare,
		SalgskanalID AS SalgsKanal,
		Aar,
		MaanedsNr,
		AntalEnheder
	INTO Datamart.SalgsBudget
	FROM BIDB.DataWarehouse.SalgsBudget INNER JOIN BIDB.DataWarehouse.Salgskanal ON SalgsBudget.SalgskanalSkey = Salgskanal.SalgskanalSkey
GO
ALTER TABLE Datamart.SalgsBudget ADD CONSTRAINT FK_SalgsBudget_Vare
		FOREIGN KEY (Vare) REFERENCES Datamart.Vare(Vare)	

ALTER TABLE Datamart.SalgsBudget ADD CONSTRAINT FK_SalgsBudget_SalgsKanal
		FOREIGN KEY (SalgsKanal) REFERENCES Datamart.Salgskanal(SalgsKanal)
GO
-- vis alle tabeller og antal forekomster
USE BIDBPowerPivot1
GO
SET NOCOUNT ON
DECLARE @TableName		SYSNAME
DECLARE @SchemaName		SYSNAME
DECLARE @Antal			INT
DECLARE @SQLString		NVARCHAR(500);

DECLARE @t TABLE(
	ID					INT NOT NULL IDENTITY,
	Object_id			INT NOT NULL,
	TableName			SYSNAME NOT NULL,
	SchemaName			SYSNAME NOT NULL,
	AntalForekomster	INT NULL,
	Brugt				CHAR(1) DEFAULT('N'))

INSERT INTO @t (Object_id, TableName, SchemaName)
	SELECT t.object_id, t.name, s.name 
		FROM sys.tables as t INNER JOIN sys.schemas as s 
			ON t.schema_id = s.schema_id
		ORDER BY t.name

WHILE EXISTS (SELECT * FROM @t WHERE Brugt = 'N')
BEGIN
	SELECT	@TableName = TableName, 
			@SchemaName = SchemaName
		FROM @t
		WHERE ID = (SELECT MIN(ID) 
						FROM @t 
						WHERE Brugt = 'N')
		
	SET @SQLString = 'SET @Antal = (SELECT COUNT(*) FROM ' + @SchemaName + '.' + @TableName + ')'
	EXECUTE sp_executesql @SqlString, N'@Antal INT OUTPUT', @Antal OUTPUT

	UPDATE @t
		SET AntalForekomster = @Antal, 
			Brugt = 'Y'
		WHERE	TableName = @TableName AND 
				SchemaName = @SchemaName
END
SELECT TableName, SchemaName, AntalForekomster 
	FROM @t
	ORDER BY SchemaName, TableName
GO
USE BIDBPowerPivot1
GO
CHECKPOINT
GO
DBCC SHRINKDATABASE(N'BIDBPowerPivot1' )
GO
