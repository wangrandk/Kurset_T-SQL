--- Datamart 4 - many-to-many
USE master
GO
IF EXISTS (SELECT * FROM master.sys.databases WHERE name = 'BIDB_DM4')
	DROP DATABASE BIDB_DM4
GO
CREATE DATABASE BIDB_DM4
ON PRIMARY
	(NAME = N'BIDB_DM4_Sys', 
	FILENAME = N'c:\Databaser\BIDB_DM4_Data.MDF', 
	SIZE = 5,
	FILEGROWTH = 10%),
FILEGROUP DataFG
	(NAME = N'BIDB_DM4_Data1', 
	FILENAME = N'c:\Databaser\BIDB_DM4_DataFG_Fil1.NDF', 
	SIZE = 10,
	FILEGROWTH = 25%)
LOG ON 
	(NAME = N'BIDB_DM4_Log',
	FILENAME = N'c:\Databaser\BIDB_DM4_Log.LDF', 
	SIZE = 5,
	FILEGROWTH = 10%)
GO
USE BIDB_DM4
GO
ALTER DATABASE BIDB_DM4 SET RECOVERY SIMPLE
GO
ALTER DATABASE BIDB_DM4 MODIFY FILEGROUP DataFG DEFAULT
GO
CREATE SCHEMA Datamart
GO
SELECT	KontoID AS Konto,
		KontoSaldo
	INTO Datamart.Konto
	FROM BIDB.ManyToMany.Konto
	
SELECT	KundeSkey  AS Kunde,
		Navn AS Navn
	INTO Datamart.Kunde
	FROM BIDB.ManyToMany.Kunde
	WHERE KundeSkey IN (SELECT	KundeSkey FROM BIDB.ManyToMany.KundeKonto)

SELECT	KundeSkey AS Kunde,
		KontoID AS Konto
	INTO Datamart.KundeKonto
	FROM BIDB.ManyToMany.KundeKonto
GO
ALTER TABLE Datamart.Kunde 
	ALTER COLUMN Kunde INT NOT NULL

ALTER TABLE Datamart.Konto
	ALTER COLUMN Konto INT NOT NULL

ALTER TABLE Datamart.KundeKonto
	ALTER COLUMN Konto INT NOT NULL

ALTER TABLE Datamart.KundeKonto
	ALTER COLUMN Kunde INT NOT NULL
GO
ALTER TABLE Datamart.Kunde 
	ADD CONSTRAINT PK__Datamart_Kunde PRIMARY KEY (Kunde)

ALTER TABLE Datamart.Konto 
	ADD CONSTRAINT PK__Datamart_Konto PRIMARY KEY (Konto)
GO
ALTER TABLE Datamart.KundeKonto 
	ADD CONSTRAINT FK__Datamart_KundeKonto_Kunde
	FOREIGN KEY (Kunde) REFERENCES Datamart.Kunde(Kunde)

ALTER TABLE Datamart.KundeKonto 
	ADD CONSTRAINT FK__Datamart_KundeKonto_Konto
	FOREIGN KEY (Konto) REFERENCES Datamart.Konto(Konto)
GO
-- vis alle tabeller og antal forekomster
USE BIDB_DM4
GO
SET NOCOUNT ON
DECLARE @TableName		SYSNAME
DECLARE @SchemaName		SYSNAME
DECLARE @Antal			INT
DECLARE @SQLString		NVARCHAR(500);

DECLARE @t TABLE(
	ID					INT NOT NULL IDENTITY,
	Object_id			INT NOT NULL,
	TableName			SYSNAME NOT NULL,
	SchemaName			SYSNAME NOT NULL,
	AntalForekomster	INT NULL,
	Brugt				CHAR(1) DEFAULT('N'))

INSERT INTO @t (Object_id, TableName, SchemaName)
	SELECT t.object_id, t.name, s.name 
		FROM sys.tables as t INNER JOIN sys.schemas as s 
			ON t.schema_id = s.schema_id
		ORDER BY t.name

WHILE EXISTS (SELECT * FROM @t WHERE Brugt = 'N')
BEGIN
	SELECT	@TableName = TableName, 
			@SchemaName = SchemaName
		FROM @t
		WHERE ID = (SELECT MIN(ID) FROM @t WHERE Brugt = 'N')
		
	SET @SQLString = 'SET @Antal = (SELECT COUNT(*) FROM ' + @SchemaName + '.' + @TableName + ')'
	EXECUTE sp_executesql @SqlString, N'@Antal INT OUTPUT', @Antal OUTPUT

	UPDATE @t
		SET AntalForekomster = @Antal, Brugt = 'Y'
		WHERE TableName = @TableName AND SchemaName = @SchemaName
END
SELECT TableName, SchemaName, AntalForekomster 
	FROM @t
	ORDER BY SchemaName, TableName
GO
