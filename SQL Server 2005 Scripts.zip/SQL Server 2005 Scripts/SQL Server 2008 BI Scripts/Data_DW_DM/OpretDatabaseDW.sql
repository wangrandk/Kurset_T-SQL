-- Datawarehouse
USE master
GO
IF EXISTS (SELECT * 
				FROM master.sys.databases 
				WHERE name = 'BIDB')
	DROP DATABASE BIDB
GO
CREATE DATABASE BIDB
ON PRIMARY
	(NAME = N'BIDB_Sys', 
	FILENAME = N'c:\Databaser\BIDB_Data.MDF', 
	SIZE = 40,
	FILEGROWTH = 10%),
FILEGROUP DataFG
	(NAME = N'BIDB_Data1', 
	FILENAME = N'c:\Databaser\BIDB_DataFG_Fil1.NDF', 
	SIZE = 1000,
	FILEGROWTH = 25%),

	(NAME = N'BIDB_Data2', 
	FILENAME = N'c:\Databaser\BIDB_DataFG_Fil2.NDF', 
	SIZE = 1000,
	FILEGROWTH = 25%),

	(NAME = N'BIDB_Data3', 
	FILENAME = N'c:\Databaser\BIDB_DataFG_Fil3.NDF', 
	SIZE = 1000,
	FILEGROWTH = 25%),

	(NAME = N'BIDB_Data4', 
	FILENAME = N'c:\Databaser\BIDB_DataFG_Fil4.NDF', 
	SIZE = 1000,
	FILEGROWTH = 25%)
LOG ON 
	(NAME = N'BIDB_Log',
	FILENAME = N'c:\Databaser\BIDB_Log.LDF', 
	SIZE = 2000,
	FILEGROWTH = 10%)
GO
USE BIDB
GO
ALTER DATABASE BIDB SET RECOVERY SIMPLE
GO
ALTER DATABASE BIDB MODIFY FILEGROUP DataFG DEFAULT
GO
USE BIDB
GO
CREATE SCHEMA DataWarehouse
GO
CREATE SCHEMA HjaelpeTabeller
GO
CREATE TABLE HjaelpeTabeller.Efternavn (
	Efternavn 		VARCHAR(20) NOT NULL)

CREATE TABLE HjaelpeTabeller.Fornavn (
	Fornavn 		VARCHAR(50) NOT NULL,
	Koen			CHAR(1) NOT NULL) 

CREATE TABLE HjaelpeTabeller.Gade (
	Gade 			VARCHAR(30) NOT NULL)

CREATE TABLE DataWarehouse.Region (
	DelRegionSkey	SMALLINT NOT NULL IDENTITY(1,1)
					CONSTRAINT PK_Region PRIMARY KEY,
	DelRegionID		SMALLINT NOT NULL
					CONSTRAINT UQ_Region_DelRegionID UNIQUE,
	DelRegionsnavn	VARCHAR(20) NULL
					CONSTRAINT UQ_Region_DelRegionsnavn UNIQUE,
	Regionsnavn		VARCHAR(20) NOT NULL,
	DelRegionSort	SMALLINT NOT NULL)

CREATE TABLE DataWarehouse.Postopl (
	Postnr 			SMALLINT NOT NULL 
					CONSTRAINT PK_Postopl PRIMARY KEY (Postnr),
	Bynavn 			VARCHAR (20) NOT NULL,
	DelRegionID		SMALLINT NOT NULL 
					CONSTRAINT FK_Postopl_Region REFERENCES DataWarehouse.Region(DelRegionID))

CREATE TABLE DataWarehouse.Kundetypekode (
	KundeTypeSkey	INT NOT NULL IDENTITY(1,1)
					CONSTRAINT PK_Kundetypekode PRIMARY KEY,
	Kundetype		CHAR(1) NOT NULL 
					CONSTRAINT UQ_Kundetypekode_Kundetype UNIQUE,
	Kundetypetxt	VARCHAR(20) NOT NULL
					CONSTRAINT UQ_Kundetypekode_Kundetypetxt UNIQUE )

CREATE TABLE DataWarehouse.Koen (
	KoenSkey		INT NOT NULL IDENTITY(1,1)
					CONSTRAINT PK_Koen PRIMARY KEY,
	Koen			CHAR(1) NOT NULL 
					CONSTRAINT UQ_Koen_Koen UNIQUE,
	KoenText		VARCHAR(10) NOT NULL)

CREATE TABLE DataWarehouse.Kunde (
	KundeSkey 		INT IDENTITY(1, 1) NOT NULL
					CONSTRAINT PK_Kunde PRIMARY KEY,
	KundeBkey 		INT NOT NULL,
	Fornavn 		VARCHAR(20) NOT NULL,
	Efternavn 		VARCHAR(20) NOT NULL,
	Gade 			VARCHAR(30) NOT NULL,
	Postnr 			SMALLINT NOT NULL 
					CONSTRAINT FK_Kunde_Postopl REFERENCES DataWarehouse.Postopl(Postnr),
	Kundetype		CHAR(1) NOT NULL
					CONSTRAINT FK_Kunde_Kundetypekode REFERENCES DataWarehouse.Kundetypekode(Kundetype),
	Koen			CHAR(1) NULL
					CONSTRAINT FK_Kunde_Koen REFERENCES DataWarehouse.Koen(Koen),
	GaeldendeFra	DATE NOT NULL DEFAULT(SYSDATETIME()),
	GaeldendeTil	DATE NULL,
	Navn 			AS Fornavn + ' ' + Efternavn)
GO
SET NOCOUNT ON
IF EXISTS (SELECT * FROM HjaelpeTabeller.Fornavn)
	RETURN
	
INSERT INTO HjaelpeTabeller.Fornavn VALUES 
	('Anne', 'K'),
	('Ane', 'K'),
	('Annemette', 'K'),
	('Anne Mette', 'K'),
	('Anne Marie', 'K'),
	('Anders', 'M'),
	('Andreas', 'M'),
	('Arne', 'M'),
	('Arvid', 'M'),
	('Allan', 'M'),
	('Birte', 'K'),
	('Birthe', 'K'),
	('Bente', 'K'),
	('Bent', 'K'),
	('B�rge', 'M'),
	('Bruno', 'M'),
	('Carl', 'M'),
	('Carina', 'K'),
	('Christian', 'M'),
	('Christina', 'K'),
	('Dorte', 'K'),
	('Dorthe', 'K'),
	('David', 'M'),
	('Daniel', 'M'),
	('Erik', 'M'),
	('Eva', 'K'),
	('Emma', 'K'),
	('Ebba', 'K'),
	('Ebbe', 'M'),
	('Ellen', 'K'),
	('Edvard', 'M'),
	('Edward', 'M'),
	('Egon', 'M'),
	('Esther', 'K'),
	('Frank', 'M'),
	('Frederikke', 'K'),
	('Frede', 'M'),
	('Frode', 'M'),
	('Frida', 'K'),
	('Grete', 'K'),
	('Gitte', 'K'),
	('Grethe', 'K'),
	('Gert', 'M'),
	('Gerd', 'K'),
	('Gunnar', 'M'),
	('Gustav', 'M'),
	('Gudrun', 'K'),
	('Henrik', 'M'),
	('Hans', 'M'),
	('Hans Erik', 'M'),
	('Hans Ole', 'M'),
	('Hanne', 'K'),
	('Henriette', 'K'),
	('Hedvig', 'K'),
	('Henry', 'M'),
	('Hugo', 'M'),
	('Ib', 'M'),
	('Ida', 'K'),
	('Ilse', 'K'),
	('Ivar', 'M'),
	('Ivan', 'M'),
	('Inger', 'K'),
	('Inge', 'K'),
	('Jens', 'M'),
	('Jens Erik', 'M'),
	('Jens Ole', 'M'),
	('Jens Peter', 'M'),
	('Jakob', 'M'),
	('Jacob', 'M'),
	('Jesper', 'M'),
	('Jette', 'K'),
	('Jytte', 'K'),
	('Jane', 'K'),
	('Karl', 'M'),
	('Karen', 'K'),
	('Karin', 'K'),
	('Kis', 'K'),
	('Karina', 'K'),
	('Kristina', 'K'),
	('Kristine', 'K'),
	('Kurt', 'M'),
	('Knud', 'M'),
	('Kenneth', 'M'),
	('Lars', 'M'),
	('Lars Ole', 'M'),
	('Lars Bo', 'M'),
	('Ludvig', 'M'),
	('Line', 'K'),
	('Lise', 'K'),
	('Lisette', 'K'),
	('Lene', 'K'),
	('Lisbeth', 'K'),
	('Lena', 'K'),
	('Liselotte', 'K'),
	('Lise Lotte', 'K'),
	('Morten', 'M'),
	('Marie', 'K'),
	('Mads', 'M'),
	('Maren', 'K'),
	('Malene', 'K'),
	('Mette', 'K'),
	('Michael', 'M'),
	('Mikael', 'M'),
	('Niels', 'M'),
	('Nis', 'M'),
	('Nicolaj', 'M'),
	('Nikolaj', 'M'),
	('Ninna', 'K'),
	('Nette', 'K'),
	('Nanna', 'K'),
	('Ole', 'M'),
	('Oda', 'K'),
	('Olivia', 'K'),
	('Oskar', 'M'),
	('Ove', 'M'),
	('Peter', 'M'),
	('Per', 'M'),
	('Petrea', 'K'),
	('Peder', 'M'),
	('Pil', 'K'),
	('Poul', 'M'),
	('Paul', 'M'),
	('Poula', 'K'),
	('Rasmus', 'M'),
	('Rie', 'K'),
	('Rikke', 'K'),
	('Richard', 'M'),
	('Rune', 'M'),
	('Ruth', 'K'),
	('Rosa', 'K'),
	('Robert', 'M'),
	('Rositta', 'K'),
	('S�ren', 'M'),
	('Sys', 'K'),
	('Sara', 'K'),
	('Simone', 'K'),
	('Susanne', 'K'),
	('Sanne', 'K'),
	('Sofus', 'M'),
	('Solvej', 'K'),
	('Signe', 'K'),
	('Thomas', 'M'),
	('Tove', 'K'),
	('Tommy', 'M'),
	('Tone', 'K'),
	('Trine', 'K'),
	('Tine', 'K'),
	('Tina', 'K'),
	('Tobias', 'M'),
	('Uffe', 'M'),
	('Ulla', 'K'),
	('Ulrik', 'M'),
	('Vera', 'K'),
	('Villy', 'M'),
	('Vagn', 'M'),
	('Willy', 'M'),
	('Yrsa', 'K'),
	('�jvind', 'M'),
	('�ge', 'M'),
	('�se', 'K')
GO
IF EXISTS (SELECT * FROM HjaelpeTabeller.Efternavn) 
	RETURN
	
INSERT INTO HjaelpeTabeller.Efternavn VALUES 
	('Andersen'),
	('B�rgesen'),
	('Bentsen'),
	('Christensen'),
	('Christiansen'),
	('Carlsen'),
	('Davidsen'),
	('Danielsen'),
	('Eriksen'),
	('Frandsen'),
	('Frederiksen'),
	('Gertsen'),
	('Henriksen'),
	('Hansen'),
	('Iversen'),
	('Ibsen'),
	('Jensen'),
	('Jensen'),
	('Jakobsen'),
	('Jacobsen'),
	('Karlsen'),
	('Knudsen'),
	('Kristensen'),
	('Larsen'),
	('Lassen'),
	('Mortensen'),
	('Madsen'),
	('Mikkelsen'),
	('Nielsen'),
	('Nyborg'),
	('Olsen'),
	('Olesen'),
	('Pedersen'),
	('Petersen'),
	('Rasmussen'),
	('S�rensen'),
	('Thomsen'),
	('Vognsen'),
	('Vesterg�rd'),
	('Westergaard'),
	('�vlisen'),
	('�gesen'),
	('�berg')
GO
IF EXISTS (SELECT * FROM HjaelpeTabeller.Gade)
	RETURN
	
INSERT INTO HjaelpeTabeller.Gade VALUES
	('N�rregade 2'),
	('N�rregade 34'),
	('N�rregade 27'),
	('N�rregade 67'),
	('Vestergade 3'),
	('Vestergade 56'),
	('Vestergade 5'),
	('�stergade 23'),
	('�stergade 1'),
	('S�ndergade 6'),
	('S�ndergade 78'),
	('Torvet 2'),
	('Torvet 4'),
	('Runddelen 1'),
	('Ved Stranden 3'),
	('Ved Stranden 5'),
	('Strandvejen 112'),
	('All�gade 29'),
	('Norgesgade 3'),
	('Ungarnsgade 4'),
	('Italiensvej 32'),
	('Strandvejen 2'),
	('All�gade 5'),
	('Norgesgade 38'),
	('Ungarnsgade 7'),
	('Italiensvej 21'),
	('Italiensvej 4'),
	('Bragesgade 1'),
	('Bragesgade 12'),
	('Dortesvej 4'),
	('Dortesvej 3'),
	('Ellebjergvej 114'),
	('Ellebjergvej 34'),
	('Ellebjergvej 65'),
	('Ellebjergvej 87'),
	('Frankrigsgade 14'),
	('Frankrigsgade 6'),
	('Frankrigsgade 115'),
	('Helgolandsgade 54'),
	('Helgolandsgade 19'),
	('Helgolandsgade 8'),
	('K�gevej 4'),
	('K�gevej 48'),
	('M�llegade 13'),
	('M�llegade 33'),
	('M�llegade 34'),
	('Ollerupvej 3'),
	('Sct. Pouls Gade 2'),
	('Sct. Pouls Gade 3'),
	('Sct. Pouls Gade 25'),
	('Willemoesgade 2'),
	('Willemoesgade 17')
GO
INSERT INTO DataWarehouse.Region VALUES 
	(1, 'Stork�benhavn', 'Stork�benhavn', 1),
	(2, 'Sj�lland', 'Sj�lland', 2),
	(3, 'Fyn', 'Fyn', 3),
	(4, 'Nordjylland', 'Jylland', 6),
	(5, 'Midtjylland', 'Jylland', 5),
	(6, 'S�nderjylland', 'Jylland', 4)
GO
INSERT INTO DataWarehouse.Postopl VALUES
	(1127, 'K�benhavn K', 1),
	(1001, 'K�benhavn K', 1),
	(1129, 'K�benhavn K', 1),
	(1130, 'K�benhavn K', 1),
	(2000, 'Frederiksberg', 1),
	(8000, 'Aarhus C', 5),
	(8200, 'Aarhus N', 5),
	(8240, 'Risskov', 5),
	(8270, 'H�jbjerg', 5),
	(8310, 'Tranbjerg J', 5),
	(9000, 'Aalborg', 4),
	(9400, 'N�rresundby', 4),
	(9600, 'Br�nderslev', 4),
	(9800, 'Hj�rring', 4),
	(9990, 'Skagen', 4),
	(3400, 'Hiller�d', 2),
	(3050, 'Humleb�k', 2),
	(2600, 'Glostrup', 1),
	(2605, 'Br�ndby', 1),
	(2610, 'R�dovre', 1),
	(2620, 'Albertslund', 1),
	(2625, 'Vallensb�k', 1),
	(2630, 'Taastrup', 1),
	(2635, 'Ish�j', 1),
	(2640, 'Hedehusene', 1),
	(2650, 'Hvidovre', 1),
	(2660, 'Br�ndby Strand', 1),
	(2665, 'Vallensb�k Strand', 1),
	(2670, 'Greve', 1),
	(2680, 'Solr�d Strand', 1),
	(2800, 'Kongens Lyngby', 1),
	(2820, 'Gentofte', 1),
	(2830, 'Virum', 1),
	(2840, 'Holte', 1),
	(2850, 'N�rum', 1),
	(2860, 'S�borg', 1),
	(2870, 'Dysseg�rd', 1),
	(2880, 'Bagsv�rd', 1),
	(2900, 'Hellerup', 1),
	(2920, 'Charlottenlund', 1),
	(2930, 'Klampenborg', 1),
	(2942, 'Skodsborg', 1),
	(2950, 'Vedb�k', 1),
	(5000, 'Odense C', 3),
	(5220, 'Odense S�', 3),
	(5700, 'Svendborg', 3),
	(2300, 'K�benhavn S', 1),
	(6051, 'Almind', 6),
	(6000, 'Kolding', 6),
	(6950, 'Ringk�bing', 5),
	(8700, 'Horsens', 5)
GO
INSERT INTO DataWarehouse.Kundetypekode VALUES
	('A', 'Almindelig'),
	('B', 'Firma'),
	('C', 'Storkunde'),
	('D', 'Ung - 14-18'),
	('E', 'Barn - 0-13')
GO
CREATE CLUSTERED INDEX cl_Fornavn ON HjaelpeTabeller.Fornavn (Fornavn)
CREATE CLUSTERED INDEX cl_Efternavn ON HjaelpeTabeller.Efternavn (Efternavn)
CREATE CLUSTERED INDEX cl_Gade ON HjaelpeTabeller.Gade (Gade)
CREATE NONCLUSTERED INDEX nc_Postopl_Bynavn ON DataWarehouse.Postopl (Bynavn)
GO
INSERT INTO DataWarehouse.Koen VALUES
	('K', 'Kvinde'),
	('M', 'Mand')
GO
INSERT INTO DataWarehouse.Kunde (KundeBkey, Fornavn, Efternavn, Gade, Postnr, Koen, Kundetype)
   SELECT  1 AS ForeloebigKundeID, Fornavn, Efternavn, Gade, Postnr, Koen, 'A'
      FROM HjaelpeTabeller.Fornavn	
				INNER JOIN HjaelpeTabeller.Efternavn	ON Fornavn.Fornavn > Efternavn.Efternavn
				INNER JOIN HjaelpeTabeller.Gade			ON Efternavn.Efternavn > Gade.Gade
				INNER JOIN DataWarehouse.Postopl		ON Gade.Gade <> Postopl.Bynavn
      WHERE LEN(Fornavn) + LEN(Efternavn) < 11

INSERT INTO DataWarehouse.Kunde (KundeBkey, Fornavn, Efternavn, Gade, Postnr, Koen, Kundetype)
   SELECT   1 AS ForeloebigKundeID, Fornavn, Efternavn, Gade, Postnr, Koen, 'A'
      FROM HjaelpeTabeller.Fornavn	
				INNER JOIN HjaelpeTabeller.Efternavn	ON Fornavn.Fornavn < Efternavn.Efternavn
				INNER JOIN HjaelpeTabeller.Gade			ON Efternavn.Efternavn < Gade.Gade
				INNER JOIN DataWarehouse.Postopl		ON Gade.Gade < Postopl.Bynavn
      WHERE LEN(Fornavn) + LEN(Efternavn) BETWEEN 11 AND 16
      
INSERT INTO DataWarehouse.Kunde (KundeBkey, Fornavn, Efternavn, Gade, Postnr, Koen, Kundetype)
   SELECT	1 AS ForeloebigKundeID,	Fornavn, Efternavn, Gade, Postnr, Koen, 'A'
      FROM HjaelpeTabeller.Fornavn	
				INNER JOIN HjaelpeTabeller.Efternavn	ON Fornavn.Fornavn > Efternavn.Efternavn
				INNER JOIN HjaelpeTabeller.Gade			ON Efternavn.Efternavn < Gade.Gade
				INNER JOIN DataWarehouse.Postopl		ON Gade.Gade > Postopl.Bynavn
      WHERE LEN(Fornavn) + LEN(Efternavn) > 16
  
UPDATE  DataWarehouse.Kunde
	SET KundeBkey = KundeSkey, GaeldendeFra = DATEADD(d, - (KundeSkey % 3287) - 12, SYSDATETIME())
GO
CREATE NONCLUSTERED INDEX nc_Kunde_KundeBkey ON DataWarehouse.Kunde(KundeBkey)
CREATE NONCLUSTERED INDEX nc_Kunde_Postnr ON DataWarehouse.Kunde(Postnr)
GO
CREATE TRIGGER ins_DataWarehouse_Kunde ON DataWarehouse.Kunde
AFTER INSERT
AS
BEGIN
	DECLARE @GaeldendeTil	DATETIME2
	DECLARE @KundeBkey		INT 
	DECLARE @KundeSkey		INT = (SELECT MIN(KundeSkey) - 1 FROM INSERTED)

	IF EXISTS (SELECT * FROM INSERTED WHERE GaeldendeTil IS NOT NULL)
	BEGIN
		RAISERROR(' Dato for G�ldende til m� ikke v�re udfyldt', 16, 1)
		ROLLBACK TRANSACTION
		RETURN
	END

	WHILE EXISTS (SELECT * FROM INSERTED WHERE KundeSkey > @KundeSkey)
	BEGIN
		SELECT	@KundeBkey = KundeBkey,
				@KundeSkey = KundeSkey,
				@GaeldendeTil = DATEADD(DAY, -1, GaeldendeFra)
			FROM INSERTED 
			WHERE KundeSkey = (SELECT MIN(KundeSkey) FROM INSERTED WHERE KundeSkey > @KundeSkey)
			
		UPDATE DataWarehouse.Kunde
			SET		GaeldendeTil = @GaeldendeTil
			WHERE	KundeSkey < @KundeSkey AND
					KundeBkey = @KundeBkey AND
					GaeldendeTil IS NULL
	END
END
GO
CREATE NONCLUSTERED INDEX nc_KundeDubletter 
	ON DataWarehouse.Kunde (Fornavn, Efternavn, Gade, Postnr, KundeBkey)
GO
WITH 
KundeDubletter
AS
(
SELECT Fornavn, Efternavn, Gade, Postnr, COUNT(*) AS Antal
	FROM DataWarehouse.Kunde
	GROUP BY Fornavn, Efternavn, Gade, Postnr
	HAVING COUNT(*) > 1),

SletKundeBkey
AS
(
SELECT KundeBkey
	FROM  KundeDubletter AS KD CROSS APPLY (SELECT TOP (Antal - 1) KundeBkey 
												FROM	DataWarehouse.Kunde AS K
												WHERE	KD.Fornavn = K.Fornavn AND
														KD.Efternavn = K.Efternavn AND
														KD.Gade = K.Gade AND
														KD.Postnr = K.Postnr) AS TopKunde)
DELETE
	FROM DataWarehouse.Kunde 
	WHERE KundeBkey IN (SELECT KundeBkey 
						FROM SletKundeBkey)
GO
DROP INDEX nc_KundeDubletter ON DataWarehouse.Kunde
GO
UPDATE DataWarehouse.Kunde
	SET Kundetype = 'B'
	WHERE KundeBkey % 95 = 1

UPDATE DataWarehouse.Kunde
	SET Kundetype = 'C'
	WHERE KundeBkey % 997 = 2

UPDATE DataWarehouse.Kunde
	SET Kundetype = 'D'
	WHERE KundeBkey % 9999 = 1

UPDATE DataWarehouse.Kunde
	SET Koen = NULL
	WHERE KundeBkey % 37834 = 9
GO
INSERT INTO DataWarehouse.Kunde (KundeBkey, Fornavn, Efternavn, Gade, Postnr, Kundetype, Koen, GaeldendeFra, GaeldendeTil)
		SELECT	KundeBkey, Fornavn, Efternavn, 
				'Parkvejen ' + CAST(KundeBkey % 45 AS VARCHAR(10)), 
				(SELECT TOP 1 Postnr
					FROM (SELECT TOP (KundeBkey % (SELECT COUNT(*) 
												FROM DataWarehouse.Postopl) + 1) Postnr
							FROM DataWarehouse.Postopl
							ORDER BY Postnr ASC) AS p
					ORDER BY Postnr DESC),
				Kundetype,
				Koen,
				SYSDATETIME(),
				NULL					
			FROM DataWarehouse.Kunde
			WHERE KundeSkey % 36912 = 682
			
INSERT INTO DataWarehouse.Kunde (KundeBkey, Fornavn, Efternavn, Gade, Postnr, Kundetype, Koen, GaeldendeFra, GaeldendeTil)
		SELECT	KundeBkey, Fornavn, Efternavn, 
				'S�ndre Boulevard ' + CAST(KundeBkey % 23 AS VARCHAR(10)), 
				(SELECT TOP 1 Postnr
					FROM (SELECT TOP (KundeBkey % (SELECT COUNT(*) 
												FROM DataWarehouse.Postopl) + 1) Postnr
							FROM DataWarehouse.Postopl
							ORDER BY Postnr ASC) AS p
					ORDER BY Postnr DESC),
				Kundetype,
				Koen,
				SYSDATETIME(),
				NULL					
			FROM DataWarehouse.Kunde
			WHERE KundeSkey % 8999 = 7001
			
INSERT INTO DataWarehouse.Kunde (KundeBkey, Fornavn, Efternavn, Gade, Postnr, Kundetype, Koen, GaeldendeFra, GaeldendeTil)
		SELECT	KundeBkey, Fornavn, Efternavn, 
				'Polensgade ' + CAST(KundeBkey % 59 AS VARCHAR(10)), 
				(SELECT TOP 1 Postnr
					FROM (SELECT TOP (KundeBkey % (SELECT COUNT(*) 
												FROM DataWarehouse.Postopl) + 1) Postnr
							FROM DataWarehouse.Postopl
							ORDER BY Postnr ASC) AS p
					ORDER BY Postnr DESC),
				Kundetype,
				Koen,
				SYSDATETIME(),
				NULL					
			FROM DataWarehouse.Kunde
			WHERE KundeSkey % 15243 = 1222
GO
CREATE NONCLUSTERED INDEX nc_Kunde_Kundetype ON DataWarehouse.Kunde (Kundetype)
GO
DROP TABLE HjaelpeTabeller.Fornavn
DROP TABLE HjaelpeTabeller.Efternavn
DROP TABLE HjaelpeTabeller.Gade
GO
CREATE TABLE DataWarehouse.Medarbejder (
	MedarbejderID		SMALLINT NOT NULL PRIMARY KEY,
	Fornavn				VARCHAR(20) NOT NULL, 
	Efternavn			VARCHAR(20) NOT NULL, 
	Gade				VARCHAR(30) NOT NULL, 
	Postnr				SMALLINT NOT NULL REFERENCES DataWarehouse.Postopl, 
	ChefId				SMALLINT NULL,
	CONSTRAINT FK_Medarbejder_Chef FOREIGN KEY (Chefid) REFERENCES DataWarehouse.Medarbejder(MedarbejderID))
GO
INSERT INTO DataWarehouse.Medarbejder VALUES
	(1, 'Ida', 'Andersen', 'Vestergade 23', 2000, NULL),
	(2, 'Jens', 'Pedersen', 'Torvet 2', 1127, 1),
	(3, 'Ane', 'Larsen', '�stergade 4', 1129, 1),
	(4, 'Peter', 'Madsen', 'S�ndergade 11', 2605, 1),
	(5, 'Lone', 'Olsen', 'Sankt Peders Str�de 1', 2610, 2),
	(6, 'Tina', 'Olesen', 'Kirkevej 14', 2600, 2),
	(7, 'Carl', 'Thomsen', 'Nygade 6', 2000, 3),
	(8, 'Lars', 'Jensen', 'Vestergade 1', 1127, 3),
	(9, 'Hans', 'Hansen', '�stergade 9', 1129, 3),
	(10, 'Sofie', 'Carlsen', 'Vejlevej 4', 2000, 4),
	(11, 'Rita', 'Knudsen', 'Irlandsvej 78', 2630, 4),
	(12, '�ge', 'Rasmussen', 'Christiansgade 3', 2000, 4),
	(13, 'Per', 'Aagaard', 'S�ndergade 17', 2635, 10),
	(14, 'Dorthe', 'Ibsen', 'Lille Str�de 6', 2000, 10),
	(15, 'Vivi', 'Davidsen', '�stergade 24 23', 1127, 11),
	(16, 'Bo', 'Jensen', 'Torvet 7', 1129, 11),
	(17, 'Michael', 'Christensen', 'Bredgade 112', 2000, 11),
	(18, 'Irene', 'Eriksen', 'S�ndergade 34', 2600, 11)
GO
CREATE TABLE DataWarehouse.Kategori (
	KategoriSkey		SMALLINT NOT NULL IDENTITY 
						CONSTRAINT PK_Kategori PRIMARY KEY,
	KategoriID			SMALLINT NOT NULL 
						CONSTRAINT UQ_Kategori_KategoriID UNIQUE,
	Kategorinavn		VARCHAR(30) NOT NULL)

CREATE TABLE DataWarehouse.Subkategori (
	SubkategoriSkey		SMALLINT NOT NULL IDENTITY 
						CONSTRAINT PK_Subkategori PRIMARY KEY,
	SubkategoriID		SMALLINT NOT NULL 
						CONSTRAINT UQ_Subkategori_SubkategoriID UNIQUE,
	SubKategorinavn		VARCHAR(30) NOT NULL,
	KategoriSkey		SMALLINT NOT NULL
						CONSTRAINT FK_SubKategori_Kategori
						REFERENCES DataWarehouse.Kategori (KategoriSKey))

CREATE TABLE DataWarehouse.Indkoeb (
	IndkoebsType		CHAR(1) NOT NULL PRIMARY KEY,
	IndkoebsTypenavn	VARCHAR(20) NOT NULL)

CREATE TABLE DataWarehouse.Vare (
	VareSkey			INT NOT NULL IDENTITY
						CONSTRAINT PK_Vare PRIMARY KEY,
	VareBkey			SMALLINT NOT NULL
						CONSTRAINT UQ_Vare_VareBkey UNIQUE,
	Varenavn			VARCHAR(30) NOT NULL,
	Vejledendepris		DECIMAL(9,2) NULL,
	IndkoebsType		CHAR(1) NOT NULL DEFAULT('I'),
	SubKategoriSkey		SMALLINT NOT NULL
						CONSTRAINT FK_Vare_Subkategori
						REFERENCES DataWarehouse.Subkategori (SubkategoriSkey))

CREATE TABLE DataWarehouse.Salgskanal (
	SalgskanalSkey		SMALLINT NOT NULL IDENTITY (1,1)
						CONSTRAINT PK_Salgskanal PRIMARY KEY,
	SalgskanalID		SMALLINT NOT NULL 
						CONSTRAINT UQ_Salgskanal_SalgskanalID UNIQUE,
	SalgskanalNavn		VARCHAR(30) NOT NULL,
	SorteringsOrden		SMALLINT NOT NULL)
GO
CREATE TABLE DataWarehouse.Tid (
	TidSkey				INT NOT NULL IDENTITY (1,1)
						CONSTRAINT PK_Time PRIMARY KEY,
	Dato				DATETIME NOT NULL,
	Aar					SMALLINT NOT NULL,
	KvartalsNr			SMALLINT NOT NULL,
	MaanedsNr			SMALLINT NOT NULL,
	MaanedsNavn			VARCHAR(12) NOT NULL,
	DagNrIMaaned		SMALLINT NOT NULL,
	DagnrIUge			SMALLINT NOT NULL,
	DagNavn				VARCHAR(12) NOT NULL)
GO
CREATE TABLE DataWarehouse.Maanedsnavn (
	Maanedsnr			SMALLINT NOT NULL
						CONSTRAINT PK_Maanedsnavn PRIMARY KEY,
	Maanedsnavn_da		VARCHAR(12) NOT NULL)
GO
CREATE TABLE DataWarehouse.Ugedagsnavn (
	Ugedagsnr			SMALLINT NOT NULL
						CONSTRAINT PK_Ugedagsnavn PRIMARY KEY,
	Ugedagsnavn_da		VARCHAR(12) NOT NULL)
GO
SET NOCOUNT ON
INSERT INTO DataWarehouse.Indkoeb VALUES
	('A', 'Automatisk indk�b'),
	('I', 'Indk�ber')
GO
INSERT INTO DataWarehouse.Salgskanal VALUES
	(0, 'Ukendt', 4),
	(1, 'Butik', 1),
	(2, 'Internet', 3),
	(3, 'Telefon', 2)
GO
SET IDENTITY_INSERT DataWarehouse.Kategori ON

INSERT INTO DataWarehouse.Kategori 
	(KategoriSkey, KategoriID, Kategorinavn) VALUES
	(1, 1, 'Frugt og Gr�ntsager'),
	(2, 2, 'Dagligvarer'),
	(3, 3, 'Husholdningsartikler')
	
SET IDENTITY_INSERT DataWarehouse.Kategori OFF
GO
SET IDENTITY_INSERT DataWarehouse.Subkategori ON

INSERT INTO DataWarehouse.Subkategori 
	(SubkategoriSkey, SubkategoriID, SubKategorinavn, KategoriSkey) VALUES
	(1, 1, 'Frugt', 1),
	(2, 2, 'Gr�ntsager', 1),
	(3, 3, 'Kaffe og Te', 2),
	(4, 4, 'Mel, Gryn, mv.', 2),
	(5, 5, 'Vand og Juice', 2),
	(6, 6, '�l og Vin', 2),
	(7, 7, 'Toiletartikler', 3),
	(8, 8, 'Reng�ringsmidler', 3),
	(9, 9, 'Plasticposer mv.', 3)
	
SET IDENTITY_INSERT DataWarehouse.Subkategori OFF
GO
SET IDENTITY_INSERT DataWarehouse.Vare ON

INSERT INTO DataWarehouse.Vare 
	(VareSkey, VareBkey, Varenavn, Vejledendepris, IndkoebsType, SubKategoriSkey) VALUES
	(1, 1, '�ble', 20.00, 'I', 1),
	(2, 2, 'Appelsin', 30.00, 'I', 1),
	(3, 3, 'Blomme', 15.00, 'I', 1),
	(4, 4, 'Jordb�r', 25.00, 'I', 1),
	(5, 5, 'Kiwi', 8.00, 'I', 1),
	(6, 6, 'Vandmelon', 10.00, 'I', 1),
	(7, 7, 'Fersken', 10.00, 'I', 1),
	(8, 8, 'Honningmelon', 15.00, 'I', 1),
	(9, 9, 'Netmelon', 13.00, 'I', 1),
	(10, 10, 'Vindruer - gr�nne', 17.25, 'I', 1),
	(11, 11, 'Vindruer - bl�', 18.50, 'I', 1),
	(12, 12, 'Grapefrugt', 8.00, 'I', 1),

	(13, 13, 'Guler�dder', 15.00, 'I', 2),
	(14, 14, 'Kartofler', 9.00, 'I', 2),
	(15, 15, 'L�g', 10.00, 'I', 2),
	(16, 16, 'For�rsl�g', 12.00, 'I', 2),
	(17, 17, 'Porer', 18.00, 'I', 2),
	(18, 18, 'Pastinak', 6.00, 'I', 2),
	(19, 19, 'Jordskok', 8.00, 'I', 2),
	(20, 20, 'Selleri', 13.25, 'I', 2),
	(21, 21, 'Bagekartofler', 13.00, 'I', 2),

	(22, 22, 'Kaffe', 27.00, 'I', 3),
	(23, 23, 'Te', 15.00, 'I', 3),
	(24, 24, 'Urtete', 20.00, 'I', 3),
	(25, 25, '�kologisk kaffe', 37.00, 'I', 3),

	(26, 26, 'Rugmel', 9.75, 'A', 4),
	(27, 27, 'Sukker', 8.50, 'A', 4),
	(28, 28, 'Havregryn', 19.75, 'A', 4),
	(29, 29, 'Bygmel', 14.00, 'A', 4),
	(30, 30, 'R�rsukker', 22.50, 'A', 4),
	(31, 31, 'Hvedemel', 8.75, 'A', 4),
	(32, 32, '3-korns mel', 16.25, 'A', 4),

	(33, 33, 'Sodavand - 30cl', 3.00, 'I', 5),
	(34, 34, 'Sodavand - 50cl', 5.00, 'I', 5),
	(35, 35, 'Sodavand - 1 liter', 9.00, 'I', 5),
	(36, 36, '�blejuice', 5.00, 'A', 5),
	(37, 37, 'Appelsinjuice', 4.50, 'A', 5),
	(38, 38, 'Gulerodsjuice', 7.50, 'A', 5),
	(39, 39, '�kologisk �blejuice', 7.00, 'I', 5),
	(40, 40, '�kologisk Appelsinjuice', 6.50, 'I', 5),
	(41, 41, 'Blandet juice', 7.75, 'I', 5),

	(42, 42, '�l', 4.00, 'I', 6),
	(43, 43, 'R�dvin', 65.00, 'I', 6),
	(44, 44, 'Hvidvin', 45.00, 'I', 6),
	(45, 45, 'Rose', 39.75, 'I', 6),

	(46, 46, 'Toiletpapir', 40.00, 'A', 7),
	(47, 47, 'Papirslommet�rkl�de', 2.50, 'A', 7),
	(48, 48, 'Vatpinde', 12.25, 'A', 7),
	(49, 49, 'Vat', 10.00, 'A', 7),
	(50, 50, 'S�be', 8.00, 'A', 7),
	(51, 51, 'H�rshampoo', 29.75, 'A', 7),
	(52, 52, 'Badesalt', 35.50, 'A', 7),

	(53, 53, 'Opvaskemiddel', 12.00, 'A', 8),
	(54, 54, 'WC-rens', 23.50, 'A', 8),
	(55, 55, 'Brun s�be', 6.50, 'A', 8),
	(56, 56, 'S�besp�ner', 8.75, 'A', 8),
	(57, 57, 'Reng�ringssvamp', 9.50, 'A', 8),
	(58, 58, 'Karklud - bomuld', 19.50, 'A', 8),
	(59, 59, 'Karklud - fiber', 14.50, 'A', 8),
	(60, 60, 'Gulvklud', 19.50, 'A', 8),

	(61, 61, 'Affaldsposer - alm.', 6.00, 'A', 9),
	(62, 62, 'Affaldsposer - store', 8.00, 'A', 9),
	(63, 63, 'Sorte Affaldss�kke', 13.00, 'A', 9),
	(64, 64, 'Klare Affaldss�kke', 13.00, 'A', 9),
	(65, 65, 'Frostposer 1 liter', 9.00, 'A', 9),
	(66, 66, 'Frostposer 2 liter', 14.00, 'A', 9),
	(67, 67, 'Frostposer 5 liter', 19.00, 'A', 9),
	(68, 68, 'Frostposer 8 liter', 29.00, 'A', 9)
	
SET IDENTITY_INSERT DataWarehouse.Vare OFF
GO
INSERT INTO DataWarehouse.Maanedsnavn VALUES
	(1, 'Januar'),
	(2, 'Februar'),
	(3, 'Marts'),
	(4, 'April'),
	(5, 'Maj'),
	(6, 'Juni'),
	(7, 'Juli'),
	(8, 'August'),
	(9, 'September'),
	(10, 'Oktober'),
	(11, 'November'),
	(12, 'December')

INSERT INTO DataWarehouse.Ugedagsnavn VALUES
	(1, 'Mandag'),
	(2, 'Tirsdag'),
	(3, 'Onsdag'),
	(4, 'Torsdag'),
	(5, 'Fredag'),
	(6, 'L�rdag'),
	(7, 'S�ndag')

SET NOCOUNT OFF
GO
CREATE TABLE DataWarehouse.KundeSalg (
	SalgId			INT NOT NULL IDENTITY (1,1)
					CONSTRAINT PK_KundeSalg PRIMARY KEY,
	KundeSkey		INT NULL 
					CONSTRAINT FK_KundeSalg_Kunde REFERENCES DataWarehouse.Kunde(KundeSkey),
	VareSkey		INT NOT NULL
					CONSTRAINT FK_KundeSalg_Vare REFERENCES DataWarehouse.Vare(VareSkey),
	SalgskanalSkey	SMALLINT NULL
					CONSTRAINT FK_KundeSalg_Salgskanal REFERENCES DataWarehouse.Salgskanal(SalgskanalSkey),
	MedarbejderID	SMALLINT NULL
					CONSTRAINT FK_KundeSalg_Medarbejder REFERENCES DataWarehouse.Medarbejder (MedarbejderID),
	BestillingsDato	DATE NOT NULL DEFAULT (SYSDATETIME()),
	LeveringsDato	DATE NOT NULL DEFAULT (SYSDATETIME()),
	Antalenheder	SMALLINT NOT NULL
					CONSTRAINT CK_Salg_AntalEnheder CHECK (Antalenheder > 0),
	Enhedspris		DECIMAL(9,2) NOT NULL,
	CONSTRAINT UQ_KundeSalg UNIQUE (KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, LeveringsDato))
GO
INSERT INTO DataWarehouse.KundeSalg(KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, BestillingsDato, LeveringsDato, Antalenheder, Enhedspris)
	SELECT	Kunde.KundeSkey, 
			Vare.VareSkey, 
			3 AS SalgskanalSkey, 
			Medarbejder.MedarbejderID,
			GaeldendeFra AS BestillingsDato, 
			GaeldendeFra AS LeveringsDato, 
			2 AS Antalenheder,
			VejledendePris
		FROM DataWarehouse.Kunde, DataWarehouse.Vare, DataWarehouse.Medarbejder
		WHERE	Kunde.KundeBkey % 201 = 37 AND
				Vare.VareBkey % 6 = 2 AND
				Medarbejder.MedarbejderID % 5 = 1

INSERT INTO DataWarehouse.KundeSalg(KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, BestillingsDato, LeveringsDato, Antalenheder, Enhedspris)
	SELECT	Kunde.KundeSkey, 
			Vare.VareSkey, 
			2 AS SalgskanalSkey, 
			Medarbejder.MedarbejderID,
			DATEADD(DAY, DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) / 2, GaeldendeFra) AS BestillingsDato, 
			DATEADD(DAY, DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) / 2, GaeldendeFra) AS LeveringsDato, 
			1 AS Antalenheder,
			VejledendePris
		FROM DataWarehouse.Kunde, DataWarehouse.Vare, DataWarehouse.Medarbejder
		WHERE	Kunde.KundeSkey % 43 = 11 AND
				Vare.VareBkey % 9 = 1 AND
				Medarbejder.MedarbejderID % 7 = 1

INSERT INTO DataWarehouse.KundeSalg(KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, BestillingsDato, LeveringsDato, Antalenheder, Enhedspris)
	SELECT	Kunde.KundeSkey, 
			Vare.VareSkey, 
			2 AS SalgskanalSkey, 
			Medarbejder.MedarbejderID,
			DATEADD(DAY, - DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % 3, ISNULL(GaeldendeTil, SYSDATETIME())) AS BestillingsDato, 
			DATEADD(DAY, - DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % 3, ISNULL(GaeldendeTil, SYSDATETIME())) AS LeveringsDato, 
			1 AS Antalenheder,
			VejledendePris
		FROM DataWarehouse.Kunde, DataWarehouse.Vare, DataWarehouse.Medarbejder
		WHERE	Kunde.KundeSkey % 765 = 123 AND
				Vare.VareBkey % 34 = 22 AND
				Medarbejder.MedarbejderID % 13 = 4
GO
DECLARE @i	INT
SET @i = 24
WHILE @i < 320
BEGIN
	INSERT INTO DataWarehouse.KundeSalg(KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, BestillingsDato, LeveringsDato, Antalenheder, Enhedspris)
		SELECT	Kunde.KundeSkey, 
			Vare.VareBkey, 
			1 AS SalgskanalSkey, 
			Medarbejder.MedarbejderID,
			DATEADD(DAY, DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % @i, GaeldendeFra) AS BestillingsDato, 
			DATEADD(DAY, DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % @i, GaeldendeFra) AS LeveringsDato, 
			(@i %  4) + 1 AS AntalEnheder,
			VejledendePris
		FROM DataWarehouse.Kunde, DataWarehouse.Vare, DataWarehouse.Medarbejder
		WHERE	Kunde.KundeSkey % @i = 6 AND
				Vare.VareBkey % 33 = @i % 23  AND
				Medarbejder.MedarbejderID % 9 = @i % 5
		SET @i = @i + 15
END
GO
INSERT INTO DataWarehouse.KundeSalg (KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, BestillingsDato, LeveringsDato, AntalEnheder, EnhedsPris)
	SELECT	Kunde.KundeSkey, 
			Vare.VareBkey, 
			2 AS SalgskanalSkey, 
			Medarbejder.MedarbejderID,
			DATEADD(DAY, - DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % 6, ISNULL(GaeldendeTil, SYSDATETIME())) AS BestillingsDato,
			DATEADD(DAY, - DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % 6, ISNULL(GaeldendeTil, SYSDATETIME())) AS LeveringsDato,
			3 AS AntalEnheder,
			CAST(VejledendePris AS DECIMAL(7,0))
		FROM DataWarehouse.Kunde, DataWarehouse.Vare, DataWarehouse.Medarbejder
		WHERE	Kunde.KundeBkey % 43600 = 234 AND
				Vare.VareBkey % 11 = 4 AND
				Medarbejder.MedarbejderID % 9 = 5

INSERT INTO DataWarehouse.KundeSalg (KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, BestillingsDato,LeveringsDato, AntalEnheder, EnhedsPris)
	SELECT	Kunde.KundeSkey, 
			Vare.VareBkey, 
			3 AS SalgskanalSkey, 
			Medarbejder.MedarbejderID,
			DATEADD(DAY, - DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % 4, ISNULL(GaeldendeTil, SYSDATETIME())) AS BestillingsDato,			
			DATEADD(DAY, - DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % 4, ISNULL(GaeldendeTil, SYSDATETIME())) AS LeveringsDato,
			5 AS AntalEnheder,
			CAST(VejledendePris AS DECIMAL(7,0)) - 0.5
		FROM DataWarehouse.Kunde, DataWarehouse.Vare, DataWarehouse.Medarbejder
		WHERE	Kunde.KundeBkey % 57500 = 6890 AND
				Vare.VareBkey % 16 = 3 AND
				Medarbejder.MedarbejderID % 8 = 2
GO
UPDATE DataWarehouse.KundeSalg
	SET BestillingsDato = DATEADD(DAY, -3, LeveringsDato)
	WHERE SalgskanalSkey = 2
	
UPDATE DataWarehouse.KundeSalg
	SET BestillingsDato = DATEADD(DAY, -2, LeveringsDato)
	WHERE SalgskanalSkey = 3
GO
UPDATE DataWarehouse.KundeSalg
	SET EnhedsPris = EnhedsPris * 0.97
	WHERE AntalEnheder = 3
GO
UPDATE DataWarehouse.KundeSalg
	SET EnhedsPris = EnhedsPris * 0.9
	WHERE AntalEnheder = 5
GO
DELETE TOP (80) PERCENT
	FROM DataWarehouse.Kunde
	WHERE KundeBkey NOT IN (SELECT KundeBkey FROM DataWarehouse.KundeSalg)
GO
UPDATE DataWarehouse.KundeSalg
	SET KundeSkey = NULL
	WHERE	SalgId = 23
			
UPDATE DataWarehouse.KundeSalg
	SET SalgskanalSkey = NULL
	WHERE	SalgId % 123 = 87
GO
SET NOCOUNT ON
DECLARE @StartDato		DATETIME
DECLARE @SlutDato		DATETIME
DECLARE @Maanedsnr		SMALLINT
DECLARE @DagnrUge		SMALLINT
DECLARE @Maanedsnavn	VARCHAR(12)
DECLARE @Dagnavn		VARCHAR(12)

SET DATEFIRST 1

SET @StartDato	= DATEADD(DAY, -1030, (SELECT MIN(LeveringsDato) FROM DataWarehouse.KundeSalg))
SET @SlutDato	= DATEADD(DAY, 15, (SELECT MAX(LeveringsDato) FROM DataWarehouse.KundeSalg))
SET @SlutDato	= DATEADD(YEAR, 1, @SlutDato)

WHILE @StartDato <= @SlutDato
BEGIN
	SET @Maanedsnr = MONTH(@StartDato)
	SET @Maanedsnavn = (SELECT Maanedsnavn_da FROM DataWarehouse.Maanedsnavn WHERE Maanedsnr = @Maanedsnr)

	SET @DagnrUge = DATEPART(WEEKDAY, @Startdato)
	SET @Dagnavn = (SELECT Ugedagsnavn_da FROM DataWarehouse.Ugedagsnavn WHERE Ugedagsnr = @DagnrUge)

	INSERT INTO DataWarehouse.Tid(Dato, Aar, KvartalsNr, MaanedsNr, MaanedsNavn, DagNrIMaaned, DagNrIUge, DagNavn)
		VALUES (@Startdato, 
				YEAR(@Startdato),
				DATEPART(qq, @Startdato),
				@Maanedsnr, 
				@Maanedsnavn,
				DAY(@Startdato), 
				@DagnrUge, 
				@Dagnavn)

	SET @Startdato = DATEADD(dd, 1, @Startdato)
END
SET NOCOUNT OFF
GO
CREATE NONCLUSTERED INDEX nc_KundeSalg_KundeSkey ON DataWarehouse.KundeSalg (KundeSkey)
CREATE NONCLUSTERED INDEX nc_KundeSalg_VareSkey ON DataWarehouse.KundeSalg (VareSkey)
CREATE NONCLUSTERED INDEX nc_KundeSalg_MedarbejderId ON DataWarehouse.KundeSalg (MedarbejderId)
CREATE NONCLUSTERED INDEX nc_KundeSalg_SalgskanalSkey ON DataWarehouse.KundeSalg (SalgskanalSkey)
CREATE NONCLUSTERED INDEX nc_KundeSalg_LeveringsDato ON DataWarehouse.KundeSalg (LeveringsDato)
CREATE NONCLUSTERED INDEX nc_KundeSalg_BestillingsDato ON DataWarehouse.KundeSalg (BestillingsDato)
GO
CREATE TABLE DataWarehouse.SalgsBudget(
	VareSkey		INT NOT NULL,
	SalgskanalSkey	SMALLINT NOT NULL,
	Aar				SMALLINT NOT NULL,
	MaanedsNr		SMALLINT NOT NULL,
	AntalEnheder	INT NULL,
	CONSTRAINT PK_SalgsBudget PRIMARY KEY (VareSkey, SalgskanalSkey, Aar, MaanedsNr))
GO
INSERT INTO DataWarehouse.SalgsBudget (VareSkey, SalgskanalSkey, Aar, MaanedsNr, AntalEnheder)
	SELECT	VareTimeSalgskanal.VareSkey,
		VareTimeSalgskanal.SalgskanalSkey,
		CAST(YEAR(SYSDATETIME()) AS SMALLINT) AS Aar,  
		VareTimeSalgskanal.MaanedsNr, 
		COALESCE(Salg.AntalEnheder, 
				 567/(VareTimeSalgskanal.SalgskanalSkey + 1)  - VareTimeSalgskanal.VareSkey * 4 + VareTimeSalgskanal.MaanedsNr) AS AntalEnheder
		FROM
		 (SELECT KundeSalg.VareSkey,
			MONTH(KundeSalg.LeveringsDato) AS MaanedsNr, 
			SUM(AntalEnheder)/2 AS AntalEnheder
			FROM DataWarehouse.KundeSalg
			WHERE YEAR(KundeSalg.LeveringsDato) IN (YEAR(SYSDATETIME()) - 1, YEAR(SYSDATETIME()) - 2)
			GROUP BY KundeSalg.VareSkey, MONTH(LeveringsDato)) AS Salg 
		 RIGHT JOIN
		 (SELECT VareSkey, Maanedsnr, SalgsKanalID AS SalgskanalSkey
			FROM DataWarehouse.Vare CROSS JOIN DataWarehouse.Maanedsnavn CROSS JOIN DataWarehouse.Salgskanal 
			WHERE SalgskanalSkey > 0) AS VareTimeSalgskanal
		 ON	Salg.VareSkey = VareTimeSalgskanal.VareSkey AND 
			Salg.Maanedsnr = VareTimeSalgskanal.Maanedsnr
GO
INSERT INTO DataWarehouse.SalgsBudget
	SELECT VareSkey, SalgskanalSkey, Aar + 1, MaanedsNr, AntalEnheder * 1.03
		FROM DataWarehouse.SalgsBudget
GO
CREATE NONCLUSTERED INDEX nc_SalgsBudget_VareSkey ON DataWarehouse.SalgsBudget (VareSkey)
CREATE NONCLUSTERED INDEX nc_SalgsBudget_SalgskanalId ON DataWarehouse.SalgsBudget (SalgskanalSkey)
CREATE NONCLUSTERED INDEX nc_SalgsBudget_Aar_MaanedsNr ON DataWarehouse.SalgsBudget (Aar, MaanedsNr)
GO
DECLARE @time	DATE = SYSDATETIME()

SELECT	IDENTITY(INT) AS OrdreId, 
		KundeSkey AS KundeID, 
		VareSkey AS VareID, 
		CAST(DATEADD(DAY, - KundeSkey % 200, @time) AS DATE) AS BestillingsDato,
		CAST(DATEADD(DAY, - KundeSkey % 200 + 14, @time) AS DATE) AS LeveringsDato,
		CAST(DATEADD(DAY, - KundeSkey % 200 + 14, @time) AS DATE) AS FaktureringsDato,
		CAST(DATEADD(DAY, - KundeSkey % 200, @time) AS DATE) AS BetalingsDato,
		CAST(NULL AS DATE) AS RykkerDato, 
		AntalEnheder
	INTO HjaelpeTabeller.Ordre
	FROM (SELECT	KundeSkey, 
					VareSkey, 
					SUM(AntalEnheder) AS AntalEnheder
				FROM (SELECT TOP 100000 *  
							FROM DataWarehouse.KundeSalg) AS ks
				GROUP BY KundeSkey, VareSkey) AS Salg
	ORDER BY KundeSkey, VareSkey

DELETE 
	FROM HjaelpeTabeller.Ordre
	WHERE KundeID IS NULL

UPDATE HjaelpeTabeller.Ordre
	SET LeveringsDato = BestillingsDato
	WHERE LeveringsDato < BestillingsDato

UPDATE HjaelpeTabeller.Ordre
	SET FaktureringsDato = LeveringsDato
	WHERE FaktureringsDato < LeveringsDato

UPDATE HjaelpeTabeller.Ordre
	SET BetalingsDato = FaktureringsDato
	WHERE BetalingsDato < FaktureringsDato

SELECT DENSE_RANK() OVER (ORDER By Grp, KundeID)  AS OrdreID,
		*
	INTO HjaelpeTabeller.Ordre2
	FROM (
		SELECT	OL.KundeID,
				1 AS GRP,
				OL.VareID,
				(OL.VareID + OL.KundeID) % OL.AntalEnheder + 1 AS AntalEnheder,
				OL.BestillingsDato,
				OL.LeveringsDato,
				OL.FaktureringsDato,
				OL.BetalingsDato,
				ol.RykkerDato
			FROM (SELECT DISTINCT KundeId
						FROM HjaelpeTabeller.Ordre) AS k CROSS APPLY
											(SELECT TOP (KundeID % 5) *
												FROM HjaelpeTabeller.Ordre AS O
												WHERE k.KundeID = O.KundeID
												ORDER BY OrdreID) AS OL
		UNION ALL
		SELECT	OL.KundeID,
				2 AS GRP,
				OL.VareID,
				(OL.VareID + OL.KundeID) % OL.AntalEnheder + 1 AS AntalEnheder,
				OL.BestillingsDato,
				OL.LeveringsDato,
				OL.FaktureringsDato,
				OL.BetalingsDato,
				ol.RykkerDato
			FROM (SELECT DISTINCT KundeId	
						FROM HjaelpeTabeller.Ordre) AS k CROSS APPLY
											(SELECT TOP (KundeID % 6) *
												FROM HjaelpeTabeller.Ordre AS O
												WHERE k.KundeID = O.KundeID
												ORDER BY OrdreID DESC) AS OL) AS Resultat
SELECT	OrdreID,
		KundeID,
		MAX(BestillingsDato) AS BestillingsDato,
		MAX(FaktureringsDato) AS FaktureringsDato,
		MAX(BetalingsDato) AS BetalingsDato,
		MAX(RykkerDato) AS RykkerDato
	INTO Datawarehouse.Ordre
	FROM HjaelpeTabeller.Ordre2
	GROUP BY OrdreID, KundeID

UPDATE Datawarehouse.Ordre
	SET Rykkerdato = DATEADD(DAY, 7, BetalingsDato), 
		BetalingsDato = NULL
	WHERE	OrdreID % 265 BETWEEN 20 AND 40  AND
			KundeID % 123 BETWEEN 17 AND 80 

UPDATE Datawarehouse.Ordre
	SET BetalingsDato = DATEADD(DAY, 4, Rykkerdato)
	WHERE Rykkerdato < DATEADD(DAY, -12, SYSDATETIME())

SELECT	OrdreID,
		VareID,
		Antalenheder,
		LeveringsDato
	INTO DatawareHouse.OrdreLinie
	FROM HjaelpeTabeller.Ordre2
GO
CREATE VIEW DataWarehouse.KundeMedOrdre
AS
SELECT *
	FROM Datawarehouse.Kunde
	WHERE KundeBkey IN (SELECT KundeId
							FROM DataWarehouse.Ordre)
GO
DROP TABLE HjaelpeTabeller.Ordre
DROP TABLE HjaelpeTabeller.Ordre2
GO
SELECT TOP 10000 
		IDENTITY(INT,1,1) AS SalgId,
		KundeSkey, 
		VareSkey, 
		SalgskanalSkey, 
		MedarbejderID,
		CAST(SYSDATETIME() AS SMALLDATETIME) AS LeveringsDato, 
		CAST(AntalEnheder + 1 AS SMALLINT) AS AntalEnheder,
		EnhedsPris
	INTO DataWarehouse.NyeKundeSalg
	FROM DataWarehouse.KundeSalg
	WHERE KundeSalg.SalgId % 4 = 2
GO
ALTER TABLE DataWarehouse.NyeKundeSalg ADD CONSTRAINT PK_NyeKundeSalg PRIMARY KEY (SalgID)
GO
ALTER TABLE DataWarehouse.NyeKundeSalg ADD CONSTRAINT UQ_NyeKundeSalg UNIQUE  
		(KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, LeveringsDato)
GO
-----------------------------------------------------------------------------------------------------
-- Costum Rollup
CREATE SCHEMA CustomRollup
GO
CREATE TABLE CustomRollup.KontoPlan (
	Kontonr			INT NOT NULL PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	UnaryOp			CHAR(1) NOT NULL,
	ParentKonto		INT NULL REFERENCES CustomRollup.KontoPlan)

CREATE TABLE CustomRollup.Tid (
	DatoId			INT NOT NULL PRIMARY KEY,
	Dato			DATE NOT NULL,
	Aar				AS YEAR(Dato),
	Maaned			AS MONTH(Dato),
	DagMaaned		AS DAY(Dato))

CREATE TABLE CustomRollup.Fact (
	Kontonr			INT NOT NULL REFERENCES CustomRollup.KontoPlan,
	DatoId			INT NOT NULL REFERENCES CustomRollup.Tid,
	Beloeb			INT NOT NULL)
GO
INSERT INTO CustomRollup.KontoPlan VALUES
	(0, 'Til r�dighed', '+', NULL),

	(1, 'L�n og bank', '+', 0),
	(11, 'L�n', '+', 1),
	(12, 'Skat, ATP, mv', '-', 1),
	(13, 'Renter', '+', 1),
	(120, 'Renteindt�gter', '+', 13),
	(121, 'Renteudgifter', '-', 13),

	(1000, 'Faste udgifter', '-', 0),
	(10001, 'Husleje', '+', 1000),
	(10002, 'Bil', '+', 1000),
	(10003, 'Avis', '+', 1000)

DECLARE @Starttid	DATETIME
SET @Starttid = DATEADD(YEAR, -1, SYSDATETIME());

WITH DatoDim (Id, Dato) 
AS
(
SELECT 1 AS Id, @Starttid AS Dato
UNION ALL
SELECT Id + 1, Dato + 1
	FROM DatoDim
	WHERE Dato <= @Starttid + 365
)
INSERT INTO CustomRollup.Tid
	SELECT * 
		FROM DatoDim
OPTION(MAXRECURSION 0)

INSERT INTO CustomRollup.Fact 
	SELECT 11, DatoId, 25000
		FROM CustomRollup.Tid 
		WHERE DAY(Dato) = 1

INSERT INTO CustomRollup.Fact 
	SELECT 12, DatoId, 8000
		FROM CustomRollup.Tid 
		WHERE DAY(Dato) = 1

INSERT INTO CustomRollup.Fact 
	SELECT 120, DatoId, 300 + DatoId * 3
		FROM CustomRollup.Tid 
		WHERE DAY(Dato) = 5

INSERT INTO CustomRollup.Fact 
	SELECT 121, DatoId, 500 + DatoId * 4
		FROM CustomRollup.Tid 
		WHERE DAY(Dato) = 2

INSERT INTO CustomRollup.Fact 
	SELECT 10001, DatoId, 7000
		FROM CustomRollup.Tid 
		WHERE DAY(Dato) = 2

INSERT INTO CustomRollup.Fact 
	SELECT 10002, DatoId, 100 + (DatoId % 4) * 4
		FROM CustomRollup.Tid 
		WHERE DATEPART(WEEKDAY, Dato) IN (1, 2, 7)

INSERT INTO CustomRollup.Fact 
	SELECT 10003, DatoId, 400
		FROM CustomRollup.Tid 
		WHERE DAY(Dato) = 1
GO
----------------------------------------------------------------------------------------
-- Datamining
CREATE SCHEMA Datamining
GO
SELECT	TOP 30000 IDENTITY(INT, 1, 1) AS KundeSkey, 
		Navn, 
		Gade, 
		Postnr, 
		Kundetype, 
		Koen, 
		'G' AS AegteskabeligStatus, 
		KundeSkey % 5 AS AntalBoern
	INTO Datamining.Kunde
	FROM DataWarehouse.Kunde
	WHERE KundeSkey % 12 = 2
GO
UPDATE Datamining.Kunde 
	SET Kundetype = 'B' 
	WHERE KundeSkey % 10 = 4
UPDATE Datamining.Kunde 
	SET Kundetype = 'C' 
	WHERE KundeSkey % 36 = 8
UPDATE Datamining.Kunde 
	SET Kundetype = 'D' 
	WHERE KundeSkey % 134 = 54
UPDATE Datamining.Kunde 
	SET Kundetype = 'C' 
	WHERE KundeSkey % 99 = 87
UPDATE Datamining.Kunde 
	SET Kundetype = 'D' 
	WHERE KundeSkey % 211 = 17

UPDATE Datamining.Kunde 
	SET AegteskabeligStatus = 'U' 
	WHERE KundeSkey % 4 = 2
UPDATE Datamining.Kunde 
	SET AegteskabeligStatus = 'F' 
	WHERE KundeSkey % 8 = 6
UPDATE Datamining.Kunde 
	SET AegteskabeligStatus = 'S' 
	WHERE KundeSkey % 17 = 3
UPDATE Datamining.Kunde 
	SET AegteskabeligStatus = 'E' 
	WHERE KundeSkey % 13 = 8 
GO 
SELECT TOP 30000 IDENTITY(INT, 1, 1) AS KundeSkey, 
		YEAR(SYSDATETIME()) - 4 AS Aar,
		(((KundeSkey/7) * Postnr) % 9) + 1 AS AntalKoeb, 
		(((KundeSkey/5) * Postnr) % 8976) + 214 AS KoebIalt 
	INTO Datamining.KundeTransaktionMinus4
	FROM DataWarehouse.Kunde
	WHERE KundeSkey % 12 = 2
GO
SELECT	TOP 30000 IDENTITY(INT, 1, 1) AS KundeSkey, 
		YEAR(SYSDATETIME()) - 3 AS Aar,
		(((KundeSkey/7) * Postnr) % 11) + 4 AS AntalKoeb, 
		(((KundeSkey/5) * Postnr) % 9764) + 498 AS KoebIalt 
	INTO Datamining.KundeTransaktionMinus3
	FROM DataWarehouse.Kunde
	WHERE KundeSkey % 12 = 3
GO
SELECT	TOP 30000 IDENTITY(INT, 1, 1) AS KundeSkey, 
		YEAR(SYSDATETIME()) - 2 AS Aar,
		(((KundeSkey/8) * Postnr) % 14) + 3 AS AntalKoeb, 
		(((KundeSkey/9) * Postnr) % 10975) + 389 AS KoebIalt 
	INTO Datamining.KundeTransaktionMinus2
	FROM DataWarehouse.Kunde
	WHERE KundeSkey % 12 = 4
GO
SELECT	TOP 30000 IDENTITY(INT, 1, 1) AS KundeSkey, 
		YEAR(SYSDATETIME()) - 1 AS Aar,
		(((KundeSkey/7) * Postnr) % 17) + 6 AS AntalKoeb, 
		(((KundeSkey/5) * Postnr) % 14628) + 786 AS KoebIalt 
	INTO Datamining.KundeTransaktionMinus1
	FROM DataWarehouse.Kunde
	WHERE KundeSkey % 12 = 5

SELECT TOP 30000 IDENTITY(INT, 1, 1) AS KundeSkey, 
		YEAR(SYSDATETIME()) AS Aar,
		(((KundeSkey/6) * Postnr) % 15) + 5 AS AntalKoeb, 
		(((KundeSkey/4) * Postnr) % 6958) + 351 AS KoebIalt 
	INTO Datamining.KundeTransaktionMinus0
	FROM DataWarehouse.Kunde
	WHERE KundeSkey % 12 = 7
GO
DELETE FROM Datamining.KundeTransaktionMinus4 
	WHERE KundeSkey % 23 = 3
DELETE FROM Datamining.KundeTransaktionMinus3 
	WHERE KundeSkey % 13 = 2
DELETE FROM Datamining.KundeTransaktionMinus2 
	WHERE KundeSkey % 40 = 36 
DELETE FROM Datamining.KundeTransaktionMinus1 
	WHERE KundeSkey % 37 = 29
DELETE FROM Datamining.KundeTransaktionMinus0 
	WHERE KundeSkey % 20 = 19

DELETE FROM Datamining.KundeTransaktionMinus4 
	WHERE KundeSkey % 24 = 18
DELETE FROM Datamining.KundeTransaktionMinus3 
	WHERE KundeSkey % 23 = 12
DELETE FROM Datamining.KundeTransaktionMinus2 
	WHERE KundeSkey % 11 = 4
DELETE FROM Datamining.KundeTransaktionMinus1 
	WHERE KundeSkey % 21 = 19
DELETE FROM Datamining.KundeTransaktionMinus0 
	WHERE KundeSkey % 9 = 7
GO
SELECT *
	INTO Datamining.KundeTransaktion
	FROM (
		SELECT * FROM Datamining.KundeTransaktionMinus4
		UNION ALL
		SELECT * FROM Datamining.KundeTransaktionMinus3
		UNION ALL
		SELECT * FROM Datamining.KundeTransaktionMinus2
		UNION ALL
		SELECT * FROM Datamining.KundeTransaktionMinus1
		UNION ALL
		SELECT * FROM Datamining.KundeTransaktionMinus0
		) AS Kt
GO
DROP TABLE Datamining.KundeTransaktionMinus4
DROP TABLE Datamining.KundeTransaktionMinus3
DROP TABLE Datamining.KundeTransaktionMinus2
DROP TABLE Datamining.KundeTransaktionMinus1
DROP TABLE Datamining.KundeTransaktionMinus0
GO
ALTER TABLE Datamining.Kunde ADD CONSTRAINT PK_KundeDM PRIMARY KEY (KundeSkey)

ALTER TABLE Datamining.KundeTransaktion ALTER COLUMN KundeSkey INT NOT NULL
ALTER TABLE Datamining.KundeTransaktion ALTER COLUMN Aar SMALLINT NOT NULL
GO
ALTER TABLE Datamining.KundeTransaktion ADD CONSTRAINT PK_KundeDMTransaktion PRIMARY KEY (KundeSkey, Aar)
		
ALTER TABLE Datamining.KundeTransaktion ADD CONSTRAINT FK_KundeDM_KundeDMTransaktion
		FOREIGN KEY (KundeSkey) REFERENCES Datamining.Kunde(KundeSkey)
GO
SELECT TOP 0 *
	INTO Datamining.KundeNy
	FROM Datamining.Kunde
GO
INSERT INTO Datamining.KundeNy VALUES
	('Ole Jensen', 'Vestergade 5', 8000, 'A', 'M', 'U', 4),
	('Dorte Larsen', 'Nygade 2', 2000, 'A', 'K', 'G', 1),
	('Ane Pedersen', 'Torvet 12', 2000, 'A', 'K', 'U', 2),
	('Per Olsen', '�stergade 4', 9000, 'D', 'M', 'G', 0),
	('Lars Ibsen', 'Vestergade 21', 2000, 'A', 'M', 'U', 4),
	('David Hansen', 'Nygade 6', 3000, 'C', 'K', 'G', 1),
	('Lise Knudsen', 'Torvegade 67', 2000, 'A', 'K', 'G', 5),
	('Klaus Petersen', 'S�ndergade 44', 8000, 'A', 'M', 'E', 0),
	('Karin Larsen', 'Vestergade 1', 2000, 'A', 'M', 'G', 0),
	('Sofie Jensen', 'Nygade 11', 2000, 'B', 'K', 'U', 1),
	('Bente Olesen', 'Torvet 3', 2000, 'A', 'K', 'U', 2),
	('Arvid S�rensen', '�stergade 114', 8000, 'A', 'M', 'G', 10)
GO
-----------------------------------------------------------------------------------------------------
-- Many-To-Many
CREATE SCHEMA ManyToMany
GO
SELECT	TOP 10 IDENTITY(INT, 1, 1) AS KundeMedKontoID, 
		KundeSkey + 1 - 1 AS KundeSkey		-- undg� at kolonne bliver identity
	INTO ManyToMany.KundeMedKonto
	FROM DataWarehouse.Kunde
	WHERE KundeSkey % 2378 = 28

SELECT	KundeMedKontoID + 1 - 1 AS KontoID, 
		(KundeSkey % 6) * 56 + 200 AS KontoSaldo
	INTO ManyToMany.Konto
	FROM ManyToMany.KundeMedKonto

SELECT	KundeSkey + 1 - 1 AS KundeSkey, 
		KundeMedKontoID + 1 - 1 AS KontoID
	INTO ManyToMany.KundeKonto
	FROM ManyToMany.KundeMedKonto

INSERT INTO ManyToMany.KundeKonto
	SELECT KundeSkey, KontoID
		FROM (SELECT TOP 3 KundeSkey FROM ManyToMany.KundeMedKonto) AS Kunde
			  CROSS JOIN
			 (SELECT TOP 2 KontoID FROM ManyToMany.Konto ORDER BY KontoSaldo) AS Konto

DELETE TOP (1)
	FROM ManyToMany.KundeKonto
	WHERE KundeSkey IN (SELECT KundeSkey
						FROM ManyToMany.KundeKonto
						GROUP BY KundeSkey, KontoID
						HAVING COUNT(*) > 2)  
GO
SELECT *
	INTO ManyToMany.Kunde
	FROM DataWarehouse.Kunde
	WHERE KundeSkey IN (SELECT KundeSkey 
							FROM ManyToMany.KundeKonto)
GO
DROP TABLE ManyToMany.KundeMedKonto
GO
DROP SCHEMA HjaelpeTabeller
GO
-- vis alle tabeller og antal forekomster
USE BIDB
GO
SET NOCOUNT ON
DECLARE @TableName		SYSNAME
DECLARE @SchemaName		SYSNAME
DECLARE @Antal			INT
DECLARE @SQLString		NVARCHAR(500);

DECLARE @t TABLE(
	ID					INT NOT NULL IDENTITY,
	Object_id			INT NOT NULL,
	TableName			SYSNAME NOT NULL,
	SchemaName			SYSNAME NOT NULL,
	AntalForekomster	INT NULL,
	Brugt				CHAR(1) DEFAULT('N'))

INSERT INTO @t (Object_id, TableName, SchemaName)
	SELECT t.object_id, t.name, s.name 
		FROM sys.tables as t INNER JOIN sys.schemas as s 
			ON t.schema_id = s.schema_id
		ORDER BY t.name

WHILE EXISTS (SELECT * FROM @t WHERE Brugt = 'N')
BEGIN
	SELECT	@TableName = TableName, 
			@SchemaName = SchemaName
		FROM @t
		WHERE ID = (SELECT MIN(ID) FROM @t WHERE Brugt = 'N')
		
	SET @SQLString = 'SET @Antal = (SELECT COUNT(*) FROM ' + @SchemaName + '.' + @TableName + ')'
	EXECUTE sp_executesql @SqlString, N'@Antal INT OUTPUT', @Antal OUTPUT

	UPDATE @t
		SET AntalForekomster = @Antal, Brugt = 'Y'
		WHERE TableName = @TableName AND SchemaName = @SchemaName
END
SELECT TableName, SchemaName, AntalForekomster 
	FROM @t
	ORDER BY SchemaName, TableName
GO
USE BIDB
GO
CHECKPOINT
GO
DBCC SHRINKDATABASE(N'BIDB')
GO
