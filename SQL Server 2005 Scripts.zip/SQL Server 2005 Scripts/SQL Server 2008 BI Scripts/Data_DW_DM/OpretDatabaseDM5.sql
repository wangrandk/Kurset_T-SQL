--- Datamart 5 - Costum RollUp
USE master
GO
IF EXISTS (SELECT * FROM master.sys.databases WHERE name = 'BIDB_DM5')
	DROP DATABASE BIDB_DM5
GO
CREATE DATABASE BIDB_DM5
ON PRIMARY
	(NAME = N'BIDB_DM5_Sys', 
	FILENAME = N'c:\Databaser\BIDB_DM5_Data.MDF', 
	SIZE = 40,
	FILEGROWTH = 10%),
FILEGROUP DataFG
	(NAME = N'BIDB_DM5_Data1', 
	FILENAME = N'c:\Databaser\BIDB_DM5_DataFG_Fil1.NDF', 
	SIZE = 10,
	FILEGROWTH = 25%)
LOG ON 
	(NAME = N'BIDB_DM5_Log',
	FILENAME = N'c:\Databaser\BIDB_DM5_Log.LDF', 
	SIZE = 2,
	FILEGROWTH = 10%)
GO
USE BIDB_DM5
GO
ALTER DATABASE BIDB_DM5 SET RECOVERY SIMPLE
GO
ALTER DATABASE BIDB_DM5 MODIFY FILEGROUP DataFG DEFAULT
GO
CREATE SCHEMA Datamart
GO
SELECT *
	INTO Datamart.Tid
	FROM BIDB.CustomRollup.Tid
	
SELECT *
	INTO Datamart.KontoPlan
	FROM BIDB.CustomRollup.KontoPlan

SELECT *
	INTO Datamart.Fact
	FROM BIDB.CustomRollup.Fact
GO
-- vis alle tabeller og antal forekomster
USE BIDB_DM5
GO
SET NOCOUNT ON
DECLARE @TableName		SYSNAME
DECLARE @SchemaName		SYSNAME
DECLARE @Antal			INT
DECLARE @SQLString		NVARCHAR(500);

DECLARE @t TABLE(
	ID					INT NOT NULL IDENTITY,
	Object_id			INT NOT NULL,
	TableName			SYSNAME NOT NULL,
	SchemaName			SYSNAME NOT NULL,
	AntalForekomster	INT NULL,
	Brugt				CHAR(1) DEFAULT('N'))

INSERT INTO @t (Object_id, TableName, SchemaName)
	SELECT t.object_id, t.name, s.name 
		FROM sys.tables as t INNER JOIN sys.schemas as s 
			ON t.schema_id = s.schema_id
		ORDER BY t.name

WHILE EXISTS (SELECT * FROM @t WHERE Brugt = 'N')
BEGIN
	SELECT	@TableName = TableName, 
			@SchemaName = SchemaName
		FROM @t
		WHERE ID = (SELECT MIN(ID) FROM @t WHERE Brugt = 'N')
		
	SET @SQLString = 'SET @Antal = (SELECT COUNT(*) FROM ' + @SchemaName + '.' + @TableName + ')'
	EXECUTE sp_executesql @SqlString, N'@Antal INT OUTPUT', @Antal OUTPUT

	UPDATE @t
		SET AntalForekomster = @Antal, Brugt = 'Y'
		WHERE TableName = @TableName AND SchemaName = @SchemaName
END
SELECT TableName, SchemaName, AntalForekomster 
	FROM @t
	ORDER BY SchemaName, TableName
GO
