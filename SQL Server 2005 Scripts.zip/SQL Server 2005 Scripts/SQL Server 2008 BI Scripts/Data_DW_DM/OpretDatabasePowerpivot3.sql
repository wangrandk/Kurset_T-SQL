--- Datamart PowerPivot3
USE master
GO
IF EXISTS (SELECT * FROM master.sys.databases WHERE name = 'BIDBPowerPivot3')
	DROP DATABASE BIDBPowerPivot3
GO
CREATE DATABASE BIDBPowerPivot3
ON PRIMARY
	(NAME = N'BIDBPowerPivot3_Sys',
	FILENAME = N'c:\Databaser\BIDBPowerPivot3_Data.MDF', 
	SIZE = 5,
	FILEGROWTH = 10%),

FILEGROUP DataFG
	(NAME = N'BIDBPowerPivot3_Data1',
	FILENAME = N'c:\Databaser\BIDBPowerPivot3_DataFG_Fil1.NDF', 
	SIZE = 150,
	FILEGROWTH = 25%)

LOG ON 
	(NAME = N'BIDBPowerPivot3_Log',
	FILENAME = N'c:\Databaser\BIDBPowerPivot3_Log.LDF', 
	SIZE = 100,
	FILEGROWTH = 100)
GO
USE BIDBPowerPivot3
CREATE TABLE Tid1
(
	Dato			DATE NOT NULL PRIMARY KEY,
	Beloeb			INT NULL DEFAULT(5)
)
CREATE TABLE Tid2
(
	Dato			DATE NOT NULL PRIMARY KEY,
	Beloeb			INT NULL DEFAULT(5)
)
CREATE TABLE Tid3
(
	Dato			DATE NOT NULL PRIMARY KEY,
	Beloeb			INT NULL DEFAULT(5)
)
GO
WITH Tid (Dato)
AS
(
SELECT DATEADD(DAY, -2000, SYSDATETIME()) AS Dato
UNION ALL
SELECT DATEADD(DAY, 1, Dato)
	FROM Tid
	WHERE Dato < SYSDATETIME()
)
INSERT INTO Tid1(Dato)
	SELECT Dato
		FROM Tid
	OPTION (MAXRECURSION 0);
	
UPDATE Tid1
	SET Beloeb = 0
	WHERE DATEPART(WEEKDAY, Dato) = 1
GO		
WITH Tid (Dato)
AS
(
SELECT DATEADD(DAY, -2000, SYSDATETIME()) AS Dato
UNION ALL
SELECT DATEADD(DAY, 1, Dato)
	FROM Tid
	WHERE Dato < SYSDATETIME()
)
INSERT INTO Tid2(Dato)
	SELECT Dato
		FROM Tid
	OPTION (MAXRECURSION 0);

DELETE 
	FROM Tid2
	WHERE DATEPART(WEEKDAY, Dato) = 1;
GO	
WITH Tid (Dato)
AS
(
SELECT DATEADD(DAY, -2000, SYSDATETIME()) AS Dato
UNION ALL
SELECT DATEADD(DAY, 1, Dato)
	FROM Tid
	WHERE Dato < SYSDATETIME()
)
INSERT INTO Tid3(Dato)
	SELECT Dato
		FROM Tid
	OPTION (MAXRECURSION 0)

UPDATE Tid3
	SET Beloeb = NULL
	WHERE DATEPART(WEEKDAY, Dato) = 1
GO
SELECT SUM(Beloeb)
	FROM Tid1
SELECT SUM(Beloeb)
	FROM Tid2
SELECT SUM(Beloeb)
	FROM Tid3

SELECT COUNT(*)
	FROM Tid1
SELECT COUNT(*)
	FROM Tid2
SELECT COUNT(*)
	FROM Tid3
	
SELECT *
	FROM Tid1
SELECT *
	FROM Tid2
SELECT *
	FROM Tid3
GO
CREATE TABLE NullData
(
	ID					INT NOT NULL PRIMARY KEY,
	i					INT NULL,
	j					INT NULL,
	k					INT NULL,
	l					INT NULL
)
GO
INSERT INTO NullData VALUES
	(1, 10, 10, 10, NULL),
	(2, 10, 10, 10, NULL),
	(3, 10, 10, 10, NULL),
	(4, 10, 0, NULL, NULL),
	(5, 10, 0, NULL, NULL),
	(6, 10, 0, NULL, NULL)
GO
CREATE TABLE DateFunction
(
	ID					INT NOT NULL PRIMARY KEY,
	Aar					SMALLINT NOT NULL,
	Maaned				SMALLINT NOT NULL,
	Dag					SMALLINT NOT NULL
)
GO
INSERT INTO DateFunction VALUES
	(1, 2011, 9, 20),
	(2, 2011, 19, 20),
	(3, 2011, 9, 31),
	(4, 2011, -19, 20),
	(5, 2011, 9, -20),
	(6, 1, 9, 20),
	(7, 11, 9, 20)
GO
-- vis alle tabeller og antal forekomster
USE BIDBPowerPivot3
GO
SET NOCOUNT ON
DECLARE @TableName		SYSNAME
DECLARE @SchemaName		SYSNAME
DECLARE @Antal			INT
DECLARE @SQLString		NVARCHAR(500);

DECLARE @t TABLE
(
	ID					INT NOT NULL IDENTITY,
	Object_id			INT NOT NULL,
	TableName			SYSNAME NOT NULL,
	SchemaName			SYSNAME NOT NULL,
	AntalForekomster	INT NULL,
	Brugt				CHAR(1) DEFAULT('N')
)

INSERT INTO @t (Object_id, TableName, SchemaName)
	SELECT t.object_id, t.name, s.name 
		FROM sys.tables as t INNER JOIN sys.schemas as s 
			ON t.schema_id = s.schema_id
		ORDER BY t.name

WHILE EXISTS (SELECT * FROM @t WHERE Brugt = 'N')
BEGIN
	SELECT	@TableName = TableName, 
			@SchemaName = SchemaName
		FROM @t
		WHERE ID = (SELECT MIN(ID) 
						FROM @t 
						WHERE Brugt = 'N')
		
	SET @SQLString = 'SET @Antal = (SELECT COUNT(*) FROM ' + @SchemaName + '.' + @TableName + ')'
	EXECUTE sp_executesql @SqlString, N'@Antal INT OUTPUT', @Antal OUTPUT

	UPDATE @t
		SET AntalForekomster = @Antal, 
			Brugt = 'Y'
		WHERE	TableName = @TableName AND 
				SchemaName = @SchemaName
END
SELECT TableName, SchemaName, AntalForekomster 
	FROM @t
	ORDER BY SchemaName, TableName
GO
USE BIDBPowerPivot3
GO
CHECKPOINT
GO
DBCC SHRINKDATABASE(N'BIDBPowerPivot3' )
GO
