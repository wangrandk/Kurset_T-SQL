USE IndexDB;
GO
SET STATISTICS TIME, IO ON;
SELECT Fornavn
	FROM dbo.Person
	WHERE Fornavn = 'Susanne';

SELECT Efternavn
	FROM dbo.Person
	WHERE Efternavn = 'Thomsen';

SELECT Fornavn, Efternavn
	FROM dbo.Person
	WHERE Fornavn = 'Susanne' AND
		  Efternavn = 'Thomsen';
GO
CREATE NONCLUSTERED INDEX nc_Person_Fornavn ON dbo.Person(Fornavn);
CREATE NONCLUSTERED INDEX nc_Person_Efternavn ON dbo.Person(Efternavn);
GO
SELECT Fornavn
	FROM dbo.Person
	WHERE Fornavn = 'Susanne';

SELECT Efternavn
	FROM dbo.Person
	WHERE Efternavn = 'Thomsen';

SELECT Fornavn, Efternavn
	FROM dbo.Person
	WHERE Fornavn = 'Susanne' AND
		  Efternavn = 'Thomsen';
GO
DROP INDEX nc_Person_Efternavn ON dbo.Person;
CREATE NONCLUSTERED INDEX nc_Person_Fornavn_Efternavn ON dbo.Person(Fornavn, Efternavn);
GO
SELECT Fornavn
	FROM dbo.Person
	WHERE Fornavn = 'Susanne';

SELECT Efternavn
	FROM dbo.Person
	WHERE Efternavn = 'Thomsen';

SELECT Fornavn, Efternavn
	FROM dbo.Person
	WHERE Fornavn = 'Susanne' AND
		  Efternavn = 'Thomsen';
GO
DROP INDEX nc_Person_Fornavn_Efternavn ON dbo.Person;
DROP INDEX nc_Person_Fornavn ON dbo.Person;
GO
CREATE NONCLUSTERED INDEX nc_Person_Fornavn ON dbo.Person(Fornavn);
CREATE NONCLUSTERED INDEX nc_Person_Efternavn_Fornavn ON dbo.Person(Efternavn, Fornavn);
GO
SELECT Fornavn
	FROM dbo.Person
	
	WHERE Fornavn = 'Susanne';

SELECT Efternavn
	FROM dbo.Person
	WHERE Efternavn = 'Thomsen';

SELECT Fornavn, Efternavn
	FROM dbo.Person
	WHERE Fornavn = 'Susanne' AND
		  Efternavn = 'Thomsen';
GO
CREATE NONCLUSTERED INDEX nc_Person_Efternavn ON dbo.Person(Efternavn);
GO
SELECT Fornavn
	FROM dbo.Person
	WHERE Fornavn = 'Susanne';

SELECT Efternavn
	FROM dbo.Person
	WHERE Efternavn = 'Thomsen';

SELECT Fornavn, Efternavn
	FROM dbo.Person
	WHERE Fornavn = 'Susanne' AND
		  Efternavn = 'Thomsen';
GO