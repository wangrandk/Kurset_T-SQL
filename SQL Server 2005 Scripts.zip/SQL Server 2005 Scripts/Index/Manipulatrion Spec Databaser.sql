USE IndexDB;
GO
EXEC sp_spaceused 'Person';
GO
USE Index2DB;
GO
EXEC sp_spaceused 'Person';
GO
USE Index3DB;
GO
EXEC sp_spaceused 'Person';
GO
USE Index4DB;
GO
EXEC sp_spaceused 'Person';
GO
USE Index5DB;
GO
EXEC sp_spaceused 'Person';
GO
USE IndexDB
GO
SET STATISTICS TIME ON;
SET STATISTICS IO ON;
USE IndexDB
GO
SELECT	PersonID,
		Fornavn,
		Efternavn,
		Gade,
		Postnr,
		Koenkode,
		Landekode,
		Tlfnr,
		Persontype
	FROM dbo.Person
	WHERE Personid BETWEEN 1000000 AND 2000000;
GO
USE Index2DB
GO
SELECT	PersonID,
		Fornavn,
		Efternavn,
		Gade,
		Postnr,
		Koenkode,
		Landekode,
		Tlfnr,
		Persontype
	FROM dbo.Person
	WHERE Personid BETWEEN 1000000 AND 2000000;
GO
USE Index3DB
GO
SELECT	PersonID,
		Fornavn,
		Efternavn,
		Gade,
		Postnr,
		Koenkode,
		Landekode,
		Tlfnr,
		Persontype
	FROM dbo.Person
	WHERE Personid BETWEEN 1000000 AND 2000000;
GO
USE Index4DB
GO
SELECT	PersonID,
		Fornavn,
		Efternavn,
		Gade,
		Postnr,
		Koenkode,
		Landekode,
		Tlfnr,
		Persontype
	FROM dbo.Person
	WHERE Personid BETWEEN 1000000 AND 2000000;
GO
USE Index5DB
GO
SELECT	PersonID,
		Fornavn,
		Efternavn,
		Gade,
		Postnr,
		Koenkode,
		Landekode,
		Tlfnr,
		Persontype
	FROM dbo.Person
	WHERE Personid BETWEEN 1000000 AND 2000000;
GO
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
USE IndexDB;
GO
SELECT *
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL, 'DETAILED');
GO
USE Index2DB;
GO
SELECT *
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL, 'DETAILED');
GO
USE Index3DB;
GO
SELECT *
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL, 'DETAILED');
GO
USE Index4DB;
GO
SELECT *
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL, 'DETAILED');
GO
USE Index5DB;
GO
SELECT *
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL, 'DETAILED');
GO
