USE master
DROP DATABASE IndexDB
GO
CREATE DATABASE IndexDB
GO
USE IndexDB
CREATE TABLE Person (
	Personid		INT NOT NULL,
	Navn			VARCHAR(30) NOT NULL,
	Gade			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL)
GO
SET noCOUNT on
DECLARE @i	int
SET @i = 10000
WHILE @i < 14000
begin
	INSERT INTO Person VALUES (@i, CAST(@i AS VARCHAR(5)),
							   CAST(@i AS VARCHAR(5)), 2000)
	SET @i = @i + 1
END
SET NOCOUNT OFF
GO
CREATE NONCLUSTERED INDEX ix_Person_Personid
	ON Person(Personid) include (navn, gade)
GO
DBCC SHOWCONTIG (Person, ix_Person_Personid)
GO
UPDATE Person
	SET navn = CAST(14000 - Personid AS VARCHAR(5)) 
GO
DBCC SHOWCONTIG (Person, ix_Person_Personid)
-------- uden include ----------------------------------------------
USE master
DROP DATABASE IndexDB
GO
CREATE DATABASE IndexDB
GO
USE IndexDB
CREATE TABLE Person (
	Personid		INT NOT NULL,
	Navn			VARCHAR(30) NOT NULL,
	Gade			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL)
GO
SET NOCOUNT ON
DECLARE @i	INT
SET @i = 10000
WHILE @i < 14000
begin
	INSERT INTO Person VALUES (@i, CAST(@i AS VARCHAR(5)),
							   CAST(@i AS VARCHAR(5)), 2000)
	SET @i = @i + 1
END
SET NOCOUNT OFF
GO
CREATE NONCLUSTERED INDEX ix_Person_Personid
	ON Person(Personid, navn, gade)
GO
DBCC SHOWCONTIG (Person, ix_Person_Personid)
GO
UPDATE Person
	SET navn = CAST(14000 - Personid AS VARCHAR(5)) 
GO
DBCC SHOWCONTIG (Person, ix_Person_Personid)