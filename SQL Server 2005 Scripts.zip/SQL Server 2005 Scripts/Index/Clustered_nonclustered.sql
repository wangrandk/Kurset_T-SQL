USE IndexDB
GO
INSERT INTO Persontype VALUES ('E', 'Ukendt')
INSERT INTO postopl VALUES (9310, 'Vodskov')
INSERT INTO Person (Fornavn, Efternavn, gade, postnr, Persontype) 
	VALUES ('Olfert', 'Guldbrandsen', 'Lergravsvej 234', 9310, 'E')
GO
SET STATISTICS IO ON
INSERT INTO Person (Fornavn, Efternavn, gade, postnr, Persontype) -- med clustered index
	VALUES ('Jens', 'Olsen', 'Vestergade 14', 9400, 'D')
SET STATISTICS IO OFF
GO
SELECT * 
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL , NULL);
GO
ALTER TABLE Person DROP CONSTRAINT pk_Person
GO
SELECT * 
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL , NULL);
GO
SET STATISTICS IO ON
INSERT INTO Person (Fornavn, Efternavn, gade, postnr, Persontype)	-- heap (sidst)
	VALUES ('Jens', 'Olsen', 'Vestergade 14', 9400, 'D')
SET STATISTICS IO OFF
GO
DELETE FROM Person WHERE Personid < 10
GO
SET STATISTICS IO ON
INSERT INTO Person (Fornavn, Efternavn, gade, postnr, Persontype) -- heap (formodentlig f�rst)
	VALUES ('Jens', 'Olsen', 'Vestergade 14', 9400, 'D')
SET STATISTICS IO OFF
GO
CREATE NONCLUSTERED INDEX nc_Person_gade ON Person(gade)
CREATE NONCLUSTERED INDEX nc_Person_Efternavn ON Person(Efternavn)
CREATE NONCLUSTERED INDEX nc_Person_postnr ON Person(postnr)
CREATE NONCLUSTERED INDEX nc_Person_Persontype ON Person(Persontype)
GO
SET STATISTICS IO ON
SELECT * FROM Person WHERE Efternavn = 'Guldbrandsen'
SELECT * FROM Person WHERE gade =  'Lergravsvej 234'
SELECT * FROM Person WHERE postnr = 9310
SELECT * FROM Person WHERE Persontype = 'E'
SET STATISTICS IO OFF
GO
SELECT * 
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL , 'DETAILED');
GO
CREATE UNIQUE CLUSTERED INDEX pk_Person ON Person(Personid)
GO
SELECT * 
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL , NULL);
GO
SET STATISTICS IO ON
SELECT * FROM Person WHERE Efternavn = 'Guldbrandsen'
SELECT * FROM Person WHERE gade =  'Lergravsvej 234'
SELECT * FROM Person WHERE postnr = 9310
SELECT * FROM Person WHERE Persontype = 'E'
SET STATISTICS IO OFF
GO
SET STATISTICS IO ON
INSERT INTO Person (Fornavn, Efternavn, gade, postnr, Persontype) 
	VALUES ('Jens', 'Olsen', 'Vestergade 14', 9400, 'D')
SET STATISTICS IO OFF
GO
