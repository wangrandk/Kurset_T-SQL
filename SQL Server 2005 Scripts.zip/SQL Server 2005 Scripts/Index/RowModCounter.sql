USE IndexDB;
GO
SELECT	objects.name, 
		sysindexes.indid,
		sysindexes.name, 
		sysindexes.rowmodctr, 
		sysindexes.rowcnt, 
		objects.type
	FROM sys.objects objects INNER JOIN sys.sysindexes sysindexes 
		ON objects.object_id = sysindexes.id
	WHERE	objects.type IN ('U', 'IT') AND 
			sysindexes.indid > 0 
	ORDER BY objects.type DESC, objects.name;
