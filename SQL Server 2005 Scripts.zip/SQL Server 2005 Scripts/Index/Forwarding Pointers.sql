USE master
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB
CREATE TABLE dbo.Person 
(
	PersonId		INT NOT NULL PRIMARY KEY NONCLUSTERED,
	Fornavn			VARCHAR(200) NOT NULL INDEX nc_Person_Fornavn,
	Efternavn		VARCHAR(200) NOT NULL INDEX nc_Person_Efternavn,
	Gade			VARCHAR(300) NOT NULL INDEX nc_Person_Gade,
	Postnr			SMALLINT NOT NULL INDEX nc_Person_Postnr,
	Ubrugt			CHAR(900) NOT NULL DEFAULT(REPLICATE('x', 900))	
);
GO
SET NOCOUNT ON
INSERT INTO dbo.Person (PersonId, Fornavn, Efternavn, Gade, Postnr) VALUES 
	(1, 'Ole', 'Olsen', 'Nygade 2', 8000),
	(2, 'Ole', 'Jensen', 'Nygade 2', 8000),
	(3, 'Ole', 'Hansen', 'Nygade 2', 8000),
	(4, 'Ole', 'Pedersen', 'Nygade 2', 8000),
	(5, 'Ole', 'Andersen', 'Nygade 2', 8000),
	(6, 'Ole', 'Larsen', 'Nygade 2', 8000),
	(7, 'Ole', 'Knudsen', 'Nygade 2', 8000),
	(8, 'Ole', 'B�rgesen', 'Nygade 2', 8000),
	(9, 'Ole', 'S�rensen', 'Nygade 2', 8000),
	(10, 'Ole', 'Madsen', 'Nygade 2', 8000),
	(11, 'Ole', 'Poulsen', 'Nygade 2', 8000),
	(12, 'Ole', 'Davidsen', 'Nygade 2', 8000),
	(13, 'Ole', 'Eriksen', 'Nygade 2', 8000);
SET NOCOUNT OFF
GO
INSERT INTO dbo.Person (PersonId, Fornavn, Efternavn, Gade, Postnr)
	SELECT	PersonId + (SELECT MAX(PersonID) FROM dbo.Person), 
			Fornavn, 
			Efternavn, 
			Gade, 
			Postnr
		FROM dbo.Person;
GO 10
--DELETE TOP (90) PERCENT
--	FROM dbo.Person
--	WHERE Efternavn = 'Poulsen';
GO
UPDATE STATISTICS dbo.Person WITH FULLSCAN;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		PersonID, 
		Fornavn, 
		Efternavn 
	FROM Person
	WHERE Efternavn = 'Poulsen';

UPDATE Person
	SET Gade = REPLICATE(Gade, 10)

UPDATE Person
	SET Fornavn = REPLICATE(Fornavn, 20)

SET STATISTICS IO ON;
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		PersonID, 
		Fornavn, 
		Efternavn 
	FROM Person
	WHERE Efternavn = 'Poulsen';

SELECT i.name,  ps.forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id
	WHERE I.index_id = 0;

ALTER TABLE dbo.Person REBUILD;

SELECT	i.name,
		ps.forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'DETAILED') AS ps 
			INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id
	WHERE I.index_id = 0;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		PersonID, 
		Fornavn, 
		Efternavn 
	FROM Person
	WHERE Efternavn = 'Poulsen';
