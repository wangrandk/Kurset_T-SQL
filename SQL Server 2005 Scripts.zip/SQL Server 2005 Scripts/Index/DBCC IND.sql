USE IndexDB
GO
CREATE INDEX nc_Person_Persontype ON Person(Persontype)
GO
DBCC IND (IndexDB, Person, 1)
