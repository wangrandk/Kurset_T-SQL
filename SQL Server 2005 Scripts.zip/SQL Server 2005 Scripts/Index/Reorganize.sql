USE master;
GO
DROP DATABASE StorageDB;
GO
CREATE DATABASE StorageDB;
GO
USE StorageDB;
GO
CREATE TABLE dbo.Data
(
	ID			INT NOT NULL CONSTRAINT PK_Data PRIMARY KEY CLUSTERED,
	Txt1		VARCHAR(198) NOT NULL DEFAULT (REPLICATE('A', 198)) 
				INDEX nc_Data_Txt1 WITH(FILLFACTOR = 85),
	Txt2		VARCHAR(198) NOT NULL DEFAULT (REPLICATE('A', 198)) 
				INDEX nc_Data_Txt2 WITH(FILLFACTOR = 85)
);
GO
SET NOCOUNT ON;

DECLARE @Maxrows		INT = 4000;
DECLARE @i				INT = 1;
DECLARE @j				INT = @Maxrows;


WHILE @i <= @Maxrows
BEGIN;
	INSERT INTO dbo.Data (ID) VALUES(@i);
	INSERT INTO dbo.Data (ID) VALUES(@j);

	SET @i += 2;
	SET @j -= 2; 
END;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		ID
	FROM dbo.Data;
GO
SELECT	i.name,
		'Data' AS table_name,
		ps.index_level,
		ps.page_count,
		ps.fragment_count,
		ps.forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Data'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
GO
DELETE
	FROM dbo.Data
	WHERE ID % 20 < = 12 AND ID <= 1000;
GO
SELECT	i.name,
		'Data' AS table_name,
		ps.index_level,
		ps.page_count,
		ps.fragment_count,
		ps.forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Data'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
GO
ALTER INDEX nc_Data_Txt1 ON dbo.Data REORGANIZE;
GO
SELECT	i.name,
		'Data' AS table_name,
		ps.index_level,
		ps.page_count,
		ps.fragment_count,
		ps.forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Data'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
GO
DELETE
	FROM dbo.Data
	WHERE ID % 20 < = 12;

ALTER INDEX nc_Data_Txt2 ON dbo.Data REORGANIZE;
GO
SELECT	i.name,
		'Data' AS table_name,
		ps.index_level,
		ps.page_count,
		ps.fragment_count,
		ps.forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Data'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
GO
ALTER INDEX PK_Data ON dbo.Data REORGANIZE;
GO
SELECT	i.name,
		'Data' AS table_name,
		ps.index_level,
		ps.page_count,
		ps.fragment_count,
		ps.forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Data'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
