USE IndexDB
GO
CREATE NONCLUSTERED INDEX nc_person_Fornavn_Efternavn_4_5_7
	ON dbo.Person(Fornavn, Efternavn) INCLUDE (Gade, Postnr, Navn)
GO
CREATE NONCLUSTERED INDEX nc_person_Fornavn_Efternavn_Gade_Postnr_Navn
	ON dbo.Person(Fornavn, Efternavn, Gade, Postnr, Navn)

DROP INDEX nc_person_Fornavn_Efternavn_4_5_7
	ON dbo.Person

DROP INDEX nc_person_Fornavn_Efternavn_Gade_Postnr_Navn
	ON dbo.Person
GO
SELECT * 
	FROM sys.dm_db_index_operational_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL);

UPDATE dbo.Person
	SET Gade = 'Borgergade 13'
	WHERE PersonId BETWEEN 100000 AND 102000;

SELECT * 
	FROM sys.dm_db_index_operational_stats(DB_ID(), OBJECT_ID('Person'), NULL, NULL);
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('person'), NULL, NULL , 'DETAILED');
GO
DBCC DROPCLEANBUFFERS
SET STATISTICS IO ON
SET STATISTICS TIME ON
GO
SELECT TOP 1 *
	FROM dbo.Person WITH(INDEX(nc_person_Fornavn_Efternavn_4_5_7))
	WHERE	Fornavn = 'Malene' AND 
			Efternavn = 'Thomsen'
GO
DBCC DROPCLEANBUFFERS
GO
SELECT TOP 1 *
	FROM dbo.Person WITH(INDEX(nc_person_Fornavn_Efternavn_Gade_Postnr_Navn))
	WHERE	Fornavn = 'Malene' AND 
			Efternavn = 'Thomsen'
GO
SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO
SELECT *
	FROM dbo.Person
	WHERE	Fornavn = 'Malene' AND 
			Efternavn = 'Thomsen'

SELECT *
	FROM dbo.Person
	WHERE	Fornavn = 'Malene' AND 
			Efternavn = 'Thomsen' AND
			Gade LIKE 'Torvet%'

SELECT *
	FROM dbo.Person
	WHERE	Fornavn = 'Malene' AND 
			Efternavn = 'Thomsen' AND
			Postnr = 8310
GO
CREATE NONCLUSTERED INDEX nc_person_Fornavn_Efternavn_4
	ON dbo.Person(Fornavn, Efternavn) INCLUDE (Gade)

SELECT	Fornavn,
		Efternavn
	FROM dbo.Person
	WHERE	Gade LIKE 'Torvet%'
