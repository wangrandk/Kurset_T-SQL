USE IndexDB
GO
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Tablenames')
	DROP TABLE Tablenames
GO
SELECT *
	INTO Tablenames
	FROM (VALUES ('p1'), ('p2'), ('p3'), ('p4')) AS T(Tablename)
GO
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'p1')
	DROP TABLE p1

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'p2')
	DROP TABLE p2

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'p3')
	DROP TABLE p3

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'p4')
	DROP TABLE p4
GO
SELECT *
	INTO p1
	FROM Person

SELECT *
	INTO p2
	FROM Person
	
SELECT *
	INTO p3
	FROM Person

SELECT *
	INTO p4
	FROM Person
GO
ALTER TABLE p1 ADD CONSTRAINT PK_p1 PRIMARY KEY CLUSTERED(PersonID)
ALTER TABLE p2 ADD CONSTRAINT PK_p2 PRIMARY KEY CLUSTERED (PersonID)
ALTER TABLE p3 ADD CONSTRAINT PK_p3 PRIMARY KEY NONCLUSTERED (PersonID)
ALTER TABLE p4 ADD CONSTRAINT PK_p4 PRIMARY KEY NONCLUSTERED (PersonID)
GO
SELECT	object_name(dm.object_id) AS Table_name, 
		i.name AS Index_name, 
		* 
	FROM sys.dm_db_index_usage_stats AS dm INNER JOIN sys.indexes AS i ON	dm.object_id = i.object_id AND 
																			dm.index_id = i.index_id
	WHERE	database_id = db_id() AND 
			object_name(dm.object_id) IN (SELECT Tablename FROM Tablenames)
	ORDER BY Table_name, Index_name 
GO
CREATE NONCLUSTERED INDEX nc_p1_k2_k3_k1 ON P1(Fornavn, Efternavn, PersonID)
CREATE NONCLUSTERED INDEX nc_p2_k2_k3	ON P2(Fornavn, Efternavn)
CREATE NONCLUSTERED INDEX nc_p3_k2_k3_k1 ON P3(Fornavn, Efternavn, PersonID)
GO
SELECT	object_name(object_id) AS Table_name, 
		*
	FROM sys.indexes
	WHERE object_name(object_id) IN (SELECT Tablename FROM Tablenames)
GO
SELECT	object_name(dm.object_id) AS Table_name, 
		i.name AS Index_name, 
		* 
	FROM sys.dm_db_index_usage_stats AS dm INNER JOIN sys.indexes AS i ON	dm.object_id = i.object_id AND 
																			dm.index_id = i.index_id
	WHERE	database_id = db_id() AND 
			object_name(dm.object_id) IN (SELECT Tablename FROM Tablenames)
	ORDER BY Table_name, Index_name
GO
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p1
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
			
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p2
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
			
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p3
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
GO
SELECT	object_name(dm.object_id) AS Table_name, 
		i.name AS Index_name, 
		* 
	FROM sys.dm_db_index_usage_stats AS dm INNER JOIN sys.indexes AS i ON	dm.object_id = i.object_id AND 
																			dm.index_id = i.index_id
	WHERE	database_id = db_id() AND 
			object_name(dm.object_id) IN (SELECT Tablename FROM Tablenames)
	ORDER BY Table_name, Index_name
GO
SET STATISTICS TIME ON
SET STATISTICS IO ON
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p1
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
			
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p2
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
			
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p3
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
SET STATISTICS TIME OFF
SET STATISTICS IO OFF
GO
SELECT	object_name(ips.object_id) AS Table_name, 
		i.name AS Index_name, 
		index_type_desc,
		index_depth,
		index_level,
		avg_fragment_size_in_pages,
		avg_fragmentation_in_percent,
		avg_page_space_used_in_percent,
		page_count,
		record_count,
		min_record_size_in_bytes,
		max_record_size_in_bytes,
		avg_record_size_in_bytes,
		forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL , 'DETAILED') AS ips 
						INNER JOIN sys.indexes AS i ON	ips.object_id = i.object_id AND 
														ips.index_id = i.index_id
	WHERE object_name(ips.object_id) IN (SELECT Tablename FROM Tablenames)
	ORDER BY Table_name, Index_name
GO
DROP INDEX nc_p1_k2_k3_k1 ON P1
DROP INDEX nc_p2_k2_k3	ON P2
DROP INDEX nc_p3_k2_k3_k1 ON P3
GO
CREATE NONCLUSTERED INDEX nc_p1_k1_k2_k3 ON P1(PersonID, Fornavn, Efternavn)
CREATE NONCLUSTERED INDEX nc_p2_k2_k3_k1 ON P2(Fornavn, Efternavn, PersonID)
CREATE NONCLUSTERED INDEX nc_p3_k1_k2_k3 ON P3(PersonID, Fornavn, Efternavn)
CREATE NONCLUSTERED INDEX nc_p4_k2_k3_k1 ON P4(Fornavn, Efternavn, PersonID)
GO
SET STATISTICS TIME ON
SET STATISTICS IO ON
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p1
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
			
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p2
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
			
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p3
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
			
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p4
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
SET STATISTICS TIME OFF
SET STATISTICS IO OFF
GO
SELECT	object_name(dm.object_id) AS Table_name, 
		i.name AS Index_name, 
		* 
	FROM sys.dm_db_index_usage_stats AS dm INNER JOIN sys.indexes AS i ON	dm.object_id = i.object_id AND 
																			dm.index_id = i.index_id
	WHERE	database_id = db_id() AND 
			object_name(dm.object_id) IN (SELECT Tablename FROM Tablenames)
	ORDER BY Table_name, Index_name
GO
SELECT	object_name(ips.object_id) AS Table_name, 
		i.name AS Index_name, 
		index_type_desc,
		index_depth,
		index_level,
		avg_fragment_size_in_pages,
		avg_fragmentation_in_percent,
		avg_page_space_used_in_percent,
		page_count,
		record_count,
		min_record_size_in_bytes,
		max_record_size_in_bytes,
		avg_record_size_in_bytes,
		forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL , 'DETAILED') AS ips 
						INNER JOIN sys.indexes AS i ON	ips.object_id = i.object_id AND 
														ips.index_id = i.index_id
	WHERE object_name(ips.object_id) IN (SELECT Tablename FROM Tablenames)
	ORDER BY Table_name, Index_name
GO
SET STATISTICS TIME ON
SET STATISTICS IO ON
SELECT	Fornavn,
		EFternavn,
		PersonID,
		Gade
	FROM p1
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
			
SELECT	Fornavn,
		EFternavn,
		PersonID,
		Gade
	FROM p2
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
			
SELECT	Fornavn,
		EFternavn,
		PersonID,
		Gade
	FROM p3
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
			
SELECT	Fornavn,
		EFternavn,
		PersonID,
		Gade
	FROM p4
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
SET STATISTICS TIME OFF
SET STATISTICS IO OFF
GO
DROP INDEX nc_p1_k1_k2_k3 ON P1
DROP INDEX nc_p2_k2_k3_k1 ON P2
DROP INDEX nc_p3_k1_k2_k3 ON p3
DROP INDEX nc_p4_k2_k3_k1 ON P4

GO
CREATE NONCLUSTERED INDEX nc_p1_k1_k2_k3_k4_k5 ON P1(PersonID, Fornavn, Efternavn, Gade, Postnr)
CREATE NONCLUSTERED INDEX nc_p2_k2_k3_k1_k4_k5 ON P2(Fornavn, Efternavn, PersonID, Gade, Postnr)
CREATE NONCLUSTERED INDEX nc_p3_k2_k3_k1_k4_k5 ON P3(Fornavn, Efternavn, PersonID, Gade, Postnr)
CREATE NONCLUSTERED INDEX nc_p4_k1_k2_k3_k4_k5 ON P3(PersonID, Fornavn, Efternavn, Gade, Postnr)
GO
SET STATISTICS TIME ON
SET STATISTICS IO ON
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p1
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
			
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p2
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
			
SELECT	Fornavn,
		EFternavn,
		PersonID
	FROM p3
	WHERE	Fornavn = 'Andreas' AND
			Efternavn = 'Nielsen'
SET STATISTICS TIME OFF
SET STATISTICS IO OFF
GO
SELECT	object_name(dm.object_id) AS Table_name, 
		i.name AS Index_name, 
		* 
	FROM sys.dm_db_index_usage_stats AS dm INNER JOIN sys.indexes AS i ON	dm.object_id = i.object_id AND 
																			dm.index_id = i.index_id
	WHERE	database_id = db_id() AND 
			object_name(dm.object_id) IN (SELECT Tablename FROM Tablenames)
	ORDER BY Table_name, Index_name
GO
SELECT	object_name(ips.object_id) AS Table_name, 
		i.name AS Index_name, 
		index_type_desc,
		index_depth,
		index_level,
		avg_fragment_size_in_pages,
		avg_fragmentation_in_percent,
		avg_page_space_used_in_percent,
		page_count,
		record_count,
		min_record_size_in_bytes,
		max_record_size_in_bytes,
		avg_record_size_in_bytes,
		forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL , 'DETAILED') AS ips 
						INNER JOIN sys.indexes AS i ON	ips.object_id = i.object_id AND 
														ips.index_id = i.index_id
	WHERE object_name(ips.object_id) IN (SELECT Tablename FROM Tablenames)
	ORDER BY Table_name, Index_name
GO
