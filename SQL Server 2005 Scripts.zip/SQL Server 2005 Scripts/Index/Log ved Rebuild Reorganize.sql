USE master;
GO
DROP DATABASE IF EXISTS LogRebuildReorgDB;
GO
CREATE DATABASE LogRebuildReorgDB
ON PRIMARY
	( NAME = LogRebuildReorgDB_file_1,
	  FILENAME = 'C:\Databaser\LogRebuildReorgDB_p.mdf',
      SIZE = 5MB,
      MAXSIZE = 6MB,
      FILEGROWTH = 10%),
	
FILEGROUP LogRebuildReorgDB_group_1
	( NAME = LogRebuildReorgDB_file_2,
	  FILENAME = 'C:\Databaser\LogRebuildReorgDB_1.ndf',
      SIZE = 1000MB,
      MAXSIZE = 2000MB,
      FILEGROWTH = 10%),
	
	( NAME = LogRebuildReorgDB_file_4,
	  FILENAME = 'C:\Databaser\LogRebuildReorgDB_2.ndf',
      SIZE = 1000MB,
      MAXSIZE = 2000MB,
      FILEGROWTH = 10%)

LOG ON
	( NAME = LogRebuildReorgDB_log_file_1,
	  FILENAME = 'C:\Databaser\LogRebuildReorgDB_log_1.ldf',
      SIZE = 1000MB,
      MAXSIZE = 2000MB,
      FILEGROWTH = 10%);
GO
ALTER DATABASE LogRebuildReorgDB 
	MODIFY FILEGROUP LogRebuildReorgDB_group_1 DEFAULT;
GO
USE LogRebuildReorgDB;

CREATE TABLE dbo.Efternavn 
(
	Efternavn 		VARCHAR (20)	NOT NULL
);

CREATE TABLE dbo.Fornavn 
(
	Fornavn 		VARCHAR (50)	NOT NULL
); 

CREATE TABLE dbo.Gade 
(
	Gade 			VARCHAR (30)	NOT NULL
);
GO
CREATE TABLE dbo.Person 
(
	PersonID 		INT IDENTITY	NOT NULL 
					CONSTRAINT PK_Person PRIMARY KEY,
	Fornavn 		VARCHAR (20)	NOT NULL ,
	Efternavn 		VARCHAR (20)	NOT NULL ,
	Gade 			VARCHAR (30)	NOT NULL ,
	Postnr 			SMALLINT		NOT NULL ,
	PersonType		CHAR(1)			NULL,
	Navn 			AS (Fornavn + ' ' + Efternavn)
);

CREATE TABLE dbo.Postopl 
(
	PostNr 			SMALLINT		NOT NULL 
					CONSTRAINT PK_Postopl PRIMARY KEY,
	Bynavn 			VARCHAR (20)	NOT NULL
);

CREATE TABLE dbo.PersonType 
(
	PersonType		CHAR(1)			NOT NULL 
					CONSTRAINT PK_PersonType PRIMARY KEY,
	PersonTypeTxt	CHAR(30)		NOT NULL
);
GO
SET NOCOUNT ON;
INSERT INTO dbo.Fornavn VALUES 
	('Anne'),
	('Ane'),
	('Annemette'),
	('Anne Mette'),
	('Anne Marie'),
	('Anders'),
	('Arne'),
	('Arvid'),
	('Allan'),
	('Birte'),
	('Birthe'),
	('Bente'),
	('Bent'),
	('B�rge'),
	('Bruno'),
	('Carl'),
	('Carina'),
	('Christian'),
	('Christina'),
	('Dorte'),
	('Dorthe'),
	('David'),
	('Daniel'),
	('Erik'),
	('Eva'),
	('Ellen'),
	('Edward'),
	('Egon'),
	('Esther'),
	('Ester'),
	('Frank'),
	('Frederikke'),
	('Frede'),
	('Grete'),
	('Grethe'),
	('Gert'),
	('Gerd'),
	('Gunnar'),
	('Gustav'),
	('Gudrun'),
	('Henrik'),
	('Hans'),
	('Hanne'),
	('Henriette'),
	('Hugo'),
	('Heidi'),
	('Helga'),
	('Hedvig'),
	('Ib'),
	('Ida'),
	('Ilse'),
	('Ivar'),
	('Ivan'),
	('Inger'),
	('Inge'),
	('Inga'),
	('Jens'),
	('Jakob'),
	('Jacob'),
	('Jette'),
	('Julie'),
	('Josefine'),
	('J�rn'),
	('J�rgen'),
	('Jane'),
	('Jesper'),
	('Karl'),
	('Karen'),
	('Karin'),
	('Karina'),
	('Kurt'),
	('Knud'),
	('Kenneth'),
	('Klara'),
	('Lars'),
	('Ludvig'),
	('Line'),
	('Lise'),
	('Lisette'),
	('Lene'),
	('Lisbeth'),
	('Lena'),
	('Morten'),
	('Marie'),
	('Mads'),
	('Maren'),
	('Malene'),
	('Michael'),
	('Mikael'),
	('Mikkel'),
	('Morten'),
	('Niels'),
	('Nette'),
	('Nanna'),
	('Ninna'),
	('Nora'),
	('Nicky'),
	('Ole'),
	('Oda'),
	('Olivia'),
	('Oskar'),
	('Ove'),
	('Oline'),
	('Peter'),
	('Per'),
	('Petrea'),
	('Peder'),
	('Palle'),
	('Poul'),
	('Paul'),
	('Poula'),
	('Rasmus'),
	('Rie'),
	('Rikke'),
	('Richard'),
	('Rune'),
	('Ruth'),
	('Rosa'),
	('Robert'),
	('Rositta'),
	('S�ren'),
	('Sara'),
	('Susanne'),
	('Sanne'),
	('Sofus'),
	('Solvej'),
	('Signe'),
	('Thomas'),
	('Tove'),
	('Tommy'),
	('Tone'),
	('Trine'),
	('Tobias'),
	('Uffe'),
	('Ulla'),
	('Ulrik'),
	('Vera'),
	('Villy'),
	('Vagn'),
	('Willy'),
	('Wagn'),
	('Yrsa'),
	('�jvind'),
	('�ge'),
	('�se');
GO
INSERT INTO dbo.Efternavn VALUES 
	('Andersen'),
	('Arnesen'),
	('Andreasen'),
	('B�rgesen'),
	('Bentsen'),
	('Christensen'),
	('Christiansen'),
	('Carlsen'),
	('Davidsen'),
	('Danielsen'),
	('Eriksen'),
	('Eskildsen'),
	('Frandsen'),
	('Frederiksen'),
	('Gertsen'),
	('Henriksen'),
	('Hansen'),
	('Hansen'),
	('Iversen'),
	('Ibsen'),
	('Jensen'),
	('Jensen'),
	('Jensen'),
	('Jakobsen'),
	('Jacobsen'),
	('Karlsen'),
	('Knudsen'),
	('Kristensen'),
	('Larsen'),
	('Lassen'),
	('Mortensen'),
	('Madsen'),
	('Mikkelsen'),
	('Nielsen'),
	('Nielsen'),
	('Olsen'),
	('Olesen'),
	('Pedersen'),
	('Petersen'),
	('Petersen'),
	('Rasmussen'),
	('S�rensen'),
	('Thomsen'),
	('�vlisen'),
	('�gesen');
GO
INSERT INTO dbo.Gade VALUES
	('N�rregade 2'),
	('N�rregade 34'),
	('N�rregade 27'),
	('Vestergade 3'),
	('�stergade 23'),
	('�stergade 1'),
	('S�ndergade 78'),
	('Torvet 2'),
	('Torvet 4'),
	('Runddelen 1'),
	('Ved Stranden 3'),
	('Strandvejen 112'),
	('All�gade 29'),
	('Norgesgade 3'),
	('Ungarnsgade 4'),
	('Italiensvej 32'),
	('Strandvejen 2'),
	('All�gade 5'),
	('Norgesgade 38'),
	('Ungarnsgade 7'),
	('Italiensvej 21'),
	('Italiensvej 4'),
	('Bragesgade 1'),
	('Bragesgade 12'),
	('Dortesvej 4'),
	('Dortesvej 3'),
	('Ellebjergvej 114'),
	('Ellebjergvej 98'),
	('Frankrigsgade 14'),
	('Frankrigsgade 6'),
	('Helgolandsgade 54'),
	('Helgolandsgade 8'),
	('K�gevej 4'),
	('K�gevej 48'),
	('M�llegade 3'),
	('M�llegade 34'),
	('Ollerupvej 3'),
	('Sct. Pouls Gade 3'),
	('Sct. Pouls Gade 25'),
	('Willemoesgade 2'),
	('Willemoesgade 23'),
	('N�rregade 11'),
	('N�rregade 36'),
	('N�rregade 72'),
	('Vesterbro 3'),
	('Vesterbrogade 23'),
	('Vesterbrogade 1'),
	('M�llevej 78'),
	('M�llevej 2'),
	('M�llevej 4'),
	('M�llevej 3'),
	('Adelgade 3'),
	('Adelgade 12'),
	('Adelgade 39'),
	('Pilegade 3'),
	('Pilegade 4'),
	('Pilegade 32'),
	('Pilegade 2'),
	('�gade 5'),
	('�gade 38'),
	('�gade 7'),
	('�boulevarden 21'),
	('�boulevarden 4'),
	('�sterbro 1'),
	('�sterbro 12'),
	('�sterbro 4'),
	('Horsensgade 3'),
	('Roskildevej 114'),
	('K�gevej 98'),
	('Nyborgvej 14'),
	('Nyborgvej 16'),
	('T�ndergade 34'),
	('T�ndergade 18'),
	('Ribevej 14'),
	('Thistedvej 8'),
	('Herningvej 2'),
	('Svendborgvej 34'),
	('�benr�vej 4'),
	('Vordingborgvej 13');
GO
INSERT INTO dbo.PostOpl VALUES 
	(1127, 'K�benhavn K'),
	(1001, 'K�benhavn K'),
	(1129, 'K�benhavn K'),
	(1130, 'K�benhavn K'),
	(2000, 'Frederiksberg'),
	(8000, '�rhus C'),
	(8200, '�rhus N'),
	(8210, '�rhus V'),
	(8240, 'Risskov'),
	(8270, 'H�jbjerg'),
	(8310, 'Tranbjerg J'),
	(9000, 'Aalborg'),
	(9400, 'N�rresundby'),
	(9600, 'Br�nderslev'),
	(9800, 'Hj�rring'),
	(9990, 'Skagen'),
	(2600, 'Glostrup'),
	(2605, 'Br�ndby'),
	(2610, 'R�dovre'),
	(2620, 'Albertslund'),
	(2625, 'Vallensb�k'),
	(2630, 'Taastrup'),
	(2635, 'Ish�j'),
	(2640, 'Hedehusene'),
	(2650, 'Hvidovre'),
	(2660, 'Br�ndby Strand');

SET NOCOUNT OFF;
GO
CREATE CLUSTERED INDEX nc_Fornavn_Fornavn ON dbo.Fornavn(Fornavn);
CREATE CLUSTERED INDEX nc_Efternavn_Efternavn ON dbo.Efternavn(Efternavn);
CREATE CLUSTERED INDEX nc_Gade_Gade ON dbo.Gade(Gade);
CREATE NONCLUSTERED INDEX nc_Postopl_Bynavn ON dbo.Postopl(Bynavn);
GO
INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr,PersonType)
   SELECT  Fornavn, Efternavn, Gade, Postnr, 'A'
      FROM dbo.Fornavn	INNER JOIN dbo.Efternavn ON Fornavn.Fornavn > Efternavn.Efternavn
						INNER JOIN dbo.Gade  ON Efternavn.Efternavn < Gade.Gade
						INNER JOIN dbo.Postopl ON Gade.Gade > Postopl.Bynavn
      WHERE LEN(Fornavn) + LEN(Efternavn) > 16;

INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr,PersonType)
   SELECT  Fornavn, Efternavn, Gade, Postnr, 'A'
      FROM dbo.Fornavn	INNER JOIN dbo.Efternavn ON Fornavn.Fornavn < Efternavn.Efternavn
						INNER JOIN dbo.Gade  ON Efternavn.Efternavn < Gade.Gade
						INNER JOIN dbo.Postopl ON Gade.Gade > Postopl.Bynavn
      WHERE LEN(Fornavn) = LEN(Efternavn);

INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, PersonType)
   SELECT  Fornavn, Efternavn, Gade, Postnr, 'A'
      FROM dbo.Fornavn	INNER JOIN dbo.Efternavn ON Fornavn.Fornavn > Efternavn.Efternavn
						INNER JOIN dbo.Gade  ON Efternavn.Efternavn < Gade.Gade
						INNER JOIN dbo.Postopl ON Gade.Gade > Postopl.Bynavn
      WHERE LEN(Gade) < LEN(Efternavn);
GO
INSERT INTO dbo.PersonType VALUES
	('A', 'Aktiv'),
	('B', 'Passiv'),
	('C', 'Mulig'),
	('D', 'Eksklusiv');
GO
UPDATE dbo.Person
  SET PersonType = 'B'
  WHERE PersonID % 100 = 1;

UPDATE dbo.Person
  SET PersonType = 'C'
  WHERE PersonID % 1000 = 3;

UPDATE dbo.Person
  SET PersonType = 'D'
  WHERE PersonID % 10000 = 7;
  
UPDATE dbo.Person
  SET PersonType = NULL
  WHERE PersonID % 98765 = 13;
GO
SELECT COUNT(*)
	FROM dbo.Person;
GO
CREATE INDEX nc_Person_Fornavn_Efternavn ON dbo.Person (Fornavn, Efternavn);

CREATE INDEX nc_Person_Gade ON dbo.Person (Gade);

CREATE INDEX nc_Person_Postnr ON dbo.Person (Postnr);
GO
BACKUP DATABASE LogRebuildReorgDB TO DISK = 'c:\Rod\LogRebuildReorgDB.bak' WITH FORMAT;
BACKUP LOG LogRebuildReorgDB TO DISK = 'c:\Rod\LogRebuildReorgDB.Log' WITH FORMAT;
GO
CREATE TABLE dbo.SqlperfLogspace 
(
	ID			INT			NOT NULL IDENTITY (1, 1),
	DbName		SYSNAME		NOT NULL,
	Logsize		FLOAT		NOT NULL,
	Logpct		FLOAT		NOT NULL,
	Status		SMALLINT	NOT NULL,
	Time		DATETIME2	NOT NULL DEFAULT(SYSDATETIME())
);
GO
INSERT INTO dbo.SqlperfLogspace (DbName, Logsize, Logpct, Status)
	EXEC ('DBCC SQLPERF(LOGSPACE)');

ALTER INDEX ALL ON dbo.Person REBUILD;

INSERT INTO dbo.SqlperfLogspace (DbName, Logsize, Logpct, Status)
	EXEC ('DBCC SQLPERF(LOGSPACE)');

BACKUP LOG LogRebuildReorgDB TO DISK = 'c:\Rod\LogRebuildReorgDB.Log' WITH FORMAT;
GO
INSERT INTO dbo.SqlperfLogspace (DbName, Logsize, Logpct, Status)
	EXEC ('DBCC SQLPERF(LOGSPACE)');
GO
ALTER INDEX ALL ON dbo.Person REORGANIZE;

INSERT INTO dbo.SqlperfLogspace (DbName, Logsize, Logpct, Status)
	EXEC ('DBCC SQLPERF(LOGSPACE)');
GO
BACKUP LOG LogRebuildReorgDB TO DISK = 'c:\Rod\LogRebuildReorgDB.Log' WITH FORMAT;
GO
INSERT INTO dbo.SqlperfLogspace (DbName, Logsize, Logpct, Status)
	EXEC ('DBCC SQLPERF(LOGSPACE)');
GO
SELECT *
	FROM dbo.SqlperfLogspace 
	WHERE DbName = 'LogRebuildReorgDB';
GO
-------------------------------------------------------------------------------------
UPDATE dbo.Person
	SET Fornavn = 'Birthe Marie', Efternavn = 'Jensen Olsen'
	WHERE PersonId % 2 = 1;
GO
INSERT INTO dbo.SqlperfLogspace (DbName, Logsize, Logpct, Status)
	EXEC ('DBCC SQLPERF(LOGSPACE)');

ALTER INDEX ALL ON dbo.Person REORGANIZE;

INSERT INTO dbo.SqlperfLogspace (DbName, Logsize, Logpct, Status)
	EXEC ('DBCC SQLPERF(LOGSPACE)');

BACKUP LOG LogRebuildReorgDB TO DISK = 'c:\Rod\LogRebuildReorgDB.Log' WITH FORMAT;
GO
INSERT INTO dbo.SqlperfLogspace (DbName, Logsize, Logpct, Status)
	EXEC ('DBCC SQLPERF(LOGSPACE)');
GO