USE master
DROP DATABASE IndexIncludeDB;
GO
CREATE DATABASE IndexIncludeDB;
GO
USE IndexIncludeDB
CREATE TABLE dbo.Person 
(
	PersonId		INT NOT NULL PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	Gade			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL,
	Ubrugt			CHAR(900) NOT NULL DEFAULT(REPLICATE('x', 900))	
);
GO
SET NOCOUNT ON
INSERT INTO dbo.Person (PersonId, Fornavn, Efternavn, Gade, Postnr) VALUES 
	(1, 'Ole', 'Olsen', 'Nygade 2', 8000),
	(2, 'Ole', 'Jensen', 'Nygade 2', 8000),
	(3, 'Ole', 'Hansen', 'Nygade 2', 8000),
	(4, 'Ole', 'Pedersen', 'Nygade 2', 8000),
	(5, 'Ole', 'Andersen', 'Nygade 2', 8000),
	(6, 'Ole', 'Larsen', 'Nygade 2', 8000),
	(7, 'Ole', 'Knudsen', 'Nygade 2', 8000),
	(8, 'Ole', 'B�rgesen', 'Nygade 2', 8000),
	(9, 'Ole', 'S�rensen', 'Nygade 2', 8000),
	(10, 'Ole', 'Madsen', 'Nygade 2', 8000),
	(11, 'Ole', 'Poulsen', 'Nygade 2', 8000),
	(12, 'Ole', 'Davidsen', 'Nygade 2', 8000),
	(13, 'Ole', 'Eriksen', 'Nygade 2', 8000);
SET NOCOUNT OFF
GO
CREATE NONCLUSTERED INDEX nc_Person_Fornavn_3 ON Person(Fornavn) INCLUDE(Efternavn);
GO
SELECT	PersonID, 
		Fornavn, 
		Efternavn 
	FROM dbo.Person
	ORDER BY Fornavn;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		PersonID, 
		Fornavn, 
		Efternavn 
	FROM Person;

UPDATE dbo.Person 
	SET Efternavn = 'Thomsen' 
	WHERE PersonID = 5;
GO
SELECT	OBJECT_NAME(op.object_id) AS ObjectName,
		i.name,
		op.leaf_insert_count,
		op.leaf_update_count,
		op.leaf_delete_count
	FROM sys.dm_db_index_operational_stats(DB_ID(), NULL, NULL, NULL) AS op INNER JOIN sys.indexes AS i
				ON op.object_id = i.object_id AND op.index_id = i.index_id
	WHERE OBJECTPROPERTYEX(op.object_id, 'IsUserTable') = 1;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		PersonID, 
		Fornavn, 
		Efternavn 
	FROM Person;
GO
SELECT	PersonID, 
		Fornavn, 
		Efternavn 
	FROM dbo.Person
	ORDER BY Fornavn;
GO
DROP INDEX nc_Person_Fornavn_3 ON Person;
GO
UPDATE dbo.Person 
	SET Efternavn = 'Andersen' 
	WHERE PersonID = 5	-- tilbage til udgangspunkt;
GO
CREATE NONCLUSTERED INDEX nc_Person_Fornavn_Efternavn ON dbo.Person(Fornavn, Efternavn);
GO
SELECT 	PersonId, 
		Fornavn, 
		Efternavn 
	FROM dbo.Person
	ORDER BY Fornavn;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		PersonID, 
		Fornavn, 
		Efternavn 
	FROM Person;

UPDATE dbo.Person
	SET Efternavn = 'Thomsen' 
	WHERE PersonID = 5;
GO
SELECT	OBJECT_NAME(op.object_id) AS ObjectName,
		i.name,
		op.leaf_insert_count,
		op.leaf_update_count,
		op.leaf_delete_count
	FROM sys.dm_db_index_operational_stats(DB_ID(), NULL, NULL, NULL) AS op INNER JOIN sys.indexes AS i
				ON op.object_id = i.object_id AND op.index_id = i.index_id
	WHERE OBJECTPROPERTYEX(op.object_id, 'IsUserTable') = 1;

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],		-- udokumenteret
		*
	FROM Person;
GO
SELECT PersonId, Fornavn, Efternavn 
	FROM dbo.Person
	ORDER BY Fornavn;
GO
DROP INDEX nc_Person_Fornavn_Efternavn ON dbo.Person;
