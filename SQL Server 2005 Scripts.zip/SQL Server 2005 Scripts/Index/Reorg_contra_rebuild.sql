USE master
DROP DATABASE IndexDB
GO
CREATE DATABASE IndexDB
GO
-- DROP TABLE t
GO
USE IndexDB
CREATE TABLE t (
	Id		INT NOT NULL CONSTRAINT PK_t PRIMARY KEY,
	Txt		CHAR(1900) NOT NULL,
	Dato	DATE NOT NULL DEFAULT(SYSDATETIME()))
CREATE NONCLUSTERED INDEX ix_t__Id ON t(Id)
GO
SET NOCOUNT ON
DECLARE @Txt		CHAR(1900)
DECLARE @i			INT = 1

SET @Txt = REPLICATE('x', 1900)

WHILE @i < 10000
BEGIN
	INSERT INTO t (Id,Txt) VALUES(@i, @Txt)
	SET @i += 2
END
GO
CREATE NONCLUSTERED INDEX nc_t__Dato_Id ON t(Dato, Id DESC)
SET NOCOUNT OFF
GO
SET NOCOUNT ON
DECLARE @Txt		CHAR(1900)
DECLARE @i			INT = 2

SET @Txt = REPLICATE('y', 1900)

WHILE @i < 10000
BEGIN
	INSERT INTO t (Id, Txt) VALUES(@i, @Txt) 
	SET @i += 2
END
GO
SELECT * 
	FROM t
GO
DBCC SHOWCONTIG(t, PK_t)
DBCC SHOWCONTIG(t, nc_t__Dato_Id)              
GO                                                                                                           
                                        GO
DBCC SHOWCONTIG(t, PK_t)
DBCC SHOWCONTIG(t, nc_t__Dato_Id)
