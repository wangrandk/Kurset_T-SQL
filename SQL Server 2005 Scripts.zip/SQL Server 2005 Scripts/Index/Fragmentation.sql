USE IndexDB
GO
CREATE NONCLUSTERED INDEX nc_Person_navn ON Person(Navn)
GO
INSERT INTO Person (Fornavn, Efternavn, Gade, Postnr, Persontype)
	SELECT top 1000000 Fornavn, Efternavn, Gade, Postnr, Persontype
		FROM Person
GO
DBCC SHOWCONTIG(Person, nc_Person_navn)
GO
SELECT		idx.name, 
			frag.*, 
			idx.type, 
			idx.type_desc, 
			idx.data_space_id, 
			idx.fill_factor
	FROM    sys.dm_db_index_physical_stats(DB_ID('IndexDB'), OBJECT_ID('dbo.Person'), NULL, NULL, 'DETAILED') AS frag 
			INNER JOIN
			sys.indexes AS idx 
			ON	frag.OBJECT_ID = idx.OBJECT_ID AND 
				frag.index_id = idx.index_id
GO
ALTER INDEX nc_Person_navn ON Person REORGANIZE
GO	
SELECT		idx.name, 
			frag.*, 
			idx.type, 
			idx.type_desc, 
			idx.data_space_id, 
			idx.fill_factor
	FROM    sys.dm_db_index_physical_stats(DB_ID('IndexDB'), OBJECT_ID('dbo.Person'), NULL, NULL, 'DETAILED') AS frag 
			INNER JOIN
			sys.indexes AS idx 
			ON	frag.OBJECT_ID = idx.OBJECT_ID AND 
				frag.index_id = idx.index_id
GO
ALTER INDEX nc_Person_navn ON Person REBUILD WITH (FILLFACTOR = 85, PAD_INDEX = ON)
GO
SELECT		idx.name, 
			frag.*, 
			idx.type, 
			idx.type_desc, 
			idx.data_space_id, 
			idx.fill_factor
	FROM	sys.dm_db_index_physical_stats(DB_ID('IndexDB'), OBJECT_ID('dbo.Person'), NULL, NULL, 'DETAILED') AS frag 
			INNER JOIN
			sys.indexes AS idx 
			ON	frag.OBJECT_ID = idx.OBJECT_ID AND 
				frag.index_id = idx.index_id

