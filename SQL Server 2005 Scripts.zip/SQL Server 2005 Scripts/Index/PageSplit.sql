USE master;
GO
DROP DATABASE StorageDB;
GO
CREATE DATABASE StorageDB;
GO
USE StorageDB;
GO
CREATE TABLE dbo.PageTable
(
	ID		INT NOT NULL CONSTRAINT PK_PageTable PRIMARY KEY CLUSTERED,
	Txt		VARCHAR(2000) NOT NULL DEFAULT (REPLICATE('x', 2000))
);
GO
DECLARE @i				INT = 1;
DECLARE @Maxrows		INT = 200;

WHILE @i <= @Maxrows
BEGIN;
	IF @i % 4 <> 3
		INSERT INTO dbo.PageTable (ID, Txt) VALUES (@i, REPLICATE('x', 2000));

	SET @i += 1;
END;

ALTER TABLE dbo.PageTable REBUILD;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		*
	FROM dbo.PageTable;
GO
DECLARE @i				INT = 3;
DECLARE @Maxrows		INT = 200;


WHILE @i <= @Maxrows
BEGIN;
		INSERT INTO dbo.PageTable (ID, Txt) VALUES (@i, REPLICATE('y', 1000));

	SET @i += 4;
END;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		*
	FROM dbo.PageTable;
GO
ALTER TABLE dbo.PageTable REBUILD;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		*
	FROM dbo.PageTable;
GO
CREATE FUNCTION dbo._ufn_File_Page_Offset
(
@PhysLoc		VARCHAR(128)
)
RETURNS @Phys TABLE
(
	PhysLoc			VARCHAR(128),
	FileID			INT,
	PageID			INT,
	Offset			INT
)
AS
BEGIN
DECLARE		@PhysLocLocal	VARCHAR(128);
DECLARE 	@FileID			INT;
DECLARE 	@PageID			INT;
DECLARE 	@Offset			INT;
DECLARE		@Strpos			INT;

SET @PhysLocLocal = SUBSTRING(@PhysLoc, 2, LEN(@PhysLoc) - 2);

SET @Strpos = CHARINDEX(':', @PhysLocLocal);
SET @FileID = CAST(LEFT(@PhysLocLocal, @Strpos - 1)  AS INT);
SET @PhysLocLocal = SUBSTRING(@PhysLocLocal, @Strpos + 1, 128);

SET @Strpos = CHARINDEX(':', @PhysLocLocal);
SET @PageID = CAST(LEFT(@PhysLocLocal, @Strpos - 1)  AS INT);
SET @PhysLocLocal = SUBSTRING(@PhysLocLocal, @Strpos + 1, 128);

SET @Offset = CAST(@PhysLocLocal AS INT);

	INSERT INTO @Phys VALUES
		(
		@PhysLoc,
		@FileID,
		@PageID,
		@Offset
		);
		 	
	RETURN;
END;
GO
SELECT	*
	FROM dbo.PageTable CROSS APPLY dbo._ufn_File_Page_Offset (sys.fn_PhysLocFormatter(%%physloc%%));
