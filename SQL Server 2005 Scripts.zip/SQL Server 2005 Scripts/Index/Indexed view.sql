USE IndexDB
GO
CREATE VIEW vPostnr
WITH SCHEMABINDING
AS
SELECT Postnr, COUNT_BIG(*) AS Antal
	FROM dbo.Person
	GROUP BY Postnr
GO
CREATE UNIQUE CLUSTERED INDEX ix_vPostnr ON vPostnr (postnr)
GO
SELECT *
	FROM vPostnr
GO
SELECT Postnr, COUNT(*)
	FROM dbo.Person
	GROUP BY Postnr
