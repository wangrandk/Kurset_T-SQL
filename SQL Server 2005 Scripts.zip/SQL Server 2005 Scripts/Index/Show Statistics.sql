USE IndexDB;
GO
CREATE NONCLUSTERED INDEX nc_Person_Navn ON Person(Navn);
GO
DBCC SHOW_STATISTICS (Person, nc_Person_Navn);

DBCC SHOW_STATISTICS (Person, nc_Person_Navn)
	WITH STAT_HEADER;

DBCC SHOW_STATISTICS (Person, nc_Person_Navn)
	WITH DENSITY_VECTOR;

DBCC SHOW_STATISTICS (Person, nc_Person_Navn)
	WITH HISTOGRAM;
	
--udsnit af statistik, vi ser p� rk 2 og 3

--RANGE_HI_KEY                              RANGE_ROWS    EQ_ROWS       DISTINCT_RANGE_ROWS  AVG_RANGE_ROWS
------------------------------------------- ------------- ------------- -------------------- --------------
--Allan Andersen                            0             752           0                    1
--Anders Jensen                             37976         4602          59                   643,661
--Andreas Carlsen                           20356         3744          22                   925,2727
--Andreas Iversen                           20514         3068          12                   1709,5
--Andreas Nielsen                           15706         5200          11                   1427,818

SELECT Navn, COUNT(*) AS Antal -- Anders Jensen findes i rk 61 = 1 + 59 + 1, Andreas Carlsen i rk 84 = 1 + 59 + 1 + 22 + 1 
	FROM dbo.Person
	GROUP BY Navn
	ORDER BY Navn;
GO
SELECT Navn, COUNT(*) AS Antal	-- giver 24 rk = 1 + 22 + 1, 1 for Anders Jensen de 22 imellem og 1 for Andreas Carlsen
	FROM dbo.Person
	WHERE Navn BETWEEN 'Anders Jensen' AND 'Andreas Carlsen'
	GROUP BY Navn
	ORDER BY Navn;
GO
SELECT COUNT(*) AS AntalPersonTabel, 20356 + 3744 + 4602 AS StatAntal
	FROM dbo.Person
	WHERE Navn BETWEEN 'Anders Jensen' AND 'Andreas Carlsen';
GO
CREATE TABLE dbo.StatInfo
(
	ID						INT NOT NULL IDENTITY,
	Range_Hi_Key			VARCHAR(255),
	Range_Rows				BIGINT,
	Eq_Rows					BIGINT,
	Distinct_Range_Rows		BIGINT,
	Avg_Range_Rows			FLOAT
);
GO
INSERT INTO dbo.StatInfo (Range_Hi_Key, Range_Rows, Eq_Rows, Distinct_Range_Rows, Avg_Range_Rows)
	EXEC('DBCC SHOW_STATISTICS (Person, nc_Person_Navn) WITH HISTOGRAM');
GO
SELECT *
	FROM dbo.StatInfo;
GO
SELECT	*,
		(SELECT COUNT(*) FROM Person WHERE	Navn = StatInfoYdre.Range_Hi_Key) AS ActueltAntalValue,
		(SELECT COUNT(*) FROM Person WHERE	Navn > (SELECT MAX(Range_Hi_Key) FROM Statinfo AS StatInfoIndre WHERE StatInfoIndre.Range_Hi_Key < StatInfoYdre.Range_Hi_Key) AND
											Navn < StatInfoYdre.Range_Hi_Key) AS ActuelAntalRange
	FROM dbo.StatInfo AS StatInfoYdre
	ORDER BY ID;
GO
DBCC SHOW_STATISTICS (Person, nc_Person_Navn)
	WITH STAT_HEADER;
GO
TRUNCATE TABLE dbo.StatInfo;
GO
-- INSERT 9.8 PERCENT data i tabellen
INSERT INTO dbo.Person (Fornavn, Efternavn,	Gade, Postnr, Koenkode,	Landekode, Tlfnr, Persontype)
	SELECT	TOP 9.8 PERCENT
			Fornavn,
			Efternavn,
			Gade,
			Postnr,
			Koenkode,
			Landekode,
			Tlfnr,
			Persontype
		FROM dbo.Person
GO
SELECT *
	FROM dbo.Person
	WHERE Navn = 'Carl Olsen'
GO
INSERT INTO dbo.StatInfo (Range_Hi_Key, Range_Rows, Eq_Rows, Distinct_Range_Rows, Avg_Range_Rows)
	EXEC('DBCC SHOW_STATISTICS (Person, nc_Person_Navn) WITH HISTOGRAM');
GO
SELECT	*,
		(SELECT COUNT(*) FROM Person WHERE	Navn = StatInfoYdre.Range_Hi_Key) AS ActueltAntalValue,
		(SELECT COUNT(*) FROM Person WHERE	Navn > (SELECT MAX(Range_Hi_Key) FROM Statinfo AS StatInfoIndre WHERE StatInfoIndre.Range_Hi_Key < StatInfoYdre.Range_Hi_Key) AND
											Navn < StatInfoYdre.Range_Hi_Key) AS ActuelAntalRange
	FROM dbo.StatInfo AS StatInfoYdre
	ORDER BY ID;
GO
DBCC SHOW_STATISTICS (Person, nc_Person_Navn)
	WITH STAT_HEADER;
GO
TRUNCATE TABLE dbo.StatInfo;
GO
-- INSERT 10.3 PERCENT data i tabellen
INSERT INTO dbo.Person (Fornavn, Efternavn,	Gade, Postnr, Koenkode,	Landekode, Tlfnr, Persontype)
	SELECT	TOP 10.3 PERCENT
			Fornavn,
			Efternavn,
			Gade,
			Postnr,
			Koenkode,
			Landekode,
			Tlfnr,
			Persontype
		FROM dbo.Person
GO
DBCC SHOW_STATISTICS (Person, nc_Person_Navn)
	WITH STAT_HEADER;
GO
SELECT *
	FROM sys.indexes
	WHERE name = 'nc_person_Navn'

SELECT *
	FROM sys.stats INNER JOIN sys.stats_columns ON stats.stats_id = stats_columns.stats_id
	WHERE name = 'nc_person_Navn'
GO
SELECT *
	FROM dbo.Person
	WHERE Navn = 'Carl Olsen'
GO
INSERT INTO dbo.StatInfo (Range_Hi_Key, Range_Rows, Eq_Rows, Distinct_Range_Rows, Avg_Range_Rows)
	EXEC('DBCC SHOW_STATISTICS (Person, nc_Person_Navn) WITH HISTOGRAM');
GO
SELECT	*,
		(SELECT COUNT(*) FROM Person WHERE	Navn = StatInfoYdre.Range_Hi_Key) AS ActueltAntalValue,
		(SELECT COUNT(*) FROM Person WHERE	Navn > (SELECT MAX(Range_Hi_Key) FROM Statinfo AS StatInfoIndre WHERE StatInfoIndre.Range_Hi_Key < StatInfoYdre.Range_Hi_Key) AND
											Navn < StatInfoYdre.Range_Hi_Key) AS ActuelAntalRange
	FROM dbo.StatInfo AS StatInfoYdre
	ORDER BY ID;
GO
DBCC SHOW_STATISTICS (Person, nc_Person_Navn)
	WITH STAT_HEADER;
GO
-- Update af statistikker med fullscan
UPDATE STATISTICS dbo.Person
	WITH FULLSCAN;
GO
TRUNCATE TABLE dbo.StatInfo;
GO
INSERT INTO dbo.StatInfo (Range_Hi_Key, Range_Rows, Eq_Rows, Distinct_Range_Rows, Avg_Range_Rows)
	EXEC('DBCC SHOW_STATISTICS (Person, nc_Person_Navn) WITH HISTOGRAM');
GO
-- Statistik kun p� hele tabel
DBCC SHOW_STATISTICS (Person, nc_Person_Navn)
	WITH STAT_HEADER;
GO
SELECT	*,
		(SELECT COUNT(*) FROM Person WHERE	Navn = StatInfoYdre.Range_Hi_Key) AS ActueltAntalValue,
		(SELECT COUNT(*) FROM Person WHERE	Navn > (SELECT MAX(Range_Hi_Key) FROM Statinfo AS StatInfoIndre WHERE StatInfoIndre.Range_Hi_Key < StatInfoYdre.Range_Hi_Key) AND
											Navn < StatInfoYdre.Range_Hi_Key) AS ActuelAntalRange
	FROM dbo.StatInfo AS StatInfoYdre
	ORDER BY ID;
GO
