CREATE NONCLUSTERED INDEX nc_person_Fornavn_Efternavn_4_5_7
	ON dbo.Person(Fornavn, Efternavn) include (Gade, Postnr, Navn)
ON partition_schema_index (PersonID)
GO
CREATE NONCLUSTERED INDEX nc_person_Fornavn_Efternavn_Gade_Postnr_Navn
	ON dbo.Person(Fornavn, Efternavn, Gade, Postnr, Navn)
ON partition_schema_index (PersonID)
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('person'), NULL, NULL , 'DETAILED');
GO
DBCC DROPCLEANBUFFERS
SET STATISTICS IO ON
SET STATISTICS TIME ON
GO
SELECT *
	FROM dbo.Person WITH(INDEX(nc_person_Fornavn_Efternavn_4_5_7))
	WHERE	Fornavn = 'Malene' AND 
			Efternavn = 'Thomsen'
GO
DBCC DROPCLEANBUFFERS
GO
SELECT *
	FROM dbo.Person WITH(INDEX(nc_person_Fornavn_Efternavn_Gade_Postnr_Navn))
	WHERE	Fornavn = 'Malene' AND 
			Efternavn = 'Thomsen'
GO
SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO
