USE IndexDB
GO
-- create an index without compute statistics
CREATE INDEX nc_Person_Gade_Postnr ON dbo.Person (Gade, Postnr) WITH STATISTICS_ONLY = 0;


--  -1 to generate statistics
CREATE INDEX nc_Person_Fornavn_Efternavn ON dbo.Person (Fornavn, Efternavn) WITH STATISTICS_ONLY = -1;
GO
SELECT *
	FROM sys.stats
	WHERE object_id = OBJECT_ID('Person');
GO
DECLARE @Stats_Id		INT = 4;

SELECT *
	FROM sys.dm_db_stats_properties(OBJECT_ID('Person'), @Stats_Id);

SELECT *
	FROM sys.dm_db_stats_histogram (OBJECT_ID('Person'), @Stats_Id);

