USE master;
DROP DATABASE ReorgRebuildDB;
GO
CREATE DATABASE ReorgRebuildDB
ON PRIMARY
	(NAME = ReorgRebuildDB_sys,
	 FILENAME = 'c:\Databaser\ReorgRebuildDB_sys.mdf',
     SIZE = 5MB),

FILEGROUP ReorgRebuildDB_fg1
	(NAME = ReorgRebuildDB_fg1,
	 FILENAME = 'c:\Databaser\ReorgRebuildDB_fg1.ndf',
     SIZE = 800MB),
	
FILEGROUP ReorgRebuildDB_fg2
	(NAME = ReorgRebuildDB_fg2,
	 FILENAME = 'c:\Databaser\ReorgRebuildDB_fg2.ndf',
     SIZE = 800MB),
	
FILEGROUP ReorgRebuildDB_fg3
	(NAME = ReorgRebuildDB_fg3,
	 FILENAME = 'c:\Databaser\ReorgRebuildDB_fg3.ndf',
     SIZE = 800MB),
	
FILEGROUP ReorgRebuildDB_fg4
	(NAME = ReorgRebuildDB_fg4,
	 FILENAME = 'c:\Databaser\ReorgRebuildDB_fg4.ndf',
     SIZE = 800MB),
	
FILEGROUP ReorgRebuildDB_fg5
	(NAME = ReorgRebuildDB_fg5,
	 FILENAME = 'c:\Databaser\ReorgRebuildDB_fg5.ndf',
     SIZE = 800MB),
	
FILEGROUP ReorgRebuildDB_fg6
	(NAME = ReorgRebuildDB_fg6,
	 FILENAME = 'c:\Databaser\ReorgRebuildDB_fg6.ndf',
     SIZE = 800MB)

LOG ON
	(NAME = ReorgRebuildDB_log,
	 FILENAME = 'c:\Databaser\ReorgRebuildDB.ldf',
     SIZE = 5000MB);
GO
ALTER DATABASE ReorgRebuildDB SET RECOVERY SIMPLE;
GO
USE ReorgRebuildDB
CREATE PARTITION FUNCTION PartitionFunction (DATE)
	AS RANGE RIGHT FOR VALUES (	'2016-2-1', 
								'2016-3-1', 
								'2016-4-1', 
								'2016-5-1', 
								'2016-6-1');
GO
CREATE PARTITION scheme PartitionScheme
	AS Partition PartitionFunction TO (	ReorgRebuildDB_fg1, 
										ReorgRebuildDB_fg2, 
										ReorgRebuildDB_fg3, 
										ReorgRebuildDB_fg4, 
										ReorgRebuildDB_fg5, 
										ReorgRebuildDB_fg6);
GO
CREATE TABLE dbo.Person 
(
	PersonId	INT			NOT NULL INDEX PK_Person  CLUSTERED IDENTITY, 
	Navn		VARCHAR(30)	NOT NULL,
	Adresse		VARCHAR(30)	NULL,
	Dummy		CHAR(200)	NOT NULL DEFAULT(REPLICATE('0123456789', 12)),
	Tid			DATE		NOT NULL,
	Maaned		AS MONTH(Tid) PERSISTED
) ON PartitionScheme (Tid);
GO
INSERT INTO dbo.Person (Navn, Tid) VALUES 
	('Ole Hansen', '2016-1-2'),
	('Per Karlsen', '2016-1-22'),
	('Ida Caroline Olsen', '2016-2-3'),
	('Ane Elizabeth Knudsen', '2016-2-14'),
	('Mie Marie Larsen', '2016-3-5'),
	('Eva Thomsen', '2016-3-6'),
	('Dea Andersen', '2016-4-7'),
	('Jan Pedersen', '2016-4-5'),
	('Fie Line Madsen', '2016-5-2'),
	('Oda Kristensen', '2016-5-29'),
	('Elo Bendsen', '2016-6-5'),
	('Tom Eriksen', '2016-6-6');
GO
INSERT INTO dbo.Person (Navn, Tid)
	SELECT	TOP 99 PERCENT	
			Navn, 
			Tid
		FROM dbo.Person
		ORDER BY NEWID();
GO 20
UPDATE dbo.Person
	SET Adresse = 'Vesterbrogade 112' 
	WHERE  PersonId % 121 = 45;

UPDATE dbo.Person
	SET Adresse = 'Store Kongensgade 25' 
	WHERE  PersonId % 88 = 35;

DELETE 
	FROM dbo.Person
	WHERE  PersonId % 876 = 68;

DELETE 
	FROM dbo.Person
	WHERE  PersonId % 1047 = 213;

DELETE 
	FROM dbo.Person
	WHERE  PersonId % 588 = 404;

UPDATE dbo.Person
	SET Dummy = REPLICATE('9876543210', 6) 
	WHERE  PersonId % 45 = 34;

DELETE 
	FROM dbo.Person
	WHERE  PersonId % 643 = 45;

DELETE 
	FROM dbo.Person
	WHERE  PersonId % 587 = 115;

UPDATE dbo.Person
	SET Dummy = REPLICATE('ABCDEFGHIJ', 20) 
	WHERE  PersonId % 35 = 20;

DELETE 
	FROM dbo.Person
	WHERE  PersonId % 433 = 266;

UPDATE dbo.Person
	SET Adresse = 'S�ndergade 44'
	WHERE  PersonId % 97 = 13;

GO
BACKUP DATABASE ReorgRebuildDB TO DISK = 'c:/Rod/ReorgRebuildDB.BAK' WITH FORMAT;
GO
SELECT COUNT(*) 
	FROM dbo.Person;
GO
SELECT '------------------ REORGANIZE ------------------'
SELECT	i.name,
		ps.index_id,
		ps.index_type_desc,
		ps.partition_number,
		ps.avg_fragmentation_in_percent,
		ps.page_count  
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'LIMITED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
GO
ALTER INDEX ALL ON dbo.Person REORGANIZE;
GO
SELECT	i.name,
		ps.index_id,
		ps.index_type_desc,
		ps.partition_number,
		ps.avg_fragmentation_in_percent,
		ps.page_count 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'LIMITED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
GO
SELECT '------------------ REBUILD ------------------'
USE master;
DROP DATABASE ReorgRebuildDB;
GO
RESTORE DATABASE ReorgRebuildDB FROM DISK = 'c:/Rod/ReorgRebuildDB.BAK' WITH RECOVERY;
GO
USE ReorgRebuildDB;
GO
SELECT	i.name,
		ps.index_id,
		ps.index_type_desc,
		ps.partition_number,
		ps.avg_fragmentation_in_percent,
		ps.page_count 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'LIMITED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
GO
ALTER INDEX ALL ON dbo.Person REBUILD;
GO
SELECT	i.name,
		ps.index_id,
		ps.index_type_desc,
		ps.partition_number,
		ps.avg_fragmentation_in_percent,
		ps.page_count  
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'LIMITED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
