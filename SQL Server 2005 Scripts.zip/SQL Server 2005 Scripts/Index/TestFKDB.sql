USE master;
GO
DROP DATABASE TestFKDB;
GO
CREATE DATABASE TestFKDB
ON PRIMARY
	(NAME = N'TestFKDB_Sys', 
	FILENAME = N'C:\Databaser\TestFKDB_Data.MDF', 
	SIZE = 5, 
	FILEGROWTH = 10%),
FILEGROUP DataFG1
	(NAME = N'TestFKDB_FG1_Fil1', 
	 FILENAME = N'C:\Databaser\TestFKDB_DataFG1_Fil1.NDF', 
	 SIZE = 3000, 
	 FILEGROWTH = 10%)
LOG ON
	(NAME = N'TestFKDB_Log',
	FILENAME = N'C:\Databaser\TestFKDB_Log.LDF', 
	SIZE = 1000,
	FILEGROWTH = 500);
GO
USE TestFKDB;
GO
SELECT *
	INTO dbo.Postopl
	FROM IndexDB.dbo.Postopl;
GO
ALTER TABLE dbo.Postopl ADD CONSTRAINT PK_Postopl 
	PRIMARY KEY (Postnr);
GO
SELECT	PersonId,
		Fornavn,
		Efternavn
		Gade,
		Koenkode,
		Persontype, 
		Landekode,
		Tlfnr
	INTO dbo.Person1
	FROM IndexDB.dbo.Person;
GO
ALTER TABLE dbo.Person1
	ADD CONSTRAINT PK_Person1
	PRIMARY KEY (PersonID);
GO
GO
SELECT	PersonId,
		Fornavn,
		Efternavn,
		Gade,
		Postnr,
		Koenkode,
		Persontype, 
		Landekode,
		Tlfnr
	INTO dbo.Person2
	FROM IndexDB.dbo.Person
	WHERE Postnr NOT IN (1127, 1129);
GO
ALTER TABLE dbo.Person2
	ADD CONSTRAINT PK_Person2
	PRIMARY KEY (PersonID);

ALTER TABLE dbo.Person2
	ALTER COLUMN Postnr SMALLINT NULL;
GO
SET IDENTITY_INSERT dbo.Person2 ON;
GO
INSERT INTO dbo.Person2 
	(	
	PersonId,
	Fornavn,
	Efternavn,
	Gade,
	Koenkode,
	Persontype, 
	Landekode,
	Tlfnr
	)
	SELECT	PersonId,
			Fornavn,
			Efternavn,
			Gade,
			Koenkode,
			Persontype, 
			Landekode,
			Tlfnr
		FROM IndexDB.dbo.Person
		WHERE Postnr IN (1127, 1129);
GO
CREATE INDEX nc_Person2_Postnr ON dbo.Person2 (Postnr);
GO
SELECT	PersonID,
		Postnr
	INTO dbo.PersonPost
	FROM IndexDB.dbo.Person
	WHERE Postnr NOT IN (1127, 1129);
GO
ALTER TABLE dbo.PersonPost 
	ADD CONSTRAINT PK_PersonPost
	PRIMARY KEY (PersonID);

ALTER TABLE dbo.PersonPost 
	ADD CONSTRAINT FK_Person_PersonPost
	FOREIGN KEY (PersonID)  REFERENCES dbo.Person2 (PersonId);

ALTER TABLE dbo.PersonPost 
	ADD CONSTRAINT FK_Person_Postopl
	FOREIGN KEY (Postnr)  REFERENCES dbo.Postopl (Postnr);
GO
CREATE NONCLUSTERED INDEX nc_PersonPost_Postnr ON PersonPost(Postnr);
GO
SELECT *
	FROM dbo.Person1 INNER JOIN dbo.PersonPost
			ON Person1.PersonId = PersonPost.PersonID
					 INNER JOIN dbo.Postopl
			ON PersonPost.Postnr = Postopl.Postnr;
GO
SELECT *
	FROM dbo.Person2 INNER JOIN dbo.Postopl
		ON Person2.Postnr = Postopl.Postnr;
GO
SELECT *
	FROM dbo.Person1 LEFT JOIN dbo.PersonPost
			ON Person1.PersonId = PersonPost.PersonID
					 LEFT JOIN dbo.Postopl
			ON PersonPost.Postnr = Postopl.Postnr;
GO
SELECT *
	FROM dbo.Person2 LEFT JOIN dbo.Postopl
		ON Person2.Postnr = Postopl.Postnr;
GO
