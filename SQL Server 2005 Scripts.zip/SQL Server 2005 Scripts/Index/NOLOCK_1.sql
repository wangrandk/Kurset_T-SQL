---- 1
USE master;
DROP DATABASE IF EXISTS NolockDB;
GO
CREATE DATABASE NolockDB
ON  PRIMARY 
( 
	NAME = N'NolockDB', 
	FILENAME = N'C:\Databaser\NolockDB.mdf' , 
	SIZE = 2000MB, 
	MAXSIZE = UNLIMITED, 
	FILEGROWTH = 1000MB
)
LOG ON 
( 
	NAME = N'NolockDB_log', 
	FILENAME = N'C:\Databaser\NolockDB_log.ldf' , 
	SIZE = 4000MB, 
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 1000MB
);
GO
ALTER DATABASE NolockDB SET DELAYED_DURABILITY = FORCED;
GO
USE NolockDB;
GO
CREATE TABLE dbo.Person
(
	PersonId		INT			NOT NULL,
	Fornavn			VARCHAR(20)	NOT NULL INDEX CL_Person_Efternavn CLUSTERED,
	Efternavn		VARCHAR(20)	NOT NULL,
	Gade			VARCHAR(30)	NOT NULL,
	Postnr			SMALLINT	NOT NULL
);
GO
INSERT INTO dbo.Person (PersonId, Fornavn, Efternavn, Gade, Postnr) VALUES 
	(1, 'Christian', 'Christiansen', 'Vesterbrogade 12 4. th.', 8000),
	(2, 'Jens', 'Petersen', 'N�rregade 112', 2000),
	(3, 'Knud', 'Andersen', 'S�ndergade 62 st tv', 9000),
	(4, 'Svend Aage', 'Poulsen', 'Torvet 44', 5000),
	(5, 'Ludvig', 'Hansen', 'Strandvejen 39 3. mf.', 7000),
	(6, 'Allan', 'Olsen', '�boulevarden 72 2. tv.', 8000),
	(7, 'Torben', 'Nielsen', 'Landevejen 28', 6000),
	(8, 'Hans Peter', 'S�rensen', 'Lille Strandstr�de 84 1. tv.', 3000);
GO
INSERT INTO dbo.Person (PersonId, Fornavn, Efternavn, Gade, Postnr)
	SELECT	PersonId + (SELECT MAX(PersonId) FROM dbo.Person),
			Fornavn, 
			Efternavn, 
			Gade, 
			Postnr
		FROM dbo.Person;
GO 21
DELETE
	FROM dbo.Person
	WHERE PersonId % 100 BETWEEN 33 AND 77;
GO
SELECT COUNT(*)
	FROM dbo.Person;
GO
SELECT i.name,  ps.* 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'DETAILED') AS ps 
						INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;

SELECT TOP 10 PERCENT PersonID
	INTO dbo.PersonUpdate
	FROM dbo.Person
	ORDER BY NEWID();
GO
----- 2
SELECT COUNT(*)
	FROM dbo.Person;
GO
UPDATE dbo.Person
	SET Fornavn = 'Christoffer Johannes'
	WHERE PersonID IN (SELECT TOP 20 PERCENT PersonId
							FROM dbo.PersonUpdate);
GO
UPDATE dbo.Person
	SET Fornavn = 'S�ren Peter'
	WHERE PersonID IN (SELECT TOP 10 PERCENT PersonId
							FROM dbo.PersonUpdate
							WHERE PersonId % 3 = 2);
GO
ALTER INDEX CL_Person_Efternavn ON dbo.Person REORGANIZE;
GO
UPDATE dbo.Person
	SET Fornavn =  'Jens J�rgen'
	WHERE PersonID + 675 IN (SELECT PersonId
								FROM dbo.PersonUpdate);
GO
SELECT i.name,  ps.* 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Person'), NULL, NULL , 'DETAILED') AS ps 
						INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
