SET STATISTICS TIME, IO ON;
GO
SELECT	Efternavn,
		Gade
	FROM IndexDB.dbo.Person
	WHERE	Postnr IN (8000, 2000, 9000, 5000) AND
			Fornavn = 'Ole' AND
			PersonId < 1987000;
GO
SELECT	Efternavn,
		Gade
	FROM IndexFilegrpDB.dbo.Person
	WHERE	Postnr IN (8000, 2000, 9000, 5000) AND
			Fornavn = 'Ole' AND
			PersonId < 1987000;
GO
USE IndexDB;
GO
CREATE NONCLUSTERED INDEX nc_Person_Fornavn_Postnr
	ON dbo.Person (Fornavn, Postnr)
	INCLUDE (Efternavn, Gade);
GO
USE IndexFilegrpDB;
GO
CREATE NONCLUSTERED INDEX nc_Person_Fornavn_Postnr
	ON dbo.Person (Fornavn, Postnr)
	INCLUDE (Efternavn, Gade)
	ON partition_schema_index (PersonID);
GO
SELECT	Efternavn,
		Gade
	FROM IndexDB.dbo.Person
	WHERE	Postnr IN (8000, 2000, 9000, 5000) AND
			Fornavn = 'Ole' AND
			PersonId < 1987000;
GO
SELECT	Efternavn,
		Gade
	FROM IndexFilegrpDB.dbo.Person
	WHERE	Postnr IN (8000, 2000, 9000, 5000) AND
			Fornavn = 'Ole' AND
			PersonId < 1987000;
GO