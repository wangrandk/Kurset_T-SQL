USE IndexDB
GO
IF EXISTS (SELECT *
				FROM sys.tables
				WHERE name = 'PersonCL')
	DROP TABLE PersonCL

IF EXISTS (SELECT *
				FROM sys.tables
				WHERE name = 'PersonNC')
	DROP TABLE PersonNC
GO
SELECT TOP 1000000 *
	INTO dbo.PersonCL
	FROM dbo.Person;

SELECT *
	INTO dbo.PersonNC
	FROM dbo.PersonCL;

UPDATE PersonCL	
	SET Tlfnr = '12345678',
		Persontype = 'D'
	WHERE PersonID = 65432;

UPDATE PersonNC
	SET Tlfnr = '12345678',
		Persontype = 'D'
	WHERE PersonID = 65432;
GO
ALTER TABLE dbo.PersonCL ADD CONSTRAINT pk_PersonCL PRIMARY KEY CLUSTERED(Personid);
ALTER TABLE dbo.PersonNC ADD CONSTRAINT pk_PersonNC PRIMARY KEY NONCLUSTERED(Personid);
GO
CREATE NONCLUSTERED INDEX nc_PersonCL_Fornavn ON  PersonCL(Fornavn);
CREATE NONCLUSTERED INDEX nc_PersonCL_Tlfnr ON  PersonCL(Tlfnr);
CREATE NONCLUSTERED INDEX nc_PersonCL_Postnr ON  PersonCL(Postnr);
CREATE NONCLUSTERED INDEX nc_PersonCL_Persontype ON  PersonCL(Persontype);

CREATE NONCLUSTERED INDEX nc_PersonNC_Fornavn ON  PersonNC(Fornavn);
CREATE NONCLUSTERED INDEX nc_PersonNC_Tlfnr ON  PersonNC(Tlfnr);
CREATE NONCLUSTERED INDEX nc_PersonNC_Postnr ON  PersonNC(Postnr);
CREATE NONCLUSTERED INDEX nc_PersonNC_Persontype ON  PersonNC(Persontype);
GO
SELECT	indexes.object_id, 
		indexes.name,
		ps.index_id,
		ps.index_type_desc,
		ps.index_level,
		ps.index_depth,
		ps.page_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('PersonCL'), NULL, NULL , 'DETAILED') AS ps
			INNER JOIN sys.indexes ON ps.object_id = indexes.object_id AND ps.index_id = indexes.index_id
UNION ALL
SELECT	indexes.object_id,
		indexes.name,
		ps.index_id,
		ps.index_type_desc,
		ps.index_level,
		ps.index_depth,
		ps.page_count 
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('PersonNC'), NULL, NULL , 'DETAILED')AS ps
			INNER JOIN sys.indexes ON ps.object_id = indexes.object_id AND ps.index_id = indexes.index_id
ORDER BY indexes.object_id, ps.index_id, ps.index_level DESC;
GO
-- Primary key
SET STATISTICS IO ON;
SELECT *
	FROM dbo.PersonCL
	WHERE PersonId = 23456;

SELECT *
	FROM dbo.PersonNC
	WHERE PersonId = 23456;
SET STATISTICS IO OFF;
GO
-- bruge et ikke-clustered index og resultat er eksakt 1 forekomst
SET STATISTICS IO ON;
SELECT *
	FROM dbo.PersonCL
	WHERE Tlfnr = '12345678';

SELECT *
	FROM dbo.PersonNC
	WHERE Tlfnr = '12345678';
SET STATISTICS IO OFF
GO
-- bruge et ikke-clustered index og resultat er flere forekomster
SET STATISTICS IO ON;
SELECT *
	FROM dbo.PersonCL
	WHERE Tlfnr LIKE '2992%';

SELECT *
	FROM dbo.PersonNC
	WHERE Tlfnr LIKE '2992%';

SET STATISTICS IO OFF
GO
-- bruge 2 ikke-clustered index og resultat er flere forekomster
SET STATISTICS IO ON;
SELECT	Fornavn, 
		Efternavn
	FROM dbo.PersonCL
	WHERE	Postnr = 2000 AND 
			Persontype = 'B';

SELECT	Fornavn,
		Efternavn
	FROM dbo.PersonNC
	WHERE	Postnr = 2000 AND 
			Persontype = 'B';

SET STATISTICS IO OFF
GO
-- bruge 3 ikke-clustered index og resultat er flere forekomster
SET STATISTICS IO ON;
SELECT	Fornavn, 
		Efternavn
	FROM dbo.PersonCL
	WHERE	Postnr = 2000 AND 
			Persontype = 'B' AND
			Fornavn = 'Ole';

SELECT	Fornavn,
		Efternavn
	FROM dbo.PersonNC
	WHERE	Postnr = 2000 AND 
			Persontype = 'B' AND
			Fornavn = 'Ole';

SET STATISTICS IO OFF
GO
-- bruge 2 ikke-clustered index og kun medtage kolonner fra index
SET STATISTICS IO ON;
SELECT	Postnr, 
		Persontype
	FROM dbo.PersonCL
	WHERE	Postnr > 9000 AND 
			Persontype = 'B';

SELECT	Postnr,
		Persontype
	FROM dbo.PersonNC
	WHERE	Postnr > 9000 AND 
			Persontype = 'B';

SET STATISTICS IO OFF
GO
