---- 3
USE NolockDB;
CREATE TABLE dbo.TableHintCount
(
	ID				INT NOT NULL IDENTITY,
	Antal			INT NOT NULL,
	TableHint		VARCHAR(20) NOT NULL
);
GO
SET NOCOUNT ON;
GO
DECLARE @i		INT = (SELECT COUNT(*) 
							FROM dbo.TableHintCount);

IF @i % 20 = 0
	PRINT  @i / 2;

INSERT INTO dbo.TableHintCount(Antal, TableHint)
	SELECT COUNT(*), 'NOLOCK'
		FROM dbo.Person WITH (NOLOCK);

INSERT INTO dbo.TableHintCount(Antal, TableHint)
	SELECT COUNT(*), 'READUNCOMMITTED'
		FROM dbo.Person WITH (READUNCOMMITTED);
GO 500
USE NolockDB;

SELECT	MIN(Antal) AS Minimum, 
		MAX(Antal) AS Maximum, 
		MAX(Antal) - MIN(Antal) AS Difference, 
		COUNT(DISTINCT Antal) AS ForskelligeVaerdier,
		(SELECT COUNT(*) FROM dbo.Person) AS KorrektAntal,
		MIN(Antal) - (SELECT COUNT(*) FROM dbo.Person) AS MinimumMinusAktuel, 
		MAX(Antal) - (SELECT COUNT(*) FROM dbo.Person) AS MaximumMinusAktuel, 
		'NOLOCK' AS Tablehint
	FROM dbo.TableHintCount
	WHERE TableHint = 'NOLOCK'
UNION ALL
SELECT	MIN(Antal) AS Minimum, 
		MAX(Antal) AS Maximum, 
		MAX(Antal) - MIN(Antal) AS Difference, 
		COUNT(DISTINCT Antal) AS ForskelligeVaerdier,
		(SELECT COUNT(*) FROM dbo.Person) AS KorrektAntal,
		MIN(Antal) - (SELECT COUNT(*) FROM dbo.Person) AS MinimumMinusAktuel, 
		MAX(Antal) - (SELECT COUNT(*) FROM dbo.Person) AS MaximumMinusAktuel, 
		'READUNCOMMITTED' AS Tablehint
	FROM dbo.TableHintCount
	WHERE TableHint = 'READUNCOMMITTED';
GO
--SELECT *
--	FROM dbo.TableHintCount
--	WHERE TableHint = 'NOLOCK'
--	ORDER BY ID;

--SELECT *
--	FROM dbo.TableHintCount
--	WHERE TableHint = 'READUNCOMMITTED'
--	ORDER BY ID;
GO
USE master;
