USE master;
GO
DROP DATABASE IndexHintDB;
GO
CREATE DATABASE IndexHintDB;
GO
USE IndexHintDB;
CREATE TABLE dbo.Person
(
	PersonId			INT NOT NULL PRIMARY KEY CLUSTERED IDENTITY,
	Fornavn				VARCHAR(20) NOT NULL,
	Efternavn			VARCHAR(20) NOT NULL,
	Gade				VARCHAR(30) NULL,
	Postnr				SMALLINT NULL,
	Fyld				NVARCHAR(200) NOT NULL DEFAULT (REPLICATE(N'ABCD', 50)),
	Bemaerkning			NVARCHAR(1000) NULL
);
GO
INSERT INTO dbo.Person
		(
		Fornavn,
		Efternavn
		)
	SELECT TOP 300
		Fornavn,
		Efternavn
	  FROM IndexDb.dbo.Person
	  WHERE PersonId % 873 = 321;

INSERT INTO dbo.Person
		(
		Fornavn,
		Efternavn,
		Gade,
		Postnr
		)
	SELECT TOP 400
		Fornavn,
		Efternavn,
		Gade,
		Postnr
	  FROM IndexDb.dbo.Person
	  WHERE PersonId % 2304 = 3;

UPDATE dbo.Person
	SET Gade = 'S�nder Strandvej 123', Postnr = 6000
	WHERE	Gade IS NULL AND
			PersonId BETWEEN 234 AND 874;

UPDATE dbo.Person
	SET Gade = 'Aaboulevarden 34', Postnr = 6000, Fornavn = 'Jens Erik Ole'
	WHERE	Gade IS NULL AND
			PersonId BETWEEN 12 AND 456;

UPDATE dbo.Person
	SET Bemaerkning = REPLICATE(N'1234567890', 60)
	WHERE PersonId % 13 = 10;

UPDATE dbo.Person
	SET Bemaerkning = REPLICATE(N'1234567890', 95)
	WHERE PersonId % 6 = 5;
GO
SET STATISTICS TIME ON;
DBCC DROPCLEANBUFFERS;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		*
	FROM dbo.Person;
GO
DBCC DROPCLEANBUFFERS;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		*
	FROM dbo.Person WITH (TABLOCK);
GO
DBCC DROPCLEANBUFFERS;
GO
SELECT *
	FROM dbo.Person WITH (NOLOCK);
GO
DBCC DROPCLEANBUFFERS;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		*
	FROM dbo.Person
	ORDER BY PersonId;
GO
DBCC DROPCLEANBUFFERS;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		*
	FROM dbo.Person WITH (TABLOCK)
	ORDER BY PersonId;
GO