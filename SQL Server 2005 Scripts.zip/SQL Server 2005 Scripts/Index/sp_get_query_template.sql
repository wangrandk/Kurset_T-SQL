USE master;
GO
DROP DATABASE TraceDB;
GO
CREATE DATABASE TraceDB;
GO
USE TraceDB;
GO
SELECT *
	FROM dbo.TraceData;
GO
SELECT	*, 
		CAST(NULL AS NVARCHAR(MAX)) AS Statement,
		CAST(NULL AS NVARCHAR(MAX)) AS Param
	INTO #TraceData
	FROM dbo.TraceData
	WHERE Textdata LIKE '%SELECT%';

DECLARE @Statement		NVARCHAR(MAX);
DECLARE	@Params			NVARCHAR(MAX);
DECLARE @RowNumber		INT				= 0;
DECLARE @Textdata		NVARCHAR(MAX);

WHILE EXISTS (SELECT * FROM #TraceData WHERE Rownumber > @RowNumber)
BEGIN
	SELECT	TOP 1 
			@RowNumber = RowNumber,
			@Textdata = Textdata
		FROM #TraceData
		WHERE Rownumber > @RowNumber
		ORDER BY RowNumber;

		BEGIN TRY
			EXECUTE sys.sp_get_query_template
					@querytext	= @Textdata,
					@templatetext	= @Statement	OUTPUT,
					@parameters		= @Params		OUTPUT;
		END TRY
		BEGIN CATCH
			SET @Statement = @Textdata;
			SET @Params = N'Ingen parametre';
		END CATCH

		UPDATE #TraceData
			SET Statement = @Statement, Param = @Params
			WHERE RowNumber = @RowNumber;
END;
SELECT *
	FROM #TraceData;
