SET STATISTICS TIME ON
SET STATISTICS IO ON
DBCC DROPCLEANBUFFERS
GO
USE IndexDB
GO
SELECT	PersonID,
		Fornavn,
		Efternavn,
		Gade,
		Postnr,
		Koenkode,
		Landekode,
		Tlfnr,
		Persontype,
		LandekodeTlfnr,
		Navn
  FROM dbo.Person
GO
DBCC DROPCLEANBUFFERS
GO
USE Index2DB
GO
SELECT	PersonID,
		Fornavn,
		Efternavn,
		Gade,
		Postnr,
		Koenkode,
		Landekode,
		Tlfnr,
		Kundetype,
		LandekodeTlfnr,
		Navn
  FROM dbo.Person
GO
DBCC DROPCLEANBUFFERS
GO
USE Index3DB
GO
SELECT	PersonID,
		Fornavn,
		Efternavn,
		Gade,
		Postnr,
		Koenkode,
		Landekode,
		Tlfnr,
		Kundetype,
		LandekodeTlfnr,
		Navn
  FROM dbo.Person
GO
DBCC DROPCLEANBUFFERS
GO
USE IndexFilgrpDB
GO
SELECT	PersonID,
		Fornavn,
		Efternavn,
		Gade,
		Postnr,
		Koenkode,
		Landekode,
		Tlfnr,
		Persontype,
		LandekodeTlfnr,
		Navn
  FROM dbo.Person
GO

