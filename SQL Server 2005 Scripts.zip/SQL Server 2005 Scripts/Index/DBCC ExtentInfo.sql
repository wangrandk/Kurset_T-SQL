USE master
GO
IF EXISTS (SELECT *
				FROM master.sys.databases
				WHERE name = 'DBCCDB')
	DROP DATABASE DBCCDB
GO
CREATE DATABASE DBCCDB  
ON PRIMARY
	(NAME = N'DBCCDB_Sys', 
	FILENAME = N'C:\Databaser\DBCCDB_Data.MDF', 
	SIZE = 5, 
	FILEGROWTH = 10%),
FILEGROUP DataFG1
	(NAME = N'DBCCDB_FG1_Fil1', 
	 FILENAME = N'C:\Databaser\DBCCDB_DataFG1_Fil1.NDF', 
	 SIZE = 1000, 
	 FILEGROWTH = 10%)
LOG ON
	(NAME = N'DBCCDB_Log',
	FILENAME = N'C:\Databaser\DBCCDB_Log.LDF', 
	SIZE = 200,
	FILEGROWTH = 100)
GO
USE DBCCDB
ALTER DATABASE DBCCDB MODIFY FILEGROUP DataFG1 DEFAULT
GO
BACKUP DATABASE DBCCDB TO DISK  = 'c:\rod\DBCCDB.bak' WITH FORMAT
GO
ALTER DATABASE DBCCDB SET RECOVERY SIMPLE
GO
USE DBCCDB
GO
CREATE SCHEMA Hjaelpedata
GO
CREATE TABLE dbo.Koen (
	Koenkode		CHAR(1) NOT NULL CONSTRAINT PK_Koen PRIMARY KEY,
	Koentext		VARCHAR(10) NOT NULL)
GO	
CREATE TABLE Hjaelpedata.Efternavn (
	Efternavn 		VARCHAR (20)  NOT NULL)
GO
CREATE TABLE Hjaelpedata.Fornavn (
	Fornavn 		VARCHAR (50)  NOT NULL,
	Koen			CHAR(1) NULL  CONSTRAINT FK_Fornavn_Koen__Koenkode FOREIGN KEY REFERENCES dbo.Koen(Koenkode)) 
GO
CREATE TABLE Hjaelpedata.Gade (
	Gade 			VARCHAR (30)  NOT NULL)
GO
CREATE TABLE dbo.Postopl (
	Postnr 			SMALLINT NOT NULL CONSTRAINT PK_Postopl PRIMARY KEY,
	Bynavn 			VARCHAR (20) NOT NULL)
GO
CREATE TABLE dbo.Persontype (
	Persontype		CHAR(1) NOT NULL CONSTRAINT PK_Persontype PRIMARY KEY,
	PersontypeTxt	VARCHAR(30) NOT NULL)
GO	
CREATE TABLE dbo.Landekode (
	Landekode		VARCHAR(5) NOT NULL CONSTRAINT PK_Landekode PRIMARY KEY,
	Land			VARCHAR(20) NOT NULL CONSTRAINT UQ_Landekode__Land UNIQUE)
GO
CREATE TABLE dbo.Person (
	PersonID 		INT IDENTITY NOT NULL CONSTRAINT PK_Person PRIMARY KEY,
	Fornavn 		VARCHAR (20)  NOT NULL,
	Efternavn 		VARCHAR (20)  NOT NULL,
	Gade 			VARCHAR (30)  NOT NULL,
	Postnr 			SMALLINT NOT NULL CONSTRAINT FK_Person_Postopl__Postnr FOREIGN KEY REFERENCES dbo.Postopl(Postnr),
	Koenkode		CHAR(1) NULL CONSTRAINT FK_Person_Koen__Koenkode FOREIGN KEY REFERENCES dbo.Koen(Koenkode),
	Landekode		VARCHAR(5) NULL CONSTRAINT FK_Person_Landekode__Landekode FOREIGN KEY REFERENCES dbo.Landekode(Landekode),
	Tlfnr			VARCHAR(20) NULL,
	Persontype		CHAR(1) NOT NULL,
	CONSTRAINT CK_Person__Landekode_Tlfnr CHECK ((Landekode IS NULL AND Tlfnr IS NULL) OR
												(Landekode IS NOT NULL AND Tlfnr IS NOT NULL)),
	LandekodeTlfnr	AS Landekode + ' ' + Tlfnr,
	Navn 			AS (Fornavn + ' ' + Efternavn))
GO
SET NOCOUNT ON
INSERT INTO dbo.Koen VALUES
	('K', 'Kvinde'),
	('M', 'Mand')

INSERT INTO dbo.Persontype VALUES
	('A', 'Aktiv'),
	('B', 'Passiv'),
	('C', 'Ukendt'),
	('D', 'Eksklusiv')
	
INSERT INTO dbo.Landekode VALUES
	('+45', 'Danmark')

INSERT INTO Hjaelpedata.Fornavn VALUES 
	('Anne', 'K'),
	('Ane', 'K'),
	('Anni', 'K'),
	('Annemette', 'K'),
	('Anne Mette', 'K'),
	('Anne Marie', 'K'),
	('Anders', 'M'),
	('Andreas', 'M'),
	('August', 'M'),
	('Arne', 'M'),
	('Andreas', 'M'),
	('Asger', 'M'),
	('Allan', 'M'),
	('Bo', NULL),
	('Birte', 'K'),
	('Birthe', 'K'),
	('Bente', 'K'),
	('Bent', 'K'),
	('B�rge', 'M'),
	('Bruno', 'M'),
	('Carl', 'M'),
	('Carina', 'K'),
	('Christian', 'M'),
	('Christina', 'K'),
	('Dorte', 'K'),
	('Dorthe', 'K'),
	('David', 'M'),
	('Daniel', 'M'),
	('Erik', 'M'),
	('Eva', 'K'),
	('Emma', 'K'),
	('Ebba', 'K'),
	('Ebbe', 'M'),
	('Ellen', 'K'),
	('Edvard', 'M'),
	('Edward', 'M'),
	('Egon', 'M'),
	('Esther', 'K'),
	('Frank', 'M'),
	('Frederikke', 'K'),
	('Frede', 'M'),
	('Frode', 'M'),
	('Frida', 'K'),
	('Grete', 'K'),
	('Gitte', 'K'),
	('Grethe', 'K'),
	('Gert', 'M'),
	('Gerd', 'K'),
	('Gunnar', 'M'),
	('Gustav', 'M'),
	('Gudrun', 'K'),
	('Henrik', 'M'),
	('Hans', 'M'),
	('Hans Erik', 'M'),
	('Hans Ole', 'M'),
	('Hanne', 'K'),
	('Henriette', 'K'),
	('Hedvig', 'K'),
	('Henry', 'M'),
	('Hugo', 'M'),
	('Ib', 'M'),
	('Ida', 'K'),
	('Ilse', 'K'),
	('Ivar', 'M'),
	('Ivan', 'M'),
	('Inger', 'K'),
	('Inge', 'K'),
	('Jens', 'M'),
	('Jens Erik', 'M'),
	('Jens Ole', 'M'),
	('Jens Peter', 'M'),
	('Jakob', 'M'),
	('Jacob', 'M'),
	('Jesper', 'M'),
	('Jette', 'K'),
	('Jytte', 'K'),
	('Jane', 'K'),
	('Karl', 'M'),
	('Karen', 'K'),
	('Karin', 'K'),
	('Kis', 'K'),
	('Karina', 'K'),
	('Kristina', 'K'),
	('Kristine', 'K'),
	('Kurt', 'M'),
	('Knud', 'M'),
	('Kenneth', 'M'),
	('Lars', 'M'),
	('Lars Ole', 'M'),
	('Lars Bo', 'M'),
	('Ludvig', 'M'),
	('Line', 'K'),
	('Lise', 'K'),
	('Lisette', 'K'),
	('Lene', 'K'),
	('Lisbeth', 'K'),
	('Lena', 'K'),
	('Liselotte', 'K'),
	('Lise Lotte', 'K'),
	('Morten', 'M'),
	('Marie', 'K'),
	('Mads', 'M'),
	('Maren', 'K'),
	('Malene', 'K'),
	('Mette', 'K'),
	('Michael', 'M'),
	('Mikael', 'M'),
	('Niels', 'M'),
	('Nis', 'M'),
	('Nicolaj', 'M'),
	('Nikolaj', 'M'),
	('Ninna', 'K'),
	('Nette', 'K'),
	('Nanna', 'K'),
	('Ole', 'M'),
	('Oda', 'K'),
	('Olivia', 'K'),
	('Oskar', 'M'),
	('Ove', 'M'),
	('Peter', 'M'),
	('Per', 'M'),
	('Petrea', 'K'),
	('Peder', 'M'),
	('Pil', 'K'),
	('Poul', 'M'),
	('Paul', 'M'),
	('Poula', 'K'),
	('Rasmus', 'M'),
	('Rie', 'K'),
	('Rikke', 'K'),
	('Richard', 'M'),
	('Rune', 'M'),
	('Ruth', 'K'),
	('Rosa', 'K'),
	('Robert', 'M'),
	('Rositta', 'K'),
	('S�ren', 'M'),
	('Sys', 'K'),
	('Sara', 'K'),
	('Simone', 'K'),
	('Susanne', 'K'),
	('Sanne', 'K'),
	('Sofus', 'M'),
	('Solvej', 'K'),
	('Signe', 'K'),
	('Thomas', 'M'),
	('Tove', 'K'),
	('Tommy', 'M'),
	('Tone', 'K'),
	('Trine', 'K'),
	('Tine', 'K'),
	('Tina', 'K'),
	('Tobias', 'M'),
	('Uffe', 'M'),
	('Ulla', 'K'),
	('Ulrik', 'M'),
	('Vera', 'K'),
	('Villy', 'M'),
	('Vagn', 'M'),
	('Willy', 'M'),
	('Yrsa', 'K'),
	('�jvind', 'M'),
	('�ge', 'M'),
	('�se', 'K')

INSERT INTO Hjaelpedata.Efternavn VALUES 
	('Andersen'),
	('Arnesen'),
	('Andreasen'),
	('B�rgesen'),
	('Bentsen'),
	('Christensen'),
	('Christiansen'),
	('Carlsen'),
	('Davidsen'),
	('Danielsen'),
	('Eriksen'),
	('Eskildsen'),
	('Frandsen'),
	('Frederiksen'),
	('Gertsen'),
	('Henriksen'),
	('Hansen'),
	('Hansen'),
	('Iversen'),
	('Ibsen'),
	('Jensen'),
	('Jensen'),
	('Jensen'),
	('Jakobsen'),
	('Jacobsen'),
	('Karlsen'),
	('Knudsen'),
	('Kristensen'),
	('Larsen'),
	('Lassen'),
	('Mortensen'),
	('Madsen'),
	('Mikkelsen'),
	('Nielsen'),
	('Nielsen'),
	('Olsen'),
	('Olesen'),
	('Pedersen'),
	('Petersen'),
	('Petersen'),
	('Rasmussen'),
	('S�rensen'),
	('Thomsen'),
	('�vlisen'),
	('�gesen')

INSERT INTO Hjaelpedata.Gade VALUES 
	('N�rregade 2'),
	('N�rregade 34'),
	('N�rregade 27'),
	('Vestergade 3'),
	('�stergade 23'),
	('�stergade 1'),
	('S�ndergade 78'),
	('Torvet 2'),
	('Torvet 4'),
	('Runddelen 1'),
	('Ved Stranden 3'),
	('Strandvejen 112'),
	('All�gade 29'),
	('Norgesgade 3'),
	('Ungarnsgade 4'),
	('Italiensvej 32'),
	('Strandvejen 2'),
	('All�gade 5'),
	('Norgesgade 38'),
	('Ungarnsgade 7'),
	('Italiensvej 21'),
	('Italiensvej 4'),
	('Bragesgade 1'),
	('Bragesgade 12'),
	('Dortesvej 4'),
	('Dortesvej 3'),
	('Ellebjergvej 114'),
	('Ellebjergvej 98'),
	('Frankrigsgade 14'),
	('Frankrigsgade 6'),
	('Helgolandsgade 54'),
	('Helgolandsgade 8'),
	('K�gevej 4'),
	('K�gevej 48'),
	('M�llegade 3'),
	('M�llegade 34'),
	('Ollerupvej 3'),
	('Sct. Pouls Gade 3'),
	('Sct. Pouls Gade 25'),
	('Willemoesgade 2'),
	('Willemoesgade 23'),
	('N�rregade 11'),
	('N�rregade 36'),
	('N�rregade 72'),
	('Vesterbro 3'),
	('Vesterbrogade 23'),
	('Vesterbrogade 1'),
	('M�llevej 78'),
	('M�llevej 2'),
	('M�llevej 4'),
	('M�llevej 3'),
	('Adelgade 3'),
	('Adelgade 12'),
	('Adelgade 39'),
	('Pilegade 3'),
	('Pilegade 4'),
	('Pilegade 32'),
	('Pilegade 2'),
	('�gade 5'),
	('�gade 38'),
	('�gade 7'),
	('�boulevarden 21'),
	('�boulevarden 4'),
	('�sterbro 1'),
	('�sterbro 12'),
	('�sterbro 4'),
	('Horsensgade 3'),
	('Roskildevej 114'),
	('K�gevej 98'),
	('Nyborgvej 14'),
	('Nyborgvej 16'),
	('T�ndergade 34'),
	('T�ndergade 18'),
	('Ribevej 14'),
	('Thistedvej 8'),
	('Herningvej 2'),
	('Svendborgvej 34'),
	('�benr�vej 4'),
	('Vordingborgvej 13')

INSERT INTO dbo.Postopl VALUES 
	(1127, 'K�benhavn K'),
	(1001, 'K�benhavn K'),
	(1129, 'K�benhavn K'),
	(1130, 'K�benhavn K'),
	(2000, 'Frederiksberg'),
	(8000, '�rhus C'),
	(8200, '�rhus N'),
	(8210, '�rhus V'),
	(8240, 'Risskov'),
	(8270, 'H�jbjerg'),
	(8310, 'Tranbjerg J'),
	(9000, 'Aalborg'),
	(9400, 'N�rresundby'),
	(9600, 'Br�nderslev'),
	(9800, 'Hj�rring'),
	(9990, 'Skagen'),
	(2600, 'Glostrup'),
	(2605, 'Br�ndby'),
	(2610, 'R�dovre'),
	(2620, 'Albertslund'),
	(2625, 'Vallensb�k'),
	(2630, 'Taastrup'),
	(2635, 'Ish�j'),
	(2640, 'Hedehusene'),
	(2650, 'Hvidovre'),
	(2660, 'Br�ndby Strand')
SET NOCOUNT OFF
GO
CREATE CLUSTERED INDEX nc_Fornavn__Fornavn ON Hjaelpedata.Fornavn(Fornavn)
CREATE CLUSTERED INDEX nc_Efternavn__Efternavn ON Hjaelpedata.Efternavn(Efternavn)
CREATE CLUSTERED INDEX nc_Gade__Gade ON Hjaelpedata.Gade(Gade)
CREATE NONCLUSTERED INDEX nc_Postopl__Bynavn ON dbo.Postopl(Bynavn)
GO
--INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, Koenkode, Persontype)
--   SELECT  Fornavn, Efternavn, Gade, Postnr, Koen, 'A'
--      FROM Hjaelpedata.Fornavn	INNER JOIN Hjaelpedata.Efternavn ON Fornavn.Fornavn > Efternavn.Efternavn
--								INNER JOIN Hjaelpedata.Gade  ON Efternavn.Efternavn < Gade.Gade
--								INNER JOIN dbo.Postopl ON Gade.Gade <> dbo.Postopl.Bynavn
--      WHERE LEN (Fornavn) + LEN (Efternavn) < 13

INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, Koenkode, Persontype)
   SELECT  Fornavn, Efternavn, Gade, Postnr, Koen, 'A'
      FROM Hjaelpedata.Fornavn	INNER JOIN Hjaelpedata.Efternavn ON Fornavn.Fornavn < Efternavn.Efternavn
								INNER JOIN Hjaelpedata.Gade  ON Efternavn.Efternavn < Gade.Gade
								INNER JOIN dbo.Postopl ON Gade.Gade < dbo.Postopl.Bynavn

--INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, Koenkode, Persontype)
--   SELECT  Fornavn, Efternavn, Gade, Postnr, Koen, 'A'
--      FROM Hjaelpedata.Fornavn	INNER JOIN Hjaelpedata.Efternavn ON Fornavn.Fornavn > Efternavn.Efternavn
--								INNER JOIN Hjaelpedata.Gade  ON Efternavn.Efternavn < Gade.Gade
--								INNER JOIN dbo.Postopl ON Gade.Gade > dbo.Postopl.Bynavn
--      WHERE LEN(Fornavn) + LEN(Efternavn) > 16

--INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, Koenkode, Persontype)
--   SELECT  Fornavn, Efternavn, Gade, Postnr, Koen, 'A'
--      FROM Hjaelpedata.Fornavn	INNER JOIN Hjaelpedata.Efternavn ON Fornavn.Fornavn < Efternavn.Efternavn
--								INNER JOIN Hjaelpedata.Gade  ON Efternavn.Efternavn < Gade.Gade
--								INNER JOIN dbo.Postopl ON Gade.Gade > dbo.Postopl.Bynavn
--      WHERE LEN(Fornavn) = LEN(Efternavn)

--INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, Koenkode, Persontype)
--   SELECT  Fornavn, Efternavn, Gade, Postnr, Koen, 'A'
--      FROM Hjaelpedata.Fornavn	INNER JOIN Hjaelpedata.Efternavn ON Fornavn.Fornavn > Efternavn.Efternavn
--								INNER JOIN Hjaelpedata.Gade  ON Efternavn.Efternavn < Gade.Gade
--								INNER JOIN dbo.Postopl ON Gade.Gade > dbo.Postopl.Bynavn
--      WHERE LEN(Gade) < LEN(Efternavn)
GO
UPDATE dbo.Person
  SET Persontype = 'B'
  WHERE PersonID % 100 = 1

UPDATE dbo.Person
  SET Persontype = 'C'
  WHERE PersonID % 1000 = 2

UPDATE dbo.Person
  SET Persontype = 'D'
  WHERE PersonID % 10000 = 3
  
UPDATE dbo.Person
	SET Tlfnr = RIGHT('32415672' + CAST(PersonId AS VARCHAR(10)), 8),
		Landekode = '+45'
	WHERE	PersonID % 2 = 1 AND
			Koenkode = 'M' 

UPDATE dbo.Person
	SET Tlfnr = RIGHT('46529927' + CAST(PersonId AS VARCHAR(10)), 8),
		Landekode = '+45'
	WHERE	PersonID % 3 = 2 AND
			Koenkode = 'M' 

UPDATE dbo.Person
	SET Tlfnr = RIGHT('98727378' + CAST(PersonId AS VARCHAR(10)), 8),
		Landekode = '+45'
	WHERE	PersonID % 3 = 2 AND
			Koenkode = 'K' 
GO
DROP TABLE Hjaelpedata.Fornavn
DROP TABLE Hjaelpedata.Efternavn
DROP TABLE Hjaelpedata.Gade
DROP SCHEMA Hjaelpedata
GO
CREATE INDEX nc_Person_Fornavn ON Person (Fornavn)
CREATE INDEX nc_Person_Efternavn ON Person (Efternavn)
CREATE INDEX nc_Person_PersonID_Fornavn_Efternavn_Gade_Postnr ON Person (PersonID, Fornavn, EFternavn, Gade, Postnr)
CREATE INDEX nc_Person_PersonID_Fornavn_Efternavn_4_5 ON Person (PersonID, Fornavn, EFternavn) INCLUDE (Gade, Postnr)
GO
SELECT name, index_Id, type_desc
	FROM sys.indexes
	WHERE object_id = OBJECT_ID('Person')
GO 
DBCC EXTENTINFO (DBCCDB, Person, 6)
DBCC EXTENTINFO (DBCCDB, Person, 5)
DBCC EXTENTINFO (DBCCDB, Person, -1)
GO
CREATE TABLE dbo.extent_info (
	file_id				BIGINT,
	page_id				BIGINT,
	pg_alloc			TINYINT,
	ext_size			SMALLINT,
	obj_id				BIGINT,	
	index_id			TINYINT,
	partition_number	BIGINT,
	partition_id		BIGINT,
	iam_chain_type		NVARCHAR(255),	
	pfs_bytes			VARBINARY(16)
)
GO
INSERT INTO dbo.extent_info
	EXEC('DBCC EXTENTINFO (DBCCDB, Person, -1)')
GO
SELECT *
	FROM dbo.extent_info
	WHERE pfs_bytes <> 0x4040404040404040
GO
SELECT name, index_Id, type_desc
	FROM sys.indexes
	WHERE object_id = OBJECT_ID('Person')
GO 
DBCC IND(DBCCDB, Person, 6)
DBCC IND(DBCCDB, Person, 5)
DBCC IND(DBCCDB, Person, -1)
GO
CREATE TABLE dbo.ind_info
(
    PageFID				TINYINT,
    PagePID				INT,
    IAMFID				TINYINT,
    IAMPID				INT,
    ObjectID			INT,
    IndexID				TINYINT,
    PartitionNumber		TINYINT,
    PartitionID			BIGINT,
    iam_chain_type		VARCHAR(30),
    PageType			TINYINT,
    IndexLevel			TINYINT,
    NextPageFID			TINYINT,
    NextPagePID			INT,
    PrevPageFID			TINYINT,
    PrevPagePID			INT
)
GO
INSERT INTO dbo.ind_info
	EXEC('DBCC IND(DBCCDB, Person, -1)')
GO
SELECT	IndexID,
		IndexLevel,
		PageFID,
		PagePID,
		PrevPageFID,
		PrevPagePID,
		NextPageFID,
		NextPagePID,
		PageTypetext
	FROM dbo.ind_info INNER JOIN (VALUES 
										(1, 'data page'),
										(2, 'index page'),
										(3, 'text page'),
										(4, 'text page'),
										(8, 'GAM page'),
										(9, 'SGAM page'),
										(10, 'IAM page'),
										(11, 'PFS page'))  AS Pagetypeinfo(PageType, PageTypetext)
		ON ind_info.PageType = Pagetypeinfo.PageType
		WHERE ind_info.IndexID = 6
	ORDER BY IndexLevel DESC, PrevPagePID
GO

