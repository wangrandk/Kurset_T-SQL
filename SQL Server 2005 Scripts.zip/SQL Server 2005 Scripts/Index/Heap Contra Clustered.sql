USE IndexDB;
GO
SELECT *
	INTO dbo.PersonHeap
	FROM dbo.Person;

SELECT *
	INTO dbo.PersonClustered
	FROM dbo.Person;
GO
ALTER TABLE dbo.PersonHeap
	ADD CONSTRAINT PK_PersonHeap_PersonId PRIMARY KEY NONCLUSTERED (PersonId);

ALTER TABLE dbo.PersonClustered
	ADD CONSTRAINT PK_PersonClustered_PersonId PRIMARY KEY CLUSTERED (PersonId);
GO
CREATE NONCLUSTERED INDEX NC_PersonHeap_Fornavn_Efternavn
	ON dbo.PersonHeap (Fornavn, Efternavn);

CREATE NONCLUSTERED INDEX NC_PersonClustered_Fornavn_Efternavn
	ON dbo.PersonClustered (Fornavn, Efternavn);

CREATE NONCLUSTERED INDEX NC_PersonHeap_Postnr
	ON dbo.PersonHeap (Postnr);

CREATE NONCLUSTERED INDEX NC_PersonClustered_Postnr
	ON dbo.PersonClustered (Postnr);	
 
CREATE NONCLUSTERED INDEX NC_PersonHeap_Koenkode
	ON dbo.PersonHeap (Koenkode);

CREATE NONCLUSTERED INDEX NC_PersonClustered_Koenkode
	ON dbo.PersonClustered (Koenkode);

CREATE NONCLUSTERED INDEX NC_PersonHeap_Persontype
	ON dbo.PersonHeap (Persontype);

CREATE NONCLUSTERED INDEX NC_PersonClustered_Persontype
	ON dbo.PersonClustered (Persontype);
GO
SELECT	i.name,  
		ps.index_id,
		ps.index_type_desc,
		ps.index_level,
		ps.page_count,
		ps.record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('PersonHeap'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id
	ORDER BY ps.index_id, ps.record_count;

SELECT	i.name,  
		ps.index_id,
		ps.index_type_desc,
		ps.index_level,
		ps.page_count,
		ps.record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('PersonClustered'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id
	ORDER BY ps.index_id, ps.record_count;
GO
SET STATISTICS TIME ON;

SELECT COUNT(*)
	FROM dbo.PersonHeap;

SELECT COUNT(*)
	FROM dbo.PersonClustered;
GO
SELECT COUNT(Postnr)
	FROM dbo.PersonHeap;

SELECT COUNT(Postnr)
	FROM dbo.PersonClustered;
GO
SELECT COUNT(Koenkode)
	FROM dbo.PersonHeap;

SELECT COUNT(Koenkode)
	FROM dbo.PersonClustered;
GO