USE IndexDB
GO
CREATE NONCLUSTERED INDEX nc_Person_Persontype ON dbo.Person(Persontype);
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('person'), NULL, NULL , 'DETAILED');
GO
SELECT Persontype,
		COUNT(*),
		COUNT(*) * 100.0 / (SELECT COUNT(*) FROM dbo.Person) 
	FROM dbo.Person
	GROUP BY Persontype;
GO
SELECT * FROM dbo.Person WHERE Persontype = 'A';
SELECT * FROM dbo.Person WHERE Persontype = 'B';
SELECT * FROM dbo.Person WHERE Persontype = 'C';
SELECT * FROM dbo.Person WHERE Persontype = 'D';
GO
CREATE NONCLUSTERED INDEX nc_Person_Persontype_Filter ON dbo.Person(Persontype)
	WHERE Persontype <> 'A' ;
GO 
DROP INDEX Person.nc_Person_Persontype;
GO
SELECT * 
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('person'), NULL, NULL , 'DETAILED');
