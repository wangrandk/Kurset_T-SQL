-- �ndret fra version 2016
-- TRACE FLAG 2371 - �ndrer opdatering af statistik fra 20% til en procent, som er afh�ngig af st�rrelsen p� tabellen.
USE master;
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB
ON PRIMARY
	(NAME = N'TestDB_Sys', 
	FILENAME = N'C:\Databaser\TestDB_Data.MDF', 
	SIZE = 5, 
	FILEGROWTH = 10%),
FILEGROUP DataFG1
	(NAME = N'TestDB_FG1_Fil1', 
	 FILENAME = N'C:\Databaser\TestDB_DataFG1_Fil1.NDF', 
	 SIZE = 1000, 
	 FILEGROWTH = 10%),

	(NAME = N'TestDB_FG1_Fil2', 
	 FILENAME = N'C:\Databaser\TestDB_DataFG1_Fil2.NDF', 
	 SIZE = 1000, 
	 FILEGROWTH = 10%),

	(NAME = N'TestDB_FG1_Fil3', 
	 FILENAME = N'C:\Databaser\TestDB_DataFG1_Fil3.NDF', 
	 SIZE = 1000, 
	 FILEGROWTH = 10%),

	(NAME = N'TestDB_FG1_Fil4', 
	 FILENAME = N'C:\Databaser\TestDB_DataFG1_Fil4.NDF', 
	 SIZE = 1000, 
	 FILEGROWTH = 10%)

LOG ON
	(NAME = N'TestDB_Log',
	FILENAME = N'C:\Databaser\TestDB_Log.LDF', 
	SIZE = 2000,
	FILEGROWTH = 500);
GO
USE TestDB;
ALTER DATABASE TestDB MODIFY FILEGROUP DataFG1 DEFAULT;
ALTER DATABASE TestDB SET DELAYED_DURABILITY = FORCED;
ALTER DATABASE TestDB SET RECOVERY SIMPLE WITH NO_WAIT;
GO
USE TestDB;
CREATE TABLE dbo.Data
(
	ID		INT NOT NULL PRIMARY KEY IDENTITY,
	Data1	VARCHAR(10) NULL,
	Data2	INT NULL,
	Data3	VARCHAR(10) NOT NULL,
	Data4	INT NOT NULL,
	Data5	CHAR(800) NOT NULL DEFAULT(REPLICATE('A', 800))
);
GO
SELECT *
	INTO dbo.Data1
	FROM	(VALUES 
			('a'), ('b'), ('c'), ('d'), ('e'), ('f'), ('g'), ('h'), ('i'), ('j'), 
			('k'), ('l'), ('m'), ('n'), ('o'), ('p'), ('q'), ('r'), ('s'), ('t'), 
			('u'), ('v'), ('w'), ('x'), ('y'), ('z'), ('�'), ('�'), ('�') 
			) AS Data1(Data1)
	
SELECT *
	INTO dbo.Data2
	FROM	(VALUES 
			(0), (1), (2), (3), (4), (5), (6), (7), (8), (9) 
			) AS Data2(Data2)
GO
--DBCC TRACEOFF (2371);
--DBCC TRACEON (2371);
GO
-----------------------------------------------------------------------------------------
INSERT INTO dbo.Data (Data1, Data2, Data3, Data4)
	SELECT	Data1.Data1,
			Data2.Data2,
			Data1.Data1 + Data1.Data1,
			Data2.Data2 * 10 + Data2.Data2 
		FROM	dbo.Data1 CROSS JOIN dbo.Data2
GO
CREATE INDEX nc_Data_Data1 ON dbo.Data (Data1);
CREATE INDEX nc_Data_Data2 ON dbo.Data (Data2);
CREATE INDEX nc_Data_Data3 ON dbo.Data (Data3);
CREATE INDEX nc_Data_Data4 ON dbo.Data (Data4);
GO
SELECT	1 AS Number,
		stats.object_id, 
        stats.name, 
        statsprop.rows, 
        statsprop.modification_counter,
		statsprop.last_updated,
		statsprop.rows_sampled
	INTO dbo.Statsdata
	FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
	WHERE stats.object_id =  OBJECT_ID(N'dbo.Data'); 
GO
SELECT *
	FROM dbo.Statsdata;
GO
UPDATE TOP (30) PERCENT dbo.Data
	SET Data1 = Data1 + Data1

UPDATE TOP (40) PERCENT dbo.Data
	SET Data2 = Data2 + Data2

UPDATE TOP (2) PERCENT dbo.Data
	SET Data3 = Data3 + Data3

UPDATE TOP (3) PERCENT dbo.Data
	SET Data4 = Data4 + Data4
GO
INSERT INTO dbo.Statsdata
	SELECT	2 AS Number,
			stats.object_id, 
			stats.name, 
			statsprop.rows, 
			statsprop.modification_counter,
			statsprop.last_updated,
			statsprop.rows_sampled
		FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
		WHERE stats.object_id =  OBJECT_ID(N'dbo.Data'); 
GO
--SELECT *
--	FROM dbo.Statsdata;
GO
SELECT *
	FROM dbo.data
	WHERE Data1 = 'a'
GO
INSERT INTO dbo.Statsdata
	SELECT	3 AS Number,
			stats.object_id, 
			stats.name, 
			statsprop.rows, 
			statsprop.modification_counter,
			statsprop.last_updated,
			statsprop.rows_sampled
		FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
		WHERE stats.object_id =  OBJECT_ID(N'dbo.Data');
GO
SELECT *
	FROM dbo.data
	WHERE Data2 = 0;
GO
INSERT INTO dbo.Statsdata
	SELECT	4 AS Number,
			stats.object_id, 
			stats.name, 
			statsprop.rows, 
			statsprop.modification_counter,
			statsprop.last_updated,
			statsprop.rows_sampled
		FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
		WHERE stats.object_id =  OBJECT_ID(N'dbo.Data'); 
GO
SELECT *
	FROM dbo.Statsdata;
GO
DROP INDEX nc_Data_Data1 ON dbo.Data;
DROP INDEX nc_Data_Data2 ON dbo.Data;
DROP INDEX nc_Data_Data3 ON dbo.Data;
DROP INDEX nc_Data_Data4 ON dbo.Data

DROP TABLE  dbo.Statsdata;
GO
-----------------------------------------------------------------------------------------
INSERT INTO dbo.Data (Data1, Data2, Data3, Data4)
	SELECT	Data1.Data1,
			Data2.Data2,
			Data1.Data1 + Data3.Data1,
			Data2.Data2 * 10 + Data4.Data2 
		FROM	dbo.Data1	CROSS JOIN dbo.Data2
							CROSS JOIN dbo.Data1 AS Data3
							CROSS JOIN dbo.Data2 AS Data4;
GO
INSERT INTO dbo.Data (Data1, Data2, Data3, Data4, Data5)
	SELECT Data1, Data2, Data3, Data4, Data5
		FROM dbo.Data;
GO 5
CREATE INDEX nc_Data_Data1 ON dbo.Data (Data1);
CREATE INDEX nc_Data_Data2 ON dbo.Data (Data2);
CREATE INDEX nc_Data_Data3 ON dbo.Data (Data3);
CREATE INDEX nc_Data_Data4 ON dbo.Data (Data4);
GO
SELECT	1 AS Number,
		stats.object_id, 
        stats.name, 
        statsprop.rows, 
        statsprop.modification_counter,
		statsprop.last_updated,
		statsprop.rows_sampled
	INTO dbo.Statsdata
	FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
	WHERE stats.object_id =  OBJECT_ID(N'dbo.Data'); 
GO
--SELECT *
--	FROM dbo.Statsdata;
GO
UPDATE TOP (12) PERCENT dbo.Data
	SET Data1 = Data1 + Data1

UPDATE TOP (15) PERCENT dbo.Data
	SET Data2 = Data2 + Data2

UPDATE TOP (2) PERCENT dbo.Data
	SET Data3 = Data3 + Data3

UPDATE TOP (3) PERCENT dbo.Data
	SET Data4 = Data4 + Data4
GO
INSERT INTO dbo.Statsdata
	SELECT	2 AS Number,
			stats.object_id, 
			stats.name, 
			statsprop.rows, 
			statsprop.modification_counter,
			statsprop.last_updated,
			statsprop.rows_sampled
		FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
		WHERE stats.object_id =  OBJECT_ID(N'dbo.Data'); 
GO
--SELECT *
--	FROM dbo.Statsdata;
GO
SELECT *
	FROM dbo.data
	WHERE Data1 = 'a'
GO
INSERT INTO dbo.Statsdata
	SELECT	3 AS Number,
			stats.object_id, 
			stats.name, 
			statsprop.rows, 
			statsprop.modification_counter,
			statsprop.last_updated,
			statsprop.rows_sampled
		FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
		WHERE stats.object_id =  OBJECT_ID(N'dbo.Data');
GO
SELECT *
	FROM dbo.data
	WHERE Data2 = 0;
GO
INSERT INTO dbo.Statsdata
	SELECT	4 AS Number,
			stats.object_id, 
			stats.name, 
			statsprop.rows, 
			statsprop.modification_counter,
			statsprop.last_updated,
			statsprop.rows_sampled
		FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
		WHERE stats.object_id =  OBJECT_ID(N'dbo.Data'); 
GO
SELECT *
	FROM dbo.Statsdata;
----------------------------------------------------------------------------------------------
GO
DROP INDEX nc_Data_Data1 ON dbo.Data;
DROP INDEX nc_Data_Data2 ON dbo.Data;
DROP INDEX nc_Data_Data3 ON dbo.Data;
DROP INDEX nc_Data_Data4 ON dbo.Data

DROP TABLE  dbo.Statsdata;
GO
CREATE INDEX nc_Data_Data1 ON dbo.Data (Data1);
CREATE INDEX nc_Data_Data2 ON dbo.Data (Data2);
CREATE INDEX nc_Data_Data3 ON dbo.Data (Data3);
CREATE INDEX nc_Data_Data4 ON dbo.Data (Data4);
GO
SELECT	1 AS Number,
		stats.object_id, 
        stats.name, 
        statsprop.rows, 
        statsprop.modification_counter,
		statsprop.last_updated,
		statsprop.rows_sampled
	INTO dbo.Statsdata
	FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
	WHERE stats.object_id =  OBJECT_ID(N'dbo.Data'); 
GO
--SELECT *
--	FROM dbo.Statsdata;
GO
UPDATE TOP (23) PERCENT dbo.Data
	SET Data1 = Data1 + Data1

UPDATE TOP (18) PERCENT dbo.Data
	SET Data2 = Data2 + Data2

UPDATE TOP (25) PERCENT dbo.Data
	SET Data3 = Data3 + Data3

UPDATE TOP (31) PERCENT dbo.Data
	SET Data4 = Data4 + Data4
GO
UPDATE STATISTICS Data(nc_data_Data1)
	WITH FULLSCAN;
GO
UPDATE STATISTICS Data(nc_data_Data2)
	WITH FULLSCAN;
GO
INSERT INTO dbo.Statsdata
	SELECT	2 AS Number,
			stats.object_id, 
			stats.name, 
			statsprop.rows, 
			statsprop.modification_counter,
			statsprop.last_updated,
			statsprop.rows_sampled
		FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
		WHERE stats.object_id =  OBJECT_ID(N'dbo.Data'); 
GO
--SELECT *
--	FROM dbo.Statsdata;
GO
SELECT *
	FROM dbo.data
	WHERE Data1 = 'a'
GO
INSERT INTO dbo.Statsdata
	SELECT	3 AS Number,
			stats.object_id, 
			stats.name, 
			statsprop.rows, 
			statsprop.modification_counter,
			statsprop.last_updated,
			statsprop.rows_sampled
		FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
		WHERE stats.object_id =  OBJECT_ID(N'dbo.Data');
GO
SELECT *
	FROM dbo.data
	WHERE Data2 = 0;
GO
INSERT INTO dbo.Statsdata
	SELECT	4 AS Number,
			stats.object_id, 
			stats.name, 
			statsprop.rows, 
			statsprop.modification_counter,
			statsprop.last_updated,
			statsprop.rows_sampled
		FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
		WHERE stats.object_id =  OBJECT_ID(N'dbo.Data'); 
GO
SELECT *
	FROM dbo.Statsdata;
------------------------------------------------------------------------------------------
USE TestDB;
GO
DROP INDEX nc_Data_Data1 ON dbo.Data;
DROP INDEX nc_Data_Data2 ON dbo.Data;
DROP INDEX nc_Data_Data3 ON dbo.Data;
DROP INDEX nc_Data_Data4 ON dbo.Data

DROP TABLE  dbo.Statsdata;
GO
CREATE INDEX nc_Data_Data1 ON dbo.Data (Data1);
CREATE INDEX nc_Data_Data2 ON dbo.Data (Data2);
CREATE INDEX nc_Data_Data3 ON dbo.Data (Data3);
CREATE INDEX nc_Data_Data4 ON dbo.Data (Data4);
GO
SELECT	1 AS Number,
		stats.object_id, 
        stats.name, 
        statsprop.rows, 
        statsprop.modification_counter,
		statsprop.last_updated,
		statsprop.rows_sampled
	INTO dbo.Statsdata
	FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
	WHERE stats.object_id =  OBJECT_ID(N'dbo.Data'); 
GO
--SELECT *
--	FROM dbo.Statsdata;
GO
UPDATE TOP (23) PERCENT dbo.Data
	SET Data1 = REVERSE(Data1)

UPDATE TOP (18) PERCENT dbo.Data
	SET Data2 = Data2 + Data2

UPDATE TOP (4) PERCENT dbo.Data
	SET Data3 = REVERSE(Data3)

UPDATE TOP (8) PERCENT dbo.Data
	SET Data4 = Data4 + Data4
GO
UPDATE STATISTICS Data(nc_data_Data1)
	WITH FULLSCAN;
GO
UPDATE STATISTICS Data(nc_data_Data2)
	WITH FULLSCAN;
GO
INSERT INTO dbo.Statsdata
	SELECT	2 AS Number,
			stats.object_id, 
			stats.name, 
			statsprop.rows, 
			statsprop.modification_counter,
			statsprop.last_updated,
			statsprop.rows_sampled
		FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
		WHERE stats.object_id =  OBJECT_ID(N'dbo.Data'); 
GO
--SELECT *
--	FROM dbo.Statsdata;
GO
SELECT *
	FROM dbo.data
	WHERE Data1 = 'a'
GO
INSERT INTO dbo.Statsdata
	SELECT	3 AS Number,
			stats.object_id, 
			stats.name, 
			statsprop.rows, 
			statsprop.modification_counter,
			statsprop.last_updated,
			statsprop.rows_sampled
		FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
		WHERE stats.object_id =  OBJECT_ID(N'dbo.Data');
GO
SELECT *
	FROM dbo.data
	WHERE Data2 = 0;
GO
INSERT INTO dbo.Statsdata
	SELECT	4 AS Number,
			stats.object_id, 
			stats.name, 
			statsprop.rows, 
			statsprop.modification_counter,
			statsprop.last_updated,
			statsprop.rows_sampled
		FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
		WHERE stats.object_id =  OBJECT_ID(N'dbo.Data'); 
GO
SELECT *
	FROM dbo.Statsdata;
