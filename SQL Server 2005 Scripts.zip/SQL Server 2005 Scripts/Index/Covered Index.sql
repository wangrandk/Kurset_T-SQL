USE master;
GO
DROP DATABASE CoveredDB;
GO
CREATE DATABASE CoveredDB;
GO
USE CoveredDB;
CREATE TABLE dbo.t
(
	a		INT NOT NULL,
	b		INT NOT NULL,
	c		INT NOT NULL,
	d		INT NOT NULL,
	e		CHAR(10) NOT NULL DEFAULT('dummydata'),
	f		CHAR(10) NOT NULL DEFAULT('dummydata'),
	g		CHAR(10) NOT NULL DEFAULT('dummydata'),
	h		CHAR(10) NOT NULL DEFAULT('dummydata'),
	i		CHAR(10) NOT NULL DEFAULT('dummydata'),
	j		CHAR(10) NOT NULL DEFAULT('dummydata'),
	k		CHAR(10) NOT NULL DEFAULT('dummydata'),
	l		CHAR(10) NOT NULL DEFAULT('dummydata'),
	m		CHAR(10) NOT NULL DEFAULT('dummydata'),
	n		CHAR(10) NOT NULL DEFAULT('dummydata'),
	o		CHAR(10) NOT NULL DEFAULT('dummydata'),
	p		CHAR(10) NOT NULL DEFAULT('dummydata'),
	q		CHAR(10) NOT NULL DEFAULT('dummydata'),
	r		CHAR(10) NOT NULL DEFAULT('dummydata'),
	s		CHAR(10) NOT NULL DEFAULT('dummydata'),
	t		CHAR(10) NOT NULL DEFAULT('dummydata'),
	u		CHAR(10) NOT NULL DEFAULT('dummydata'),
	v		CHAR(10) NOT NULL DEFAULT('dummydata'),
	x		CHAR(10) NOT NULL DEFAULT('dummydata'),
	y		CHAR(10) NOT NULL DEFAULT('dummydata'),
	z		CHAR(10) NOT NULL DEFAULT('dummydata')
);
GO
SET NOCOUNT ON
DECLARE @a		INT;
DECLARE @b		INT;
DECLARE @c		INT;
DECLARE @d		INT;

SET @a = 1;
WHILE @a <= 10
BEGIN
	SET @b = 1;
	WHILE @b <= 20
	BEGIN
		SET @c = 1;
		WHILE @c <= 30
		BEGIN
			SET @d = 1;
			WHILE @d <= 40
			BEGIN
				INSERT INTO dbo.t (a, b, c, d)
					VALUES(@a, @b, @c, @d);

				SET @d += 1;
			END
			SET @c += 1;
		END
		SET @b += 1;
	END
	SET @a += 1;
END
GO
SELECT COUNT(*)
	FROM dbo.t;
GO
SELECT DB_NAME() AS  database_name, OBJECT_NAME(object_id) AS object_name,  * 
	FROM sys.dm_db_index_usage_stats
	WHERE	database_id = DB_ID() AND 
			object_id = OBJECT_ID('dbo.t');
GO
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT a, b, c
	FROM dbo.t
	WHERE c = 4;

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
SELECT DB_NAME() AS  database_name, OBJECT_NAME(object_id) AS object_name,  * 
	FROM sys.dm_db_index_usage_stats
	WHERE	database_id = DB_ID() AND 
			object_id = OBJECT_ID('dbo.t');
GO
-- det bedste covered index
-- betingelseskolonne - c - er f�rste kolonne i indexed
-- kun de �vrige kolonner - a og b - er med
CREATE NONCLUSTERED INDEX nc_t__c_a_b ON dbo.t(c, a, b);
GO
SELECT  index_id,
		index_type_desc,
		index_depth,
		index_level,
		page_count,
		record_count,
		avg_record_size_in_bytes
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('dbo.t'), NULL, NULL , 'DETAILED');
GO
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT a, b, c
	FROM dbo.t
	WHERE c = 4;

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
SELECT DB_NAME() AS  database_name, OBJECT_NAME(object_id) AS object_name,  * 
	FROM sys.dm_db_index_usage_stats
	WHERE	database_id = DB_ID() AND 
			object_id = OBJECT_ID('dbo.t');
GO
DROP INDEX nc_t__c_a_b ON dbo.t;
GO
-- godt men ikke det bedste covered index
-- betingelseskolonne - c - er f�rste kolonne i indexed
-- �vrige kolonner - a, b og d - er med, men d bruges ikke
CREATE NONCLUSTERED INDEX nc_t__c_a_b_d ON dbo.t(c, a, b, d);
GO
SELECT  index_id,
		index_type_desc,
		index_depth,
		index_level,
		page_count,
		record_count,
		avg_record_size_in_bytes
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('dbo.t'), NULL, NULL , 'DETAILED');
GO
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT a, b, c
	FROM dbo.t
	WHERE c = 4;

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
SELECT DB_NAME() AS  database_name, OBJECT_NAME(object_id) AS object_name,  * 
	FROM sys.dm_db_index_usage_stats
	WHERE	database_id = DB_ID() AND 
			object_id = OBJECT_ID('dbo.t');
GO
DROP INDEX nc_t__c_a_b_d ON dbo.t;
GO
-- ikke godt, da betingelseskolonne ikke er f�rste kolonne i index
-- betingelseskolonne - c - er 3. kolonne i indexed
-- �vrige kolonner - a og b - er med
CREATE NONCLUSTERED INDEX nc_t__a_b_c ON dbo.t(a, b, c);
GO
SELECT  index_id,
		index_type_desc,
		index_depth,
		index_level,
		page_count,
		record_count,
		avg_record_size_in_bytes
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('dbo.t'), NULL, NULL , 'DETAILED');
GO
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT a, b, c
	FROM dbo.t
	WHERE c = 4;

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
SELECT DB_NAME() AS  database_name, OBJECT_NAME(object_id) AS object_name,  * 
	FROM sys.dm_db_index_usage_stats
	WHERE	database_id = DB_ID() AND 
			object_id = OBJECT_ID('dbo.t');
GO
DROP INDEX nc_t__a_b_c ON dbo.t;
GO
-- ikke godt, da betingelseskolonne ikke er f�rste kolonne i index og kolonne d er med, men anvendes ikke
-- betingelseskolonne - c - er 3. kolonne i indexed
-- �vrige kolonner - a, b og d - er med, men d anvendes ikke
CREATE NONCLUSTERED INDEX nc_t__a_b_c_d ON dbo.t(a, b, c, d);
GO
SELECT  index_id,
		index_type_desc,
		index_depth,
		index_level,
		page_count,
		record_count,
		avg_record_size_in_bytes
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('dbo.t'), NULL, NULL , 'DETAILED');
GO
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT a, b, c
	FROM dbo.t
	WHERE c = 4;

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
SELECT DB_NAME() AS  database_name, OBJECT_NAME(object_id) AS object_name,  * 
	FROM sys.dm_db_index_usage_stats
	WHERE	database_id = DB_ID() AND 
			object_id = OBJECT_ID('dbo.t');
GO
DROP INDEX nc_t__a_b_c_d ON dbo.t;
GO
SELECT *
	FROM sys.indexes
	WHERE object_id = OBJECT_ID('dbo.t');
