USE IndexDB
GO
CREATE INDEX ix_Person_Navn ON dbo.Person (Navn)
GO
DBCC  SHOW_STATISTICS (Person, ix_person_Navn)
GO
CREATE INDEX ix_Person_Fornavn_Efternavn ON dbo.Person (Fornavn, Efternavn)
GO
DBCC  SHOW_STATISTICS (Person, ix_Person_Fornavn_Efternavn)
GO
