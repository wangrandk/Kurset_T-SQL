USE IndexDB;
GO
SELECT *
	INTO dbo.Person1
	FROM dbo.Person;

SELECT *
	INTO dbo.Person2
	FROM dbo.Person;
GO
CREATE INDEX nc_Person1__Koenkode_Fornavn ON Person1(Koenkode, Fornavn);

CREATE INDEX nc_Person2__Fornavn_Koenkode ON Person2(Fornavn, Koenkode);
GO
SET STATISTICS TIME ON
SET STATISTICS IO ON

SELECT Fornavn, Koenkode
	FROM Person1
	WHERE Fornavn = 'Peter' AND Koenkode = 'M'

SELECT Fornavn, Koenkode
	FROM Person2
	WHERE Fornavn = 'Peter' AND Koenkode = 'M'
GO
DBCC SHOW_STATISTICS(Person1, nc_Person1__Koenkode_Fornavn)
DBCC SHOW_STATISTICS(Person2, nc_Person2__Fornavn_Koenkode)
GO
SELECT	*,
		stats.object_id,
		stats.name,
		stats_columns.column_id,
		stats_columns.stats_column_id
	FROM sys.stats INNER JOIN sys.stats_columns
			ON stats.object_id = stats_columns.object_id AND
				stats.stats_id = stats_columns.stats_id
	WHERE stats.object_id IN (OBJECT_ID('Person1'), OBJECT_ID('Person2'))
	ORDER BY 1, 2, 3, 4
GO
DROP STATISTICS Person1.[_WA_Sys_00000002_33D4B598]

DROP STATISTICS Person2.[_WA_Sys_00000006_34C8D9D1]
GO
CREATE INDEX nc_Person1__Mangekolonner ON Person1(Fornavn, Efternavn, Gade, Postnr, Persontype, Koenkode);

CREATE INDEX nc_Person2__Include ON Person2(Fornavn, Efternavn, Gade) INCLUDE (Postnr, Persontype, Koenkode);

