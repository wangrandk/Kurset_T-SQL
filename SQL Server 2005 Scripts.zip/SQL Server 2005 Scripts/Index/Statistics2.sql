USE IndexDB
GO
CREATE INDEX nc_Person__Fornavn_Efternavn ON Person(Fornavn, Efternavn)
GO
SELECT Fornavn, Efternavn, COUNT(*) AS Antal
	FROM Person
	GROUP BY Fornavn, Efternavn
	ORDER BY Antal
--f�
SELECT *
	FROM Person
	WHERE	Fornavn = 'Tove' AND 
			Efternavn = '�vlisen'
GO
SELECT PersonId
	FROM Person
	WHERE	Fornavn = 'Tove' AND 
			Efternavn = '�vlisen'
GO
SELECT Fornavn, Efternavn, COUNT(*) AS Antal
	FROM Person
	GROUP BY Fornavn, Efternavn
	ORDER BY Antal DESC
GO
--mange
SELECT *
	FROM Person
	WHERE	Fornavn = 'Morten' AND 
			Efternavn = 'Jensen'
GO
SELECT PersonId
	FROM Person
	WHERE	Fornavn = 'Morten' AND 
			Efternavn = 'Jensen'
GO
SELECT Fornavn, Efternavn, COUNT(*) AS Antal
	FROM Person
	WHERE Efternavn = 'Jensen'
	GROUP BY Fornavn, Efternavn
	ORDER BY Fornavn
GO
UPDATE Person 
	SET Fornavn = 'Arne' 
	WHERE	Efternavn = 'Jensen' AND 
			Fornavn < 'Q'
GO
UPDATE STATISTICS Person(nc_Person__Fornavn_Efternavn) WITH FULLSCAN
GO
SELECT *
	FROM Person
	WHERE	Fornavn = 'Arne' AND 
			Efternavn = 'Jensen'
GO
SELECT PersonId
	FROM Person
	WHERE	Fornavn = 'Arne' AND 
			Efternavn = 'Jensen'
GO
DROP STATISTICS Person._WA_Sys_00000003_00551192
GO
SELECT *
	FROM Person
	WHERE	Fornavn = 'Arne' AND 
			Efternavn = 'Jensen'
GO
SELECT PersonId
	FROM Person
	WHERE	Fornavn = 'Arne' AND 
			Efternavn = 'Jensen'
GO
CREATE STATISTICS st_Person__Efternavn ON Person(Efternavn) WITH FULLSCAN
GO
SELECT *
	FROM Person
	WHERE	Fornavn = 'Arne' AND 
			Efternavn = 'Jensen'
GO
DROP STATISTICS Person.st_Person__Efternavn
CREATE STATISTICS st_Person__Fornavn_Efternavn ON Person(Fornavn, Efternavn) WITH FULLSCAN
GO
SELECT *
	FROM Person
	WHERE	Fornavn = 'Arne' AND 
			Efternavn = 'Jensen'
GO
