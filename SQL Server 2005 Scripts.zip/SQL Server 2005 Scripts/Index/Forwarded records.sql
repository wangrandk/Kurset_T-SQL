USE master;
GO
DROP DATABASE StorageDB;
GO
CREATE DATABASE StorageDB;
GO
USE StorageDB;
GO
-- kun interessant, n�r alle index er nonclustered

CREATE TABLE dbo.Data1
(
	ID			INT NOT NULL CONSTRAINT PK_Data1 PRIMARY KEY NONCLUSTERED,
	Txt1		VARCHAR(500) NOT NULL DEFAULT (REPLICATE('1', 200)),
	Txt2		VARCHAR(500) NOT NULL DEFAULT (REPLICATE('2', 200)),
	Txt3		VARCHAR(500) NOT NULL DEFAULT (REPLICATE('3', 200)),
	Txt4		VARCHAR(500) NOT NULL DEFAULT (REPLICATE('4', 200)),
);

CREATE TABLE dbo.Data2
(
	ID			INT NOT NULL CONSTRAINT PK_Data2 PRIMARY KEY NONCLUSTERED,
	Txt1		VARCHAR(500) NOT NULL DEFAULT (REPLICATE('1', 200)) INDEX nc_Data2_Txt1,
	Txt2		VARCHAR(500) NOT NULL DEFAULT (REPLICATE('2', 200)) INDEX nc_Data2_Txt2,
	Txt3		VARCHAR(500) NOT NULL DEFAULT (REPLICATE('3', 200)) INDEX nc_Data2_Txt3,
	Txt4		VARCHAR(500) NOT NULL DEFAULT (REPLICATE('4', 200)) INDEX nc_Data2_Txt4,
);
GO
SET NOCOUNT ON;

DECLARE @i				INT = 1;
DECLARE @Maxrows		INT = 2000;

WHILE @i <= @Maxrows
BEGIN;
	INSERT INTO dbo.Data1 (ID) VALUES(@i);
	INSERT INTO dbo.Data2 (ID) VALUES(@i);

	SET @i += 1;
END;

ALTER TABLE dbo.Data1 REBUILD;
ALTER TABLE dbo.Data2 REBUILD;
GO
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		ID
	FROM dbo.Data1
	WHERE Txt1 = REPLICATE('1', 200);

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		ID
	FROM dbo.Data1
	WHERE Txt2 = REPLICATE('2', 200);
GO
SELECT	i.name,
		'Data1' AS table_name,
		ps.index_level,
		ps.page_count,
		ps.fragment_count,
		ps.forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Data1'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id
UNION ALL
SELECT	i.name,
		'Data2' AS table_name,
		ps.index_level,
		ps.page_count,
		ps.fragment_count,
		ps.forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Data2'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;

UPDATE dbo.Data1
	SET Txt2 = Txt2 + REPLICATE('A', 300), Txt3 = Txt3 + REPLICATE('B', 300), Txt4 = Txt4 + REPLICATE('C', 300)
	WHERE ID % 23 = 12;

UPDATE dbo.Data2
	SET Txt2 = Txt2 + REPLICATE('A', 300), Txt3 = Txt3 + REPLICATE('B', 300), Txt4 = Txt4 + REPLICATE('C', 300)
	WHERE ID % 23 = 12;

SELECT	i.name,
		'Data1' AS table_name,
		ps.index_level,
		ps.page_count,
		ps.fragment_count,
		ps.forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Data1'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id
UNION ALL
SELECT	i.name,
		'Data2' AS table_name,
		ps.index_level,
		ps.page_count,
		ps.fragment_count,
		ps.forwarded_record_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Data2'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
GO
