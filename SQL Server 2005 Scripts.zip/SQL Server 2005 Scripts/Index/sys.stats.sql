USE IndexDB;
GO
CREATE NONCLUSTERED INDEX nc_Person_Fornavn
		ON Person (Fornavn);

CREATE NONCLUSTERED INDEX nc_Person_Postnr
		ON Person (Postnr);

CREATE NONCLUSTERED INDEX nc_Person_Persontype
		ON Person (Persontype);
GO
SELECT	stats.object_id, 
        stats.name, 
        statsprop.last_updated, 
        statsprop.rows, 
        statsprop.modification_counter,
		statsprop.last_updated,
		statsprop.rows_sampled
	FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
	WHERE stats.object_id = OBJECT_ID(N'dbo.Person'); 
GO
UPDATE dbo.Person
	SET Fornavn = LEFT(Fornavn, 1)
	WHERE Efternavn = 'Olsen';
GO
SELECT	stats.object_id, 
        stats.name, 
        statsprop.last_updated, 
        statsprop.rows, 
        statsprop.modification_counter,
		statsprop.last_updated,
		statsprop.rows_sampled 
	FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
	WHERE stats.object_id = OBJECT_ID(N'dbo.Person'); 
GO
INSERT INTO Person (Fornavn, Efternavn, Gade, Postnr, PersonType) 
	SELECT TOP 20000 Fornavn, Efternavn, Gade, Postnr, PersonType 
		FROM dbo.Person
		WHERE PersonID % 45 = 23;
GO
SELECT	stats.object_id, 
        stats.name, 
        statsprop.last_updated, 
        statsprop.rows, 
        statsprop.modification_counter,
		statsprop.last_updated,
		statsprop.rows_sampled
	FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
	WHERE stats.object_id = OBJECT_ID(N'dbo.Person'); 
GO
DELETE TOP (10000)
		FROM dbo.Person;
GO
SELECT	stats.object_id, 
        stats.name, 
        statsprop.last_updated, 
        statsprop.rows, 
        statsprop.modification_counter,
		statsprop.last_updated,
		statsprop.rows_sampled 
	FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
	WHERE stats.object_id = OBJECT_ID(N'dbo.Person'); 
GO