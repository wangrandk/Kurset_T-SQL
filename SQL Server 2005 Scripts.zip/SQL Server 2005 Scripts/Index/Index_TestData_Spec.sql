-- Dan tabel med mange ubrugte kolonner, som er NULL
USE master;
GO
IF EXISTS (SELECT *
				FROM master.sys.databases
				WHERE name = 'Index2DB')
	DROP DATABASE Index2DB;
GO
CREATE DATABASE Index2DB  
ON PRIMARY
	(NAME = N'Index2DB_Sys', 
	 FILENAME = N'C:\Databaser\Index2DB_Data.MDF', 
	 SIZE = 5, 
	 FILEGROWTH = 10%),

FILEGROUP DataFG1
	(NAME = N'Index2DB_FG1_Data1', 
	 FILENAME = N'C:\Databaser\Index2DB_DataFG1_Fil1.NDF', 
	 SIZE = 3000, 
	 FILEGROWTH = 10%)

LOG ON
	(NAME = N'Index2DB_Log',
	 FILENAME = N'C:\Databaser\Index2DB_Log.LDF', 
	 SIZE = 500,
	 FILEGROWTH = 500);
GO
USE Index2DB;
GO
ALTER DATABASE Index2DB MODIFY FILEGROUP DataFG1 DEFAULT;
GO
ALTER DATABASE Index2DB SET RECOVERY SIMPLE;
GO
SELECT *
	INTO dbo.Postopl
	FROM IndexDB.dbo.Postopl;

SELECT *
	INTO dbo.Koen
	FROM IndexDB.dbo.Koen;
	
SELECT *
	INTO dbo.Landekode
	FROM IndexDB.dbo.Landekode;

SELECT *
	INTO dbo.Persontype
	FROM IndexDB.dbo.Persontype;
GO
ALTER TABLE dbo.Postopl ADD CONSTRAINT PK_Postopl PRIMARY KEY (Postnr);
ALTER TABLE dbo.Koen ADD CONSTRAINT PK_Koen PRIMARY KEY (Koenkode);
ALTER TABLE dbo.Landekode ADD CONSTRAINT PK_Landekode PRIMARY KEY (Landekode);
ALTER TABLE dbo.Persontype ADD CONSTRAINT PK_Persontype PRIMARY KEY (Persontype);
GO
CREATE TABLE dbo.Person 
(
	PersonID 		INT IDENTITY NOT NULL CONSTRAINT PK_Person PRIMARY KEY,
	Fornavn 		VARCHAR (20)  NOT NULL,
	Efternavn 		VARCHAR (20)  NOT NULL,
	Gade 			VARCHAR (30)  NOT NULL,
	Postnr 			SMALLINT NOT NULL CONSTRAINT FK_Person_Postopl__Postnr FOREIGN KEY REFERENCES dbo.Postopl(Postnr),
	Koenkode		CHAR(1) NULL CONSTRAINT FK_Person_Koen__Koenkode FOREIGN KEY REFERENCES dbo.Koen(Koenkode),
	Landekode		VARCHAR(5) NULL CONSTRAINT FK_Person_Landekode__Landekode FOREIGN KEY REFERENCES dbo.Landekode(Landekode),
	Tlfnr			CHAR(8) NULL,
	Persontype		CHAR(1) NOT NULL CONSTRAINT FK_Person_Persontype__Persontype FOREIGN KEY REFERENCES dbo.Persontype(Persontype),
	Ubrugt1			VARCHAR(20) NULL,
	Ubrugt2			INT NULL,
	Ubrugt3			INT NULL,
	Ubrugt4			CHAR(20) NULL,
	Ubrugt5			BIGINT NULL,
	Ubrugt6			DATE NULL,
	Ubrugt7			TIME NULL,
	Ubrugt8			DECIMAL(18,2) NULL,
	Ubrugt9			DECIMAL(18,2) NULL,
	Ubrugt10		DECIMAL(18,2) NULL,
	Ubrugt11		DECIMAL(18,2) NULL,
	Ubrugt12		INT NULL,
	Ubrugt13		INT NULL,
	Ubrugt14		INT NULL,
	Ubrugt15		CHAR(20) NULL,
	Ubrugt16		INT NULL,
	Ubrugt17		BIGINT NULL,
	Ubrugt18		VARCHAR(10) NULL,
	Ubrugt19		VARCHAR(10) NULL,
	Ubrugt20		INT NULL,
	Ubrugt21		SMALLINT NULL,
	Ubrugt22		SMALLINT NULL,
	Ubrugt23		INT NULL,
	Ubrugt24		INT NULL,
	Ubrugt25		BIGINT NULL,
	Ubrugt26		VARCHAR(40) NULL,
	Ubrugt27		INT NULL,
	Ubrugt28		INT NULL,
	Ubrugt29		SMALLINT NULL,
	Ubrugt30		INT NULL,

	LandekodeTlfnr	AS Landekode + ' ' + Tlfnr,
	Navn 			AS Fornavn + ' ' + Efternavn
);

INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, Landekode, Tlfnr, Koenkode, Persontype)
	SELECT Fornavn, Efternavn, Gade, Postnr, Landekode, Tlfnr, Koenkode, Persontype
		FROM IndexDB.dbo.Person;
GO
-- database med flere filer i filegroup
USE master;
GO
IF EXISTS (SELECT *
				FROM master.sys.databases
				WHERE name = 'Index3DB')
	DROP DATABASE Index3DB;
GO
CREATE DATABASE Index3DB  
ON PRIMARY
	(NAME = N'IndexDB_Sys', 
	 FILENAME = N'C:\Databaser\Index3DB_Data.MDF', 
	 SIZE = 5, 
	 FILEGROWTH = 10%),
	
FILEGROUP DataFG1
	(NAME = N'IndexDB_FG1_Data1', 
	 FILENAME = N'C:\Databaser\Index3DB_DataFG1_Fil1.NDF', 
	 SIZE = 400, 
	 FILEGROWTH = 10%),

	(NAME = N'IndexDB_FG1_Data2', 
	 FILENAME = N'C:\Databaser\Index3DB_DataFG1_Fil2.NDF', 
	 SIZE = 400, 
	 FILEGROWTH = 10%),

	(NAME = N'IndexDB_FG1_Data3', 
	 FILENAME = N'C:\Databaser\Index3DB_DataFG1_Fil3.NDF', 
	 SIZE = 400, 
	 FILEGROWTH = 10%),

	(NAME = N'IndexDB_FG1_Data4', 
	 FILENAME = N'C:\Databaser\Index3DB_DataFG1_Fil4.NDF', 
	 SIZE = 400, 
	 FILEGROWTH = 10%)

LOG ON
	(NAME = N'IndexDB_Log',
	 FILENAME = N'C:\Databaser\Index3DB_Log.LDF', 
	 SIZE = 500,
	 FILEGROWTH = 500);
GO
USE Index3DB;
GO
ALTER DATABASE Index3DB MODIFY FILEGROUP DataFG1 DEFAULT;
GO
ALTER DATABASE Index3DB SET RECOVERY SIMPLE;
GO
SELECT *
	INTO dbo.Postopl
	FROM IndexDB.dbo.Postopl;

SELECT *
	INTO dbo.Koen
	FROM IndexDB.dbo.Koen;
	
SELECT *
	INTO dbo.Landekode
	FROM IndexDB.dbo.Landekode;

SELECT *
	INTO dbo.Persontype
	FROM IndexDB.dbo.Persontype;
GO
ALTER TABLE dbo.Postopl ADD CONSTRAINT PK_Postopl PRIMARY KEY (Postnr);
ALTER TABLE dbo.Koen ADD CONSTRAINT PK_Koen PRIMARY KEY (Koenkode);
ALTER TABLE dbo.Landekode ADD CONSTRAINT PK_Landekode PRIMARY KEY (Landekode);
ALTER TABLE dbo.Persontype ADD CONSTRAINT PK_Persontype PRIMARY KEY (Persontype);
GO
CREATE TABLE dbo.Person 
(
	PersonID 		INT IDENTITY NOT NULL CONSTRAINT PK_Person PRIMARY KEY,
	Fornavn 		VARCHAR (20)  NOT NULL,
	Efternavn 		VARCHAR (20)  NOT NULL,
	Gade 			VARCHAR (30)  NOT NULL,
	Postnr 			SMALLINT NOT NULL CONSTRAINT FK_Person_Postopl__Postnr FOREIGN KEY REFERENCES dbo.Postopl(Postnr),
	Koenkode		CHAR(1) NULL CONSTRAINT FK_Person_Koen__Koenkode FOREIGN KEY REFERENCES dbo.Koen(Koenkode),
	Landekode		VARCHAR(5) NULL CONSTRAINT FK_Person_Landekode__Landekode FOREIGN KEY REFERENCES dbo.Landekode(Landekode),
	Tlfnr			CHAR(8) NULL,
	Persontype		CHAR(1) NOT NULL CONSTRAINT FK_Person_Persontype__Persontype FOREIGN KEY REFERENCES dbo.Persontype(Persontype),
	Ubrugt1			VARCHAR(20) NULL,
	Ubrugt2			INT NULL,
	Ubrugt3			INT NULL,
	Ubrugt4			CHAR(20) NULL,
	Ubrugt5			BIGINT NULL,
	Ubrugt6			DATE NULL,
	Ubrugt7			TIME NULL,
	Ubrugt8			DECIMAL(18,2) NULL,
	Ubrugt9			DECIMAL(18,2) NULL,
	Ubrugt10		DECIMAL(18,2) NULL,
	Ubrugt11		DECIMAL(18,2) NULL,
	Ubrugt12		INT NULL,
	Ubrugt13		INT NULL,
	Ubrugt14		INT NULL,
	Ubrugt15		CHAR(20) NULL,
	Ubrugt16		INT NULL,
	Ubrugt17		BIGINT NULL,
	Ubrugt18		VARCHAR(10) NULL,
	Ubrugt19		VARCHAR(10) NULL,
	Ubrugt20		INT NULL,
	Ubrugt21		SMALLINT NULL,
	Ubrugt22		SMALLINT NULL,
	Ubrugt23		INT NULL,
	Ubrugt24		INT NULL,
	Ubrugt25		BIGINT NULL,
	Ubrugt26		VARCHAR(40) NULL,
	Ubrugt27		INT NULL,
	Ubrugt28		INT NULL,
	Ubrugt29		SMALLINT NULL,
	Ubrugt30		INT NULL,

	LandekodeTlfnr	AS Landekode + ' ' + Tlfnr,
	Navn 			AS Fornavn + ' ' + Efternavn
);

INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, Landekode, Tlfnr, Koenkode, Persontype)
	SELECT Fornavn, Efternavn, Gade, Postnr, Landekode, Tlfnr, Koenkode, Persontype
		FROM IndexDB.dbo.Person;
GO
-- database med default-v�rdier i stedet for NULL. PK i Person er CLUSTERED
USE master;
GO
IF EXISTS (SELECT *
				FROM master.sys.databases
				WHERE name = 'Index4DB')
	DROP DATABASE Index4DB;
GO
CREATE DATABASE Index4DB  
ON PRIMARY
	(NAME = N'IndexDB_Sys', 
	 FILENAME = N'C:\Databaser\Index4DB_Data.MDF', 
	 SIZE = 5, 
	 FILEGROWTH = 10%),
	
FILEGROUP DataFG1
	(NAME = N'IndexDB_FG1_Data1', 
	 FILENAME = N'C:\Databaser\Index4DB_DataFG1_Fil1.NDF', 
	 SIZE = 3000, 
	 FILEGROWTH = 10%)

LOG ON
	(NAME = N'IndexDB_Log',
	 FILENAME = N'C:\Databaser\Index4DB_Log.LDF', 
	 SIZE = 500,
	 FILEGROWTH = 500);
GO
USE Index4DB;
GO
ALTER DATABASE Index4DB MODIFY FILEGROUP DataFG1 DEFAULT;
GO
ALTER DATABASE Index4DB SET RECOVERY SIMPLE;
GO
SELECT *
	INTO dbo.Postopl
	FROM IndexDB.dbo.Postopl;

SELECT *
	INTO dbo.Koen
	FROM IndexDB.dbo.Koen;
	
SELECT *
	INTO dbo.Landekode
	FROM IndexDB.dbo.Landekode;

SELECT *
	INTO dbo.Persontype
	FROM IndexDB.dbo.Persontype;
GO
ALTER TABLE dbo.Postopl ADD CONSTRAINT PK_Postopl PRIMARY KEY (Postnr);
ALTER TABLE dbo.Koen ADD CONSTRAINT PK_Koen PRIMARY KEY (Koenkode);
ALTER TABLE dbo.Landekode ADD CONSTRAINT PK_Landekode PRIMARY KEY (Landekode);
ALTER TABLE dbo.Persontype ADD CONSTRAINT PK_Persontype PRIMARY KEY (Persontype);
GO
CREATE TABLE dbo.Person 
(
	PersonID 		INT IDENTITY NOT NULL CONSTRAINT PK_Person PRIMARY KEY CLUSTERED,
	Fornavn 		VARCHAR (20)  NOT NULL,
	Efternavn 		VARCHAR (20)  NOT NULL,
	Gade 			VARCHAR (30)  NOT NULL,
	Postnr 			SMALLINT NOT NULL CONSTRAINT FK_Person_Postopl__Postnr FOREIGN KEY REFERENCES dbo.Postopl(Postnr),
	Koenkode		CHAR(1) NULL CONSTRAINT FK_Person_Koen__Koenkode FOREIGN KEY REFERENCES dbo.Koen(Koenkode),
	Landekode		VARCHAR(5) NULL CONSTRAINT FK_Person_Landekode__Landekode FOREIGN KEY REFERENCES dbo.Landekode(Landekode),
	Tlfnr			CHAR(8) NULL,
	Persontype		CHAR(1) NOT NULL CONSTRAINT FK_Person_Persontype__Persontype FOREIGN KEY REFERENCES dbo.Persontype(Persontype),
	Ubrugt1			VARCHAR(20) NOT NULL DEFAULT(''),
	Ubrugt2			INT NOT NULL DEFAULT(0),
	Ubrugt3			INT NOT NULL DEFAULT(0),
	Ubrugt4			CHAR(20) NOT NULL DEFAULT(''),
	Ubrugt5			BIGINT NOT NULL DEFAULT(0),
	Ubrugt6			DATE NOT NULL DEFAULT('1900-1-1'),
	Ubrugt7			TIME NOT NULL DEFAULT('00:00:00'),
	Ubrugt8			DECIMAL(18,2) NOT NULL DEFAULT(0),
	Ubrugt9			DECIMAL(18,2) NOT NULL DEFAULT(0),
	Ubrugt10		DECIMAL(18,2) NOT NULL DEFAULT(0),
	Ubrugt11		DECIMAL(18,2) NOT NULL DEFAULT(0),
	Ubrugt12		INT NOT NULL DEFAULT(0),
	Ubrugt13		INT NOT NULL DEFAULT(0),
	Ubrugt14		INT NOT NULL DEFAULT(0),
	Ubrugt15		CHAR(20) NOT NULL DEFAULT(''),
	Ubrugt16		INT NOT NULL DEFAULT(0),
	Ubrugt17		BIGINT NOT NULL DEFAULT(0),
	Ubrugt18		VARCHAR(10) NOT NULL DEFAULT(''),
	Ubrugt19		VARCHAR(10) NOT NULL DEFAULT(''),
	Ubrugt20		INT NOT NULL DEFAULT(0),
	Ubrugt21		SMALLINT NOT NULL DEFAULT(0),
	Ubrugt22		SMALLINT NOT NULL DEFAULT(0),
	Ubrugt23		INT NOT NULL DEFAULT(0),
	Ubrugt24		INT NOT NULL DEFAULT(0),
	Ubrugt25		BIGINT NOT NULL DEFAULT(0),
	Ubrugt26		VARCHAR(40) NOT NULL DEFAULT(''),
	Ubrugt27		INT NOT NULL DEFAULT(0),
	Ubrugt28		INT NOT NULL DEFAULT(0),
	Ubrugt29		SMALLINT NOT NULL DEFAULT(0),
	Ubrugt30		INT NOT NULL DEFAULT(0),

	LandekodeTlfnr	AS Landekode + ' ' + Tlfnr,
	Navn 			AS Fornavn + ' ' + Efternavn
);

INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, Landekode, Tlfnr, Koenkode, Persontype)
	SELECT Fornavn, Efternavn, Gade, Postnr, Landekode, Tlfnr, Koenkode, Persontype
		FROM IndexDB.dbo.Person;
GO
-- database med default-v�rdier i stedet for NULL. PK i Person er NONCLUSTERED
USE master;
GO
IF EXISTS (SELECT *
				FROM master.sys.databases
				WHERE name = 'Index5DB')
	DROP DATABASE Index5DB;
GO
CREATE DATABASE Index5DB  
ON PRIMARY
	(NAME = N'IndexDB_Sys', 
	 FILENAME = N'C:\Databaser\Index5DB_Data.MDF', 
	 SIZE = 5, 
	 FILEGROWTH = 10%),
	
FILEGROUP DataFG1
	(NAME = N'IndexDB_FG1_Data1', 
	 FILENAME = N'C:\Databaser\Index5DB_DataFG1_Fil1.NDF', 
	 SIZE = 2000,
	 FILEGROWTH = 10%)

LOG ON
	(NAME = N'IndexDB_Log',
	 FILENAME = N'C:\Databaser\Index5DB_Log.LDF', 
	 SIZE = 500,
	 FILEGROWTH = 500);
GO
USE Index5DB;
GO
ALTER DATABASE Index5DB MODIFY FILEGROUP DataFG1 DEFAULT;
GO
ALTER DATABASE Index5DB SET RECOVERY SIMPLE;
GO
SELECT *
	INTO dbo.Postopl
	FROM IndexDB.dbo.Postopl;

SELECT *
	INTO dbo.Koen
	FROM IndexDB.dbo.Koen;
	
SELECT *
	INTO dbo.Landekode
	FROM IndexDB.dbo.Landekode;

SELECT *
	INTO dbo.Persontype
	FROM IndexDB.dbo.Persontype;
GO
ALTER TABLE dbo.Postopl ADD CONSTRAINT PK_Postopl PRIMARY KEY (Postnr);
ALTER TABLE dbo.Koen ADD CONSTRAINT PK_Koen PRIMARY KEY (Koenkode);
ALTER TABLE dbo.Landekode ADD CONSTRAINT PK_Landekode PRIMARY KEY (Landekode);
ALTER TABLE dbo.Persontype ADD CONSTRAINT PK_Persontype PRIMARY KEY (Persontype);
GO
CREATE TABLE dbo.Person 
(
	PersonID 		INT IDENTITY NOT NULL CONSTRAINT PK_Person PRIMARY KEY NONCLUSTERED,
	Fornavn 		VARCHAR (20)  NOT NULL,
	Efternavn 		VARCHAR (20)  NOT NULL,
	Gade 			VARCHAR (30)  NOT NULL,
	Postnr 			SMALLINT NOT NULL CONSTRAINT FK_Person_Postopl__Postnr FOREIGN KEY REFERENCES dbo.Postopl(Postnr),
	Koenkode		CHAR(1) NULL CONSTRAINT FK_Person_Koen__Koenkode FOREIGN KEY REFERENCES dbo.Koen(Koenkode),
	Landekode		VARCHAR(5) NULL CONSTRAINT FK_Person_Landekode__Landekode FOREIGN KEY REFERENCES dbo.Landekode(Landekode),
	Tlfnr			CHAR(8) NULL,
	Persontype		CHAR(1) NOT NULL CONSTRAINT FK_Person_Persontype__Persontype FOREIGN KEY REFERENCES dbo.Persontype(Persontype),
	Ubrugt1			VARCHAR(20) NOT NULL DEFAULT(''),
	Ubrugt2			INT NOT NULL DEFAULT(0),
	Ubrugt3			INT NOT NULL DEFAULT(0),
	Ubrugt4			CHAR(20) NOT NULL DEFAULT(''),
	Ubrugt5			BIGINT NOT NULL DEFAULT(0),
	Ubrugt6			DATE NOT NULL DEFAULT('1900-1-1'),
	Ubrugt7			TIME NOT NULL DEFAULT('00:00:00'),
	Ubrugt8			DECIMAL(18,2) NOT NULL DEFAULT(0),
	Ubrugt9			DECIMAL(18,2) NOT NULL DEFAULT(0),
	Ubrugt10		DECIMAL(18,2) NOT NULL DEFAULT(0),
	Ubrugt11		DECIMAL(18,2) NOT NULL DEFAULT(0),
	Ubrugt12		INT NOT NULL DEFAULT(0),
	Ubrugt13		INT NOT NULL DEFAULT(0),
	Ubrugt14		INT NOT NULL DEFAULT(0),
	Ubrugt15		CHAR(20) NOT NULL DEFAULT(''),
	Ubrugt16		INT NOT NULL DEFAULT(0),
	Ubrugt17		BIGINT NOT NULL DEFAULT(0),
	Ubrugt18		VARCHAR(10) NOT NULL DEFAULT(''),
	Ubrugt19		VARCHAR(10) NOT NULL DEFAULT(''),
	Ubrugt20		INT NOT NULL DEFAULT(0),
	Ubrugt21		SMALLINT NOT NULL DEFAULT(0),
	Ubrugt22		SMALLINT NOT NULL DEFAULT(0),
	Ubrugt23		INT NOT NULL DEFAULT(0),
	Ubrugt24		INT NOT NULL DEFAULT(0),
	Ubrugt25		BIGINT NOT NULL DEFAULT(0),
	Ubrugt26		VARCHAR(40) NOT NULL DEFAULT(''),
	Ubrugt27		INT NOT NULL DEFAULT(0),
	Ubrugt28		INT NOT NULL DEFAULT(0),
	Ubrugt29		SMALLINT NOT NULL DEFAULT(0),
	Ubrugt30		INT NOT NULL DEFAULT(0),

	LandekodeTlfnr	AS Landekode + ' ' + Tlfnr,
	Navn 			AS Fornavn + ' ' + Efternavn
);

INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, Landekode, Tlfnr, Koenkode, Persontype)
	SELECT Fornavn, Efternavn, Gade, Postnr, Landekode, Tlfnr, Koenkode, Persontype
		FROM IndexDB.dbo.Person;
GO
-- autogrow
USE master;
GO
IF EXISTS (SELECT *
				FROM master.sys.databases
				WHERE name = 'Index6DB')
	DROP DATABASE Index6DB;
GO
CREATE DATABASE Index6DB;
GO
ALTER DATABASE Index6DB SET RECOVERY SIMPLE;
GO
USE Index6DB;
GO
SELECT *
	INTO dbo.Postopl
	FROM IndexDB.dbo.Postopl;

SELECT *
	INTO dbo.Koen
	FROM IndexDB.dbo.Koen;
	
SELECT *
	INTO dbo.Landekode
	FROM IndexDB.dbo.Landekode;

SELECT *
	INTO dbo.Persontype
	FROM IndexDB.dbo.Persontype;
GO
ALTER TABLE dbo.Postopl ADD CONSTRAINT PK_Postopl PRIMARY KEY (Postnr);
ALTER TABLE dbo.Koen ADD CONSTRAINT PK_Koen PRIMARY KEY (Koenkode);
ALTER TABLE dbo.Landekode ADD CONSTRAINT PK_Landekode PRIMARY KEY (Landekode);
ALTER TABLE dbo.Persontype ADD CONSTRAINT PK_Persontype PRIMARY KEY (Persontype);
GO
CREATE TABLE dbo.Person 
(
	PersonID 		INT IDENTITY NOT NULL CONSTRAINT PK_Person PRIMARY KEY,
	Fornavn 		VARCHAR (20)  NOT NULL,
	Efternavn 		VARCHAR (20)  NOT NULL,
	Gade 			VARCHAR (30)  NOT NULL,
	Postnr 			SMALLINT NOT NULL CONSTRAINT FK_Person_Postopl__Postnr FOREIGN KEY REFERENCES dbo.Postopl(Postnr),
	Koenkode		CHAR(1) NULL CONSTRAINT FK_Person_Koen__Koenkode FOREIGN KEY REFERENCES dbo.Koen(Koenkode),
	Landekode		VARCHAR(5) NULL CONSTRAINT FK_Person_Landekode__Landekode FOREIGN KEY REFERENCES dbo.Landekode(Landekode),
	Tlfnr			CHAR(8) NULL,
	Persontype		CHAR(1) NOT NULL CONSTRAINT FK_Person_Persontype__Persontype FOREIGN KEY REFERENCES dbo.Persontype(Persontype),
	Ubrugt1			VARCHAR(20) NULL,
	Ubrugt2			INT NULL,
	Ubrugt3			INT NULL,
	Ubrugt4			CHAR(20) NULL,
	Ubrugt5			BIGINT NULL,
	Ubrugt6			DATE NULL,
	Ubrugt7			TIME NULL,
	Ubrugt8			DECIMAL(18,2) NULL,
	Ubrugt9			DECIMAL(18,2) NULL,
	Ubrugt10		DECIMAL(18,2) NULL,
	Ubrugt11		DECIMAL(18,2) NULL,
	Ubrugt12		INT NULL,
	Ubrugt13		INT NULL,
	Ubrugt14		INT NULL,
	Ubrugt15		CHAR(20) NULL,
	Ubrugt16		INT NULL,
	Ubrugt17		BIGINT NULL,
	Ubrugt18		VARCHAR(10) NULL,
	Ubrugt19		VARCHAR(10) NULL,
	Ubrugt20		INT NULL,
	Ubrugt21		SMALLINT NULL,
	Ubrugt22		SMALLINT NULL,
	Ubrugt23		INT NULL,
	Ubrugt24		INT NULL,
	Ubrugt25		BIGINT NULL,
	Ubrugt26		VARCHAR(40) NULL,
	Ubrugt27		INT NULL,
	Ubrugt28		INT NULL,
	Ubrugt29		SMALLINT NULL,
	Ubrugt30		INT NULL,

	LandekodeTlfnr	AS Landekode + ' ' + Tlfnr,
	Navn 			AS Fornavn + ' ' + Efternavn
);

INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, Landekode, Tlfnr, Koenkode, Persontype)
	SELECT Fornavn, Efternavn, Gade, Postnr, Landekode, Tlfnr, Koenkode, Persontype
		FROM IndexDB.dbo.Person;
GO
-- Vis alle tabeller og antal forekomster
USE IndexDB;
GO
SET NOCOUNT ON
DECLARE @TableName	SYSNAME;
DECLARE @SchemaName	SYSNAME;
DECLARE @Antal		INT;
DECLARE @SQLString	NVARCHAR(500);

DECLARE @t TABLE
(
	ID				INT NOT NULL IDENTITY,
	Object_id		INT NOT NULL,
	TableName		SYSNAME NOT NULL, 
	SchemaName		SYSNAME NOT NULL,
	AntalForkomster INT NULL,
	Brugt			CHAR(1) DEFAULT('N')
);

INSERT INTO @t (Object_id, TableName, SchemaName)
	SELECT t.object_id, t.name, s.name 
		FROM sys.tables as t INNER JOIN sys.schemas as s 
			ON t.schema_id = s.schema_id
		ORDER BY t.name;

WHILE EXISTS (SELECT * 
				FROM @t 
				WHERE Brugt = 'N')
BEGIN
	SELECT @TableName = TableName, 
			@SchemaName = SchemaName
		FROM @t
		WHERE ID = (SELECT MIN(ID) 
						FROM @t 
						WHERE Brugt = 'N');
		
	SET @SQLString = 'SET @Antal = (SELECT COUNT(*) FROM ' + @SchemaName + '.' + @TableName + ')';
	EXECUTE sp_executesql @SqlString, N'@Antal INT OUTPUT', @Antal OUTPUT;

	UPDATE @t
		SET AntalForkomster = @Antal, Brugt = 'Y'
		WHERE TableName = @TableName AND SchemaName = @SchemaName;
END
SELECT TableName, SchemaName, AntalForkomster 
	FROM @t
	ORDER BY TableName, SchemaName;
GO
USE Index2DB;
GO
CHECKPOINT;
GO
DBCC SHRINKDATABASE(N'Index2DB');
GO
USE Index3DB;
GO
CHECKPOINT;
GO
DBCC SHRINKDATABASE(N'Index3DB');
GO
USE Index4DB;
GO
CHECKPOINT;
GO
DBCC SHRINKDATABASE(N'Index4DB');
GO
USE Index5DB;
GO
CHECKPOINT;
GO
DBCC SHRINKDATABASE(N'Index5DB');
GO
USE Index6DB;
GO
CHECKPOINT;
GO
DBCC SHRINKDATABASE(N'Index6DB');
GO
USE IndexDB
EXEC sp_spaceused 'Person'
GO
USE Index2DB
EXEC sp_spaceused 'Person'
GO
USE Index3DB
EXEC sp_spaceused 'Person'
GO
USE Index4DB
EXEC sp_spaceused 'Person'
GO
USE Index5DB
EXEC sp_spaceused 'Person'
GO
USE Index6DB
EXEC sp_spaceused 'Person'
GO
