USE master;
GO
DROP DATABASE MangeIndexDB;
GO
CREATE DATABASE MangeIndexDB
ON PRIMARY
	( NAME = MangeIndexDB_file_1,
	  FILENAME = 'C:\Databaser\MangeIndexDB_p.mdf',
      SIZE = 10MB,
      FILEGROWTH = 10%),
	
FILEGROUP MangeIndexDB_group_1
	( NAME = MangeIndexDB_file_2,
	  FILENAME = 'C:\Databaser\MangeIndexDB_1.ndf',
      SIZE = 2000MB,
      FILEGROWTH = 10%),

	( NAME = MangeIndexDB_file_4,
	  FILENAME = 'C:\Databaser\MangeIndexDB_2.ndf',
      SIZE = 2000MB,
      FILEGROWTH = 10%)

LOG ON
	( NAME = MangeIndexDB_log_file_1,
	  FILENAME = 'C:\Databaser\MangeIndexDB_log_1.ldf',
      SIZE = 1000MB,
      FILEGROWTH = 10%);
GO
USE MangeIndexDB;
GO
ALTER DATABASE MangeIndexDB MODIFY FILEGROUP MangeIndexDB_group_1 DEFAULT;
GO
DECLARE @i				INT = 1;
DECLARE @AntalKolonner	INT = 999;
DECLARE @AntalInsert	INT = 14;

DECLARE @Create			VARCHAR(MAX) = 'CREATE TABLE dbo.t (ID INT NOT NULL PRIMARY KEY IDENTITY';
DECLARE @KolonneListe	VARCHAR(MAX) = '';
DECLARE @ValueListe		VARCHAR(MAX) = '';
DECLARE @Insert			VARCHAR(MAX) = 'INSERT INTO dbo.t';
DECLARE @Insert_Select	VARCHAR(MAX) = 'INSERT INTO dbo.t';
DECLARE @Index			VARCHAR(MAX) = '';

WHILE @i <= @AntalKolonner
BEGIN
	SET @Create			+=	CONCAT(', k', @i, ' INT');

	SET @KolonneListe	+=	CONCAT('k',  @i, ',');
	SET @ValueListe		+=	CONCAT('''', @i, ''',');
	
	SET @Index			+=	CONCAT('CREATE INDEX IX_k', @i, ' ON dbo.t (k', @i, ');') ;
	
	SET @i += 1;
END;

SET @Create		+=	')';

SET @Insert		+=	CONCAT('(', LEFT(@KolonneListe, LEN(@KolonneListe) - 1), ') VALUES(', LEFT(@ValueListe, LEN(@ValueListe) - 1), ')');
SET @Insert_Select += CONCAT('(', LEFT(@KolonneListe, LEN(@KolonneListe) - 1), ')', 
							 'SELECT ', LEFT(@KolonneListe, LEN(@KolonneListe) - 1), ' FROM dbo.t;');

EXEC (@Create);

SET NOCOUNT ON;
EXEC (@Insert);

SET @i = 1;

WHILE @i <= @AntalInsert
BEGIN
	PRINT @i;

	EXEC (@Insert_Select);
	SET @i += 1;
END;

SET NOCOUNT OFF;
EXEC (@Index);
GO
SELECT *
	FROM dbo.t
GO
SELECT	stats.object_id, 
        stats.name, 
        statsprop.rows, 
        statsprop.modification_counter,
		statsprop.last_updated,
		statsprop.rows_sampled
	FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
	WHERE stats.object_id =  OBJECT_ID(N'dbo.t'); 
GO
UPDATE dbo.t
	SET k11 = k11 * DATEPART(MS, SYSDATETIME()),
		K7 = DATEPART(NS, SYSDATETIME());

UPDATE dbo.t
	SET k11 = k11 % 50,
		K7 = (k7 - ID) % 23
		WHERE ID < (SELECT MAX(ID) / 2 FROM dbo.t);

UPDATE dbo.t
	SET k11 = (k11 + ID) % 37,
		K7 = k7 % 19
		WHERE ID > (SELECT MAX(ID) / 3 FROM dbo.t);
GO
SELECT	stats.object_id, 
        stats.name, 
        statsprop.rows, 
        statsprop.modification_counter,
		statsprop.last_updated,
		statsprop.rows_sampled
	FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
	WHERE stats.object_id =  OBJECT_ID(N'dbo.t'); 
GO
SELECT k3, k22
	FROM dbo.t
	WHERE	k3 BETWEEN 1 AND 34 AND
			k22 BETWEEN 2 AND 14;
GO
SELECT	stats.object_id, 
        stats.name, 
        statsprop.rows, 
        statsprop.modification_counter,
		statsprop.last_updated,
		statsprop.rows_sampled
	FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
	WHERE stats.object_id =  OBJECT_ID(N'dbo.t'); 
GO
SELECT	ID,
		k7
	FROM dbo.t
	WHERE	k7 IN (3, 5, 9);

SELECT	ID,
		k11
	FROM dbo.t
	WHERE k11 IN (2, 3, 7, 11);
GO
SELECT	stats.object_id, 
        stats.name, 
        statsprop.rows, 
        statsprop.modification_counter,
		statsprop.last_updated,
		statsprop.rows_sampled
	FROM sys.stats CROSS APPLY sys.dm_db_stats_properties(stats.object_id, stats.stats_id) AS statsprop 
	WHERE stats.object_id =  OBJECT_ID(N'dbo.t'); 
GO
