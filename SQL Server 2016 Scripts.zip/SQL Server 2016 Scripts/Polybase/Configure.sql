EXEC sp_configure 'hadoop connectivity', 5;

RECONFIGURE;
