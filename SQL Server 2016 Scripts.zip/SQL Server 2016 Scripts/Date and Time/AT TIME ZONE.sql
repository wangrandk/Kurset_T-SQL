WITH PeopleAndTZs AS
(
  SELECT * 
	FROM (VALUES 
				('Rob',   'Cen. Australia Standard Time'),
				('Paul',  'New Zealand Standard Time'),
				('Aaron', 'US Eastern Standard Time'),
				('Knud', 'Central Europe Standard Time')	
		) Data (Person, tz)
)
SELECT PeopleAndTZs.Person, SYSDATETIMEOFFSET() AT TIME ZONE PeopleAndTZs.tz
	FROM PeopleAndTZs;
 GO
 SELECT CONVERT(DATETIME,'20160101 00:00') 
		AT TIME ZONE 'Cen. Australia Standard Time' 
		AT TIME ZONE 'US Eastern Standard Time';
GO
SELECT *
	FROM sys.time_zone_info;
