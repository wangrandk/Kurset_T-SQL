USE master;
GO
DROP DATABASE IF EXISTS TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
USE TemporalDB;
GO
CREATE TABLE dbo.Person
(
	Personid		INT NOT NULL IDENTITY PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL,
	Navn			AS Fornavn + ' ' + Efternavn,
	Bruger			AS SUSER_SNAME(),
    SysStartTime	DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL, 
    SysEndTime		DATETIME2 GENERATED ALWAYS AS ROW END NOT NULL,   
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.PersonHistorik));
GO
INSERT INTO dbo.Person (Fornavn, Efternavn, Adresse, Postnr) VALUES
	('Jesper', 'Knudsen', 'Vestergade 13', 2000),
	('Hanne', 'Poulsen', '�stergade 4', 3000),
	('Ane', 'Hansen', 'Torvet 45', 4000),
	('�ge', 'Jensen', 'Nygade 12', 2000),
	('Peter', 'Andersen', 'Nygade 6', 4000),
	('Maren', 'Pedersen', 'S�ndergade 18', 5000);
GO
UPDATE dbo.Person
	SET Adresse = 'Hovedgaden 22', Postnr = 3000
	WHERE Personid = 1;
GO

CREATE USER AktuelUser WITHOUT LOGIN;
CREATE USER HistoriskUser WITHOUT LOGIN;
GO
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Person TO AktuelUser;
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Person TO HistoriskUser;
GO
EXECUTE AS USER = 'AktuelUser';

UPDATE dbo.Person 
	SET Fornavn = 'Ane Louise'
	WHERE Personid = 3;

REVERT;
GO
EXECUTE AS USER = 'HistoriskUser';

UPDATE dbo.Person 
	SET Efternavn = 'Olsen', Adresse = 'Store Torv 5', Postnr = 4000
	WHERE Personid = 6;

REVERT;
GO
SELECT *
	FROM dbo.Person FOR SYSTEM_TIME ALL;

SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistorik;
GO
