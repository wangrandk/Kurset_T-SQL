USE master;
GO
DROP DATABASE IF EXISTS TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
USE TemporalDB;
GO
CREATE TABLE dbo.Postopl
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY,
	Bynavn			VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Person
(
	Personid		INT NOT NULL PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL REFERENCES dbo.Postopl(Postnr),
    SysStartTime	DATETIME2(0) GENERATED ALWAYS AS ROW START NOT NULL, 
    SysEndTime		DATETIME2(0) GENERATED ALWAYS AS ROW END NOT NULL,   
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.PersonHistorik));
GO
INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(3000, 'Helsing�r'),
	(4000, 'Roskilde');

INSERT INTO dbo.Person (Personid, Fornavn, Efternavn, Adresse, Postnr) VALUES
	(1, 'Jesper', 'Knudsen', 'Vestergade 13', 2000),
	(2, 'Hanne', 'Poulsen', '�stergade 4', 3000),
	(3, 'Ane', 'Hansen', 'Torvet 45', 4000);
GO
SELECT *
	FROM dbo.Person FOR SYSTEM_TIME ALL
	WHERE Personid = 1;
GO
UPDATE dbo.Person 
	SET Postnr = 9000
	WHERE Personid = 1;
GO 
SELECT *
	FROM dbo.Person FOR SYSTEM_TIME ALL
	WHERE Personid = 1;
GO
SELECT COUNT(*)
	FROM dbo.Person FOR SYSTEM_TIME ALL
	WHERE Personid = 3;
GO
UPDATE dbo.Person 
	SET Fornavn = Fornavn, Adresse = Adresse
	WHERE Personid = 3;

--WAITFOR DELAY '0:0:0.23';
GO 500
SELECT *
	FROM dbo.PersonHistorik;

SELECT COUNT(*)
	FROM dbo.Person FOR SYSTEM_TIME ALL
	WHERE Personid = 3;
GO
BEGIN TRANSACTION;
SELECT COUNT(*)
	FROM dbo.Person FOR SYSTEM_TIME ALL
	WHERE Personid = 2;

UPDATE dbo.Person 
	SET Fornavn = 'Hanne Sofie'
	WHERE Personid = 2;

UPDATE dbo.Person 
	SET Efternavn= 'Jensen'
	WHERE Personid = 2;

UPDATE dbo.Person 
	SET Adresse = 'Sankt Peders Gade 52'
	WHERE Personid = 2;

UPDATE dbo.Person 
	SET Postnr = 4000
	WHERE Personid = 2;

SELECT COUNT(*)
	FROM dbo.Person FOR SYSTEM_TIME ALL
	WHERE Personid = 2;

--ROLLBACK TRANSACTION;
COMMIT TRANSACTION;

SELECT COUNT(*)
	FROM dbo.Person FOR SYSTEM_TIME ALL
	WHERE Personid = 2;
GO
SELECT *
	FROM dbo.Person FOR SYSTEM_TIME ALL
	WHERE Personid = 2;
GO
CREATE TABLE dbo.Person1
(
	Personid		INT NOT NULL IDENTITY PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
    SysStartTime	DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL, 
    SysEndTime		DATETIME2 GENERATED ALWAYS AS ROW END NOT NULL,   
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.Person1Histrik));
GO
CREATE TABLE dbo.Person2
(
	Personid		INT NOT NULL IDENTITY PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
    SysStartTime	DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL, 
    SysEndTime		DATETIME2 GENERATED ALWAYS AS ROW END NOT NULL,   
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.Person2Historik));
GO
INSERT INTO dbo.Person1 (Fornavn, Efternavn) 
	VALUES ('Ole', 'Larsen');

INSERT INTO dbo.Person2 (Fornavn, Efternavn) 
	VALUES ('Ida', 'Petersen');
GO
SELECT *
	FROM dbo.Person1 FOR SYSTEM_TIME ALL;

SELECT *
	FROM dbo.Person2 FOR SYSTEM_TIME ALL;
GO
SELECT SYSUTCDATETIME();

BEGIN TRANSACTION;

SELECT SYSUTCDATETIME();

UPDATE dbo.Person1
	SET Fornavn = 'Ole Johannes'
	WHERE Personid = 1;

WAITFOR DELAY '0:00:30'; 

UPDATE dbo.Person2
	SET Fornavn = 'Ida Marie'
	WHERE Personid = 1;

WAITFOR DELAY '0:02:40'; 

INSERT INTO dbo.Person1 (Fornavn, Efternavn) 
	VALUES ('Karl', 'Christensen');

WAITFOR DELAY '0:01:00'; 

INSERT INTO dbo.Person2 (Fornavn, Efternavn) 
	VALUES ('Maren', 'Carlsen');

SELECT SYSUTCDATETIME();

COMMIT TRANSACTION;

SELECT SYSUTCDATETIME();
GO
SELECT *
	FROM dbo.Person1 FOR SYSTEM_TIME ALL;

SELECT *
	FROM dbo.Person2 FOR SYSTEM_TIME ALL;
GO
CREATE TABLE dbo.Person3
(
	Personid		INT NOT NULL PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
    SysStartTime	DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL, 
    SysEndTime		DATETIME2 GENERATED ALWAYS AS ROW END NOT NULL,   
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.Person3Historik));
GO
CREATE TABLE dbo.Tider
(
	Id				INT NOT NULL IDENTITY,
	Tid				DATETIME2 NOT NULL,
	Opereation		VARCHAR(50) NOT NULL
);
GO
INSERT INTO dbo.Tider VALUES
	 (SYSUTCDATETIME(), 'F�r transaktion');

BEGIN TRANSACTION;

WAITFOR DELAY '0:0:20';
INSERT INTO dbo.Tider VALUES
	 (SYSUTCDATETIME(), 'F�r INSERT');

INSERT INTO dbo.Person3 (PersonId, Fornavn, Efternavn) VALUES 
	(1, 'Carl', 'Kristensen'),
	(2, 'Vera', 'Olsen');

INSERT INTO dbo.Tider VALUES
	 (SYSUTCDATETIME(), 'Efter INSERT');
WAITFOR DELAY '0:00:30'; 

UPDATE dbo.Person3
	SET Fornavn = 'Carl Emil'
	WHERE PersonId = 1;

INSERT INTO dbo.Tider VALUES
	 (SYSUTCDATETIME(), 'Efter UPDATE');
WAITFOR DELAY '0:00:15'; 

DELETE 
	FROM dbo.Person3
	WHERE PersonId = 2;
	 
INSERT INTO dbo.Tider VALUES
	 (SYSUTCDATETIME(), 'Efter DELETE');
WAITFOR DELAY '0:0:40'; 

COMMIT TRANSACTION;
INSERT INTO dbo.Tider VALUES
	 (SYSUTCDATETIME(), 'Efter Transaktion');

SELECT *
	FROM dbo.Person3 FOR SYSTEM_TIME ALL;

SELECT *
	FROM dbo.Person3Historik;

SELECT *
	FROM dbo.Tider;
