USE master;
GO
DROP DATABASE TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
USE TemporalDB;
CREATE TABLE dbo.Vare
(
	VareId			INT NOT NULL PRIMARY KEY,
	Varenavn		VARCHAR(40) NOT NULL,
	EnhedsPris		DECIMAL(11,2) NOT NULL DEFAULT (0),
	TransaktionsId	INT NOT NULL,
    SysStartTime	DATETIME2(0) GENERATED ALWAYS AS ROW START NOT NULL, 
    SysEndTime		DATETIME2(0) GENERATED ALWAYS AS ROW END NOT NULL,
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (History_Table = dbo.VareHistory));

CREATE TABLE dbo.Tider
(
	TransaktionsId	INT NOT NULL PRIMARY KEY,
	Tid				DATETIME2(0) DEFAULT(SYSUTCDATETIME())
);
GO
INSERT INTO dbo.Tider (TransaktionsId) VALUES (1);

WAITFOR DELAY '0:0:04';
GO
INSERT INTO dbo.Vare (VareId, Varenavn, EnhedsPris, TransaktionsId) VALUES
	(1, 'Jordb�r Belgiske', 30.00, 1),
	(2, 'Nye Danske Kartofler', 12.00, 1),
	(3, 'For�rsl�g', 10.00, 1),
	(4, 'Guler�dder', 15.00, 1);
GO
WAITFOR DELAY '0:0:01';
INSERT INTO dbo.Tider (TransaktionsId) VALUES (2);
WAITFOR DELAY '0:0:03';

UPDATE dbo.Vare	
	SET EnhedsPris = 35.00, Varenavn = 'Jordb�r Danske', TransaktionsId = 2
	WHERE VareId = 1;

WAITFOR DELAY '0:0:01';
INSERT INTO dbo.Tider (TransaktionsId) VALUES (3);
WAITFOR DELAY '0:0:03';

UPDATE dbo.Vare	
	SET EnhedsPris = 12.00, TransaktionsId = 3
	WHERE VareId = 4;

WAITFOR DELAY '0:0:05';
INSERT INTO dbo.Tider (TransaktionsId) VALUES (4);
WAITFOR DELAY '0:0:01';

UPDATE dbo.Vare	
	SET EnhedsPris = 10.00, Varenavn = 'Danske Kartofler', TransaktionsId = 4
	WHERE VareId = 2;

WAITFOR DELAY '0:0:01';
INSERT INTO dbo.Tider (TransaktionsId) VALUES (5);
WAITFOR DELAY '0:0:03';

UPDATE dbo.Vare	
	SET EnhedsPris = 17.00, Varenavn = 'Jordb�r', TransaktionsId = 5
	WHERE VareId = 1;

WAITFOR DELAY '0:0:01';
INSERT INTO dbo.Tider (TransaktionsId) VALUES (6);
WAITFOR DELAY '0:0:04';

UPDATE dbo.Vare	
	SET EnhedsPris = 15.00, TransaktionsId = 6
	WHERE VareId = 1;

WAITFOR DELAY '0:0:01';
INSERT INTO dbo.Tider (TransaktionsId) VALUES (7);
WAITFOR DELAY '0:0:04';

UPDATE dbo.Vare	
	SET EnhedsPris = 16.00, TransaktionsId = 7
	WHERE VareId = 1;

WAITFOR DELAY '0:0:01';
INSERT INTO dbo.Tider (TransaktionsId) VALUES (8);
WAITFOR DELAY '0:0:02';

DELETE
	FROM dbo.Vare	
	WHERE VareId = 3;
GO
SELECT *
	FROM dbo.Vare
	ORDER BY VareId, TransaktionsId;

SELECT *
	FROM dbo.VareHistory
	ORDER BY VareId, TransaktionsId;

SELECT *
	FROM dbo.Tider;
GO
---------------------------------------------------------------------------------
-- Returns a table with single record for each row containing the values 
-- that were actual (current) at the specified point in time

DECLARE @Tid		DATETIME2 = (SELECT Tid 
									FROM dbo.Tider 
									WHERE TransaktionsId = 1);

SELECT @Tid;

SELECT	VareId,
		Varenavn, 
		EnhedsPris,
		TransaktionsId,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare	FOR SYSTEM_TIME AS OF @Tid
	ORDER BY VareId;
GO
DECLARE @Tid		DATETIME2 = (SELECT Tid 
									FROM dbo.Tider 
									WHERE TransaktionsId = 4);

SELECT @Tid;

SELECT	VareId,
		Varenavn, 
		EnhedsPris,
		TransaktionsId,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare	FOR SYSTEM_TIME AS OF @Tid
	ORDER BY VareId;
GO
------------------------------------------------------------------------------------------
-- Returns a table with the values for all record versions that were active 
-- within the specified time range, regardless of whether they started being active 
-- before the <start_date_time> parameter value for the FROM argument or ceased being active 
-- after the <end_date_time> parameter value

DECLARE @Tid1		DATETIME2 = (SELECT Tid 
									FROM dbo.Tider 
									WHERE TransaktionsId = 2);
DECLARE @Tid2		DATETIME2 = (SELECT Tid 
									FROM dbo.Tider 
									WHERE TransaktionsId = 5);

SELECT @Tid1, @Tid2;

SELECT	VareId,
		Varenavn, 
		EnhedsPris,
		TransaktionsId,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare FOR SYSTEM_TIME FROM @Tid1 TO @Tid2
	ORDER BY VareId, TransaktionsId;

SELECT	VareId
	FROM dbo.Vare FOR SYSTEM_TIME FROM @Tid1 TO @Tid2
	GROUP BY VareId
	HAVING COUNT(*) > 1
	ORDER BY VareId;
GO
---------------------------------------------------------------------------------------------
-- Same as above in the FOR SYSTEM_TIME FROM <start_date_time>TO <end_date_time> description, 
-- except the table of rows returned includes rows that became active on the upper boundary 
-- defined by the <end_date_time> endpoint.

DECLARE @Tid1		DATETIME2 = (SELECT Tid 
									FROM dbo.Tider 
									WHERE TransaktionsId = 2);
DECLARE @Tid2		DATETIME2 = (SELECT Tid 
									FROM dbo.Tider 
									WHERE TransaktionsId = 5);

SELECT @Tid1, @Tid2;

SELECT	VareId,
		Varenavn, 
		EnhedsPris,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare FOR SYSTEM_TIME BETWEEN @Tid1 AND @Tid2
	ORDER BY VareId;

SELECT	VareId
	FROM dbo.Vare FOR SYSTEM_TIME BETWEEN @Tid1 AND @Tid2
	GROUP BY VareId
	HAVING COUNT(*) > 1
	ORDER BY VareId;
GO
-- Forskel p� FROM ...TO og BETWEEN ... AND
SELECT	VareId,
		Varenavn, 
		EnhedsPris,
		TransaktionsId,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare FOR SYSTEM_TIME ALL
	WHERE Vareid = 1;
GO
DECLARE @Tid1		DATETIME2 = (SELECT SysStartTime 
									FROM dbo.VareHistory 
									WHERE VareId = 1 AND TransaktionsId = 2);
DECLARE @Tid2		DATETIME2 = (SELECT SysStartTime 
									FROM dbo.VareHistory 
									WHERE VareId = 1 AND TransaktionsId = 5);

SELECT @Tid1, @Tid2;

SELECT	VareId,
		Varenavn, 
		EnhedsPris,
		TransaktionsId,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare FOR SYSTEM_TIME FROM @Tid1 TO @Tid2
	WHERE VareId = 1
	ORDER BY VareId;

SELECT	VareId,
		Varenavn, 
		EnhedsPris,
		TransaktionsId,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare FOR SYSTEM_TIME BETWEEN @Tid1 AND @Tid2
	WHERE VareId = 1
	ORDER BY VareId;

GO
--------------------------------------------------------------------------------------------
-- Returns a table with the values for all record versions that were opened
-- and closed within the specified time range defined by the two datetime values

-- SysStartTime og SysEndTime, derfor medtages b�de TransaktionsId = 2 og TransaktionsId = 5
DECLARE @Tid1		DATETIME2 = (SELECT SysStartTime 
									FROM dbo.VareHistory 
									WHERE VareId = 1 AND TransaktionsId = 2);
DECLARE @Tid2		DATETIME2 = (SELECT SysEndTime 
									FROM dbo.VareHistory 
									WHERE VareId = 1 AND TransaktionsId = 5);

SELECT @Tid1, @Tid2;

SELECT	VareId,
		Varenavn, 
		EnhedsPris,
		TransaktionsId,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare FOR SYSTEM_TIME CONTAINED IN (@Tid1, @Tid2)
	WHERE VareId = 1
	ORDER BY VareId;
GO
-- SysStartTime for begge tider, derfor medtages kun TransaktionsId = 2

DECLARE @Tid1		DATETIME2 = (SELECT SysStartTime 
									FROM dbo.VareHistory 
									WHERE VareId = 1 AND TransaktionsId = 2);
DECLARE @Tid2		DATETIME2 = (SELECT SysStartTime 
									FROM dbo.VareHistory 
									WHERE VareId = 1 AND TransaktionsId = 5);

SELECT @Tid1, @Tid2;

SELECT	VareId,
		Varenavn, 
		EnhedsPris,
		TransaktionsId,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare FOR SYSTEM_TIME CONTAINED IN (@Tid1, @Tid2)
	WHERE VareId = 1
	ORDER BY VareId;

-- SysEndTime for begge tider, derfor medtages kun TransaktionsId = 5

DECLARE @Tid1		DATETIME2 = (SELECT SysEndTime 
									FROM dbo.VareHistory 
									WHERE VareId = 1 AND TransaktionsId = 2);
DECLARE @Tid2		DATETIME2 = (SELECT SysEndTime 
									FROM dbo.VareHistory 
									WHERE VareId = 1 AND TransaktionsId = 5);

SELECT @Tid1, @Tid2;

SELECT	VareId,
		Varenavn, 
		EnhedsPris,
		TransaktionsId,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare FOR SYSTEM_TIME CONTAINED IN (@Tid1, @Tid2)
	WHERE VareId = 1
	ORDER BY VareId;

---------------------------------------------------------------------------------
-- Returns the union of rows that belong to the current and the history table.

SELECT	VareId,
		Varenavn, 
		EnhedsPris,
		TransaktionsId,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare FOR SYSTEM_TIME ALL
	ORDER BY VareId, TransaktionsId;

SELECT	VareId,
		Varenavn, 
		EnhedsPris,
		TransaktionsId,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare FOR SYSTEM_TIME ALL
	WHERE VareId = 1
	ORDER BY VareId, TransaktionsId;
GO
-- Update/Merge
UPDATE dbo.VareHistory			-- Ikke tilladt
	SET Enhedspris = 112.00
	WHERE	VareId = 1 AND
			TransaktionsId = 5;

MERGE dbo.Vare AS Target
USING (SELECT *
			FROM (VALUES 
					(2, 'Kartofler', 14.00, 9),
					(1, 'Jordb�r', 12.00, 9),
					(5, 'L�g', 6.00, 9)) AS Varetransaktion(VareId, 
															Varenavn, 
															Enhedspris, 
															TransaktionsId)) AS Source
		ON Target.Vareid = Source.VareId
	WHEN MATCHED THEN
		UPDATE SET	Varenavn = Source.varenavn,
					Enhedspris = Source.Enhedspris,
					TransaktionsId = Source.TransaktionsId
	WHEN NOT MATCHED THEN
		INSERT (VareId, Varenavn, Enhedspris, TransaktionsId) VALUES
			(Source.VareId, Source.Varenavn, Source.Enhedspris, Source.TransaktionsId);
GO
SELECT *
	FROM dbo.Vare;

SELECT *
	FROM dbo.VareHistory;

-- Implementer med Alter
USE master;
GO
DROP DATABASE TemporalDB2;
GO
CREATE DATABASE TemporalDB2;
GO
USE TemporalDB2;
CREATE TABLE dbo.Vare
(
	VareId			INT NOT NULL PRIMARY KEY,
	Varenavn		VARCHAR(40) NOT NULL,
	EnhedsPris		DECIMAL(11,2) NOT NULL DEFAULT (0),
    SysStartTime	DATETIME2(0) NOT NULL, 
    SysEndTime		DATETIME2(0) NOT NULL
);

CREATE TABLE dbo.VareHistory
(
	VareId			INT NOT NULL,
	Varenavn		VARCHAR(40) NOT NULL,
	EnhedsPris		DECIMAL(11,2) NOT NULL,
    SysStartTime	DATETIME2(0) NOT NULL, 
    SysEndTime		DATETIME2(0) NOT NULL
);

CREATE TABLE dbo.Ordrelinie
(
	OrdreId			INT NOT NULL,
	VareId			INT NOT NULL,
	AntalEnheder	INT NOT NULL CHECK(AntalEnheder > 0),
	Bestillingsdato	DATETIME2(0) NOT NULL DEFAULT(SYSDATETIME()),
	Leveringsdato	DATE NOT NULL DEFAULT(SYSDATETIME()),
	CONSTRAINT PK_Ordrelinie PRIMARY KEY (OrdreId, VareId),
);
GO
INSERT INTO dbo.VareHistory (VareId, Varenavn, EnhedsPris, SysStartTime, SysEndTime) VALUES
	(1, 'Jordb�r', 25.00, '2016-05-11', '2016-05-12'),
	(1, 'Jordb�r Danske', 20.00, '2016-05-12', '2016-05-13'), 
	(1, 'Jordb�r Danske', 22.00, '2016-05-13', '2016-05-14'), 
	(1, 'Jordb�r Belgiske', 30.00, '2016-05-14', '2016-05-15'),
	
	(2, 'Nye Danske Kartofler', 15.00, '2016-05-11', '2016-05-14'), 
	(2, 'Nye Danske Kartofler', 13.00, '2016-05-14', '2016-05-15');

INSERT INTO dbo.Vare (VareId, Varenavn, EnhedsPris, SysStartTime, SysEndTime) VALUES
	(1, 'Jordb�r Belgiske', 30.00, '2016-05-15', '9999-12-31 23:59:59.9999999'),
	(2, 'Nye Danske Kartofler', 12.00, '2016-05-15', '9999-12-31 23:59:59.9999999');
GO
ALTER TABLE dbo.Vare
	ADD PERIOD FOR SYSTEM_TIME (SysStartTime, SysEndTime);
ALTER TABLE dbo.Vare
    SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE=dbo.VareHistory, DATA_CONSISTENCY_CHECK = ON));
GO
UPDATE dbo.Vare	
	SET EnhedsPris = 35
	WHERE VareId = 1;
GO
INSERT INTO dbo.Ordrelinie (OrdreId, VareId, AntalEnheder, Bestillingsdato, Leveringsdato) VALUES
	(100, 1, 2, '2016-05-12', '2016-05-12'),
 	(100, 2, 5, '2016-05-12', '2016-05-12'),
	(101, 1, 3, '2016-05-14', '2016-05-14'),
 	(102, 2, 2, '2016-05-15', '2016-05-15'),
	(103, 1, 20, '2016-05-12', '2016-05-30'),
 	(103, 2, 50, '2016-05-21', '2016-05-30');
GO
SELECT *
	FROM dbo.Vare;

SELECT *
	FROM dbo.VareHistory;

SELECT *
	FROM dbo.Ordrelinie;
GO
SELECT *										-- Fejler tiden skal v�re en konstant eller variabel
	FROM dbo.Ordrelinie CROSS APPLY (SELECT *
										FROM dbo.Vare
										FOR SYSTEM_TIME AS OF Ordrelinie.Bestillingsdato
										WHERE Vare.VareId = Ordrelinie.VareId)
	WHERE Ordrelinie.OrdreId = 100;
GO
CREATE FUNCTION dbo.ufn_vare 
(
@Dato		DATETIME2,
@VareId		INT
)
RETURNS TABLE
RETURN (SELECT *
			FROM dbo.Vare FOR SYSTEM_TIME AS OF @Dato
			WHERE Vare.VareId = @VareId)
GO
SELECT	Ordrelinie.VareId,
		Ordrelinie.Bestillingsdato,
		Ordrelinie.AntalEnheder,
		Vare.Varenavn,
		Vare.Enhedspris,
		Vare.SysStartTime,
		Vare.SysEndTime								
	FROM dbo.Ordrelinie CROSS APPLY 
		dbo.ufn_vare  (Ordrelinie.Bestillingsdato, Ordrelinie.VareId) AS Vare
	WHERE Ordrelinie.OrdreId = 100;

SELECT	Ordrelinie.VareId,
		Ordrelinie.Bestillingsdato,
		Ordrelinie.AntalEnheder,
		Vare.Varenavn,
		Vare.Enhedspris,
		Vare.SysStartTime,
		Vare.SysEndTime								
	FROM dbo.Ordrelinie CROSS APPLY 
		dbo.ufn_vare  (Ordrelinie.Bestillingsdato, Ordrelinie.VareId) AS Vare
	WHERE Ordrelinie.OrdreId = 101;

SELECT	Ordrelinie.VareId,
		Ordrelinie.Bestillingsdato,
		Ordrelinie.AntalEnheder,
		Vare.Varenavn,
		Vare.Enhedspris,
		Vare.SysStartTime,
		Vare.SysEndTime								
	FROM dbo.Ordrelinie CROSS APPLY 
		dbo.ufn_vare  (Ordrelinie.Bestillingsdato, Ordrelinie.VareId) AS Vare
	WHERE Ordrelinie.OrdreId = 102;

SELECT	Ordrelinie.VareId,
		Ordrelinie.Bestillingsdato,
		Ordrelinie.AntalEnheder,
		Vare.Varenavn,
		Vare.Enhedspris,
		Vare.SysStartTime,
		Vare.SysEndTime								
	FROM dbo.Ordrelinie CROSS APPLY 
		dbo.ufn_vare  (Ordrelinie.Bestillingsdato, Ordrelinie.VareId) AS Vare	
	WHERE Ordrelinie.OrdreId = 103;
GO
SELECT *									
	FROM dbo.Ordrelinie CROSS APPLY dbo.ufn_vare  (Ordrelinie.Bestillingsdato, Ordrelinie.VareId)
	WHERE Ordrelinie.OrdreId = 103;

SELECT *									
	FROM dbo.Ordrelinie CROSS APPLY dbo.ufn_vare  (Ordrelinie.Leveringsdato, Ordrelinie.VareId)
	WHERE Ordrelinie.OrdreId = 103;
GO
-- DATA_CONSISTENCY_CHECK = OFF
USE master;
GO
DROP DATABASE TemporalDB3;
GO
CREATE DATABASE TemporalDB3;
GO
USE TemporalDB3;
CREATE TABLE dbo.Vare
(
	VareId			INT NOT NULL PRIMARY KEY,
	Varenavn		VARCHAR(40) NOT NULL,
	EnhedsPris		DECIMAL(11,2) NOT NULL DEFAULT (0),
    SysStartTime	DATETIME2 NOT NULL, 
    SysEndTime		DATETIME2 NOT NULL
);

CREATE TABLE dbo.VareHistory
(
	VareId			INT NOT NULL,
	Varenavn		VARCHAR(40) NOT NULL,
	EnhedsPris		DECIMAL(11,2) NOT NULL,
    SysStartTime	DATETIME2 NOT NULL, 
    SysEndTime		DATETIME2 NOT NULL
);

CREATE TABLE dbo.Ordrelinie
(
	OrdreId			INT NOT NULL,
	VareId			INT NOT NULL,
	AntalEnheder	INT NOT NULL CHECK(AntalEnheder > 0),
	Bestillingsdato	DATETIME2 NOT NULL DEFAULT(SYSDATETIME()),
	Leveringsdato	DATE NOT NULL DEFAULT(SYSDATETIME()),
	CONSTRAINT PK_Ordrelinie PRIMARY KEY (OrdreId, VareId),
);
GO
INSERT INTO dbo.VareHistory (VareId, Varenavn, EnhedsPris, SysStartTime, SysEndTime) VALUES
	(1, 'Jordb�r', 25.00, '2016-05-11', '2016-05-12'),
--	(1, 'Jordb�r Danske', 20.00, '2016-05-12', '2016-05-13'),	-- fejl
	(1, 'Jordb�r Danske', 22.00, '2016-05-13', '2016-05-19'),	-- fejl
	(1, 'Jordb�r Belgiske', 30.00, '2016-05-14', '2016-05-15'),
	
	(2, 'Nye Danske Kartofler', 15.00, '2016-05-11', '2016-05-14'), 
	(2, 'Nye Danske Kartofler', 13.00, '2016-05-14', '2016-05-15');

INSERT INTO dbo.Vare (VareId, Varenavn, EnhedsPris, SysStartTime, SysEndTime) VALUES
	(1, 'Jordb�r Belgiske', 30.00, '2016-05-15', '9999-12-31 23:59:59.9999999'),
	(2, 'Nye Danske Kartofler', 12.00, '2016-05-15', '9999-12-31 23:59:59.9999999');
GO
ALTER TABLE dbo.Vare
	ADD PERIOD FOR SYSTEM_TIME (SysStartTime, SysEndTime);
ALTER TABLE dbo.Vare
    SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE=dbo.VareHistory, DATA_CONSISTENCY_CHECK = OFF));
GO
DECLARE @Dato		DATETIME2 = '2016-07-12 11:27';
DECLARE @VareId		INT = 1;

SELECT *				-- Data mangler for p�g�ldende tidspunkt
	FROM dbo.Vare FOR SYSTEM_TIME AS OF @Dato
	WHERE Vare.VareId = @VareId;
