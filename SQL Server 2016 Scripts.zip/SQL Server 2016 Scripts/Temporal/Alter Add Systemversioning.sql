USE master;
GO
DROP DATABASE TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
USE TemporalDB;
CREATE TABLE dbo.Postopl
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY,
	Bynavn			VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Person
(
	ID				INT NOT NULL IDENTITY PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL REFERENCES dbo.Postopl(Postnr)
);
GO
INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(3000, 'Helsing�r'),
	(4000, 'Roskilde'),
	(5000, 'Odense C'),
	(6000, 'Kolding');

INSERT INTO dbo.Person (Navn, Adresse, Postnr) VALUES
	('Jesper Knudsen', 'Vestergade 13', 2000),
	('Hanne Poulsen', '�stergade 4', 3000),
	('Ane Hansen', 'Torvet 45', 4000),
	('�ge Jensen', 'Nygade 12', 2000),
	('Peter Andersen', 'Nygade 6', 4000),
	('Maren Pedersen', 'S�ndergade 18', 5000);
GO
ALTER TABLE dbo.Person ADD
	SysStartTime		DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL 
						DEFAULT CAST('1900-01-01 0:0:0.0000000' AS DATETIME2),
	SysEndTime				DATETIME2 GENERATED ALWAYS AS ROW END NOT NULL 
						DEFAULT CAST('9999-12-31 23:59:59.9999999' AS DATETIME2),
	PERIOD FOR SYSTEM_TIME (SysStartTime, SysEndTime);
GO
ALTER TABLE dbo.Person 
	SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.PersonHistory))
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistory;
GO
UPDATE dbo.Person
	SET Navn = 'Ane Marie Hansen'
	WHERE ID = 3;

UPDATE dbo.Person
	SET Adresse = 'Vestergade 7', Postnr = 2000
	WHERE ID = 3;

UPDATE dbo.Person
	SET Adresse = 'Storetorv 1', Postnr = 4000
	WHERE ID = 4;
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistory;
GO
DROP TABLE dbo.Person;			-- Fejler, da der er historik defineret
GO
ALTER TABLE dbo.Person
	SET (SYSTEM_VERSIONING = OFF);
GO
DROP TABLE dbo.Person;
GO
