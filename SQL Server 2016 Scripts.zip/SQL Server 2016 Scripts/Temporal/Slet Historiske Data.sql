USE master;
GO
DROP DATABASE IF EXISTS TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
USE TemporalDB;
GO
CREATE TABLE dbo.Postopl
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY,
	Bynavn			VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Person
(
	Personid		INT NOT NULL IDENTITY PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL REFERENCES dbo.Postopl(Postnr),
    SysStartTime	DATETIME2(7) GENERATED ALWAYS AS ROW START NOT NULL, 
    SysEndTime		DATETIME2(7) GENERATED ALWAYS AS ROW END NOT NULL,   
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.PersonHistorik));
GO
INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(3000, 'Helsing�r'),
	(4000, 'Roskilde'),
	(5000, 'Odense C'),
	(6000, 'Kolding');

INSERT INTO dbo.Person (Fornavn, Efternavn, Adresse, Postnr) VALUES
	('Jesper', 'Knudsen', 'Vestergade 13', 2000),
	('Hanne', 'Poulsen', '�stergade 4', 3000),
	('Ane', 'Hansen', 'Torvet 45', 4000);
GO
UPDATE dbo.Person
	SET Adresse = 'Hovedgaden 22', Postnr = 3000
	WHERE Personid = 1;

WAITFOR DELAY '0:0:02';

UPDATE dbo.Person
	SET Adresse = 'Torvet 45 2. mf.', Postnr = 4000
	WHERE Personid = 3;
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistorik;
GO
ALTER TABLE dbo.Person
	SET (SYSTEM_VERSIONING = OFF);
GO
DELETE 
	FROM dbo.PersonHistorik
	WHERE SysEndTime <= (SELECT SysEndTime
							FROM dbo.PersonHistorik
							WHERE PersonId = 1);
GO
ALTER TABLE dbo.Person 
	SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.PersonHistorik,
								 DATA_CONSISTENCY_CHECK = OFF));
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistorik;
