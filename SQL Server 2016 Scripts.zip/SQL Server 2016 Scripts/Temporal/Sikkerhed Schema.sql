USE master;
GO
DROP DATABASE IF EXISTS TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
USE TemporalDB;
GO
CREATE SCHEMA Aktuel;
GO
CREATE SCHEMA Historisk;
GO
CREATE TABLE Aktuel.Person
(
	Personid		INT NOT NULL PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL,
	Status			CHAR(1) NOT NULL DEFAULT ('A'),
    SysStartTime	DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL, 
    SysEndTime		DATETIME2 GENERATED ALWAYS AS ROW END NOT NULL,   
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = Historisk.Person));
GO
INSERT INTO Aktuel.Person (PersonId, Fornavn, Efternavn, Adresse, Postnr) VALUES
	(1, 'Jesper', 'Knudsen', 'Vestergade 13', 2000),
	(2, 'Hanne', 'Poulsen', '�stergade 4', 3000),
	(3, 'Ane', 'Hansen', 'Torvet 45', 4000);
GO
UPDATE Aktuel.Person
	SET Adresse = 'Hovedgaden 22', Postnr = 3000
	WHERE Personid = 1;
GO
SELECT *
	FROM Aktuel.Person;

SELECT *
	FROM Historisk.Person;
GO
CREATE USER AktuelBruger WITHOUT LOGIN;
CREATE USER HistoriskBruger WITHOUT LOGIN;
GO
GRANT SELECT, INSERT, DELETE, UPDATE ON SCHEMA :: Aktuel TO AktuelBruger;
GRANT SELECT, INSERT, DELETE, UPDATE ON SCHEMA :: Aktuel TO HistoriskBruger;
GRANT SELECT, INSERT, DELETE, UPDATE ON SCHEMA :: Historisk TO HistoriskBruger;
GO
EXECUTE AS USER = 'AktuelBruger';

SELECT *
	FROM Aktuel.Person FOR SYSTEM_TIME ALL;

SELECT *
	FROM Aktuel.Person;

REVERT;
GO
EXECUTE AS USER = 'HistoriskBruger';

SELECT *
	FROM Aktuel.Person FOR SYSTEM_TIME ALL;

REVERT;
GO
EXECUTE AS USER = 'AktuelBruger';

UPDATE Aktuel.Person 
	SET Status = 'P'
	WHERE Personid = 3;

DELETE
	FROM Aktuel.Person
	WHERE PersonId = 2;

REVERT;
GO
SELECT *
	FROM Aktuel.Person FOR SYSTEM_TIME ALL
	WHERE Personid = 3;
GO
EXECUTE AS USER = 'HistoriskBruger';

UPDATE Aktuel.Person 
	SET Status = 'P'
	WHERE Personid = 1;

REVERT;
GO
TRUNCATE TABLE Aktuel.Person;			-- Fejler

DELETE
	FROM Aktuel.Person;

SELECT *
	FROM Aktuel.Person;

SELECT *
	FROM Historisk.Person;
