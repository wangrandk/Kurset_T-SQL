USE master;
GO
DROP DATABASE IF EXISTS TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
USE TemporalDB;
GO
CREATE SCHEMA Aktuel;
GO
CREATE SCHEMA Historisk;
GO
CREATE TABLE Aktuel.Postopl
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY,
	Bynavn			VARCHAR(20) NOT NULL
);

CREATE TABLE Aktuel.Person
(
	Personid		INT NOT NULL IDENTITY PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL REFERENCES Aktuel.Postopl(Postnr),
	Navn			AS Fornavn + ' '  + Efternavn,
    SysStartTime	DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL, 
    SysEndTime		DATETIME2 GENERATED ALWAYS AS ROW END NOT NULL,   
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = Historisk.Person));
GO
INSERT INTO Aktuel.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(3000, 'Helsing�r'),
	(4000, 'Roskilde'),
	(5000, 'Odense C'),
	(6000, 'Kolding');

INSERT INTO Aktuel.Person (Fornavn, Efternavn, Adresse, Postnr) VALUES
	('Jesper', 'Knudsen', 'Vestergade 13', 2000),
	('Hanne', 'Poulsen', '�stergade 4', 3000),
	('Ane', 'Hansen', 'Torvet 45', 4000),
	('�ge', 'Jensen', 'Nygade 12', 2000),
	('Peter', 'Andersen', 'Nygade 6', 4000),
	('Maren', 'Pedersen', 'S�ndergade 18', 5000);
GO
UPDATE Aktuel.Person
	SET Adresse = 'Hovedgaden 22', Postnr = 3000
	WHERE Personid = 1;
GO
ALTER TABLE Aktuel.Person 
	ADD Tlfnr VARCHAR(8) NULL;
GO
SELECT *
	FROM Aktuel.Person;

SELECT *
	FROM Historisk.Person;
GO
ALTER TABLE Aktuel.Person 
	ADD Status CHAR(1) NOT NULL DEFAULT('A');
GO
UPDATE Aktuel.Person
	SET Tlfnr = CONCAT(Postnr, Postnr + PersonId);
GO
SELECT *
	FROM Aktuel.Person;

SELECT *
	FROM Historisk.Person;
GO
ALTER TABLE Aktuel.Person 
	ALTER COLUMN Tlfnr CHAR(20) NULL;
GO
UPDATE Aktuel.Person
	SET Tlfnr = CONCAT('+45 ', Tlfnr);

UPDATE Aktuel.Person
	SET Fornavn = 'Hanne Lise'
	WHERE Personid = 2;
GO
SELECT *
	FROM Aktuel.Person;

SELECT *
	FROM Historisk.Person;
GO
ALTER TABLE Aktuel.Person
	DROP COLUMN Tlfnr;
GO
SELECT *
	FROM Aktuel.Person;

SELECT *
	FROM Historisk.Person;
GO
CREATE USER AktuelUser WITHOUT LOGIN;
CREATE USER HistoriskUser WITHOUT LOGIN;
GO
GRANT SELECT, INSERT, DELETE, UPDATE ON Aktuel.Person TO AktuelUser;
GRANT SELECT, INSERT, DELETE, UPDATE ON Aktuel.Person TO HistoriskUser;
GRANT SELECT, INSERT, DELETE, UPDATE ON Historisk.Person TO HistoriskUser;
GO
EXECUTE AS USER = 'AktuelUser';

SELECT *
	FROM Aktuel.Person FOR SYSTEM_TIME ALL;

REVERT;
GO
EXECUTE AS USER = 'HistoriskUser';

SELECT *
	FROM Aktuel.Person FOR SYSTEM_TIME ALL;

REVERT;
GO
EXECUTE AS USER = 'AktuelUser';

UPDATE Aktuel.Person 
	SET Status = 'P'
	WHERE Personid = 5;

REVERT;
GO
EXECUTE AS USER = 'HistoriskUser';

UPDATE Aktuel.Person 
	SET Status = 'P'
	WHERE Personid = 6;

REVERT;
GO
SELECT *
	FROM Aktuel.Person FOR SYSTEM_TIME ALL
	WHERE Personid = 5;

SELECT *
	FROM Aktuel.Person FOR SYSTEM_TIME ALL
	WHERE Personid = 6;
GO
EXECUTE AS USER = 'HistoriskUser';

DELETE
	FROM Historisk.Person;				-- Fejler

REVERT;
GO
