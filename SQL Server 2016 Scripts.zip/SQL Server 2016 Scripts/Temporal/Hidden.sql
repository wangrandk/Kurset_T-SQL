USE master;
GO
DROP DATABASE TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
USE TemporalDB;
CREATE TABLE dbo.Postopl
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY,
	Bynavn			VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Person
(
	ID				INT NOT NULL IDENTITY PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL REFERENCES dbo.Postopl(Postnr),
    SysStartTime	DATETIME2 GENERATED ALWAYS AS ROW START HIDDEN NOT NULL, 
    SysEndTime		DATETIME2 GENERATED ALWAYS AS ROW END HIDDEN NOT NULL,   
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (History_Table = dbo.PersonHistory));

CREATE TABLE dbo.Tider
(
	ID				INT NOT NULL PRIMARY KEY,
	Tid				DATETIME2 DEFAULT(SYSUTCDATETIME())
);
GO
INSERT INTO dbo.Tider (ID) VALUES
	(1);

WAITFOR DELAY '0:0:0:004';

INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(3000, 'Helsing�r'),
	(4000, 'Roskilde'),
	(5000, 'Odense C'),
	(6000, 'Kolding');

INSERT INTO dbo.Person (Navn, Adresse, Postnr) VALUES
	('Jesper Knudsen', 'Vestergade 13', 2000),
	('Hanne Poulsen', '�stergade 4', 3000),
	('Ane Hansen', 'Torvet 45', 4000),
	('�ge Jensen', 'Nygade 12', 2000),
	('Peter Andersen', 'Nygade 6', 4000),
	('Maren Pedersen', 'S�ndergade 18', 5000);
GO
SELECT *
	FROM dbo.Tider;

SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistory;
GO
INSERT INTO dbo.Tider (ID) VALUES
	(2);

WAITFOR DELAY '0:0:0:004';

DELETE
	FROM dbo.Person
	WHERE ID = 2;
GO
INSERT INTO dbo.Tider (ID) VALUES
	(3);

WAITFOR DELAY '0:0:0:004';

INSERT INTO dbo.Person (Navn, Adresse, Postnr) VALUES
	('Kit Knudsen', 'Vestergade 3', 3000),
	('Lars Jensen', 'Torvet 24', 2000);
GO
INSERT INTO dbo.Tider (ID) VALUES
	(4);

WAITFOR DELAY '0:0:0:004';

UPDATE dbo.Person
	SET Navn = 'Ane Marie Hansen'
	WHERE ID = 3;
GO
INSERT INTO dbo.Tider (ID) VALUES
	(5);

WAITFOR DELAY '0:0:0:004';

UPDATE dbo.Person
	SET Adresse = 'Storetorv 1', Postnr = 4000
	WHERE ID = 4;

UPDATE dbo.Person
	SET Adresse = 'Nygade 6 2. tv.', Postnr = 4000
	WHERE ID = 5;
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistory;
GO
DECLARE @Tid		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 1);

-- Returns a table with single record for each row containing the values 
-- that were actual (current) at the specified point in time
SELECT @Tid

SELECT	Id,
		Navn,
		Adresse,
		Postnr,
		SysStartTime,
		SysEndTime
	FROM dbo.Person	FOR SYSTEM_TIME AS OF @Tid
	ORDER BY ID;
GO
DECLARE @Tid		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 4);

SELECT	Id,
		Navn,
		Adresse,
		Postnr,
		SysStartTime,
		SysEndTime
	FROM dbo.Person	FOR SYSTEM_TIME AS OF @Tid
	ORDER BY ID;
GO
DECLARE @Tid		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 4);

SELECT	*
	FROM dbo.Person	FOR SYSTEM_TIME AS OF @Tid
	ORDER BY ID;
GO
DECLARE @Tid		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 4);

SELECT	*,
		SysStartTime,
		SysEndTime
	FROM dbo.Person	FOR SYSTEM_TIME AS OF @Tid
	ORDER BY ID;
GO