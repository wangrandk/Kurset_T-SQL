USE master;
GO
DROP DATABASE IF EXISTS TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
USE TemporalDB;
GO
CREATE TABLE dbo.Postopl
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY,
	Bynavn			VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Person
(
	Personid		INT NOT NULL IDENTITY PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL REFERENCES dbo.Postopl(Postnr),
    SysStartTime	DATETIME2(0) GENERATED ALWAYS AS ROW START NOT NULL, 
    SysEndTime		DATETIME2(0) GENERATED ALWAYS AS ROW END NOT NULL,   
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.PersonHistorik));
GO
INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(3000, 'Helsing�r'),
	(4000, 'Roskilde'),
	(5000, 'Odense C'),
	(6000, 'Kolding');

INSERT INTO dbo.Person (Fornavn, Efternavn, Adresse, Postnr) VALUES
	('Jesper', 'Knudsen', 'Vestergade 13', 2000),
	('Hanne', 'Poulsen', '�stergade 4', 3000),
	('Ane', 'Hansen', 'Torvet 45', 4000);
GO
UPDATE dbo.Person
	SET Adresse = 'Hovedgaden 22', Postnr = 3000
	WHERE Personid = 1;
GO
ALTER TABLE dbo.Person 
	ADD Tlfnr VARCHAR(8) NULL;
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistorik;
GO
--------------------------------------------------------------------------------
ALTER TABLE dbo.Person 
	ADD Status	CHAR(1) NOT NULL 
				CONSTRAINT DF_Person_Status DEFAULT('A');
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistorik;
GO
--------------------------------------------------------------------------------
ALTER TABLE dbo.Person
	DROP CONSTRAINT DF_Person_Status;

ALTER TABLE dbo.Person
	DROP COLUMN Status;
GO
ALTER TABLE dbo.Person
	SET (SYSTEM_VERSIONING = OFF);
GO
ALTER TABLE dbo.Person 
	ADD Status CHAR(1) NULL;
GO
UPDATE dbo.Person	
	SET Status = 'A';
GO
ALTER TABLE dbo.PersonHistorik 
	ADD Status CHAR(1) NULL;
GO
ALTER TABLE dbo.Person 
	SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.PersonHistorik));
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistorik;
GO
-- F�lgende 2 s�tninegr fejler, da begge aktuel og historik kolonne skal
-- have samme nullability

ALTER TABLE dbo.Person				
	ALTER COLUMN Status	CHAR(1) NOT NULL ;

ALTER TABLE dbo.Person
	ADD CONSTRAINT DF_Person_Status DEFAULT('A') FOR Status;
--------------------------------------------------------------------------------
GO
ALTER TABLE dbo.Person						-- fejler
	ADD Navn AS Fornavn + ' ' + Efternavn;
GO
ALTER TABLE dbo.Person
	SET (SYSTEM_VERSIONING = OFF);
GO
ALTER TABLE dbo.Person	
	ADD Navn AS Fornavn + ' ' + Efternavn;
GO
ALTER TABLE dbo.PersonHistorik	
	ADD Navn	VARCHAR(41) NULL;
GO
ALTER TABLE dbo.Person 
	SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.PersonHistorik));
GO
ALTER TABLE dbo.Person 
	ALTER COLUMN Tlfnr CHAR(20) NULL;
GO
UPDATE dbo.Person
	SET Tlfnr = CONCAT('+45 ', Tlfnr);

UPDATE dbo.Person
	SET Fornavn = 'Hanne Lise'
	WHERE Personid = 2;
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistorik;

UPDATE dbo.Person	
	SET Tlfnr = LEFT(Tlfnr, 8);
GO
ALTER TABLE dbo.Person 
	ALTER COLUMN Tlfnr CHAR(10) NULL;
GO
ALTER TABLE dbo.Person
	DROP COLUMN Tlfnr;
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistorik;
GO
