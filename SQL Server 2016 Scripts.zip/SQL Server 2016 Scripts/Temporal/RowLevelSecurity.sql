USE master
DROP DATABASE TestDB
GO
CREATE DATABASE TestDB
GO
USE TestDb
GO
CREATE SCHEMA Aktuel;
GO
CREATE SCHEMA Historisk;
GO
CREATE SCHEMA Security;
GO
CREATE TABLE Aktuel.Person
(
	Personid		INT NOT NULL PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL,
	Status			CHAR(1) NOT NULL DEFAULT ('A'),
    SysStartTime	DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL, 
    SysEndTime		DATETIME2 GENERATED ALWAYS AS ROW END NOT NULL,
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = Historisk.Person));
GO
INSERT INTO Aktuel.Person (PersonId, Fornavn, Efternavn, Adresse, Postnr) VALUES
	(1, 'Jesper', 'Knudsen', 'Vestergade 13', 2000),
	(2, 'Hanne', 'Poulsen', '�stergade 4', 3000),
	(3, 'Ane', 'Hansen', 'Torvet 45', 4000);
GO
UPDATE Aktuel.Person
	SET Adresse = 'Hovedgaden 22', Postnr = 3000
	WHERE Personid = 1;
GO
CREATE USER Aktuel WITHOUT LOGIN;
CREATE USER Historisk WITHOUT LOGIN;
GO
GRANT SELECT, INSERT, DELETE, UPDATE ON Aktuel.Person TO Aktuel;
GRANT SELECT, INSERT, DELETE, UPDATE ON Aktuel.Person TO Historisk;

GRANT SELECT ON Historisk.Person TO Aktuel;
GRANT SELECT ON Historisk.Person TO Historisk;
GO
CREATE FUNCTION Security.fn_securitypredicate
(
	@Dato	DATETIME2
)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS fn_securitypredicate_result 
				WHERE	(YEAR(@Dato) IN (9999) AND 
						USER_NAME() = 'Aktuel') OR 
						USER_NAME() = 'Historisk';
GO
CREATE SECURITY POLICY Personfilter
	ADD FILTER PREDICATE Security.fn_securitypredicate(SysEndTime) ON Aktuel.Person,
	ADD BLOCK PREDICATE Security.fn_securitypredicate(SysEndTime)  ON Aktuel.Person
	WITH (STATE = ON);

CREATE SECURITY POLICY PersonHistoriskfilter
	ADD FILTER PREDICATE Security.fn_securitypredicate(SysEndTime) ON Historisk.Person
	WITH (STATE = ON);
GO
EXECUTE AS USER = 'Aktuel';
SELECT * 
	FROM Aktuel.Person FOR SYSTEM_TIME ALL; 

REVERT;

EXECUTE AS USER = 'Historisk';
SELECT * 
	FROM Aktuel.Person FOR SYSTEM_TIME ALL; 

REVERT;
