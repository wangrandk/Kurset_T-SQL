USE master;
GO
DROP DATABASE SecurityDB;
GO
CREATE DATABASE SecurityDB;
GO
USE SecurityDB;
CREATE USER Chef WITHOUT LOGIN;
CREATE USER Saelger1 WITHOUT LOGIN;
CREATE USER Saelger2 WITHOUT LOGIN;
GO
CREATE TABLE dbo.Kunde
(
	KundeId				INT,
	Saelgernavn			SYSNAME,
	Kundenavn			VARCHAR(40)
);
GO
INSERT dbo.Kunde VALUES 
	(1, 'Saelger1', 'Olsen & S�n'), 
	(2, 'Saelger1', 'Petersen og Pedersen'), 
	(3, 'Saelger1', 'Malermesteren Aps'),
	(4, 'Saelger1', 'Ole Jensen'), 
	(5, 'Saelger2', 'Ane Hansen'), 
	(6, 'Saelger2', 'Maren Carlsen');
GO
SELECT * 
	FROM dbo.Kunde;
GO
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Kunde TO Chef;
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Kunde TO Saelger1;
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Kunde TO Saelger2;
GO
CREATE SCHEMA Security;
GO
CREATE FUNCTION Security.fn_securitypredicate
(
	@Saelgernavn	SYSNAME
)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS fn_securitypredicate_result 
				WHERE	USER_NAME() = @Saelgernavn OR 
						USER_NAME() = 'Chef';
GO
CREATE SECURITY POLICY Saelgerfilter
	ADD FILTER PREDICATE Security.fn_securitypredicate(Saelgernavn) 
	ON dbo.Kunde
	WITH (STATE = ON);

ALTER SECURITY POLICY Saelgerfilter
	ADD BLOCK PREDICATE Security.fn_securitypredicate(Saelgernavn)  ON dbo.Kunde;

ALTER SECURITY POLICY Saelgerfilter
	ADD BLOCK PREDICATE Security.fn_securitypredicate(Saelgernavn)  ON dbo.Kunde AFTER INSERT,
	ADD BLOCK PREDICATE Security.fn_securitypredicate(Saelgernavn)  ON dbo.Kunde BEFORE DELETE,
	ADD BLOCK PREDICATE Security.fn_securitypredicate(Saelgernavn)  ON dbo.Kunde AFTER UPDATE,
	ADD BLOCK PREDICATE Security.fn_securitypredicate(Saelgernavn)  ON dbo.Kunde BEFORE UPDATE;
GO
EXECUTE AS USER = 'Saelger1';
SELECT * 
	FROM dbo.Kunde; 
REVERT;

EXECUTE AS USER = 'Saelger2';
SELECT * 
	FROM dbo.Kunde; 
REVERT;

EXECUTE AS USER = 'Chef';
SELECT * 
	FROM dbo.Kunde; 
REVERT;
GO
EXECUTE AS USER = 'Saelger1';
DELETE
	FROM dbo.Kunde
	WHERE KundeId = 1;
	
DELETE
	FROM dbo.Kunde
	WHERE Kundeid = 6;

-- Den udf�rte s�tning svarer til denne s�tning
DELETE
	FROM dbo.Kunde
	WHERE	Kundeid = 6 AND
			('Saelger1' = Saelgernavn OR 
			'Saelger1' = 'Chef');
	
SELECT * 
	FROM dbo.Kunde;  
REVERT;
GO
EXECUTE AS USER = 'Saelger1';
UPDATE dbo.Kunde
	SET Kundenavn = 'Maren Marie Carlsen'
	WHERE KundeId = 6;

UPDATE dbo.Kunde
	SET Kundenavn = 'Petersen & Pedersen'
	WHERE KundeId = 2;

UPDATE dbo.Kunde
	SET Saelgernavn = 'Saelger2'
	WHERE KundeId = 2;


SELECT * 
	FROM dbo.Kunde; 
REVERT;
GO
EXECUTE AS USER = 'Saelger1';
INSERT dbo.Kunde VALUES 
	(7, 'Saelger2', 'Knud Hansen');

INSERT dbo.Kunde VALUES 
	(8, 'Saelger1', 'Fie Andersen');

SELECT * 
	FROM dbo.Kunde; 
REVERT;
GO
---------------------------------------------------------------
USE master;
GO
DROP DATABASE SecurityDB;
GO
CREATE DATABASE SecurityDB;
GO
USE SecurityDB;
CREATE USER Chef WITHOUT LOGIN;
CREATE USER Saelger1 WITHOUT LOGIN;
CREATE USER Saelger2 WITHOUT LOGIN;
GO
CREATE TABLE dbo.Kunde
(
	KundeId				INT			NOT NULL PRIMARY KEY,
	Saelgernavn			SYSNAME		NOT NULL,
	Kundenavn			VARCHAR(40)	NOT NULL,
	SidstAktivAar		SMALLINT	NOT NULL
);
GO
INSERT dbo.Kunde VALUES 
	(1, 'Saelger1', 'Olsen & S�n', 2017), 
	(2, 'Saelger1', 'Petersen og Pedersen', 2016), 
	(3, 'Saelger1', 'Malermesteren Aps', 2013),
	(4, 'Saelger1', 'Ole Jensen', 2016), 
	(5, 'Saelger2', 'Ane Hansen', 2016), 
	(6, 'Saelger2', 'Maren Carlsen', 2014);
GO
SELECT * 
	FROM dbo.Kunde;
GO
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Kunde TO Chef;
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Kunde TO Saelger1;
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Kunde TO Saelger2;
GO
CREATE SCHEMA Security;
GO
CREATE FUNCTION Security.fn_securitypredicate
(
	@Saelgernavn	SYSNAME,
	@Aar			SMALLINT
)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS fn_securitypredicate_result 
				WHERE	(USER_NAME() = @Saelgernavn AND
						@Aar >= YEAR(SYSDATETIME()) - 1 ) OR 
						USER_NAME() = 'Chef';
GO
CREATE SECURITY POLICY Saelgerfilter
	ADD FILTER PREDICATE Security.fn_securitypredicate(Saelgernavn, SidstAktivAar) 
	ON dbo.Kunde
	WITH (STATE = ON);
GO
EXECUTE AS USER = 'Saelger1';
SELECT * 
	FROM dbo.Kunde; 
REVERT;

EXECUTE AS USER = 'Saelger2';
SELECT * 
	FROM dbo.Kunde; 
REVERT;

EXECUTE AS USER = 'Chef';
SELECT * 
	FROM dbo.Kunde; 
REVERT;
GO
---------------------------------------------------------
USE master;
GO
DROP DATABASE SecurityDB;
GO
CREATE DATABASE SecurityDB;
GO
USE SecurityDB;
CREATE USER ALMA WITHOUT LOGIN;
CREATE USER PEAN WITHOUT LOGIN;
CREATE USER HAPE WITHOUT LOGIN;
CREATE USER TOMA WITHOUT LOGIN;
GO
CREATE TABLE dbo.ArbejdsFunktioner
(
	Funktion			VARCHAR(10)		NOT NULL 
						PRIMARY KEY,
	BeloebsGraense		INT				NOT NULL 
						CHECK (BeloebsGraense >= 0),
	Slette				TINYINT NOT NULL 
						DEFAULT (0)
						CHECK (Slette IN (0, 1)) 
							 -- 0 : M� ikke slette 
							 -- 1 : M� slette
); 

CREATE TABLE dbo.Medarbejder
(
	MedarbId			INT NOT NULL 
						PRIMARY KEY,
	Navn				VARCHAR(30) NOT NULL,
	Initialer			VARCHAR(5) NOT NULL,
	Funktion			VARCHAR(10) NOT NULL
						REFERENCES dbo.ArbejdsFunktioner
);
GO
INSERT INTO dbo.ArbejdsFunktioner VALUES
	('Kontorelev', 100, 0),
	('Assistent', 1000, 1),
	('Kontorchef', 10000, 1);

INSERT dbo.Medarbejder VALUES 
	(1, 'Anne Louise Madsen', 'ALMA', 'Kontorchef'), 
	(2, 'Per Andersen', 'PEAN', 'Assistent'), 
	(3, 'Hanne Pedersen', 'HAPE', 'Assistent'),
	(4, 'Tom Madsen', 'TOMA', 'Kontorelev');

CREATE TABLE dbo.Betalingsoplysning
(
		BetalingsId		INT NOT NULL PRIMARY KEY,
		Beloeb			INT NOT NULL
);
GO
SELECT * 
	FROM dbo.Medarbejder;
GO
GRANT SELECT, INSERT, DELETE, UPDATE 
	ON dbo.Betalingsoplysning 
	TO ALMA, PEAN, HAPE, TOMA;
GO
CREATE SCHEMA Security;
GO
CREATE FUNCTION Security.fn_securityInsertUpdate
(
	@Beloeb		INT
)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS fn_securitypredicate_result 
			WHERE @Beloeb
					BETWEEN 0 AND				 
					(SELECT BeloebsGraense
						FROM dbo.ArbejdsFunktioner
						WHERE Funktion =
								(SELECT Funktion	
									FROM dbo.Medarbejder
									WHERE Initialer = USER_NAME()));
GO
CREATE FUNCTION Security.fn_securityDelete
(
	@Beloeb		INT
)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS fn_securitypredicate_result 
				WHERE (SELECT Slette
						FROM dbo.ArbejdsFunktioner
						WHERE Funktion =
								(SELECT Funktion	
									FROM dbo.Medarbejder
									WHERE Initialer = USER_NAME())) = 1 AND 
										  @Beloeb = 0;
GO
CREATE SECURITY POLICY Saelgerfilter
	ADD BLOCK PREDICATE Security.fn_securityInsertUpdate(Beloeb)  
			ON dbo.Betalingsoplysning AFTER INSERT,
	ADD BLOCK PREDICATE Security.fn_securityInsertUpdate(Beloeb)  
			ON dbo.Betalingsoplysning BEFORE UPDATE,
	ADD BLOCK PREDICATE Security.fn_securityInsertUpdate(Beloeb)  
			ON dbo.Betalingsoplysning AFTER UPDATE,
	ADD BLOCK PREDICATE Security.fn_securityDelete(Beloeb) 
			ON dbo.Betalingsoplysning BEFORE DELETE
	WITH (STATE = ON);
GO
-- OK Insert
EXECUTE AS USER = 'ALMA' -- Kontorchef, 10000

INSERT INTO dbo.Betalingsoplysning VALUES
	(1, 9000);

REVERT;
GO
EXECUTE AS USER = 'PEAN'	-- Assistent, 1000

INSERT INTO dbo.Betalingsoplysning VALUES
	(2, 900);

REVERT;
GO
EXECUTE AS USER = 'TOMA'	--Kontorelev, 100

INSERT INTO dbo.Betalingsoplysning VALUES
	(3, 90);

REVERT;

SELECT *
	FROM dbo.Betalingsoplysning;
GO
-- Fejl Insert
EXECUTE AS USER = 'ALMA' -- Kontorchef, 10000

INSERT INTO dbo.Betalingsoplysning VALUES
	(4, 90000);

REVERT;
GO
EXECUTE AS USER = 'PEAN'	-- Assistent, 1000

INSERT INTO dbo.Betalingsoplysning VALUES
	(5, 9000);

REVERT;
GO
EXECUTE AS USER = 'TOMA'	--Kontorelev, 100

INSERT INTO dbo.Betalingsoplysning VALUES
	(6, 900);

REVERT;

SELECT *
	FROM dbo.Betalingsoplysning;
GO
-- OK, Update
EXECUTE AS USER = 'ALMA' -- Kontorchef, 10000

UPDATE dbo.Betalingsoplysning 
	SET Beloeb = Beloeb + 100
	WHERE BetalingsId = 1;

REVERT;
GO
EXECUTE AS USER = 'PEAN'	-- Assistent, 1000

UPDATE dbo.Betalingsoplysning 
	SET Beloeb = Beloeb - Beloeb
	WHERE BetalingsId = 2;

REVERT;
GO
EXECUTE AS USER = 'TOMA'	--Kontorelev, 100

UPDATE dbo.Betalingsoplysning 
	SET Beloeb = 0
	WHERE BetalingsId = 3;

REVERT;

SELECT *
	FROM dbo.Betalingsoplysning;
GO
-- Fejl, Update

SELECT *
	FROM dbo.Betalingsoplysning;

EXECUTE AS USER = 'ALMA' -- Kontorchef, 10000

UPDATE dbo.Betalingsoplysning 
	SET Beloeb = Beloeb + 10000		-- overstiger 10000 efter
	WHERE BetalingsId = 1;

REVERT;
GO
EXECUTE AS USER = 'PEAN'	-- Assistent, 1000

UPDATE dbo.Betalingsoplysning 
	SET Beloeb = Beloeb - 100	-- Bliver negativ
	WHERE BetalingsId = 2;

UPDATE dbo.Betalingsoplysning 
	SET Beloeb = Beloeb - 8500	-- For h�jt bel�b inden, men ikke efter
	WHERE BetalingsId = 1;

REVERT;
GO
EXECUTE AS USER = 'TOMA'	--Kontorelev, 100

UPDATE dbo.Betalingsoplysning 
	SET Beloeb = -20 	-- Bliver negativ
	WHERE BetalingsId = 3;

REVERT;

SELECT *
	FROM dbo.Betalingsoplysning;
GO
-- Delete
SELECT *
	FROM dbo.ArbejdsFunktioner;
GO	 
EXECUTE AS USER = 'ALMA' -- Kontorchef, 10000

DELETE
	FROM dbo.Betalingsoplysning 
	WHERE BetalingsId = 1;

REVERT;
GO
EXECUTE AS USER = 'PEAN'	-- Assistent, 1000

DELETE
	FROM dbo.Betalingsoplysning 
	WHERE BetalingsId = 2;

REVERT;
GO
EXECUTE AS USER = 'TOMA'	--Kontorelev, 100

DELETE
	FROM dbo.Betalingsoplysning 
	WHERE BetalingsId = 3;

REVERT;

SELECT *
	FROM dbo.Betalingsoplysning;
GO
