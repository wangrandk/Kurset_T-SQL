USE master;
DROP DATABASE IF EXISTS PartitionDB;
GO
CREATE DATABASE PartitionDB
ON PRIMARY
	(NAME = PartitionDB_sys,
	 FILENAME = 'c:\Databaser2016\PartitionDB_sys.mdf',
     SIZE = 5MB),

FILEGROUP PartitionDB_fg1
	(NAME = PartitionDB_fg1,
	 FILENAME = 'c:\Databaser2016\PartitionDB_fg1.ndf',
     SIZE = 20MB),
	
FILEGROUP PartitionDB_fg2
	(NAME = PartitionDB_fg2,
	 FILENAME = 'c:\Databaser2016\PartitionDB_fg2.ndf',
     SIZE = 20MB),
	
FILEGROUP PartitionDB_fg3
	(NAME = PartitionDB_fg3,
	 FILENAME = 'c:\Databaser2016\PartitionDB_fg3.ndf',
     SIZE = 20MB),
	
FILEGROUP PartitionDB_fg4
	(NAME = PartitionDB_fg4,
	 FILENAME = 'c:\Databaser2016\PartitionDB_fg4.ndf',
     SIZE = 20MB),
	
FILEGROUP PartitionDB_fg5
	(NAME = PartitionDB_fg5,
	 FILENAME = 'c:\Databaser2016\PartitionDB_fg5.ndf',
     SIZE = 20MB),
	
FILEGROUP PartitionDB_fg6
	(NAME = PartitionDB_fg6,
	 FILENAME = 'c:\Databaser2016\PartitionDB_fg6.ndf',
     SIZE = 20MB)

LOG ON
	(NAME = PartitionDB_log,
	 FILENAME = 'c:\Databaser2016\PartitionDB.ldf',
     SIZE = 1000MB);
GO
USE PartitionDB
CREATE PARTITION FUNCTION PartitionFunction (DATE)
	AS RANGE RIGHT FOR VALUES (	'2015-2-1', 
								'2015-3-1', 
								'2015-4-1', 
								'2015-5-1', 
								'2015-6-1');
GO
CREATE PARTITION scheme PartitionScheme
	AS PARTITION PartitionFunction TO (	PartitionDB_fg1, 
										PartitionDB_fg2, 
										PartitionDB_fg3, 
										PartitionDB_fg4, 
										PartitionDB_fg5, 
										PartitionDB_fg6);
GO
CREATE TABLE dbo.PartitionTable 
(
	Id			INT NOT NULL IDENTITY, 
	Navn		CHAR(10) NOT NULL,
	Tid			DATE NOT NULL,
	INDEX nc_PartitionTable_Tid_Id (Tid, ID)
) ON PartitionScheme (Tid);
GO
INSERT INTO dbo.PartitionTable (Navn, Tid) VALUES 
	('Ole', '2015-1-2'),
	('Per', '2015-1-22'),
	('Ida', '2015-2-3'),
	('Ane', '2015-2-14'),
	('Mie', '2015-3-5'),
	('Eva', '2015-3-6'),
	('Dea', '2015-4-7'),
	('Jan', '2015-4-5'),
	('Fie', '2015-5-2'),
	('Oda', '2015-5-29'),
	('Elo', '2015-6-5'),
	('Tom', '2015-6-6');
GO
INSERT INTO dbo.PartitionTable (Navn, Tid)
	SELECT	Navn, 
			Tid
		FROM dbo.PartitionTable
GO 17
CREATE TABLE dbo.sqlperf_logspace 
(
	dbname		SYSNAME,
	logsize		FLOAT,
	logpct		FLOAT,
	status		SMALLINT,
	time		DATETIME2 DEFAULT(SYSDATETIME())
);
GO
BACKUP DATABASE PartitionDB TO DISK = 'c:/Rod/PartitionDB.BAK' WITH FORMAT;
BACKUP LOG PartitionDB TO DISK = 'c:/Rod/PartitionDB.LOG' WITH FORMAT;
GO
INSERT INTO dbo.sqlperf_logspace (dbname, logsize, logpct, status)
	EXEC ('DBCC sqlperf(logspace)');
GO
SELECT COUNT(*) 
	FROM dbo.PartitionTable;
GO
PRINT '------------------ TRUNCATE ------------------'
SET STATISTICS TIME ON;
TRUNCATE TABLE dbo.PartitionTable
	WITH (PARTITIONS (2, 4 TO 6));
SET STATISTICS TIME OFF;
GO
SELECT COUNT(*) 
	FROM dbo.PartitionTable;
GO
INSERT INTO dbo.sqlperf_logspace (dbname, logsize, logpct, status)
	EXEC ('DBCC sqlperf(logspace)');
GO
SELECT *
	FROM dbo.sqlperf_logspace
	WHERE dbname = 'PartitionDB'
	ORDER BY time;
GO
-- DELETE ---------------------------------------------
USE master;
DROP DATABASE PartitionDB;
GO
RESTORE DATABASE PartitionDB FROM DISK = 'c:/Rod/PartitionDB.BAK';
BACKUP LOG PartitionDB TO DISK = 'c:/Rod/PartitionDB.LOG' WITH FORMAT;
GO
USE PartitionDB;
GO
INSERT INTO dbo.sqlperf_logspace (dbname, logsize, logpct, status)
	EXEC ('DBCC sqlperf(logspace)');
GO
SELECT COUNT(*) 
	FROM dbo.PartitionTable;
GO
PRINT '------------------ DELETE ------------------'
SET STATISTICS TIME ON;
DELETE 
	FROM dbo.PartitionTable
	WHERE MONTH(Tid) IN (2, 4, 5, 6);
SET STATISTICS TIME OFF;
GO
SELECT COUNT(*) 
	FROM dbo.PartitionTable;
GO
INSERT INTO dbo.sqlperf_logspace (dbname, logsize, logpct, status)
	EXEC ('DBCC sqlperf(logspace)');
GO
SELECT *
	FROM dbo.sqlperf_logspace
	WHERE dbname = 'PartitionDB'
	ORDER BY time;
GO