USE master;
DROP DATABASE IF EXISTS NativelyCompiledDB;
GO
CREATE DATABASE NativelyCompiledDB
ON PRIMARY
(
	NAME = NativelyCompiledDB_sys,
	FILENAME = N'C:\Databaser2016\NativelyCompiledDB_sys.mdf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
),
FILEGROUP NativelyCompiledDB_NotInMem_filegroup  
(
	NAME = NativelyCompiledDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser2016\NativelyCompiledDB_NativelyCompiledDB_NotInMem_filegroup.ndf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
),
FILEGROUP NativelyCompiledDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = NativelyCompiledDB_InMem_filegroup_fil1,
    FILENAME = N'C:\Databaser2016\InMem_Data_NativelyCompiledDB1'
),
( 
	NAME = NativelyCompiledDB_InMem_filegroup_fil2,
    FILENAME = N'C:\Databaser2016\InMem_Data_NativelyCompiledDB2'
),
( 
	NAME = NativelyCompiledDB_InMem_filegroup_fil3,
    FILENAME = N'C:\Databaser2016\InMem_Data_NativelyCompiledDB3'
),
( 
	NAME = NativelyCompiledDB_InMem_filegroup_fil4,
    FILENAME = N'C:\Databaser2016\InMem_Data_NativelyCompiledDB4'
)
LOG ON
( 
	NAME = NativelyCompiledDB_log_file_1,
	FILENAME = N'C:\Databaser2016\NativelyCompiledDB_log.ldf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
);
GO
USE NativelyCompiledDB;
GO
SELECT DATABASEPROPERTYEX(DB_NAME(), 'IsXTPSupported');
GO
CREATE SCHEMA InMem;
GO
CREATE TABLE InMem.Postopl 
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY NONCLUSTERED,	
	Bynavn			VARCHAR (30) NOT NULL
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);

CREATE TABLE InMem.Kunde 
(
	Kundeid			INT	NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY,
	Cvr				CHAR(8) NOT NULL
					CONSTRAINT UQ_Kunde_Cvr UNIQUE,
	Navn			VARCHAR (30) COLLATE Danish_Norwegian_CS_AS NOT NULL,
	Adresse			VARCHAR (30) NULL,
	Postnr			SMALLINT  NULL 
					CONSTRAINT FK_Postopl_Kunde FOREIGN KEY REFERENCES InMem.Postopl (Postnr),
	MaxBeloeb		INT	NOT NULL
					CONSTRAINT DF_Kunde_MaxBeloeb DEFAULT (0)
					CONSTRAINT CK_Kunde_MaxBeloeb CHECK (MaxBeloeb BETWEEN 0 AND 500000)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
CREATE TABLE InMem.Medarbejder 
(
	Medarbejderid	INT	NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY,
	Navn			VARCHAR (30) COLLATE Danish_Norwegian_CS_AS NOT NULL,
	Adresse			VARCHAR (30) COLLATE Danish_Norwegian_CS_AS NOT NULL,
	Postnr			SMALLINT  NOT NULL 
					CONSTRAINT FK_Postopl_Medarbejder FOREIGN KEY REFERENCES InMem.Postopl (Postnr),
	SysStartTime	DATETIME2 GENERATED ALWAYS AS ROW START HIDDEN NOT NULL,
	SysEndTime		DATETIME2 GENERATED ALWAYS AS ROW END HIDDEN NOT NULL,
	PERIOD FOR SYSTEM_TIME (SysStartTime, SysEndTime)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_AND_DATA,
		SYSTEM_VERSIONING = ON (HISTORY_TABLE = InMem.HistoryMedarbejder));
GO
CREATE TABLE InMem.Leverandoer 
(
	Leverandoerid	INT	NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY,
	Navn			VARCHAR (30) COLLATE Danish_Norwegian_CS_AS NOT NULL,
	Adresse			VARCHAR (30) COLLATE Danish_Norwegian_CS_AS NOT NULL,
	Postnr			SMALLINT  NOT NULL 
					CONSTRAINT FK_Postopl_Leverandoer FOREIGN KEY REFERENCES InMem.Postopl (Postnr),
	INDEX cl_Leverandoer CLUSTERED COLUMNSTORE
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_AND_DATA);
GO
SET NOCOUNT ON 
INSERT INTO InMem.Postopl (Postnr, Bynavn) VALUES 
	(2000, 'Frederiksberg'),
	(4000, 'Roskilde'),
	(5000, 'Odense C'),
	(8000, 'Aarhus C'),
	(9000, 'Aalborg');

INSERT INTO InMem.Kunde (Cvr, Navn, Adresse, Postnr) VALUES 
	('12345678', 'Jens Hansen', 'Nygade 3', 2000),
	('23456781', 'Lone Jensen', 'Torvet 12', 2000),
	('34567812', 'Peter Knudsen', 'Torvet 44', 2000),
	('45678123', 'Ole Larsen', 'Vestergade 4', 9000),
	('56781234', 'Karen Olsen', 'Borgergade 13', 8000),
	('67812345', 'Karl Nielsen', 'S�ndergade 67', 9000),
	('78123456', 'Hanne Pedersen', NULL, NULL);

SET NOCOUNT OFF;
GO
SELECT *
	FROM InMem.Kunde;

SELECT *
	FROM InMem.Postopl;
GO
-- Fejl ved inds�ttelse i kunde pga definerede constraints
INSERT INTO InMem.Postopl (Postnr, Bynavn) VALUES 
	(2000, 'Frederiksberg');

INSERT INTO InMem.Kunde (Cvr, Navn, Adresse, Postnr, MaxBeloeb) VALUES 
	('12345678', 'Jens Hansen', 'Nygade 3', 2000, 100000);

INSERT INTO InMem.Kunde (Cvr, Navn, Adresse, Postnr, MaxBeloeb) VALUES 
	('81234567', 'Hanne Pedersen', 'Storegade 34', 2000, 600000);

INSERT INTO InMem.Kunde (Cvr, Navn, Adresse, Postnr, MaxBeloeb) VALUES 
	('12348765', 'Lars Pedersen', 'Lillegade 5', 4000, 100000);
GO
-- Medarbejder
INSERT INTO InMem.Medarbejder (Navn, Adresse, Postnr) VALUES
	('Sanne Hansen', 'Vestergade 3', 8000),
	('Lars Olsen', 'Torvet 4', 2000),
	('Pia Nielsen', 'Poulsgade 34', 9000);

UPDATE InMem.Medarbejder
	SET Adresse = 'S�ndergade 45', Postnr = 2000
	WHERE Medarbejderid = 2;

SELECT *
	FROM InMem.Medarbejder
	FOR SYSTEM_TIME ALL;
GO
-- Leverandoer
INSERT INTO InMem.Leverandoer (Navn, Adresse, Postnr) VALUES
	('Carl Hansen aps', 'N�rregade 3', 9000),
	('Jensen Og S�n', 'Havnegade 14', 8000);

UPDATE InMem.Leverandoer
	SET Adresse = 'Havnegade 23', Postnr = 8000
	WHERE Leverandoerid = 2;

SELECT *
	FROM InMem.Leverandoer;
GO
-- Alter
ALTER TABLE InMem.Kunde ADD Tlfnr VARCHAR(20) NULL;
GO
ALTER TABLE InMem.Kunde
	ADD INDEX Hash_Kunde_Navn HASH(Navn) WITH (BUCKET_COUNT = 2000);
GO
ALTER TABLE InMem.Kunde
	ALTER INDEX Hash_Kunde_Navn
	REBUILD  WITH (BUCKET_COUNT = 4000);
GO
ALTER TABLE InMem.Kunde
	DROP COLUMN Tlfnr;
GO
ALTER TABLE InMem.Kunde
	ADD NONCLUSTERED COLUMNSTORE INDEX ncci_Kunde__Navn_MaxBeloeb ON InMem.Kunde (Navn, MaxBeloeb);
