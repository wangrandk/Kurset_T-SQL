USE master;
GO
DROP DATABASE IF EXISTS TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
USE TemporalDB;
CREATE TABLE dbo.Postopl
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY,
	Bynavn			VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Person
(
	ID				INT NOT NULL IDENTITY PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT NOT NULL REFERENCES dbo.Postopl(Postnr),
	Navn			AS Fornavn + ' '  + Efternavn,
    SysStartTime	DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL, 
    SysEndTime		DATETIME2 GENERATED ALWAYS AS ROW END NOT NULL,   
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (History_Table = dbo.PersonHistory));

CREATE TABLE dbo.Tider
(
	ID				INT NOT NULL PRIMARY KEY,
	Tid				DATETIME2 DEFAULT(SYSUTCDATETIME())
);
GO
INSERT INTO dbo.Tider (ID) VALUES
	(1);

WAITFOR DELAY '0:0:0:004';

INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(3000, 'Helsing�r'),
	(4000, 'Roskilde'),
	(5000, 'Odense C'),
	(6000, 'Kolding');

INSERT INTO dbo.Person (Fornavn, Efternavn, Adresse, Postnr) VALUES
	('Jesper', 'Knudsen', 'Vestergade 13', 2000),
	('Hanne', 'Poulsen', '�stergade 4', 3000),
	('Ane', 'Hansen', 'Torvet 45', 4000),
	('�ge', 'Jensen', 'Nygade 12', 2000),
	('Peter', 'Andersen', 'Nygade 6', 4000),
	('Maren', 'Pedersen', 'S�ndergade 18', 5000);
GO
SELECT *
	FROM dbo.Tider;

SELECT *
	FROM dbo.Person;
GO
INSERT INTO dbo.Tider (ID) VALUES
	(2);

WAITFOR DELAY '0:0:0:004';

DELETE
	FROM dbo.Person
	WHERE ID = 2;
GO
INSERT INTO dbo.Tider (ID) VALUES
	(3);

WAITFOR DELAY '0:0:0:004';

INSERT INTO dbo.Person (Fornavn, Efternavn, Adresse, Postnr) VALUES
	('Kit', 'Knudsen', 'Vestergade 3', 3000),
	('Lars', 'Jensen', 'Torvet 24', 2000);
GO
INSERT INTO dbo.Tider (ID) VALUES
	(4);

WAITFOR DELAY '0:0:0:004';

UPDATE dbo.Person
	SET	Fornavn = 'Ane Marie', 
		Efternavn = 'Hansen'
	WHERE ID = 3;
GO
INSERT INTO dbo.Tider (ID) VALUES
	(5);

WAITFOR DELAY '0:0:0:004';

UPDATE dbo.Person
	SET Adresse = 'Storetorv 1', Postnr = 4000
	WHERE ID = 4;

UPDATE dbo.Person
	SET Adresse = 'Nygade 6 2. tv.', Postnr = 4000
	WHERE ID = 5;
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistory;
GO
-- Returns a table with single record for each row containing the values 
-- that were actual (current) at the specified point in time
DECLARE @Tid		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 1 );

SELECT @Tid

SELECT	Id,
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		SysStartTime,
		SysEndTime
	FROM dbo.Person	FOR SYSTEM_TIME AS OF @Tid
	ORDER BY ID;
GO
DECLARE @Tid		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 4);

SELECT	Id,
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		SysStartTime,
		SysEndTime
	FROM dbo.Person	FOR SYSTEM_TIME AS OF @Tid
	ORDER BY ID;
GO
-- Returns a table with the values for all record versions that were active 
-- within the specified time range, regardless of whether they started being active 
-- before the <start_date_time> parameter value for the FROM argument or ceased being active 
-- after the <end_date_time> parameter value
DECLARE @Tid1		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 2);
DECLARE @Tid2		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 5);

SELECT	Id,
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		SysStartTime,
		SysEndTime
	FROM dbo.Person FOR SYSTEM_TIME FROM @Tid1 TO @Tid2
	ORDER BY ID;

SELECT	Id
	FROM dbo.Person FOR SYSTEM_TIME FROM @Tid1 TO @Tid2
	GROUP BY Id
	HAVING COUNT(*) > 1
	ORDER BY ID;
GO
-- Same as above in the FOR SYSTEM_TIME FROM <start_date_time>TO <end_date_time> description, 
-- except the table of rows returned includes rows that became active on the upper boundary 
-- defined by the <end_date_time> endpoint.
DECLARE @Tid1		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 2);
DECLARE @Tid2		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 5);

SELECT	Id,
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		SysStartTime,
		SysEndTime
	FROM dbo.Person FOR SYSTEM_TIME BETWEEN @Tid1 AND @Tid2
	ORDER BY ID;
GO
-- Returns a table with the values for all record versions that were opened
-- and closed within the specified time range defined by the two datetime values 
DECLARE @Tid1		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 2);
DECLARE @Tid2		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 5);

SELECT	Id,
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		SysStartTime,
		SysEndTime
	FROM dbo.Person FOR SYSTEM_TIME CONTAINED IN (@Tid1, @Tid2)
	ORDER BY ID;
GO
-- Returns the union of rows that belong to the current and the history table.

SELECT	Id,
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		SysStartTime,
		SysEndTime
	FROM dbo.Person FOR SYSTEM_TIME ALL
	ORDER BY ID;
GO
INSERT INTO dbo.Tider (ID) VALUES
	(8);

UPDATE dbo.Person
	SET Adresse = 'Storetorv 1', Postnr = 5000
	WHERE ID = 4;

WAITFOR DELAY '0:00:20';

INSERT INTO dbo.Tider (ID) VALUES
	(9);

UPDATE dbo.Person
	SET Adresse = 'Torvet 3', Postnr = 6000
	WHERE ID = 4;

WAITFOR DELAY '0:00:10';

INSERT INTO dbo.Tider (ID) VALUES
	(10);

UPDATE dbo.Person
	SET Fornavn = 'Aage', 
		Efternavn = 'Jensen'
	WHERE ID = 4;
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistory;
GO
SELECT TOP 1 SysEndTime
	FROM dbo.PersonHistory AS OldPersonYdre 
	WHERE	ID = 4 AND
			EXISTS (SELECT *
						FROM dbo.PersonHistory AS OldPersonIndre
						WHERE	OldPersonIndre.Id = 4 AND
								OldPersonIndre.SysStartTime = OldPersonYdre.SysEndTime)
	ORDER BY SysEndTime ASC;
GO
DECLARE @Tid1		DATETIME2 = (SELECT TOP 1 SysEndTime
									FROM dbo.PersonHistory AS OldPersonYdre 
									WHERE	ID = 4 AND
											EXISTS (SELECT *
														FROM dbo.PersonHistory AS OldPersonIndre
														WHERE	OldPersonIndre.Id = 4 AND
																OldPersonIndre.SysStartTime = OldPersonYdre.SysEndTime)
									ORDER BY SysEndTime ASC);
DECLARE @Tid2		DATETIME2 = DATEADD(DAY, 2, @Tid1);

SELECT *, 'Aktuel' AS Status
	FROM dbo.Person
	WHERE ID = 4
UNION ALL
SELECT *, 'Historisk'
	FROM dbo.PersonHistory
	WHERE ID = 4
ORDER BY SysEndTime;

SELECT @Tid1, @Tid2;

SELECT	Id,
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		'Saetning 1 - AS OF' AS Saetning
	FROM dbo.Person	FOR SYSTEM_TIME AS OF @Tid1
	WHERE ID = 4
UNION ALL
SELECT	Id,
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		'Saetning 2 - FROM ... TO' AS Saetning
	FROM dbo.Person FOR SYSTEM_TIME FROM @Tid1 TO @Tid2
	WHERE ID = 4
UNION ALL
SELECT	Id,
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		'Saetning 3 - BETWEEN' AS Saetning
	FROM dbo.Person FOR SYSTEM_TIME BETWEEN @Tid1 AND @Tid2
	WHERE ID = 4
UNION ALL
SELECT	Id,
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		'Saetning 4 - IN ()' AS Saetning
	FROM dbo.Person FOR SYSTEM_TIME CONTAINED IN (@Tid1, @Tid2)
	WHERE ID = 4;
GO
-- slet data i historiktabel
SELECT	Id,
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		SysStartTime,
		SysEndTime
	FROM dbo.PersonHistory;
GO
ALTER TABLE dbo.Person
	SET (SYSTEM_VERSIONING = OFF);
GO	
DECLARE @Tid		DATETIME2 = (SELECT Tid FROM dbo.Tider WHERE ID = 8);

DELETE
       FROM dbo.PersonHistory
       WHERE SysEndTime < @Tid;
GO       
ALTER TABLE dbo.Person
	SET (SYSTEM_VERSIONING = ON
		(HISTORY_TABLE  = dbo.PersonHistory,
		 DATA_CONSISTENCY_CHECK = OFF));
GO
SELECT	Id,
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		SysStartTime,
		SysEndTime
	FROM dbo.PersonHistory;
GO
