USE master;
GO
DROP DATABASE IF EXISTS TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
USE TemporalDB;
CREATE TABLE dbo.Vare
(
	VareId			INT NOT NULL PRIMARY KEY,
	Varenavn		VARCHAR(40) NOT NULL,
	EnhedsPris		DECIMAL(11,2) NOT NULL DEFAULT (0),
    SysStartTime	DATETIME2 NOT NULL, 
    SysEndTime		DATETIME2 NOT NULL
);

CREATE TABLE dbo.VareHistory
(
	VareId			INT NOT NULL,
	Varenavn		VARCHAR(40) NOT NULL,
	EnhedsPris		DECIMAL(11,2) NOT NULL,
    SysStartTime	DATETIME2 NOT NULL, 
    SysEndTime		DATETIME2 NOT NULL
);

CREATE TABLE dbo.Ordrelinie
(
	OrdreId			INT NOT NULL,
	VareId			INT NOT NULL,
	AntalEnheder	INT NOT NULL CHECK(AntalEnheder > 0),
	Bestillingsdato	DATETIME2 NOT NULL DEFAULT(SYSDATETIME()),
	Leveringsdato	DATE NOT NULL DEFAULT(SYSDATETIME()),
	CONSTRAINT PK_Ordrelinie PRIMARY KEY (OrdreId, VareId),
);
GO
INSERT INTO dbo.VareHistory (VareId, Varenavn, EnhedsPris, SysStartTime, SysEndTime) VALUES
	(1, 'Jordb�r', 25.00, '2015-07-11', '2015-07-12'),
	(1, 'Jordb�r Danske', 20.00, '2015-07-12', '2015-07-13'), 
	(1, 'Jordb�r Danske', 22.00, '2015-07-13', '2015-07-14'), 
	(1, 'Jordb�r Belgiske', 30.00, '2015-07-14', '2015-07-15'),
	
	(2, 'Nye Danske Kartofler', 15.00, '2015-07-11', '2015-07-14'), 
	(2, 'Nye Danske Kartofler', 13.00, '2015-07-14', '2015-07-15');

INSERT INTO dbo.Vare (VareId, Varenavn, EnhedsPris, SysStartTime, SysEndTime) VALUES
	(1, 'Jordb�r Belgiske', 30.00, '2015-07-15', '9999-12-31 23:59:59.9999999'),
	(2, 'Nye Danske Kartofler', 12.00, '2015-07-15', '9999-12-31 23:59:59.9999999');
GO
ALTER TABLE dbo.Vare
	ADD PERIOD FOR SYSTEM_TIME (SysStartTime, SysEndTime);
ALTER TABLE dbo.Vare
    SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE=dbo.VareHistory, DATA_CONSISTENCY_CHECK = ON));
GO
UPDATE dbo.Vare	
	SET EnhedsPris = 35
	WHERE VareId = 1;
GO
INSERT INTO dbo.Ordrelinie (OrdreId, VareId, AntalEnheder, Bestillingsdato, Leveringsdato) VALUES
	(100, 1, 2, '2015-07-12', '2015-07-12'),
 	(100, 2, 5, '2015-07-12', '2015-07-12'),
	(101, 1, 3, '2015-07-14', '2015-07-14'),
 	(102, 2, 2, '2015-07-15', '2015-07-15'),
	(103, 1, 20, '2015-07-12', '2015-07-30'),
 	(103, 2, 50, '2015-07-21', '2015-07-30');
GO
SELECT *
	FROM dbo.Vare;

SELECT *
	FROM dbo.VareHistory;

SELECT *
	FROM dbo.Ordrelinie;
GO
SELECT *										-- Fejler tiden skal v�re en konstant eller variabel
	FROM dbo.Ordrelinie CROSS APPLY (SELECT *
										FROM dbo.Vare
										FOR SYSTEM_TIME AS OF Ordrelinie.Bestillingsdato
										WHERE Vare.VareId = Ordrelinie.VareId)
	WHERE Ordrelinie.OrdreId = 100;
GO
CREATE FUNCTION dbo.ufn_vare 
(
@Dato		DATETIME2,
@VareId		INT
)
RETURNS TABLE
RETURN (SELECT *
			FROM dbo.Vare
			FOR SYSTEM_TIME AS OF @Dato
			WHERE Vare.VareId = @VareId)
GO
SELECT *									
	FROM dbo.Ordrelinie CROSS APPLY dbo.ufn_vare  (Ordrelinie.Bestillingsdato, Ordrelinie.VareId)
	WHERE Ordrelinie.OrdreId = 100;

SELECT *									
	FROM dbo.Ordrelinie CROSS APPLY dbo.ufn_vare  (Ordrelinie.Bestillingsdato, Ordrelinie.VareId)
	WHERE Ordrelinie.OrdreId = 101;

SELECT *									
	FROM dbo.Ordrelinie CROSS APPLY dbo.ufn_vare  (Ordrelinie.Bestillingsdato, Ordrelinie.VareId)
	WHERE Ordrelinie.OrdreId = 102;

SELECT *									
	FROM dbo.Ordrelinie CROSS APPLY dbo.ufn_vare  (Ordrelinie.Bestillingsdato, Ordrelinie.VareId)
	WHERE Ordrelinie.OrdreId = 103;
GO
SELECT *									
	FROM dbo.Ordrelinie CROSS APPLY dbo.ufn_vare  (Ordrelinie.Bestillingsdato, Ordrelinie.VareId)
	WHERE Ordrelinie.OrdreId = 103;

SELECT *									
	FROM dbo.Ordrelinie CROSS APPLY dbo.ufn_vare  (Ordrelinie.Leveringsdato, Ordrelinie.VareId)
	WHERE Ordrelinie.OrdreId = 103;
