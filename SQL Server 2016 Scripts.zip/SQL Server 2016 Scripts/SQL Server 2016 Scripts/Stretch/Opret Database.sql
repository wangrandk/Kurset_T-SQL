USE master;
GO
DROP DATABASE IF EXISTS StretchDB;
GO
CREATE DATABASE StretchDB;
GO
USE StretchDB;
CREATE TABLE dbo.t
(
	ID			INT NOT NULL PRIMARY KEY IDENTITY,
	Txt			VARCHAR(800) NOT NULL 
);
GO
SET NOCOUNT ON;
GO
INSERT INTO dbo.t (txt) VALUES
	(REPLICATE('0123456789', 40));
GO 200
SELECT *
	FROM dbo.t;
GO
ALTER TABLE dbo.t
	ENABLE REMOTE_DATA_ARCHIVE WITH (MIGRATION_STATE = ON);
GO
INSERT INTO dbo.t (txt) VALUES
	(REPLICATE('ABCDEFGHIJKLMNOPQ', 40));
GO 20
SELECT *
	FROM sys.remote_data_archive_databases;

SELECT *
	FROM sys.remote_data_archive_tables;
GO
SELECT *
	FROM sys.dm_db_rda_migration_status;
GO
SELECT *
	FROM dbo.t;
GO
DELETE						-- Fejler
	FROM dbo.t;
GO
