USE master;
GO
EXEC sp_configure 'remote data archive';
GO
EXEC sp_configure 'remote data archive' , '1';
GO
RECONFIGURE;
