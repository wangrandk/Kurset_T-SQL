USE master;
GO
DROP DATABASE IF EXISTS SecurityDB;
GO
CREATE DATABASE SecurityDB;
GO
USE SecurityDB;
CREATE TABLE dbo.Medarbejder
(
	MedarbejderId		INT NOT NULL PRIMARY KEY IDENTITY,
	Navn				VARCHAR(40) NOT NULL,
	Adresse				VARCHAR(40) NOT NULL,
	Postnr				SMALLINT NOT NULL,
	Cprnr				CHAR(10) NOT NULL,
	Tlfnr				VARCHAR(20) NULL,
	Initialer			VARCHAR(3) NOT NULL 
						CONSTRAINT ck_Medarbejder_Initialer CHECK (	Initialer = USER_NAME() OR 
																	USER_NAME() = 'dbo')
						CONSTRAINT uq_Medarbejder_Initialer UNIQUE,
	Slettet				BIT NOT NULL DEFAULT(0)
);
GO
CREATE TRIGGER del_Medarbejder ON dbo.Medarbejder
INSTEAD OF DELETE
AS
UPDATE dbo.Medarbejder
	SET Slettet = 1
	WHERE MedarbejderId IN (SELECT MedarbejderId FROM DELETED);
GO
INSERT INTO dbo.Medarbejder (Navn, Adresse, Postnr, Cprnr, Tlfnr, Initialer) VALUES
	('Ane Birthe Christensen', 'Nygade 3', 5000, '2704752892', NULL, 'abc'),
	('Dorthe Emilie Frandsen', 'S�ndergade 12', 8000, '0311891238', '+45 11223344', 'def'),
	('Hans Ivar Jensen', 'Torvet 8', 2000, '0506781235', '55443322', 'hij');
GO
CREATE USER abc WITHOUT LOGIN;
CREATE USER def WITHOUT LOGIN;
CREATE USER hij WITHOUT LOGIN;
GO
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Medarbejder TO abc;
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Medarbejder TO def;
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Medarbejder TO hij;
GO
CREATE SCHEMA Security;
GO
CREATE FUNCTION Security.fn_securitypredicate
(
	@Initialer	SYSNAME,
	@Slettet	BIT
)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS fn_securitypredicate_result 
				WHERE	(USER_NAME() = @Initialer	AND
						 @Slettet = 0)				OR 
						USER_NAME() = 'dbo';
GO
CREATE SECURITY POLICY Saelgerfilter
	ADD FILTER PREDICATE Security.fn_securitypredicate(Initialer, Slettet) 
	ON dbo.Medarbejder
	WITH (STATE = ON);
GO
EXECUTE AS USER = 'abc';
SELECT * 
	FROM dbo.Medarbejder; 
REVERT;

SELECT * 
	FROM dbo.Medarbejder; 
GO
EXECUTE AS USER = 'def';
SELECT * 
	FROM dbo.Medarbejder; 

UPDATE dbo.Medarbejder
	SET Adresse = 'Vestergade 11', Postnr = 5000
	WHERE Initialer = 'def';

SELECT * 
	FROM dbo.Medarbejder; 
REVERT;

SELECT * 
	FROM dbo.Medarbejder;
GO
CREATE USER klm WITHOUT LOGIN;

GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Medarbejder TO klm;
GO
EXECUTE AS USER = 'klm';

INSERT INTO dbo.Medarbejder (Navn, Adresse, Postnr, Cprnr, Initialer) VALUES
	('Karen Lis Mortensen', 'Adelgade 15 2. tv.', 5000, '0102960124', 'klm')

SELECT * 
	FROM dbo.Medarbejder;
REVERT;
GO
CREATE USER nop WITHOUT LOGIN;

GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Medarbejder TO nop;

SELECT USER_NAME();

INSERT INTO dbo.Medarbejder (Navn, Adresse, Postnr, Cprnr, Initialer) VALUES
	('Niels Ole Pedersen', 'Ringvejen 345', 5000, '2712656543', 'nop');

SELECT *
	FROM dbo.Medarbejder;
GO
EXECUTE AS USER = 'abc';
SELECT * 
	FROM dbo.Medarbejder; 

DELETE
	FROM dbo.Medarbejder
	WHERE Initialer = 'abc';

SELECT * 
	FROM dbo.Medarbejder; 
REVERT;

SELECT *
	FROM dbo.Medarbejder;
GO
-- Fejl
EXECUTE AS USER = 'hij';
SELECT * 
	FROM dbo.Medarbejder; 

UPDATE dbo.Medarbejder
	SET Tlfnr = '+45 22 88 44 11'
	WHERE Initialer = 'klm';

SELECT * 
	FROM dbo.Medarbejder; 
REVERT;

SELECT * 
	FROM dbo.Medarbejder;
GO
CREATE USER rst WITHOUT LOGIN;

GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Medarbejder TO rst;
GO
EXECUTE AS USER = 'klm';

INSERT INTO dbo.Medarbejder (Navn, Adresse, Postnr, Cprnr, Initialer) VALUES
	('Rasmus Severin Thomsen', 'Knudsgade 52', 4000, '0407583217', 'rst')

SELECT * 
	FROM dbo.Medarbejder;
REVERT;

SELECT *
	FROM dbo.Medarbejder;
GO
