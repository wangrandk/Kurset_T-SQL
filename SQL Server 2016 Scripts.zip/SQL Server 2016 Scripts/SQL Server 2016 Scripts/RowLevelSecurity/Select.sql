USE master;
GO
DROP DATABASE IF EXISTS SecurityDB;
GO
CREATE DATABASE SecurityDB;
GO
USE SecurityDB;
CREATE USER Chef WITHOUT LOGIN;
CREATE USER Saelger1 WITHOUT LOGIN;
CREATE USER Saelger2 WITHOUT LOGIN;
GO
CREATE TABLE dbo.Kunde
(
	KundeId				INT,
	Saelgernavn			SYSNAME,
	Kundenavn			VARCHAR(40)
);
GO
INSERT dbo.Kunde VALUES 
	(1, 'Saelger1', 'Olsen & S�n'), 
	(2, 'Saelger1', 'Petersen og Pedersen'), 
	(3, 'Saelger1', 'Malermesteren Aps'),
	(4, 'Saelger1', 'Ole Jensen'), 
	(5, 'Saelger2', 'Ane Hansen'), 
	(6, 'Saelger2', 'Maren Carlsen');
GO
SELECT * 
	FROM dbo.Kunde;
GO
GRANT SELECT ON dbo.Kunde TO Chef;
GRANT SELECT ON dbo.Kunde TO Saelger1;
GRANT SELECT ON dbo.Kunde TO Saelger2;
GO
CREATE SCHEMA Security;
GO
CREATE FUNCTION Security.fn_securitypredicate
(
	@Saelgernavn	SYSNAME
)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS fn_securitypredicate_result 
				WHERE	USER_NAME() = @Saelgernavn OR 
						USER_NAME() = 'Chef';
GO
SELECT	USER_NAME(),
		SUSER_NAME(),
		SUSER_SNAME(),
		ORIGINAL_LOGIN();
GO 
CREATE SECURITY POLICY Saelgerfilter
	ADD FILTER PREDICATE Security.fn_securitypredicate(Saelgernavn) 
	ON dbo.Kunde
	WITH (STATE = ON);
GO
EXECUTE AS USER = 'Saelger1';
SELECT * 
	FROM dbo.Kunde; 
REVERT;

EXECUTE AS USER = 'Saelger2';
SELECT * 
	FROM dbo.Kunde; 
REVERT;

EXECUTE AS USER = 'Chef';
SELECT * 
	FROM dbo.Kunde; 
REVERT;
GO
ALTER SECURITY POLICY Saelgerfilter
	WITH (STATE = OFF);
GO
DROP USER Chef;
DROP USER Saelger1;
DROP USER Saelger2;

DROP SECURITY POLICY Saelgerfilter;
DROP FUNCTION Security.fn_securitypredicate;

DROP SCHEMA Security;

DROP TABLE dbo.Kunde;
GO
CREATE TABLE dbo.Kunde 
(
	KundeId			INT,
	AppUserId		INT,
	Kundenavn		VARCHAR(40)
);
GO
INSERT dbo.Kunde VALUES 
	(1, 1, 'Olsen & S�n'), 
	(2, 1, 'Petersen og Pedersen'), 
	(3, 1, 'Malermesteren Aps'),
	(4, 1, 'Ole Jensen'), 
	(5, 2, 'Ane Hansen'), 
	(6, 2, 'Maren Carlsen');
GO
CREATE PROCEDURE dbo.sp_setContextInfoAsAppUserId(@AppUserId INT)
AS 
	SET CONTEXT_INFO @AppUserId;
GO
CREATE SCHEMA Security;
GO
CREATE FUNCTION Security.fn_securitypredicate
(
	@AppUserId		INT
)
	RETURNS TABLE
	WITH SCHEMABINDING
AS
	RETURN SELECT 1 AS fn_securitypredicate_result
				WHERE	DATABASE_PRINCIPAL_ID() = DATABASE_PRINCIPAL_ID('dbo')  AND	-- application context
						CONVERT(INT, CONVERT(VARBINARY(4), CONTEXT_INFO())) = @AppUserId; 
GO
CREATE SECURITY POLICY Security.Saelgerfilter
	ADD FILTER PREDICATE Security.fn_securitypredicate(AppUserId) ON dbo.Kunde
	WITH (STATE = ON);
GO
EXEC sp_setContextInfoAsAppUserId 1;

SELECT * 
	FROM dbo.Kunde;

GO
EXEC sp_setContextInfoAsAppUserId 2;

SELECT * 
	FROM dbo.Kunde;
GO
