USE master;
GO
DROP DATABASE IF EXISTS SecurityDB;
GO
CREATE DATABASE SecurityDB;
GO
USE SecurityDB;
CREATE USER Chef WITHOUT LOGIN;
CREATE USER Saelger1 WITHOUT LOGIN;
CREATE USER Saelger2 WITHOUT LOGIN;
GO
CREATE TABLE dbo.Kunde
(
	KundeId				INT,
	Saelgernavn			SYSNAME,
	Kundenavn			VARCHAR(40)
);
GO
INSERT dbo.Kunde VALUES 
	(1, 'Saelger1', 'Olsen & S�n'), 
	(2, 'Saelger1', 'Petersen og Pedersen'), 
	(3, 'Saelger1', 'Malermesteren Aps'),
	(4, 'Saelger1', 'Ole Jensen'), 
	(5, 'Saelger2', 'Ane Hansen'), 
	(6, 'Saelger2', 'Maren Carlsen');
GO
SELECT * 
	FROM dbo.Kunde;
GO
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Kunde TO Chef;
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Kunde TO Saelger1;
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Kunde TO Saelger2;
GO
CREATE SCHEMA Security;
GO
CREATE FUNCTION Security.fn_securitypredicate
(
	@Saelgernavn	SYSNAME
)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS fn_securitypredicate_result 
				WHERE	USER_NAME() = @Saelgernavn OR 
						USER_NAME() = 'Chef';
GO
CREATE SECURITY POLICY Saelgerfilter
	ADD FILTER PREDICATE Security.fn_securitypredicate(Saelgernavn) ON dbo.Kunde,
	ADD BLOCK PREDICATE Security.fn_securitypredicate(Saelgernavn)  ON dbo.Kunde
	--ADD BLOCK PREDICATE Security.fn_securitypredicate(Saelgernavn)  ON dbo.Kunde AFTER INSERT
	--ADD BLOCK PREDICATE Security.fn_securitypredicate(Saelgernavn)  ON dbo.Kunde AFTER DELETE
	--ADD BLOCK PREDICATE Security.fn_securitypredicate(Saelgernavn)  ON dbo.Kunde AFTER UPDATE
	WITH (STATE = ON);
GO
EXECUTE AS USER = 'Saelger1';
SELECT * 
	FROM dbo.Kunde; 
REVERT;

EXECUTE AS USER = 'Saelger2';
SELECT * 
	FROM dbo.Kunde; 
REVERT;

EXECUTE AS USER = 'Chef';
SELECT * 
	FROM dbo.Kunde; 
REVERT;
GO
EXECUTE AS USER = 'Saelger1';
DELETE
	FROM dbo.Kunde
	WHERE KundeId = 1;
	
DELETE
	FROM dbo.Kunde
	WHERE Kundeid = 6;
	
SELECT * 
	FROM dbo.Kunde;  
REVERT;
GO
EXECUTE AS USER = 'Saelger2';
UPDATE dbo.Kunde
	SET Kundenavn = 'Maren Marie Carlsen'
	WHERE KundeId = 6;

UPDATE dbo.Kunde
	SET Kundenavn = 'Petersen & Pedersen'
	WHERE KundeId = 2;

SELECT * 
	FROM dbo.Kunde; 
REVERT;
GO
EXECUTE AS USER = 'Saelger2';
INSERT dbo.Kunde VALUES 
	(7, 'Saelger2', 'Knud Hansen');

INSERT dbo.Kunde VALUES 
	(8, 'Saelger1', 'Fie Andersen');

SELECT * 
	FROM dbo.Kunde; 
REVERT;
GO
USE master;
GO
DROP DATABASE SecurityDB;
GO
CREATE DATABASE SecurityDB;
GO
USE SecurityDB;
CREATE USER Chef WITHOUT LOGIN;
CREATE USER Saelger1 WITHOUT LOGIN;
CREATE USER Saelger2 WITHOUT LOGIN;
GO
CREATE TABLE dbo.Kunde
(
	KundeId				INT,
	Saelgernavn			SYSNAME,
	Kundenavn			VARCHAR(40),
	SidstAktivAar		SMALLINT
);
GO
INSERT dbo.Kunde VALUES 
	(1, 'Saelger1', 'Olsen & S�n', 2014), 
	(2, 'Saelger1', 'Petersen og Pedersen', 2015), 
	(3, 'Saelger1', 'Malermesteren Aps', 2013),
	(4, 'Saelger1', 'Ole Jensen', 2015), 
	(5, 'Saelger2', 'Ane Hansen', 2015), 
	(6, 'Saelger2', 'Maren Carlsen', 2014);
GO
SELECT * 
	FROM dbo.Kunde;
GO
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Kunde TO Chef;
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Kunde TO Saelger1;
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.Kunde TO Saelger2;
GO
CREATE SCHEMA Security;
GO
CREATE FUNCTION Security.fn_securitypredicate
(
	@Saelgernavn	SYSNAME,
	@Aar			SMALLINT
)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS fn_securitypredicate_result 
				WHERE	(USER_NAME() = @Saelgernavn AND
						@Aar = YEAR(SYSDATETIME()) )OR 
						USER_NAME() = 'Chef';
GO
CREATE SECURITY POLICY Saelgerfilter
	ADD FILTER PREDICATE Security.fn_securitypredicate(Saelgernavn, SidstAktivAar) 
	ON dbo.Kunde
	WITH (STATE = ON);
GO
EXECUTE AS USER = 'Saelger1';
SELECT * 
	FROM dbo.Kunde; 
REVERT;

EXECUTE AS USER = 'Saelger2';
SELECT * 
	FROM dbo.Kunde; 
REVERT;

EXECUTE AS USER = 'Chef';
SELECT * 
	FROM dbo.Kunde; 
REVERT;
