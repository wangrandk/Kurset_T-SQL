USE master;
DROP DATABASE IF EXISTS DatamaskingDB;
GO
CREATE DATABASE DatamaskingDB;
GO
USE DatamaskingDB;
GO
CREATE TABLE dbo.Data
(
	DataId				INT IDENTITY PRIMARY KEY,
	Fornavn				VARCHAR(20) MASKED WITH (FUNCTION = 'partial(1, "xxx", 0)') NOT NULL,
	Efternavn			VARCHAR(20) MASKED WITH (FUNCTION = 'partial(2, "xxxxxx", 2)') NOT NULL,
	Gade				VARCHAR(30) MASKED WITH (FUNCTION = 'default()') NULL,
	Postnr				SMALLINT  MASKED WITH (FUNCTION = 'default()') NULL,
	Tlfnr				VARCHAR(12) MASKED WITH (FUNCTION = 'default()') NOT NULL,
	Beloeb				INT MASKED WITH (FUNCTION = 'random(0, 100)') NULL,
	EMail				VARCHAR(100) MASKED WITH (FUNCTION = 'email()') NULL,
	Oprettelsesdato		DATE MASKED WITH (FUNCTION = 'default()') DEFAULT (SYSDATETIME()) NOT NULL
);
GO
INSERT INTO dbo.Data (Fornavn, Efternavn, Gade, Postnr, Tlfnr, Beloeb, EMail) VALUES 
	('Peter', 'Chrstensen', '�stergade 4', 2000, '44337722', 1234567,  'PeterChristensen@Firma.com'),
	('Emma', 'Petersen', 'Vestergade 23', 2000,  '+45 33442277', 7654321, 'EmmaPetersen@Firma.com'),
	('Jens Christian', 'Knudsen', 'Torvet 11', 8000,  '22 33 88 22', NULL, 'JCKnu@Firma.com'),
	('Lars Erik', 'Poulsen', NULL, NULL,  '+45 47471111', 345,  'Lepo@Firma.com'),
	('Karina Louise', 'Petersen', 'S�ndergade 4', 3000,  '+45 33442277', NULL, 'KarinaLouise@Firma.com'),
	('Louise', 'Bie', 'Hovedgaden 44', 2000,  '+45 33441177', NULL, 'LouiseB@Firma.com'),
	('Per', 'Bihe', 'Vestergade 12', 2000,  '+45 11441188', NULL, 'PerBihe@Firma.de'),
	('Hanne', 'Biger', 'Nygade 3', 4000,  '+45 55554466', NULL, 'HanneBirger@Firma.dk'),
	('Lars', 'Bagger', 'Stien 2', 3000,  '+45 11228855', NULL, 'LarsBagger@Firma.dk');
GO
SELECT * 
	FROM dbo.Data;
GO
CREATE USER TestUser WITHOUT LOGIN;
GRANT SELECT ON dbo.Data TO TestUser;

EXECUTE AS USER = 'TestUser';
SELECT * 
	FROM dbo.Data;
REVERT;
GO
GRANT UNMASK TO TestUser;
EXECUTE AS USER = 'TestUser';
SELECT * 
	FROM dbo.Data;
REVERT; 

-- Removing the UNMASK permission
REVOKE UNMASK TO TestUser;
GO
ALTER TABLE dbo.Data 
	ALTER COLUMN Fornavn DROP MASKED;
GO
EXECUTE AS USER = 'TestUser';
SELECT * 
	FROM dbo.Data;
REVERT; 
