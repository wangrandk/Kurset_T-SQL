USE master
GO
DROP DATABASE IF EXISTS ColumnStoreDB;
GO
CREATE DATABASE ColumnStoreDB;
GO
USE ColumnStoreDB;

CREATE TABLE dbo.Efternavn 
(
	Efternavn 		VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Fornavn 
(
	Fornavn 		VARCHAR(50) NOT NULL,
	Koen			CHAR(1) NOT NULL
);

CREATE TABLE dbo.Gade 
(
	Gade 			VARCHAR(30) NOT NULL
);

CREATE TABLE dbo.Postopl 
(
	PostNr 			SMALLINT		NOT NULL 
					CONSTRAINT PK_Postopl PRIMARY KEY (PostNr),
	Bynavn 			VARCHAR (20)	NOT NULL,
);

CREATE TABLE dbo.KundeType 
(
	KundeTypeKode	CHAR(1)			NOT NULL 
					CONSTRAINT PK_KundeTypeKode PRIMARY KEY,
	KundeTypeTxt	VARCHAR(20)		NOT NULL
);

CREATE TABLE dbo.Koen 
(
	KoenKode		CHAR(1)			NOT NULL 
					CONSTRAINT PK_Koen PRIMARY KEY,
	KoenText		VARCHAR(10)		NOT NULL
);

CREATE TABLE dbo.Kunde 
(
	KundeID 		INT 
					IDENTITY(1, 1)	NOT NULL,
	Fornavn 		VARCHAR(20)		NOT NULL,
	Efternavn 		VARCHAR(20)		NOT NULL,
	Gade 			VARCHAR(30)		NOT NULL,
	Postnr 			SMALLINT		NOT NULL,
	KundeTypeKode	CHAR(1)			NOT NULL
					CONSTRAINT FK_Kunde_KundeTypeKode REFERENCES dbo.KundeType(KundeTypeKode),
	KoenKode		CHAR(1)			NULL
					CONSTRAINT FK_Kunde_Koen REFERENCES dbo.Koen(KoenKode)
);
GO
SET NOCOUNT ON;
IF (SELECT COUNT(*) FROM dbo.Fornavn) > 0
	RETURN;

INSERT INTO dbo.Fornavn VALUES 
	('Anne', 'K'),
	('Ane', 'K'),
	('Annemette', 'K'),
	('Anne Mette', 'K'),
	('Anne Marie', 'K'),
	('Anders', 'M'),
	('And', 'M'),
	('Arne', 'M'),
	('Arvid', 'M'),
	('Allan', 'M'),
	('Birte', 'K'),
	('Birthe', 'K'),
	('Bente', 'K'),
	('Bent', 'K'),
	('B�rge', 'M'),
	('Bruno', 'M'),
	('Carl', 'M'),
	('Carina', 'K'),
	('Christian', 'M'),
	('Christina', 'K'),
	('Dorte', 'K'),
	('Dorthe', 'K'),
	('David', 'M'),
	('Daniel', 'M'),
	('Erik', 'M'),
	('Eva', 'K'),
	('Emma', 'K'),
	('Ebba', 'K'),
	('Ebbe', 'M'),
	('Ellen', 'K'),
	('Edvard', 'M'),
	('Edward', 'M'),
	('Egon', 'M'),
	('Esther', 'K'),
	('Frank', 'M'),
	('Frederikke', 'K'),
	('Frede', 'M'),
	('Frode', 'M'),
	('Frida', 'K'),
	('Grete', 'K'),
	('Gitte', 'K'),
	('Grethe', 'K'),
	('Gert', 'M'),
	('Gerd', 'K'),
	('Gunnar', 'M'),
	('Gustav', 'M'),
	('Gudrun', 'K'),
	('Henrik', 'M'),
	('Hans', 'M'),
	('Hanne', 'K'),
	('Henriette', 'K'),
	('Hedvig', 'K'),
	('Henry', 'M'),
	('Hugo', 'M'),
	('Ib', 'M'),
	('Ida', 'K'),
	('Ilse', 'K'),
	('Ivar', 'M'),
	('Ivan', 'M'),
	('Inger', 'K'),
	('Inge', 'K'),
	('Jens', 'M'),
	('Jakob', 'M'),
	('Jacob', 'M'),
	('Jesper', 'M'),
	('Jette', 'K'),
	('Jytte', 'K'),
	('Jane', 'K'),
	('Karl', 'M'),
	('Karen', 'K'),
	('Karin', 'K'),
	('Kis', 'K'),
	('Karina', 'K'),
	('Kurt', 'M'),
	('Knud', 'M'),
	('Kenneth', 'M'),
	('Lars', 'M'),
	('Lars Ole', 'M'),
	('Lars Bo', 'M'),
	('Ludvig', 'M'),
	('Line', 'K'),
	('Lise', 'K'),
	('Lisette', 'K'),
	('Lene', 'K'),
	('Lisbeth', 'K'),
	('Lena', 'K'),
	('Liselotte', 'K'),
	('Lise Lotte', 'K'),
	('Morten', 'M'),
	('Marie', 'K'),
	('Mads', 'M'),
	('Maren', 'K'),
	('Malene', 'K'),
	('Michael', 'M'),
	('Mikael', 'M'),
	('Niels', 'M'),
	('Nis', 'M'),
	('Nicolaj', 'M'),
	('Ninna', 'K'),
	('Nette', 'K'),
	('Nanna', 'K'),
	('Ole', 'M'),
	('Oda', 'K'),
	('Olivia', 'K'),
	('Oskar', 'M'),
	('Ove', 'M'),
	('Peter', 'M'),
	('Per', 'M'),
	('Petrea', 'K'),
	('Peder', 'M'),
	('Pil', 'K'),
	('Poul', 'M'),
	('Paul', 'M'),
	('Poula', 'K'),
	('Rasmus', 'M'),
	('Rie', 'K'),
	('Rikke', 'K'),
	('Richard', 'M'),
	('Rune', 'M'),
	('Ruth', 'K'),
	('Rosa', 'K'),
	('Robert', 'M'),
	('Rositta', 'K'),
	('S�ren', 'M'),
	('Sys', 'K'),
	('Sara', 'K'),
	('Simone', 'K'),
	('Susanne', 'K'),
	('Sanne', 'K'),
	('Sofus', 'M'),
	('Solvej', 'K'),
	('Signe', 'K'),
	('Thomas', 'M'),
	('Tove', 'K'),
	('Tommy', 'M'),
	('Tone', 'K'),
	('Trine', 'K'),
	('Tine', 'K'),
	('Tina', 'K'),
	('Tobias', 'M'),
	('Uffe', 'M'),
	('Ulla', 'K'),
	('Ulrik', 'M'),
	('Vera', 'K'),
	('Villy', 'M'),
	('Vagn', 'M'),
	('Willy', 'M'),
	('Yrsa', 'K'),
	('�jvind', 'M'),
	('�ge', 'M'),
	('�se', 'K');
GO
IF (SELECT COUNT(*) FROM dbo.Efternavn) > 0
	RETURN;

INSERT INTO dbo.Efternavn VALUES 
	('Andersen'),
	('B�rgesen'),
	('Bentsen'),
	('Christensen'),
	('Christiansen'),
	('Carlsen'),
	('Davidsen'),
	('Danielsen'),
	('Eriksen'),
	('Frandsen'),
	('Frederiksen'),
	('Gertsen'),
	('Henriksen'),
	('Hansen'),
	('Iversen'),
	('Ibsen'),
	('Jensen'),
	('Jensen'),
	('Jakobsen'),
	('Jacobsen'),
	('Karlsen'),
	('Knudsen'),
	('Kristensen'),
	('Larsen'),
	('Lassen'),
	('Mortensen'),
	('Madsen'),
	('Mikkelsen'),
	('Nielsen'),
	('Nyborg'),
	('Olsen'),
	('Olesen'),
	('Pedersen'),
	('Petersen'),
	('Rasmussen'),
	('S�rensen'),
	('Thomsen'),
	('�vlisen'),
	('�gesen'),
	('�berg');
GO
IF (SELECT COUNT(*) FROM dbo.Gade) > 0
	RETURN

INSERT INTO dbo.Gade VALUES 
	('N�rregade 2'),
	('N�rregade 34'),
	('N�rregade 27'),
	('N�rregade 67'),
	('Vestergade 3'),
	('Vestergade 56'),
	('Vestergade 5'),
	('�stergade 23'),
	('�stergade 1'),
	('S�ndergade 6'),
	('S�ndergade 78'),
	('Torvet 2'),
	('Torvet 4'),
	('Runddelen 1'),
	('Ved Stranden 3'),
	('Ved Stranden 5'),
	('Strandvejen 112'),
	('All�gade 29'),
	('Norgesgade 3'),
	('Ungarnsgade 4'),
	('Italiensvej 32'),
	('Strandvejen 2'),
	('All�gade 5'),
	('Norgesgade 38'),
	('Ungarnsgade 7'),
	('Italiensvej 21'),
	('Italiensvej 4'),
	('Bragesgade 1'),
	('Bragesgade 12'),
	('Dortesvej 4'),
	('Dortesvej 3'),
	('Ellebjergvej 114'),
	('Ellebjergvej 34'),
	('Ellebjergvej 65'),
	('Ellebjergvej 87'),
	('Frankrigsgade 14'),
	('Frankrigsgade 6'),
	('Frankrigsgade 115'),
	('Helgolandsgade 54'),
	('Helgolandsgade 19'),
	('Helgolandsgade 8'),
	('K�gevej 4'),
	('K�gevej 48'),
	('M�llegade 13'),
	('M�llegade 33'),
	('M�llegade 34'),
	('Ollerupvej 3'),
	('Sct. Pouls Gade 2'),
	('Sct. Pouls Gade 3'),
	('Sct. Pouls Gade 25'),
	('Willemoesgade 2'),
	('Willemoesgade 17');
GO
INSERT INTO dbo.Postopl VALUES 
	(1127, 'K�benhavn K'),
	(1001, 'K�benhavn K'),
	(1129, 'K�benhavn K'),
	(1130, 'K�benhavn K'),
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(8200, 'Aarhus N'),
	(8240, 'Risskov'),
	(8270, 'H�jbjerg'),
	(8310, 'Tranbjerg J'),
	(9000, 'Aalborg'),
	(9400, 'N�rresundby'),
	(9600, 'Br�nderslev'),
	(9800, 'Hj�rring'),
	(9990, 'Skagen'),
	(3400, 'Hiller�d'),
	(3050, 'Humleb�k'),
	(2600, 'Glostrup'),
	(2605, 'Br�ndby'),
	(2610, 'R�dovre'),
	(2620, 'Albertslund'),
	(2625, 'Vallensb�k'),
	(2630, 'Taastrup'),
	(2635, 'Ish�j'),
	(2640, 'Hedehusene'),
	(2650, 'Hvidovre'),
	(2660, 'Br�ndby Strand'),
	(2665, 'Vallensb�k Strand'),
	(2670, 'Greve'),
	(2680, 'Solr�d Strand'),
	(2800, 'Kongens Lyngby'),
	(2820, 'Gentofte'),
	(2830, 'Virum'),
	(2840, 'Holte'),
	(2850, 'N�rum'),
	(2860, 'S�borg'),
	(2870, 'Dysseg�rd'),
	(2880, 'Bagsv�rd'),
	(2900, 'Hellerup'),
	(2920, 'Charlottenlund'),
	(2930, 'Klampenborg'),
	(2942, 'Skodsborg'),
	(2950, 'Vedb�k'),
	(5000, 'Odense C'),
	(5220, 'Odense S�'),
	(5700, 'Svendborg'),
	(2300, 'K�benhavn S'),
	(6051, 'Almind'),
	(6000, 'Kolding'),
	(6950, 'Ringk�bing'),
	(8700, 'Horsens');
GO
INSERT INTO dbo.KundeType VALUES
	('A', 'Almindelig'),
	('B', 'Firma'),
	('C', 'Storkunde'),
	('D', 'Ung - 14-18'),
	('E', 'Barn - 0-13');
GO
CREATE CLUSTERED INDEX cl_Fornavn ON dbo.Fornavn (Fornavn);
CREATE CLUSTERED INDEX cl_Efternavn ON dbo.Efternavn (Efternavn);
CREATE CLUSTERED INDEX cl_Gade ON dbo.Gade (Gade);
CREATE NONCLUSTERED INDEX nc_Postopl_Bynavn ON dbo.Postopl (Bynavn);
GO
INSERT INTO dbo.Koen VALUES 
	('K', 'Kvinde'),
	('M', 'Mand');
GO
SET NOCOUNT OFF;
GO
INSERT INTO dbo.Kunde (Fornavn, Efternavn, Gade, Postnr, KoenKode, KundeTypeKode)
   SELECT	Fornavn, 
			Efternavn, 
			Gade, 
			Postnr, 
			Koen, 
			'A'
      FROM dbo.Fornavn	INNER JOIN dbo.Efternavn		ON Fornavn.Fornavn > Efternavn.Efternavn
						INNER JOIN dbo.Gade				ON Efternavn.Efternavn > Gade.Gade
						INNER JOIN dbo.Postopl			ON Gade.Gade <> Postopl.Bynavn
      WHERE LEN(Fornavn) + LEN(Efternavn) < 13;

--INSERT INTO dbo.Kunde (Fornavn, Efternavn, Gade, Postnr, KoenKode, KundeTypeKode)
--   SELECT	Fornavn, 
--			Efternavn, 
--			Gade, 
--			Postnr, 
--			Koen, 
--			'A'
--      FROM dbo.Fornavn	 INNER JOIN dbo.Efternavn		ON Fornavn.Fornavn < Efternavn.Efternavn
--						INNER JOIN dbo.Gade				ON Efternavn.Efternavn < Gade.Gade
--						INNER JOIN dbo.Postopl			ON Gade.Gade < Postopl.Bynavn;
GO
UPDATE dbo.Kunde
	SET KundeTypeKode = 'B'
	WHERE KundeID % 95 = 1;

UPDATE dbo.Kunde
	SET KundeTypeKode = 'C'
	WHERE KundeID % 997 = 1;

UPDATE dbo.Kunde
	SET KundeTypeKode = 'D'
	WHERE KundeID % 9999 = 1;

UPDATE dbo.Kunde
	SET KoenKode = NULL
	WHERE KundeID % 37834 = 1;
GO
CREATE CLUSTERED COLUMNSTORE INDEX cci_Kunde
	ON dbo.Kunde;
GO
CREATE UNIQUE NONCLUSTERED INDEX nc_Kunde_Kundeid 
	ON dbo.Kunde (KundeId);

CREATE NONCLUSTERED INDEX nc_Person_Fornavn_Efternavn
	ON dbo.Kunde (Fornavn, Efternavn) INCLUDE (Gade, Postnr);
GO
SELECT	Fornavn,
		Efternavn,
		Gade,
		Postnr
	FROM dbo.Kunde
	WHERE	Fornavn = 'Hans' AND
			Efternavn = 'Olsen';

SELECT	COUNT(*)
	FROM dbo.Kunde
	WHERE	Efternavn = 'Olsen' AND 
			Postnr = 8000;
GO
INSERT INTO dbo.Kunde (Fornavn, Efternavn, Gade, Postnr, KoenKode, KundeTypeKode)
   SELECT	Fornavn, 
			Efternavn, 
			Gade, 
			Postnr, 
			Koen, 
			'A'
      FROM dbo.Fornavn	INNER JOIN dbo.Efternavn	ON Fornavn.Fornavn > Efternavn.Efternavn
						INNER JOIN dbo.Gade			ON Efternavn.Efternavn < Gade.Gade
						INNER JOIN dbo.Postopl		ON Gade.Gade > Postopl.Bynavn
      WHERE LEN(Fornavn) + LEN(Efternavn) > 16;
GO
ALTER INDEX cci_Kunde
	ON dbo.Kunde REBUILD;
GO
DROP INDEX cci_Kunde
	ON dbo.Kunde;

CREATE NONCLUSTERED COLUMNSTORE INDEX ncci_Kunde_Postnr
	ON dbo.Kunde (Postnr)
	WHERE Postnr > 6000;
GO
TRUNCATE TABLE dbo.Kunde;
