 DECLARE @JSalesOrderDetails NVARCHAR(4000) = 
			'{"OrdersArray": [
			   {"Nummer":1, "Dato": "08/10/2016", "Kunde": "Jens Hansen", "Antal": 120},
			   {"Nummer":4, "Dato": "05/11/2016", "Kunde": "Jens Hansen", "Antal": 100},
			   {"Nummer":6, "Dato": "01/03/2016", "Kunde": "Jens Hansen", "Antal": 250},
			   {"Nummer":8, "Dato": "12/07/2016", "Kunde": "Jens Hansen", "Antal": 220}
			]}';

SELECT	Nummer, 
		Kunde, 
		Dato, 
		Antal

	FROM OPENJSON (@JSalesOrderDetails, '$.OrdersArray')
		WITH	(
				Nummer		VARCHAR(200), 
				Dato		DATETIME,
				Kunde		VARCHAR(200),
				Antal		INT
				) AS OrdersArray;
