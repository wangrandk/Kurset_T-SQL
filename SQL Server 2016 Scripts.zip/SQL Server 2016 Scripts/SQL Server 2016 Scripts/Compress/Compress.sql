USE master;
GO
DROP DATABASE IF EXISTS CompressDB;
GO
CREATE DATABASE CompressDB;
GO
USE CompressDB;
CREATE TABLE dbo.Compressdata
(
	ID					INT NOT NULL PRIMARY KEY IDENTITY,
	CompressedData		VARBINARY(MAX) NOT NULL,
	UnCompressedData	VARCHAR(MAX) NOT NULL
);
GO
INSERT INTO dbo.Compressdata (CompressedData, UnCompressedData) VALUES
	(COMPRESS(REPLICATE(CAST('1234567890' AS VARCHAR(MAX)), 200000)), REPLICATE(CAST('1234567890' AS VARCHAR(MAX)), 200000));
GO 
SELECT	ID,
		CompressedData,
		UnCompressedData
	FROM dbo.Compressdata;
GO
SELECT	ID,
		CAST(DECOMPRESS(CompressedData) AS VARCHAR(MAX)) AS CompressedData_UnCompressed,
		UnCompressedData
	FROM dbo.Compressdata;
GO
SELECT	ID,
		DATALENGTH(CompressedData),
		DATALENGTH(UnCompressedData),
		DATALENGTH(CAST(DECOMPRESS(CompressedData) AS VARCHAR(MAX)))
	FROM dbo.Compressdata;
GO
CREATE FULLTEXT CATALOG FulltextDB_Catalog 
	WITH ACCENT_SENSITIVITY = ON
	AS DEFAULT;
GO
CREATE TABLE dbo.t_worddoc 
(
	ID			INT NOT NULL CONSTRAINT PK__t_worddoc PRIMARY KEY IDENTITY,
	Blob		VARBINARY(MAX),
	BlobType	VARCHAR(10) NOT NULL
);
GO
INSERT INTO dbo.t_worddoc (Blob, BlobType)
	SELECT d.blob, '.doc' 
		FROM OPENROWSET( BULK 'E:\SQL Server 2016 Scripts\Compress\CompressDesc.doc', SINGLE_BLOB) AS d(blob);
GO
INSERT INTO dbo.t_worddoc (Blob, BlobType)
	SELECT COMPRESS(d.blob), '.doc' 
		FROM OPENROWSET( BULK 'E:\SQL Server 2016 Scripts\Compress\CompressDesc.doc', SINGLE_BLOB) AS d(blob);
GO
CREATE FULLTEXT INDEX ON dbo.t_worddoc(Blob TYPE COLUMN BlobType)
	KEY INDEX PK__t_worddoc;
GO
SELECT ID 
	FROM dbo.t_worddoc 
	WHERE CONTAINS (Blob, 'DECOMPRESS');
GO
