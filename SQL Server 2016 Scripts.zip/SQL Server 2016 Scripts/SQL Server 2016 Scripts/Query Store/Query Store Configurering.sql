USE QueryStoreDB
GO
ALTER DATABASE QueryStoreDB 
SET QUERY_STORE 
(
    OPERATION_MODE = READ_WRITE,
    CLEANUP_POLICY = 
    (STALE_QUERY_THRESHOLD_DAYS = 30),
    DATA_FLUSH_INTERVAL_SECONDS = 3000,
    MAX_STORAGE_SIZE_MB = 500,
    INTERVAL_LENGTH_MINUTES = 15,
    SIZE_BASED_CLEANUP_MODE = AUTO,
    QUERY_CAPTURE_MODE = AUTO
);
GO
SELECT	Txt.query_text_id, 
		Txt.query_sql_text, 
		Pl.*, 
		Qry.*
	FROM sys.query_store_plan AS Pl INNER JOIN sys.query_store_query AS Qry ON Pl.query_id = Qry.query_id
									INNER JOIN sys.query_store_query_text AS Txt ON Qry.query_text_id = Txt.query_text_id
	WHERE Txt.query_text_id = 69;
