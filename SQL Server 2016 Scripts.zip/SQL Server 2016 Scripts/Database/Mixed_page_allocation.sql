USE master;
GO
DROP DATABASE IF EXISTS MixedPageDB;
GO
USE master;
GO
DROP DATABASE IF EXISTS MixedPageDB;
GO
CREATE DATABASE MixedPageDB
ON  PRIMARY
	(Name = N'MixedPageDB', 
	FILENAME = N'C:\Databaser\MixedPageDB.mdf',
	SIZE = 9192KB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 2048KB)

LOG ON
	(Name = N'MixedPageDB_log',
	FILENAME = N'C:\Databaser\MixedPageDB_log.ldf',
	SIZE = 1024KB,
	MAXSIZE = 2048GB,
	FILEGROWTH = 10%);
GO
USE MixedPageDB;
GO
ALTER DATABASE MixedPageDB SET MIXED_PAGE_ALLOCATION ON;
GO
CREATE TABLE dbo.t1 
(
	Txt	CHAR(800)
);
CREATE TABLE dbo.t2 
(
	Txt	CHAR(400)
);
GO
SET NOCOUNT ON;
GO
INSERT dbo.t1 
	VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');

INSERT dbo.t2
	VALUES ('yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy');
GO 50
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		*
	FROM dbo.t1;

SELECT DISTINCT value AS Page
	FROM (
	SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
			*
		FROM dbo.t1 CROSS APPLY 
				string_split(RTRIM(sys.fn_PhysLocFormatter(%%physloc%%)), ':')) AS t
	WHERE	LEFT(value, 1) <> '(' AND
			RIGHT(value, 1) <> ')' 
	ORDER BY page;
GO
----------------------------------------------------------------------
USE master;
GO
DROP DATABASE IF EXISTS MixedPageDB;
GO
CREATE DATABASE MixedPageDB
ON  PRIMARY
	(Name = N'MixedPageDB', 
	FILENAME = N'C:\Databaser\MixedPageDB.mdf',
	SIZE = 8MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 64MB)

LOG ON
	(Name = N'MixedPageDB_log',
	FILENAME = N'C:\Databaser\MixedPageDB_log.ldf',
	SIZE = 8MB,
	MAXSIZE = 64MB,
	FILEGROWTH = 10%);
GO
USE MixedPageDB;
GO
ALTER DATABASE MixedPageDB SET MIXED_PAGE_ALLOCATION OFF;
GO
CREATE TABLE dbo.t1 
(
	Txt	CHAR(800)
);
CREATE TABLE dbo.t2 
(
	Txt	CHAR(400)
);
GO
SET NOCOUNT ON;
GO
INSERT dbo.t1 
	VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');

INSERT dbo.t2
	VALUES ('yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy');
GO 50
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
		*
	FROM dbo.t1;

SELECT DISTINCT value AS Page
	FROM (
	SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS [Physical RID],
			*
		FROM dbo.t1 CROSS APPLY 
				string_split(RTRIM(sys.fn_PhysLocFormatter(%%physloc%%)), ':')) AS t
	WHERE	LEFT(value, 1) <> '(' AND
			RIGHT(value, 1) <> ')' 
	ORDER BY page;
