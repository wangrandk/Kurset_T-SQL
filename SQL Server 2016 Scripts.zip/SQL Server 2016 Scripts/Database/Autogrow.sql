USE master;
GO
DROP DATABASE IF EXISTS AutogrowDB;
GO
CREATE DATABASE AutogrowDB
ON  PRIMARY
	(Name = N'AutogrowDB', 
	FILENAME = N'C:\Databaser\AutogrowDB.mdf',
	SIZE = 8MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 64MB),

FILEGROUP fg1
	(Name = N'AutogrowDB_fg1_1',
	FILENAME = N'C:\Databaser\AutogrowDB_fg1_1.ndf',
	SIZE = 1MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 64MB),

	(Name = N'AutogrowDB_fg1_2',
	FILENAME = N'C:\Databaser\AutogrowDB_fg1_2.ndf',
	SIZE = 1MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 64MB),

	(Name = N'AutogrowDB_fg1_3',
	FILENAME = N'C:\Databaser\AutogrowDB_fg1_3.ndf',
	SIZE = 1MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 64MB),

FILEGROUP fg2
	(Name = N'AutogrowDB_fg2_1',
	FILENAME = N'C:\Databaser\AutogrowDB_fg2_1.ndf',
	SIZE = 1MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 64MB),

	(Name = N'AutogrowDB_fg2_2',
	FILENAME = N'C:\Databaser\AutogrowDB_fg2_2.ndf',
	SIZE = 1MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 64MB),

	(Name = N'AutogrowDB_fg2_3',
	FILENAME = N'C:\Databaser\AutogrowDB_fg2_3.ndf',
	SIZE = 1MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 64MB)

LOG ON
	(Name = N'AutogrowDB_log',
	FILENAME = N'C:\Databaser\AutogrowDB_log.ldf',
	SIZE = 10MB,
	MAXSIZE = 64MB,
	FILEGROWTH = 10%);
GO
USE AutogrowDB;
GO
SELECT	name, 
		(size*8)/1024 'Size in MB' 
	FROM AutogrowDB.sys.database_files;
GO
CREATE TABLE dbo.t1 
(
	Txt	CHAR(8000)
) ON fg1;
GO
INSERT dbo.t1 
	VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
GO 500
SELECT	name, 
		(size*8)/1024 'Size in MB' 
	FROM AutogrowDB.sys.database_files;
GO
ALTER DATABASE AutogrowDB MODIFY FILEGROUP fg2 AUTOGROW_ALL_FILES;
GO
SELECT	name, 
		(size*8)/1024 'Size in MB' 
	FROM AutogrowDB.sys.database_files;
GO
CREATE TABLE dbo.t2 
(
	Txt	CHAR(8000)
) ON fg2;
GO
INSERT dbo.t2
	VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
GO 500
SELECT	name, 
		(size*8)/1024 'Size in MB' 
	FROM AutogrowDB.sys.database_files;
GO
