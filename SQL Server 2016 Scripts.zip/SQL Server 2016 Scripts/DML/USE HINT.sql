USE master;
GO
DROP DATABASE IF EXISTS TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB
DROP TABLE IF EXISTS dbo.Person;
GO
CREATE TABLE dbo.Postopl
(
	Postnr		SMALLINT NOT NULL PRIMARY KEY,
	Bynavn		VARCHAR(20) NOT NULL,
);

CREATE TABLE dbo.Person
(
	Id			INT NOT NULL IDENTITY PRIMARY KEY,
	Fornavn		VARCHAR(20) NOT NULL,
	Efternavn	VARCHAR(20) NOT NULL,
	Adresse		VARCHAR(30) NOT NULL,
	Postnr		SMALLINT NOT NULL FOREIGN KEY REFERENCES dbo.Postopl,
	Initialer	VARCHAR(5) NOT NULL
);
GO
INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(9000, 'Aalborg');
GO
INSERT INTO dbo.Person VALUES 
	('Ida', 'Hansen', 'Nygade 3', 2000, 'IHA'),
	('Ole', 'Olsen', 'Vestergade 23', 9000, 'OlOl'),
	('Per', 'Jensen', 'S�ndergade 7', 8000, 'pej');
GO 10

SELECT	p1.*, 
		p2.Fornavn
	FROM dbo.Person AS p1 INNER JOIN dbo.Person AS p2 ON p1.Fornavn = p2.Fornavn;

SELECT	p1.*, 
		p2.Fornavn
	FROM dbo.Person AS p1 INNER JOIN dbo.Person AS p2 ON p1.Fornavn = p2.Fornavn
	OPTION (USE HINT('FORCE_LEGACY_CARDINALITY_ESTIMATION'));
