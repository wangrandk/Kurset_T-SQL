USE master;
DROP DATABASE PartitionDB;
GO
CREATE DATABASE PartitionDB
ON PRIMARY
	(NAME = PartitionDB_sys,
	 FILENAME = 'c:\Databaser\PartitionDB_sys.mdf',
     SIZE = 5MB),

FILEGROUP PartitionDB_fg1
	(NAME = PartitionDB_fg1,
	 FILENAME = 'c:\Databaser\PartitionDB_fg1.ndf',
     SIZE = 2MB),
	
FILEGROUP PartitionDB_fg2
	(NAME = PartitionDB_fg2,
	 FILENAME = 'c:\Databaser\PartitionDB_fg2.ndf',
     SIZE = 2MB),
	
FILEGROUP PartitionDB_fg3
	(NAME = PartitionDB_fg3,
	 FILENAME = 'c:\Databaser\PartitionDB_fg3.ndf',
     SIZE = 2MB),
	
FILEGROUP PartitionDB_fg4
	(NAME = PartitionDB_fg4,
	 FILENAME = 'c:\Databaser\PartitionDB_fg4.ndf',
     SIZE = 2MB),
	
FILEGROUP PartitionDB_fg5
	(NAME = PartitionDB_fg5,
	 FILENAME = 'c:\Databaser\PartitionDB_fg5.ndf',
     SIZE = 2MB),
	
FILEGROUP PartitionDB_fg6
	(NAME = PartitionDB_fg6,
	 FILENAME = 'c:\Databaser\PartitionDB_fg6.ndf',
     SIZE = 2MB)

LOG ON
	(NAME = PartitionDB_log,
	 FILENAME = 'c:\Databaser\PartitionDB.ldf',
     SIZE = 5MB);
GO
USE PartitionDB
CREATE PARTITION FUNCTION PartitionFunction (DATE)
	AS RANGE RIGHT FOR VALUES (	'2016-2-1', 
								'2016-3-1', 
								'2016-4-1', 
								'2016-5-1', 
								'2016-6-1');
GO
CREATE PARTITION scheme PartitionScheme
	AS Partition PartitionFunction TO (	PartitionDB_fg1, 
										PartitionDB_fg2, 
										PartitionDB_fg3, 
										PartitionDB_fg4, 
										PartitionDB_fg5, 
										PartitionDB_fg6);
GO
CREATE TABLE dbo.PartitionTable 
(
	Id			INT NOT NULL IDENTITY, 
	Navn		CHAR(10) NOT NULL,
	Tid			DATE NOT NULL,
	Maaned		AS MONTH(Tid) PERSISTED,
	INDEX nc_PartitionTable_Tid_Id (Tid, ID)
) ON PartitionScheme (Tid);
GO
INSERT INTO dbo.PartitionTable (Navn, Tid) 
	OUTPUT INSERTED.*
	VALUES 
	('Ole', '2016-1-2'),
	('Per', '2016-1-22'),
	('Ida', '2016-2-3'),
	('Ane', '2016-2-14'),
	('Mie', '2016-3-5'),
	('Eva', '2016-3-6'),
	('Dea', '2016-4-7'),
	('Jan', '2016-4-5'),
	('Fie', '2016-5-2'),
	('Oda', '2016-5-29'),
	('Elo', '2016-6-5'),
	('Tom', '2016-6-6');
GO
SELECT	$partition.PartitionFunction(Tid) AS Partition, 
		COUNT(*) AS antal
	FROM dbo.PartitionTable 
	GROUP BY $partition.PartitionFunction(Tid)
	ORDER BY Partition;
GO
TRUNCATE TABLE dbo.PartitionTable
	WITH (PARTITIONS (2, 4 TO 6));

SELECT *
	FROM dbo.PartitionTable;
GO
SELECT	$partition.PartitionFunction(Tid) AS Partition, 
		COUNT(*) AS antal
	FROM dbo.PartitionTable 
	GROUP BY $partition.PartitionFunction(Tid)
	ORDER BY Partition;
GO
INSERT INTO dbo.PartitionTable (Navn, Tid) 
	OUTPUT INSERTED.*
	VALUES 
	('Ole', '2016-1-2'),
	('Per', '2016-1-22'),
	('Ida', '2016-2-3'),
	('Ane', '2016-2-14'),
	('Mie', '2016-3-5'),
	('Eva', '2016-3-6'),
	('Dea', '2016-4-7'),
	('Jan', '2016-4-5'),
	('Fie', '2016-5-2'),
	('Oda', '2016-5-29'),
	('Elo', '2016-6-5'),
	('Tom', '2016-6-6');
GO
SELECT *
	FROM dbo.PartitionTable;
GO
SELECT	$partition.PartitionFunction(Tid) AS Partition, 
		COUNT(*) AS antal
	FROM dbo.PartitionTable 
	GROUP BY $partition.PartitionFunction(Tid)
	ORDER BY Partition;
GO
TRUNCATE TABLE dbo.PartitionTable;

SELECT *
	FROM dbo.PartitionTable;
GO
SELECT	$partition.PartitionFunction(Tid) AS Partition, 
		COUNT(*) AS antal
	FROM dbo.PartitionTable 
	GROUP BY $partition.PartitionFunction(Tid)
	ORDER BY Partition;
GO
INSERT INTO dbo.PartitionTable (Navn, Tid) 
	OUTPUT INSERTED.*
	VALUES 
	('Ole', '2016-1-2'),
	('Per', '2016-1-22'),
	('Ida', '2016-2-3'),
	('Ane', '2016-2-14'),
	('Mie', '2016-3-5'),
	('Eva', '2016-3-6'),
	('Dea', '2016-4-7'),
	('Jan', '2016-4-5'),
	('Fie', '2016-5-2'),
	('Oda', '2016-5-29'),
	('Elo', '2016-6-5'),
	('Tom', '2016-6-6');
GO
SELECT *
	FROM dbo.PartitionTable;