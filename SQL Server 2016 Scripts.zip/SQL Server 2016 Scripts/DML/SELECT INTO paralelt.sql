USE IndexDB
GO
SELECT TOP 0 
	   PersonID
      ,Fornavn
      ,Efternavn
      ,Gade
      ,Postnr
      ,Koenkode
      ,Landekode
      ,Tlfnr
      ,Persontype
      ,LandekodeTlfnr
      ,Navn
	INTO dbo.p2
	FROM dbo.Person;

SELECT TOP 0 
	   PersonID
      ,Fornavn
      ,Efternavn
      ,Gade
      ,Postnr
      ,Koenkode
      ,Landekode
      ,Tlfnr
      ,Persontype
      ,LandekodeTlfnr
      ,Navn
	INTO dbo.p3
	FROM dbo.Person;
GO
SET STATISTICS TIME ON;
GO
SELECT TOP 3000000
	   PersonID
      ,Fornavn
      ,Efternavn
      ,Gade
      ,Postnr
      ,Koenkode
      ,Landekode
      ,Tlfnr
      ,Persontype
      ,LandekodeTlfnr
      ,Navn
	INTO dbo.p1
	FROM dbo.Person;
GO
SET IDENTITY_INSERT dbo.p2 ON;
GO
INSERT INTO dbo.p2 WITH(TABLOCK)
				(PersonID
				,Fornavn
				,Efternavn
				,Gade
				,Postnr
				,Koenkode
				,Landekode
				,Tlfnr
				,Persontype
				,LandekodeTlfnr
				,Navn)
	SELECT	 TOP 3000000
			 PersonID
			,Fornavn
			,Efternavn
			,Gade
			,Postnr
			,Koenkode
			,Landekode
			,Tlfnr
			,Persontype
			,LandekodeTlfnr
			,Navn
		FROM dbo.Person;
GO
SET IDENTITY_INSERT dbo.p2 OFF;
GO
SET IDENTITY_INSERT dbo.p3 ON;
GO
INSERT INTO dbo.p3 -- WITH(TABLOCK)
				(PersonID
				,Fornavn
				,Efternavn
				,Gade
				,Postnr
				,Koenkode
				,Landekode
				,Tlfnr
				,Persontype
				,LandekodeTlfnr
				,Navn)
	SELECT	 TOP 3000000
			 PersonID
			,Fornavn
			,Efternavn
			,Gade
			,Postnr
			,Koenkode
			,Landekode
			,Tlfnr
			,Persontype
			,LandekodeTlfnr
			,Navn
		FROM dbo.Person;
GO
SET IDENTITY_INSERT dbo.p2 OFF;
GO
SET STATISTICS TIME OFF;
DROP TABLE dbo.p1;
DROP TABLE dbo.p2;
DROP TABLE dbo.p3;
