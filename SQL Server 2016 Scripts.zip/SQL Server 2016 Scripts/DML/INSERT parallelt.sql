USE IndexDB;
GO
DROP TABLE IF EXISTS dbo.t1;
DROP TABLE IF EXISTS dbo.t2;
GO
SELECT	TOP 0 
		Fornavn,
		Efternavn,
		Gade, 
		Postnr,
		Koenkode,
		Persontype,
		Tlfnr 
	INTO dbo.t1
	FROM dbo.Person;

SELECT	TOP 0 
		Fornavn,
		Efternavn,
		Gade, 
		Postnr,
		Koenkode,
		Persontype,
		Tlfnr 
	INTO dbo.t2
	FROM dbo.Person;
GO
SET STATISTICS IO, TIME ON;

INSERT INTO dbo.t1 WITH(TABLOCK)
	SELECT	TOP 5000000 
			Fornavn,
			Efternavn,
			Gade, 
			Postnr,
			Koenkode,
			Persontype,
			Tlfnr 
		FROM dbo.Person;

INSERT INTO dbo.t2
	SELECT	TOP 5000000 
			Fornavn,
			Efternavn,
			Gade, 
			Postnr,
			Koenkode,
			Persontype,
			Tlfnr 
		FROM dbo.Person;

SET STATISTICS TIME, IO OFF;
