USE master;
DROP DATABASE FKDB;
GO
CREATE DATABASE FKDB;
GO
-- ALTER DATABASE FKDB SET COMPATIBILITY_LEVEL = 100;
ALTER DATABASE FKDB SET COMPATIBILITY_LEVEL = 130;
GO
USE FKDB;
SET NOCOUNT ON;
GO
DECLARE @AntalTables		SMALLINT = 1000;

DECLARE @i					SMALLINT = 1;
DECLARE @sqlCreate_t		NVARCHAR(MAX) = 'CREATE TABLE dbo.t (ID INT NOT NULL IDENTITY, ';
DECLARE @sqlCreate_Mange	NVARCHAR(MAX) = '';
DECLARE @sqlInsert			NVARCHAR(MAX) = 'INSERT INTO dbo.t  VALUES(';

WHILE @i <= @AntalTables
BEGIN
	SET @sqlCreate_Mange += CONCAT(	'CREATE TABLE dbo.t', 
									@i, 
									' (ID  SMALLINT NOT NULL PRIMARY KEY);',
									' INSERT INTO dbo.t', 
									@i, 
									' VALUES(',
									@i,
									');'
									); 
	SET @sqlCreate_t += CONCAT(	'Kol', 
								@i, 
								' SMALLINT NOT NULL REFERENCES dbo.t', 
								@i, 
								'(ID),');
	SET @sqlInsert += CONCAT(@i, ',');

	SET @i += 1;
END;
SET @sqlCreate_t += 'txt	CHAR(1) NOT NULL);'
SET @sqlInsert += '''A'')';

EXECUTE (@sqlCreate_Mange);
EXECUTE (@sqlCreate_t);
EXECUTE (@sqlInsert);

PRINT @sqlCreate_Mange;
PRINT @sqlCreate_t;
PRINT @sqlInsert;

SELECT *
	FROM dbo.t;

