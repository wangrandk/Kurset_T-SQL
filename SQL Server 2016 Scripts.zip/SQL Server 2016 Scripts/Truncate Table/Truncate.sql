USE master;
DROP DATABASE PartitionDB;
GO
CREATE DATABASE PartitionDB
ON PRIMARY
	(NAME = PartitionDB_sys,
	 FILENAME = 'c:\Database\PartitionDB_sys.mdf',
     SIZE = 5MB),

FILEGROUP PartitionDB_fg1
	(NAME = PartitionDB_fg1,
	 FILENAME = 'c:\Database\PartitionDB_fg1.ndf',
     SIZE = 200MB),
	
FILEGROUP PartitionDB_fg2
	(NAME = PartitionDB_fg2,
	 FILENAME = 'c:\Database\PartitionDB_fg2.ndf',
     SIZE = 200MB),
	
FILEGROUP PartitionDB_fg3
	(NAME = PartitionDB_fg3,
	 FILENAME = 'c:\Database\PartitionDB_fg3.ndf',
     SIZE = 200MB),
	
FILEGROUP PartitionDB_fg4
	(NAME = PartitionDB_fg4,
	 FILENAME = 'c:\Database\PartitionDB_fg4.ndf',
     SIZE = 200MB),
	
FILEGROUP PartitionDB_fg5
	(NAME = PartitionDB_fg5,
	 FILENAME = 'c:\Database\PartitionDB_fg5.ndf',
     SIZE = 200MB),
	
FILEGROUP PartitionDB_fg6
	(NAME = PartitionDB_fg6,
	 FILENAME = 'c:\Database\PartitionDB_fg6.ndf',
     SIZE = 200MB)

LOG ON
	(NAME = PartitionDB_log,
	 FILENAME = 'c:\Database\PartitionDB.ldf',
     SIZE = 2000MB);
GO
USE PartitionDB
CREATE PARTITION FUNCTION PartitionFunction (DATE)
	AS RANGE RIGHT FOR VALUES (	'2016-2-1', 
								'2016-3-1', 
								'2016-4-1', 
								'2016-5-1', 
								'2016-6-1');
GO
CREATE PARTITION scheme PartitionScheme
	AS PARTITION PartitionFunction TO (	PartitionDB_fg1, 
										PartitionDB_fg2, 
										PartitionDB_fg3, 
										PartitionDB_fg4, 
										PartitionDB_fg5, 
										PartitionDB_fg6);
GO
CREATE TABLE dbo.PartitionTable 
(
	Id			INT			NOT NULL IDENTITY, 
	Navn		CHAR(10)	NOT NULL,
	Tid			DATE		NOT NULL,
	Maaned		AS MONTH(Tid) PERSISTED,
	INDEX nc_PartitionTable_Tid_Id (Tid, ID)
) ON PartitionScheme (Tid);
GO
INSERT INTO dbo.PartitionTable (Navn, Tid) VALUES 
	('Ole', '2016-1-2'),
	('Per', '2016-1-22'),
	('Ida', '2016-2-3'),
	('Ane', '2016-2-14'),
	('Mie', '2016-3-5'),
	('Eva', '2016-3-6'),
	('Dea', '2016-4-7'),
	('Jan', '2016-4-5'),
	('Fie', '2016-5-2'),
	('Oda', '2016-5-29'),
	('Elo', '2016-6-5'),
	('Tom', '2016-6-6');
GO
INSERT INTO dbo.PartitionTable (Navn, Tid)
	SELECT	Navn, 
			Tid
		FROM dbo.PartitionTable
GO 20
CREATE TABLE dbo.sqlperf_logspace 
(
	dbname		SYSNAME,
	logsize		FLOAT,
	logpct		FLOAT,
	status		SMALLINT,
	time		DATETIME2 DEFAULT(SYSDATETIME())
);
GO
BACKUP DATABASE PartitionDB TO DISK = 'c:/Rod/PartitionDB.BAK' WITH FORMAT;
BACKUP LOG PartitionDB TO DISK = 'c:/Rod/PartitionDB.LOG' WITH FORMAT;
GO
INSERT INTO dbo.sqlperf_logspace (dbname, logsize, logpct, status)
	EXEC ('DBCC sqlperf(logspace)');
GO
SELECT COUNT(*) 
	FROM dbo.PartitionTable;
GO
PRINT '------------------ TRUNCATE ------------------'
SET STATISTICS TIME ON;
TRUNCATE TABLE dbo.PartitionTable
	WITH (PARTITIONS (2, 4 TO 6));
SET STATISTICS TIME OFF;
GO
SELECT COUNT(*) 
	FROM dbo.PartitionTable;
GO
INSERT INTO dbo.sqlperf_logspace (dbname, logsize, logpct, status)
	EXEC ('DBCC sqlperf(logspace)');
GO
SELECT *
	FROM dbo.sqlperf_logspace
	WHERE dbname = 'PartitionDB'
	ORDER BY time;
GO
-- DELETE ---------------------------------------------
USE master;
DROP DATABASE PartitionDB;
GO
RESTORE DATABASE PartitionDB FROM DISK = 'c:/Rod/PartitionDB.BAK';
BACKUP LOG PartitionDB TO DISK = 'c:/Rod/PartitionDB.LOG' WITH FORMAT;
GO
USE PartitionDB;
GO
INSERT INTO dbo.sqlperf_logspace (dbname, logsize, logpct, status)
	EXEC ('DBCC sqlperf(logspace)');
GO
SELECT COUNT(*) 
	FROM dbo.PartitionTable;
GO
PRINT '------------------ DELETE ------------------'
SET STATISTICS TIME ON;
DELETE 
	FROM dbo.PartitionTable
	WHERE Maaned IN (2, 4, 5, 6);
SET STATISTICS TIME OFF;
GO
SELECT COUNT(*) 
	FROM dbo.PartitionTable;
GO
INSERT INTO dbo.sqlperf_logspace (dbname, logsize, logpct, status)
	EXEC ('DBCC sqlperf(logspace)');
GO
SELECT *
	FROM dbo.sqlperf_logspace
	WHERE dbname = 'PartitionDB'
	ORDER BY time;
GO