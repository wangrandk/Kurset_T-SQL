USE master;
DROP DATABASE LiveQueryDB;
GO
CREATE DATABASE LiveQueryDB
ON PRIMARY
	( NAME = LiveQueryDB_file_1,
	  FILENAME = 'C:\Database\LiveQueryDB_p.mdf',
      SIZE = 20MB,
      MAXSIZE = 200MB,
      FILEGROWTH = 10%),
	
FILEGROUP LiveQueryDB_group_1
	( NAME = LiveQueryDB_file_2,
	  FILENAME = 'C:\Database\LiveQueryDB_1_1.ndf',
      SIZE = 100MB,
      MAXSIZE = 400MB,
      FILEGROWTH = 10%),
	
	( NAME = LiveQueryDB_file_3,
	  FILENAME = 'C:\Database\LiveQueryDB_1_2.ndf',
      SIZE = 100MB,
      MAXSIZE = 400MB,
      FILEGROWTH = 10%)

LOG ON
	( NAME = LiveQueryDB_log_file_1,
	  FILENAME = 'C:\Database\LiveQueryDB_log_1.ldf',
      SIZE = 500MB,
      MAXSIZE = 1000MB,
      FILEGROWTH = 10%);
GO
ALTER DATABASE LiveQueryDB SET DELAYED_DURABILITY = FORCED;
ALTER DATABASE LiveQueryDB MODIFY FILEGROUP LiveQueryDB_group_1 DEFAULT;
GO
USE LiveQueryDB;
CREATE TABLE dbo.Postopl 
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY,	
	Bynavn			VARCHAR (30) NOT NULL
);
CREATE TABLE dbo.Kunde 
(
	Kundeid			INT	NOT NULL PRIMARY KEY IDENTITY,
	Navn			VARCHAR (30) NOT NULL,
	Adresse			VARCHAR (30) NULL,
	Postnr			SMALLINT  NULL 
					CONSTRAINT FK_Postopl_Kunde FOREIGN KEY REFERENCES dbo.Postopl (Postnr)
);
CREATE TABLE dbo.Ordre 
(
	Ordreid			INT	NOT NULL PRIMARY KEY IDENTITY,
	Bestildato		DATE NOT NULL DEFAULT (SYSDATETIME()),
	Levdato			DATE NULL,
	Kundeid			INT NULL 
					CONSTRAINT FK_Kunde_Ordre FOREIGN KEY REFERENCES dbo.Kunde (Kundeid)
);
CREATE TABLE dbo.Ordrelinie 
(
	Ordreid			INT	NOT NULL
					CONSTRAINT FK_Ordre_Ordrelinie FOREIGN KEY REFERENCES dbo.Ordre (Ordreid),
	Vareid			INT	NOT NULL INDEX nc_Ordrelinie_Vareid,
	Antalenheder	SMALLINT NOT NULL,
	CONSTRAINT PK_Ordrelinie PRIMARY KEY (Ordreid, Vareid)
);

CREATE TABLE dbo.Vare
(
	Vareid			INT NOT NULL PRIMARY KEY,
	Varenavn		VARCHAR(30) NOT NULL DEFAULT ('xxxxxxxxxxxxxxx'),
	AntalPaaLager	SMALLINT NOT NULL DEFAULT(0)
);
GO
SET NOCOUNT ON 
INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES 
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(9000, 'Aalborg');

INSERT INTO dbo.Kunde (Navn, Adresse, Postnr) VALUES 
	('Jens Hansen', 'Nygade 3', 2000),
	('Lone Jensen', 'Torvet 12', 2000),
	('Peter Knudsen', 'Torvet 44', 2000),
	('Ole Larsen', 'Vestergade 4', 9000),
	('Karen Olsen', 'Borgergade 13', 8000),
	('Karl Nielsen', 'S�ndergade 67', 9000),
	('Hanne Pedersen', NULL, NULL);

INSERT INTO dbo.Ordre (Levdato, Kundeid) VALUES 
	(DATEADD(DAY, 10, SYSDATETIME()), 2),
	(DATEADD(DAY, 2, SYSDATETIME()), 1),
	(DATEADD(DAY, 20, SYSDATETIME()), 2),
	(DATEADD(DAY, 4, SYSDATETIME()), 3),
	(DATEADD(DAY, 12, SYSDATETIME()), 4),
	(DATEADD(DAY, 20, SYSDATETIME()), 5),
	(DATEADD(DAY, 4, SYSDATETIME()), 3),
	(DATEADD(DAY, 20, SYSDATETIME()), 6),
	(DATEADD(DAY, 4, SYSDATETIME()), 7),
	(DATEADD(DAY, 24, SYSDATETIME()), 2);

INSERT INTO dbo.Ordrelinie (Ordreid, Vareid, Antalenheder) VALUES
	(1, 3, 2),
	(1, 6, 8),
	(2, 3, 4),
	(3, 1, 1),
	(3, 2, 2),
	(4, 4, 3),
	(5, 2, 6),
	(5, 6, 1),
	(5, 7, 1),
	(6, 3, 2),
	(6, 6, 8),
	(7, 3, 4),
	(8, 1, 1),
	(8, 2, 2),
	(8, 8, 3),
	(9, 7, 5),
	(9, 5, 2),
	(10, 3, 1);
SET NOCOUNT OFF;
GO
INSERT INTO dbo.Kunde (Navn, Adresse, Postnr)
	SELECT	Navn,
			Adresse,
			Postnr
		FROM dbo.Kunde;

INSERT INTO dbo.Ordre (Bestildato, Levdato, Kundeid)
	SELECT	Bestildato,
			Levdato,
			(SELECT MAX(Kundeid) FROM dbo.Kunde) - Kundeid
		FROM dbo.Ordre;

INSERT INTO dbo.Ordrelinie(Ordreid, Vareid, Antalenheder)
	SELECT	(SELECT MAX(Ordreid) FROM dbo.Ordre) + 1 - Ordreid,
			VareId + (SELECT MAX(Vareid) FROM dbo.Ordrelinie) % 200,
			Antalenheder
		FROM dbo.Ordrelinie;
GO 16
INSERT INTO dbo.Vare (Vareid)
	SELECT DISTINCT 
			Vareid
		FROM dbo.Ordrelinie;
GO
ALTER TABLE dbo.Ordrelinie 
	ADD CONSTRAINT fk_Ordrelinie_Vare FOREIGN KEY (Vareid) REFERENCES dbo.Vare(Vareid);
GO
CREATE TABLE dbo.Moms 
(
	ID			INT PRIMARY KEY IDENTITY,
	FraDato		DATE NOT NULL,
	TilDato		DATE NULL UNIQUE,		-- UNIQUE sikrer, at der kun er �n aktuel forekomst
										-- def. med NULL i TilDato
	Momspct		DECIMAL(4,2) NOT NULL CHECK (MomsPct BETWEEN 0 AND 100),
	CHECK (FraDato < TilDato)
);

GO
CREATE TRIGGER ins_upd_del_Moms ON Moms AFTER INSERT, UPDATE, DELETE
AS
DECLARE @Datoer TABLE
	(
	DATO	DATE NOT NULL
	);

WITH
MaxFradato
AS
(
SELECT MAX(FraDato) AS Dato
	FROM dbo.Moms 
),
Datoer
AS
(
SELECT MIN(Fradato) AS Dato
	FROM dbo.Moms 
UNION ALL
SELECT DATEADD(DAY, 1, Dato)
	FROM Datoer
	WHERE Dato < (SELECT ISNULL(TilDato, CAST(SYSDATETIME() AS DATE)) 
					FROM dbo.Moms 
					WHERE FraDato = (SELECT Dato
										FROM MaxFraDato))
)
INSERT INTO @Datoer
	SELECT Dato
		FROM Datoer
		OPTION (MAXRECURSION 0); 

IF	EXISTS (SELECT Datoer.Dato				-- mere end �n momspct pr dag
				FROM @Datoer AS Datoer INNER JOIN dbo.Moms  
						ON Datoer.Dato BETWEEN Moms.FraDato AND ISNULL(Moms.TilDato, SYSDATETIME())
				GROUP BY Datoer.Dato
				HAVING COUNT(*) > 1) 
	OR
	EXISTS (SELECT *						-- manglende datoer
				FROM @Datoer AS Datoer LEFT JOIN dbo.Moms  
						ON Datoer.Dato BETWEEN Moms.FraDato AND ISNULL(Moms.TilDato, SYSDATETIME())
				WHERE Moms.FraDato IS NULL)
BEGIN;
	THROW 56754, 'Overlap i datoer eller manglende datoer', 1;
	ROLLBACK TRANSACTION;
END			
GO
INSERT INTO dbo.Moms VALUES
	('1962-1-1', '1966-12-31', 9.00),
	('1967-1-1', '1967-12-31', 10.00),
	('1968-1-1', '1969-12-31', 12.50),
	('1970-1-1', '1976-12-31', 15.00),
	('1977-1-1', '1977-12-31', 18.00),
	('1978-1-1', '1979-12-31', 20.25),
	('1980-1-1', '1991-12-31', 22.00),
	('1992-1-1', NULL, 25.00);
GO
SELECT 
	(SELECT COUNT(*) FROM dbo.Postopl) AS AntalPostopl,
	(SELECT COUNT(*) FROM dbo.Kunde) AS AntalKunde,
	(SELECT COUNT(*) FROM dbo.Ordre) AS AntalOrdre,
	(SELECT COUNT(*) FROM dbo.Ordrelinie) AS AntalOrdrelinie,
	(SELECT COUNT(*) FROM dbo.Vare) AS AntalVare;
GO
SELECT  *
	FROM  (dbo.Kunde RIGHT JOIN dbo.Postopl ON Kunde.Postnr = Postopl.Postnr)
		  LEFT JOIN 
		  (dbo.Ordre INNER JOIN dbo.Ordrelinie ON Ordre.Ordreid = Ordrelinie.Ordreid)
		  ON Kunde.Kundeid = Ordre.Kundeid 		 
		  RIGHT JOIN dbo.Vare ON Ordrelinie.Vareid = Vare.Vareid;

SELECT  *
	FROM  (dbo.Kunde RIGHT JOIN dbo.Postopl ON Kunde.Postnr = Postopl.Postnr)
		  RIGHT JOIN 
		  (dbo.Ordre INNER JOIN dbo.Ordrelinie ON Ordre.Ordreid = Ordrelinie.Ordreid)
		  ON Kunde.Kundeid = Ordre.Kundeid 		 
		  LEFT JOIN dbo.Vare ON Ordrelinie.Vareid = Vare.Vareid;
GO
ALTER DATABASE LiveQueryDB SET AUTO_UPDATE_STATISTICS OFF WITH NO_WAIT;
GO
UPDATE STATISTICS dbo.Kunde
	WITH SAMPLE 0 PERCENT;			

UPDATE STATISTICS dbo.Ordre
	WITH SAMPLE 0 PERCENT;			

UPDATE STATISTICS dbo.Ordrelinie
	WITH SAMPLE 0 PERCENT;			

UPDATE STATISTICS dbo.Vare
	WITH SAMPLE 0 PERCENT;			

DBCC SHOW_STATISTICS (Ordrelinie, nc_Ordrelinie_Vareid);

PRINT 'uden statistikker'

SET STATISTICS TIME ON;
SELECT  *
	FROM  (dbo.Kunde LEFT JOIN dbo.Postopl ON Kunde.Postnr = Postopl.Postnr)
		  LEFT JOIN 
		  (dbo.Ordre INNER JOIN dbo.Ordrelinie ON Ordre.Ordreid = Ordrelinie.Ordreid)
		  ON Kunde.Kundeid = Ordre.Kundeid
		  INNER JOIN dbo.Vare ON Vare.Vareid = Ordrelinie.Vareid 		 
	WHERE	Ordre.Ordreid > (SELECT COUNT(*) FROM dbo.Ordre) / 2 AND
			Kunde.Adresse LIKE 'Torvet%';

SET STATISTICS TIME OFF;

UPDATE STATISTICS dbo.Kunde
	WITH FULLSCAN;

UPDATE STATISTICS dbo.Ordre
	WITH FULLSCAN;

UPDATE STATISTICS dbo.Ordrelinie
	WITH FULLSCAN;

UPDATE STATISTICS dbo.Vare
	WITH FULLSCAN;

DBCC SHOW_STATISTICS (Ordrelinie, nc_Ordrelinie_Vareid);

PRINT 'med statistik p� alle r�kker'
SET STATISTICS TIME ON;
SELECT  *
	FROM  (dbo.Kunde LEFT JOIN dbo.Postopl ON Kunde.Postnr = Postopl.Postnr)
		  LEFT JOIN 
		  (dbo.Ordre INNER JOIN dbo.Ordrelinie ON Ordre.Ordreid = Ordrelinie.Ordreid)
		  ON Kunde.Kundeid = Ordre.Kundeid 
		  INNER JOIN dbo.Vare ON Vare.Vareid = Ordrelinie.Vareid 		 
	WHERE	Ordre.Ordreid > (SELECT COUNT(*) FROM dbo.Ordre) / 2 AND
			Kunde.Adresse LIKE 'Torvet%';
SET STATISTICS TIME OFF;
