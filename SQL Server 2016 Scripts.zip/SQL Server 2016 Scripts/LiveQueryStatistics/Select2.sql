USE IndexDB;
GO
SELECT	*  
	FROM Koen	INNER JOIN Person 
					ON ISNULL(CAST(Koen.Koenkode AS VARCHAR(10)), 'U') = CAST(Person.Koenkode AS VARCHAR(10)) 
				INNER JOIN Landekode 
					ON LEFT(ISNULL(CAST(Person.Landekode AS CHAR(10)), 'x'), 5) = LEFT(ISNULL(CAST(Landekode.Landekode AS CHAR(10)), 'x'), 5)
				INNER JOIN Persontype 
					ON Person.Persontype = Persontype.Persontype 
				INNER JOIN Postopl 
					ON CAST(Person.Postnr AS VARCHAR(10)) = CAST(Postopl.Postnr AS VARCHAR(10))
