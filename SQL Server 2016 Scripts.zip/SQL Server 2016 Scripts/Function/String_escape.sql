USE master;
GO
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
DECLARE @name		VARCHAR(20) = 'Ole';
DECLARE @surname	VARCHAR(20) = 'Olsen';
DECLARE @json		VARCHAR(8000);

SET @json = FORMATMESSAGE('{ "id": %d,"name": "%s", "surname": "%s" }', 
    17, STRING_ESCAPE(@name,'json'), STRING_ESCAPE(@surname,'json') );

SELECT @json;
