USE master;
GO
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
CREATE TABLE dbo.Vare
(
	VareID			INT NOT NULL PRIMARY KEY,
	Farver			VARCHAR(100) NULL
);
GO
INSERT INTO dbo.Vare (VareId, Farver) VALUES
	(1, 'R�d,Gr�n,Bl�'),
	(2, 'Gul,     Hvid,      Sort');
GO
SELECT *
	FROM dbo.Vare CROSS APPLY string_split(Farver, ',');
GO
SELECT	Vareid,
		Farver,
		LTRIM(RTRIM(value)) AS Farve
	FROM dbo.Vare CROSS APPLY string_split(Farver, ',');
GO
INSERT INTO dbo.Vare (VareID) VALUES
	(3), (4);
GO
SELECT *
	FROM dbo.Vare OUTER APPLY string_split(Farver, ',');
GO
SELECT	Vareid,
		Farver,
		LTRIM(RTRIM(value)) AS Farve
	FROM dbo.Vare OUTER APPLY string_split(Farver, ',');
