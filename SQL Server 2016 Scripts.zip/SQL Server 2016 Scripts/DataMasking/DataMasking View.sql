USE master;
DROP DATABASE IF EXISTS DataMaskingDB;
GO
CREATE DATABASE DataMaskingDB;
GO
USE DataMaskingDB;
GO
CREATE TABLE dbo.Person
(
	PersonId			INT PRIMARY KEY,
	Fornavn				VARCHAR(20) 
						MASKED WITH (FUNCTION = 'partial(1, "+++", 2)') NOT NULL,
	Efternavn			VARCHAR(20) 
						MASKED WITH (FUNCTION = 'partial(2, "XXXXXX", 2)') NOT NULL,
	Gade				VARCHAR(30) 
						MASKED WITH (FUNCTION = 'default()') NULL,
	Postnr				SMALLINT  
						MASKED WITH (FUNCTION = 'default()') NULL,
	Tlfnr				VARCHAR(12) 
						MASKED WITH (FUNCTION = 'default()') NOT NULL,
	Beloeb				INT 
						MASKED WITH (FUNCTION = 'random(-100, 100)') NULL,
	EMail				VARCHAR(100) 
						MASKED WITH (FUNCTION = 'email()') NULL,
	Opretdato			DATE 
						MASKED WITH (FUNCTION = 'default()') DEFAULT (SYSDATETIME()) NOT NULL
);
GO
INSERT INTO dbo.Person (PersonId, Fornavn, Efternavn, Gade, Postnr, Tlfnr, Beloeb, EMail) VALUES 
	(1, 'Peter', 'Kristensen', '�stergade 4', 2000, '44337722', 1234567,  'PeterKristensen@Firma.dk'),
	(2, 'Emma', 'Bo', 'Vestergade 23', 2000,  '+45 33442277', 7654321, 'EmmaPetersen@Firma.DK'),
	(3, 'Jens Christian', 'Knudsen', 'Torvet 11', 8000,  '22 33 88 22', NULL, 'JCKnu@Firma.se'),
	(4, 'Lars Erik', 'Boel', NULL, NULL,  '+45 47471111', 345,  'LB@Firma.dk'),
	(5, 'Karina Louise', 'Petersen', 'S�ndergade 4', 3000, '+45 33442277', NULL, 'karinalouise@Firma.com'),
	(6, 'Lars', 'Olsen', NULL, NULL,  '+45 34471167', 345, NULL),
	(7, 'Louise', 'Hansen', 'Wildersgade 47', 6000,  '+45 67442244', NULL, 'FejlEmail@'),
	(8, 'Knud', 'Hansen', 'Knudsgade 2', 8000, '33441327', NULL, '@Firma.de');
GO
SELECT * 
	FROM dbo.Person;
GO
CREATE VIEW dbo.vPerson
AS
SELECT *
	FROM dbo.Person;
GO
CREATE USER TestUser WITHOUT LOGIN;
GRANT SELECT ON dbo.Person TO TestUser;
GRANT SELECT ON dbo.vPerson TO TestUser;
GO
EXECUTE AS USER = 'TestUser';
SELECT * 
	FROM dbo.Person;
REVERT;
GO
EXECUTE AS USER = 'TestUser';
SELECT * 
	FROM dbo.vPerson;
REVERT;
GO