USE master;
DROP DATABASE IF EXISTS DataMaskingDB;
GO
CREATE DATABASE DataMaskingDB;
GO
USE DataMaskingDB;
GO
CREATE TABLE dbo.Postopl
(
	Postnr				SMALLINT NOT NULL
						CONSTRAINT PK_Postopl PRIMARY KEY,
	Bynavn				VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Person
(
	PersonId	INT NOT NULL CONSTRAINT PK_Person PRIMARY KEY,
	Navn		VARCHAR(20) NOT NULL,
	Cprnr		CHAR(10) 
				MASKED WITH (FUNCTION = 'partial(6, "", 0)') NULL,
	Postnr		SMALLINT 
				MASKED WITH (FUNCTION = 'default()') NOT NULL
				CONSTRAINT FK_Person_Postopl 
				FOREIGN KEY REFERENCES dbo.Postopl	
);

GO
INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C');

INSERT INTO dbo.Person (PersonId, Navn, Cprnr, Postnr) VALUES 
	(1, 'Peter Christensen', '2704711357', 2000),
	(2, 'Emma Bo', '0402861234', 8000),
	(3, 'Hans Jensen', '1612941753', 2000);
GO
SELECT *
	FROM dbo.Postopl;

SELECT * 
	FROM dbo.Person;
GO
CREATE USER TestUser WITHOUT LOGIN;
GRANT SELECT ON dbo.Postopl TO TestUser;
GRANT SELECT ON dbo.Person TO TestUser;
GO
EXECUTE AS USER = 'TestUser';
SELECT *
	FROM dbo.Postopl;

SELECT * 
	FROM dbo.Person;

SELECT	Person.PersonId,
		Person.Navn,
		Person.Postnr,
		Postopl.Bynavn
	FROM dbo.Person INNER JOIN dbo.Postopl 
		ON Person.Postnr = Postopl.Postnr;

SELECT	Person.PersonId,
		Person.Navn,
		Postopl.Postnr,
		Postopl.Bynavn
	FROM dbo.Person INNER JOIN dbo.Postopl 
		ON Person.Postnr = Postopl.Postnr;

REVERT;
GO
EXECUTE AS USER = 'TestUser';

SELECT	Person.Postnr,
		COUNT(*) AS Antal 
	FROM dbo.Person
	GROUP BY Person.Postnr;

SELECT	Postopl.Postnr,
		COUNT(*) AS Antal 
	FROM dbo.Person INNER JOIN dbo.Postopl 
		ON Person.Postnr = Postopl.Postnr
	GROUP BY Postopl.Postnr;

REVERT;
GO
EXECUTE AS USER = 'TestUser';

WITH LbnrData 
AS
(
SELECT 1 AS Lbnr
UNION ALL
SELECT Lbnr + 1
	FROM LbnrData
	WHERE Lbnr < 9999
)
SELECT *
	FROM dbo.Person INNER JOIN LbnrData 
		ON CAST(SUBSTRING(Person.Cprnr, 7, 4) AS INT) = LbnrData.Lbnr
	OPTION (MAXRECURSION 0)

SELECT	*
	FROM dbo.Person
	WHERE Cprnr = '0402861234';

REVERT;
GO
