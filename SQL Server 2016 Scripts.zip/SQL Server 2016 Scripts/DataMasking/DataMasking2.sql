USE master;
DROP DATABASE IF EXISTS DataMaskingDB;
GO
CREATE DATABASE DataMaskingDB;
GO
USE DataMaskingDB;
GO
CREATE TABLE dbo.Person
(
	PersonId			INT PRIMARY KEY,
	Fornavn				VARCHAR(20) NOT NULL,
	Efternavn			VARCHAR(20) MASKED WITH (FUNCTION = 'partial(2, "XXXXXX", 2)') NOT NULL,
	Postnr				SMALLINT  MASKED WITH (FUNCTION = 'default()') NULL,
	Cprnr				CHAR(10) MASKED WITH (FUNCTION = 'partial(6, "", 0)') NULL,
	Navn				AS Fornavn + ' ' + Efternavn,
	Region				AS Postnr / 1000,
	Foedselsdato		AS LEFT(Cprnr, 6),
	Ident				AS CONCAT(PersonId, ' - ', Fornavn, Efternavn)
);
GO
INSERT INTO dbo.Person (PersonId, Fornavn, Efternavn, Postnr, Cprnr) VALUES 
	(1, 'Peter', 'Chrstensen', 2000, '2704891235'),
	(2, 'Emma', 'Bo', 2000, '2210757654'),
	(3, 'Jens Christian', 'Knudsen', 8000, '1201861357'),
	(4, 'Lars Erik', 'Boel', NULL, '1507659751'),
	(5, 'Karina Louise', 'Petersen', 3000, '0202823579'),
	(6, 'Lars', 'Knudsen', NULL, NULL),
	(7, 'Louise', 'Hansen', 6000, '1912711739');
GO
SELECT * 
	FROM dbo.Person;
GO
CREATE USER TestUser WITHOUT LOGIN;
GRANT SELECT ON dbo.Person TO TestUser;
GO
EXECUTE AS USER = 'TestUser';
SELECT * 
	FROM dbo.Person;

SELECT Navn, Region
	FROM dbo.Person;

REVERT;