USE master;
GO
DROP DATABASE IF EXISTS TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
DROP TABLE IF EXISTS dbo.Person;
GO
CREATE TABLE dbo.Person
(
	Id			INT NOT NULL PRIMARY KEY,
	Fornavn		VARCHAR(20) NOT NULL,
	Efternavn	VARCHAR(20) NOT NULL,
	Adresse		VARCHAR(30) NOT NULL,
	Postnr		SMALLINT NOT NULL,
	Initialer	VARCHAR(5) NOT NULL
);
GO
CREATE OR ALTER TRIGGER ins_upd_Person ON dbo.Person
AFTER INSERT, UPDATE
AS
	UPDATE dbo.Person
		SET Initialer = LOWER(Initialer)
		WHERE Id IN (SELECT Id	
						FROM INSERTED);
GO
INSERT INTO dbo.Person VALUES 
	(1, 'Ida', 'Hansen', 'Nygade 3', 2000, 'IHA'),
	(2, 'Ole', 'Olsen', 'Vestergade 23', 9000, 'OlOl'),
	(7, 'Per', 'Jensen', 'S�ndergade 7', 8000, 'pej');
GO
CREATE OR ALTER PROCEDURE dbo.usp_t
AS
SELECT *
	FROM dbo.Person;
GO
EXEC dbo.usp_t;
GO
CREATE OR ALTER PROCEDURE dbo.usp_t
AS
SELECT	Id,
		Fornavn + ' ' + Efternavn AS Navn
	FROM dbo.Person;
GO
EXEC dbo.usp_t;
GO
CREATE OR ALTER VIEW dbo.vPerson
AS
	SELECT *
		FROM dbo.Person;
GO
SELECT *
	FROM dbo.vPerson;
GO
CREATE OR ALTER VIEW dbo.vPerson
AS
	SELECT	Id,
			Fornavn + ' ' + Efternavn AS Navn
		FROM dbo.Person;
GO
SELECT *
	FROM dbo.vPerson;
GO
CREATE OR ALTER FUNCTION dbo.ufn_Navn 
(
	@Fornavn		VARCHAR(20),
	@Efternavn		VARCHAR(20)
)
RETURNS VARCHAR(30)
AS
BEGIN 
	DECLARE @Navn	VARCHAR(30);
		
	IF LEN(@Fornavn) + LEN(@Efternavn) > 30
		SET @Navn = @Fornavn + ' ' + @Efternavn
	ELSE
		SET @Navn = LEFT(@Fornavn, 1) + ' ' + @Efternavn;

	RETURN @Navn;
END;
GO
CREATE TABLE dbo.Medarbejder
(
	Id			INT NOT NULL PRIMARY KEY,
	Fornavn		VARCHAR(20) NOT NULL,
	Efternavn	VARCHAR(20) NOT NULL,
	Navn		AS dbo.ufn_Navn (Fornavn, Efternavn)
);
GO
INSERT INTO dbo.Medarbejder (Id, Fornavn, Efternavn) VALUES
	(2, 'Hanne', 'Hansen'),
	(3, 'Lars', 'Knudsen');
GO
SELECT *
	FROM dbo.Medarbejder;
GO
CREATE OR ALTER FUNCTION dbo.ufn_Navn		-- Fejler, da den indg�r i definition af tabel
(
	@Fornavn		VARCHAR(20),
	@Efternavn		VARCHAR(20)
)
RETURNS VARCHAR(30)
AS
BEGIN 
	DECLARE @Navn	VARCHAR(30);
		
	IF LEN(@Fornavn) + LEN(@Efternavn) > 30
		SET @Navn = @Fornavn + ' ' + @Efternavn
	ELSE
		SET @Navn = LEFT(@Fornavn, 1) + ' ' + @Efternavn;

	RETURN @Navn;
END;
GO
