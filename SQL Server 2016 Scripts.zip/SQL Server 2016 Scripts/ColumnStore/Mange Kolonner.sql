-- Dan tabel med mange ubrugte kolonner, som er NULL
USE master;
GO
IF EXISTS (SELECT *
				FROM master.sys.databases
				WHERE name = 'Index2DB')
	DROP DATABASE Index2DB;
GO
CREATE DATABASE Index2DB  
ON PRIMARY
	(NAME = N'Index2DB_Sys', 
	 FILENAME = N'C:\Databaser\Index2DB_Data.MDF', 
	 SIZE = 5, 
	 FILEGROWTH = 10%),

FILEGROUP DataFG1
	(NAME = N'Index2DB_FG1_Data1', 
	 FILENAME = N'C:\Databaser\Index2DB_DataFG1_Fil1.NDF', 
	 SIZE = 3000, 
	 FILEGROWTH = 10%)

LOG ON
	(NAME = N'Index2DB_Log',
	 FILENAME = N'C:\Databaser\Index2DB_Log.LDF', 
	 SIZE = 500,
	 FILEGROWTH = 500);
GO
USE Index2DB;
GO
ALTER DATABASE Index2DB MODIFY FILEGROUP DataFG1 DEFAULT;
GO
ALTER DATABASE Index2DB SET RECOVERY SIMPLE;
GO
SELECT *
	INTO dbo.Postopl
	FROM IndexDB.dbo.Postopl;

SELECT *
	INTO dbo.Koen
	FROM IndexDB.dbo.Koen;
	
SELECT *
	INTO dbo.Landekode
	FROM IndexDB.dbo.Landekode;

SELECT *
	INTO dbo.Persontype
	FROM IndexDB.dbo.Persontype;
GO
ALTER TABLE dbo.Postopl ADD CONSTRAINT PK_Postopl PRIMARY KEY (Postnr);
ALTER TABLE dbo.Koen ADD CONSTRAINT PK_Koen PRIMARY KEY (Koenkode);
ALTER TABLE dbo.Landekode ADD CONSTRAINT PK_Landekode PRIMARY KEY (Landekode);
ALTER TABLE dbo.Persontype ADD CONSTRAINT PK_Persontype PRIMARY KEY (Persontype);
GO
CREATE TABLE dbo.Person 
(
	PersonID 		INT IDENTITY NOT NULL CONSTRAINT PK_Person PRIMARY KEY,
	Fornavn 		VARCHAR (20)  NOT NULL,
	Efternavn 		VARCHAR (20)  NOT NULL,
	Gade 			VARCHAR (30)  NOT NULL,
	Postnr 			SMALLINT NOT NULL CONSTRAINT FK_Person_Postopl__Postnr FOREIGN KEY REFERENCES dbo.Postopl(Postnr),
	Koenkode		CHAR(1) NULL CONSTRAINT FK_Person_Koen__Koenkode FOREIGN KEY REFERENCES dbo.Koen(Koenkode),
	Landekode		VARCHAR(5) NULL CONSTRAINT FK_Person_Landekode__Landekode FOREIGN KEY REFERENCES dbo.Landekode(Landekode),
	Tlfnr			CHAR(8) NULL,
	Persontype		CHAR(1) NOT NULL CONSTRAINT FK_Person_Persontype__Persontype FOREIGN KEY REFERENCES dbo.Persontype(Persontype),
	Ubrugt1			VARCHAR(20) NULL,
	Ubrugt2			INT NULL,
	Ubrugt3			INT NULL,
	Ubrugt4			CHAR(20) NULL,
	Ubrugt5			BIGINT NULL,
	Ubrugt6			DATE NULL,
	Ubrugt7			TIME NULL,
	Ubrugt8			DECIMAL(18,2) NULL,
	Ubrugt9			DECIMAL(18,2) NULL,
	Ubrugt10		DECIMAL(18,2) NULL,
	Ubrugt11		DECIMAL(18,2) NULL,
	Ubrugt12		INT NULL,
	Ubrugt13		INT NULL,
	Ubrugt14		INT NULL,
	Ubrugt15		CHAR(20) NULL,
	Ubrugt16		INT NULL,
	Ubrugt17		BIGINT NULL,
	Ubrugt18		VARCHAR(10) NULL,
	Ubrugt19		VARCHAR(10) NULL,
	Ubrugt20		INT NULL,
	Ubrugt21		SMALLINT NULL,
	Ubrugt22		SMALLINT NULL,
	Ubrugt23		INT NULL,
	Ubrugt24		INT NULL,
	Ubrugt25		BIGINT NULL,
	Ubrugt26		VARCHAR(40) NULL,
	Ubrugt27		INT NULL,
	Ubrugt28		INT NULL,
	Ubrugt29		SMALLINT NULL,
	Ubrugt30		INT NULL
);

INSERT INTO dbo.Person (Fornavn, Efternavn, Gade, Postnr, Landekode, Tlfnr, Koenkode, Persontype)
	SELECT Fornavn, Efternavn, Gade, Postnr, Landekode, Tlfnr, Koenkode, Persontype
		FROM IndexDB.dbo.Person;
GO
USE Index2DB;
GO
SET STATISTICS TIME, IO ON;
SELECT *
	FROM dbo.Person;
SET STATISTICS TIME, IO OFF;
GO
ALTER TABLE dbo.Person DROP CONSTRAINT PK_Person;

CREATE CLUSTERED COLUMNSTORE INDEX clci_Person 
	ON dbo.Person;

CREATE UNIQUE NONCLUSTERED INDEX PK_Person
	ON dbo.Person(PersonID);
GO
SET STATISTICS TIME, IO ON;
SELECT *
	FROM dbo.Person;
SET STATISTICS TIME, IO OFF;




(6588314 row(s) affected)
Table 'Person'. Scan count 1, logical reads 187095, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 5672 ms,  elapsed time = 81186 ms.
---------------------------------------------------------
SQL Server parse and compile time: 
   CPU time = 0 ms, elapsed time = 1 ms.

(6588314 row(s) affected)
Table 'Person'. Scan count 1, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 13585, lob physical reads 310, lob read-ahead reads 12917.
Table 'Person'. Segment reads 9, segment skipped 0.

 SQL Server Execution Times:
   CPU time = 10781 ms,  elapsed time = 87491 ms.