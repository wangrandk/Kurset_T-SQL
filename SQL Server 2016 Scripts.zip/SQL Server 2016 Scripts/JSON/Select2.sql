USE master
GO
DROP DATABASE IF EXISTS Blockchain;
GO
CREATE DATABASE Blockchain;
GO
ALTER DATABASE Blockchain SET COMPATIBILITY_LEVEL = 130
GO
USE Blockchain
GO
CREATE SCHEMA btc;
GO
CREATE TABLE btc.Block
(
	BlockID				BIGINT NOT NULL CONSTRAINT PK_BlockID PRIMARY KEY CLUSTERED ,
	BlockchainFileID	INT NOT NULL,
	BlockVersion		INT NOT NULL,
	BlockHash			VARBINARY(32) NOT NULL,
	PreviousBlockHash	VARBINARY(32) NOT NULL,
	BlockTimestamp		DATETIME NOT NULL
);
GO
INSERT btc.Block (BlockID, BlockchainFileID, BlockVersion, BlockHash, PreviousBlockHash, BlockTimestamp) VALUES 
	(0, 0, 1, 0x000000000019D6689C085AE165831E934FF763AE46A2A6C172B3F1B60A8CE26F, 0x0000000000000000000000000000000000000000000000000000000000000000, CAST(N'2009-01-03T18:15:05.000' AS DATETIME)),
	(1, 0, 1, 0x00000000839A8E6886AB5951D76F411475428AFC90947EE320161BBF18EB6048, 0x000000000019D6689C085AE165831E934FF763AE46A2A6C172B3F1B60A8CE26F, CAST(N'2009-01-09T02:54:25.000' AS DateTime)),
	(2, 0, 1, 0x000000006A625F06636B8BB6AC7B960A8D03705D1ACE08B1A19DA3FDCC99DDBD, 0x00000000839A8E6886AB5951D76F411475428AFC90947EE320161BBF18EB6048, CAST(N'2009-01-09T02:55:44.000' AS DateTime)),
	(3, 0, 1, 0x0000000082B5015589A3FDF2D4BAFF403E6F0BE035A5D9742C1CAE6295464449, 0x000000006A625F06636B8BB6AC7B960A8D03705D1ACE08B1A19DA3FDCC99DDBD, CAST(N'2009-01-09T03:02:53.000' AS DateTime)),
	(4, 0, 1, 0x000000004EBADB55EE9096C9A2F8880E09DA59C0D68B1C228DA88E48844A1485, 0x0000000082B5015589A3FDF2D4BAFF403E6F0BE035A5D9742C1CAE6295464449, CAST(N'2009-01-09T03:16:28.000' AS DateTime)),
	(5, 0, 1, 0x000000009B7262315DBF071787AD3656097B892ABFFD1F95A1A022F896F533FC, 0x000000004EBADB55EE9096C9A2F8880E09DA59C0D68B1C228DA88E48844A1485, CAST(N'2009-01-09T03:23:48.000' AS DateTime));
GO
USE Blockchain;
SELECT 
		BlockID AS 				'Block.BlockID',
		BlockchainFileID AS 	'Block.BlockchainFileID',
		BlockVersion AS			'Block.BlockVersion',
		BlockHash AS 			'Block.BlockHash',
		PreviousBlockHash AS 	'Block.PreviousBlockHash',
		BlockTimestamp AS 		'Block.BlockTimestamp'
	FROM btc.Block
	FOR JSON PATH;
GO
TRUNCATE TABLE btc.Block;  -- Empty the table to reload through OPENJSON command

DECLARE @Block			NVARCHAR(MAX);
SET @Block = N'
{
	"Block" :
	{
		"BlockArray" :
		[
			{
				"Block" :
				{
					"BlockID" : 0,
					"BlockchainFileID" : 0,
					"BlockVersion" : 1,
					"BlockHash" : "AAAAAAAZ1micCFrhZYMek0/3Y65GoqbBcrPxtgqM4m8=",
					"PreviousBlockHash" : "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
					"BlockTimestamp" : "2009-01-03T18:15:05"
				}
			},
			{
				"Block" :
				{
					"BlockID" : 1,
					"BlockchainFileID" : 0,
					"BlockVersion" : 1,
					"BlockHash" : "AAAAAIOajmiGq1lR129BFHVCivyQlH7jIBYbvxjrYEg=",
					"PreviousBlockHash" : "AAAAAAAZ1micCFrhZYMek0/3Y65GoqbBcrPxtgqM4m8=",
					"BlockTimestamp" : "2009-01-09T02:54:25"
				}
			},
			{
				"Block" :
				{
					"BlockID" : 2,
					"BlockchainFileID" : 0,
					"BlockVersion" : 1,
					"BlockHash" : "AAAAAGpiXwZja4u2rHuWCo0DcF0azgixoZ2j/cyZ3b0=",
					"PreviousBlockHash" : "AAAAAIOajmiGq1lR129BFHVCivyQlH7jIBYbvxjrYEg=",
					"BlockTimestamp" : "2009-01-09T02:55:44"
				}
			},
			{
				"Block" :
				{
					"BlockID" : 3,
					"BlockchainFileID" : 0,
					"BlockVersion" : 1,
					"BlockHash" : "AAAAAIK1AVWJo/3y1Lr/QD5vC+A1pdl0LByuYpVGREk=",
					"PreviousBlockHash" : "AAAAAGpiXwZja4u2rHuWCo0DcF0azgixoZ2j/cyZ3b0=",
					"BlockTimestamp" : "2009-01-09T03:02:53"
				}
			},
			{
				"Block" :
				{
					"BlockID" : 4,
					"BlockchainFileID" : 0,
					"BlockVersion" : 1,
					"BlockHash" : "AAAAAE6621XukJbJoviIDgnaWcDWixwijaiOSIRKFIU=",
					"PreviousBlockHash" : "AAAAAIK1AVWJo/3y1Lr/QD5vC+A1pdl0LByuYpVGREk=",
					"BlockTimestamp" : "2009-01-09T03:16:28"
				}
			},
			{
				"Block" :
				{
					"BlockID" : 5,
					"BlockchainFileID" : 0,
					"BlockVersion" : 1,
					"BlockHash" : "AAAAAJtyYjFdvwcXh602Vgl7iSq//R+VoaAi+Jb1M/w=",
					"PreviousBlockHash" : "AAAAAE6621XukJbJoviIDgnaWcDWixwijaiOSIRKFIU=",
					"BlockTimestamp" : "2009-01-09T03:23:48"
				}
			}
		]
	}
}'

INSERT INTO btc.Block(BlockID, BlockchainFileID, BlockVersion, BlockHash, PreviousBlockHash, BlockTimestamp)
	SELECT * 
		FROM OPENJSON (@Block, '$.Block.BlockArray')
		WITH ( 
				BlockID				INT				'$.Block.BlockID',
				BlockchainFileID	INT				'$.Block.BlockchainFileID',
				BlockVersion		INT				'$.Block.BlockVersion',
				BlockHash			VARBINARY(32)	'$.Block.BlockHash',
				PreviousBlockHash	VARBINARY(32)	'$.Block.PreviousBlockHash',
				BlockTimestamp		DATETIME		'$.Block.BlockTimestamp'	
			);
GO
SELECT *
	FROM btc.Block;
