-- 2
USE ValidInMemoryRecordTimeDB;

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
GO
SELECT *
	FROM dbo.Kunde WITH(SERIALIZABLE);

-- 4
SELECT *
	FROM dbo.Kunde;

-- 6
SELECT *
	FROM dbo.Kunde;

USE master;
