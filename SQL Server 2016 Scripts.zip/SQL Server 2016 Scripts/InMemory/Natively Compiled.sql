USE master;
DROP DATABASE IF EXISTS NativelyCompiledDB;
GO
CREATE DATABASE NativelyCompiledDB
ON PRIMARY
(
	NAME = NativelyCompiledDB_sys,
	FILENAME = N'C:\Databaser\NativelyCompiledDB_sys.mdf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
),
FILEGROUP NativelyCompiledDB_NotInMem_filegroup  
(
	NAME = NativelyCompiledDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\NativelyCompiledDB_NativelyCompiledDB_NotInMem_filegroup.ndf',
	SIZE = 1000MB,
	MAXSIZE = 5000MB,
	FILEGROWTH = 10%
),
FILEGROUP NativelyCompiledDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = NativelyCompiledDB_InMem_filegroup_fil1,
    FILENAME = N'C:\Databaser\InMem_Data_NativelyCompiledDB1'
),
( 
	NAME = NativelyCompiledDB_InMem_filegroup_fil2,
    FILENAME = N'C:\Databaser\InMem_Data_NativelyCompiledDB2'
),
( 
	NAME = NativelyCompiledDB_InMem_filegroup_fil3,
    FILENAME = N'C:\Databaser\InMem_Data_NativelyCompiledDB3'
),
( 
	NAME = NativelyCompiledDB_InMem_filegroup_fil4,
    FILENAME = N'C:\Databaser\InMem_Data_NativelyCompiledDB4'
)
LOG ON
( 
	NAME = NativelyCompiledDB_log_file_1,
	FILENAME = N'C:\Databaser\NativelyCompiledDB_log.ldf',
	SIZE = 1000MB,
	MAXSIZE = 5000MB,
	FILEGROWTH = 10%
);
GO
USE NativelyCompiledDB;
GO
CREATE SCHEMA InMem;
GO
CREATE SCHEMA NotInMem;
GO
CREATE TABLE NotInMem.Postopl 
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY NONCLUSTERED,	
	Bynavn			VARCHAR (30) NOT NULL
);
CREATE TABLE NotInMem.Kunde 
(
	Kundeid			INT	NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY,
	Navn			VARCHAR (30) NOT NULL,
	Adresse			VARCHAR (30) NULL,
	Postnr			SMALLINT  NULL 
					CONSTRAINT FK_Postopl_Kunde FOREIGN KEY REFERENCES NotInMem.Postopl (Postnr)
);
CREATE TABLE NotInMem.Ordre 
(
	Ordreid			INT	NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY,
	Bestildato		DATE NOT NULL DEFAULT (SYSDATETIME()),
	Levdato			DATE NULL,
	Kundeid			INT NULL 
					CONSTRAINT FK_Kunde_Ordre FOREIGN KEY REFERENCES NotInMem.Kunde (Kundeid)
);
CREATE TABLE NotInMem.Ordrelinie 
(
	Ordreid			INT	NOT NULL
					CONSTRAINT FK_Ordre_Ordrelinie FOREIGN KEY REFERENCES NotInMem.Ordre (Ordreid),
	Vareid			INT	NOT NULL,
	Antalenheder	SMALLINT NOT NULL,
	CONSTRAINT PK_Ordrelinie PRIMARY KEY NONCLUSTERED (Ordreid, Vareid)
);

CREATE TABLE NotInMem.Vare
(
	Vareid			INT NOT NULL PRIMARY KEY,
	Varenavn		VARCHAR(30) NOT NULL DEFAULT ('xxxxxxxxxxxxxxx'),
	AntalPaaLager	SMALLINT NOT NULL DEFAULT(0)
);

CREATE TABLE NotInMem.Moms 
(
	ID			INT PRIMARY KEY IDENTITY,
	FraDato		DATE NOT NULL,
	TilDato		DATE NULL UNIQUE,		-- UNIQUE sikrer, at der kun er �n aktuel forekomst
										-- def. med NULL i TilDato
	Momspct		DECIMAL(4,2) NOT NULL CHECK (MomsPct BETWEEN 0 AND 100),
	CHECK (FraDato < TilDato)
);
GO
CREATE TABLE InMem.Postopl 
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY NONCLUSTERED,	
	Bynavn			VARCHAR (30) NOT NULL
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);

CREATE TABLE InMem.Kunde 
(
	Kundeid			INT	NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY,
	Navn			VARCHAR (30) NOT NULL,
	Adresse			VARCHAR (30) NULL,
	Postnr			SMALLINT  NULL 
--					CONSTRAINT FK_Postopl_Kunde FOREIGN KEY REFERENCES InMem.Postopl (Postnr)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);

CREATE TABLE InMem.Ordre 
(
	Ordreid			INT	NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY,
	Bestildato		DATE NOT NULL DEFAULT (SYSDATETIME()),
	Levdato			DATE NULL,
	Kundeid			INT NULL 
--					CONSTRAINT FK_Kunde_Ordre FOREIGN KEY REFERENCES InMem.Kunde (Kundeid)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);

CREATE TABLE InMem.Ordrelinie 
(
	Ordreid			INT	NOT NULL,
--					CONSTRAINT FK_Ordre_Ordrelinie FOREIGN KEY REFERENCES InMem.Ordre (Ordreid),
	Vareid			INT	NOT NULL,
	Antalenheder	SMALLINT NOT NULL,
	CONSTRAINT PK_Ordrelinie PRIMARY KEY NONCLUSTERED(Ordreid, Vareid) 
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);

CREATE TABLE InMem.Vare
(
	Vareid			INT NOT NULL PRIMARY KEY NONCLUSTERED,
	Varenavn		VARCHAR(30) NOT NULL DEFAULT ('xxxxxxxxxxxxxxx'),
	AntalPaaLager	SMALLINT NOT NULL DEFAULT(0)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);

CREATE TABLE InMem.Moms 
(
	ID			INT PRIMARY KEY NONCLUSTERED IDENTITY,
	FraDato		DATE NOT NULL,
	TilDato		DATE NULL,
	Momspct		DECIMAL(4,2) NOT NULL,
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
SET NOCOUNT ON 
INSERT INTO NotInMem.Postopl (Postnr, Bynavn) VALUES 
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(9000, 'Aalborg');

INSERT INTO NotInMem.Kunde (Navn, Adresse, Postnr) VALUES 
	('Jens Hansen', 'Nygade 3', 2000),
	('Lone Jensen', 'Torvet 12', 2000),
	('Peter Knudsen', 'Torvet 44', 2000),
	('Ole Larsen', 'Vestergade 4', 9000),
	('Karen Olsen', 'Borgergade 13', 8000),
	('Karl Nielsen', 'S�ndergade 67', 9000),
	('Hanne Pedersen', NULL, NULL);

INSERT INTO NotInMem.Ordre (Levdato, Kundeid) VALUES 
	(DATEADD(DAY, 10, SYSDATETIME()), 2),
	(DATEADD(DAY, 2, SYSDATETIME()), 1),
	(DATEADD(DAY, 20, SYSDATETIME()), 2),
	(DATEADD(DAY, 4, SYSDATETIME()), 3),
	(DATEADD(DAY, 12, SYSDATETIME()), 4),
	(DATEADD(DAY, 20, SYSDATETIME()), 5),
	(DATEADD(DAY, 4, SYSDATETIME()), 3),
	(DATEADD(DAY, 20, SYSDATETIME()), 6),
	(DATEADD(DAY, 4, SYSDATETIME()), 7),
	(DATEADD(DAY, 24, SYSDATETIME()), 2);

INSERT INTO NotInMem.Ordrelinie (Ordreid, Vareid, Antalenheder) VALUES
	(1, 3, 2),
	(1, 6, 8),
	(2, 3, 4),
	(3, 1, 1),
	(3, 2, 2),
	(4, 4, 3),
	(5, 2, 6),
	(5, 6, 1),
	(5, 7, 1),
	(6, 3, 2),
	(6, 6, 8),
	(7, 3, 4),
	(8, 1, 1),
	(8, 2, 2),
	(8, 8, 3),
	(9, 7, 5),
	(9, 5, 2),
	(10, 3, 1);
SET NOCOUNT OFF;
GO
INSERT INTO NotInMem.Kunde (Navn, Adresse, Postnr)
	SELECT	Navn,
			Adresse,
			Postnr
		FROM NotInMem.Kunde;

INSERT INTO NotInMem.Ordre (Bestildato, Levdato, Kundeid)
	SELECT	Bestildato,
			Levdato,
			(SELECT MAX(Kundeid) FROM NotInMem.Kunde) - Kundeid
		FROM NotInMem.Ordre;

INSERT INTO NotInMem.Ordrelinie(Ordreid, Vareid, Antalenheder)
	SELECT	(SELECT MAX(Ordreid) FROM NotInMem.Ordre) + 1 - Ordreid,
			VareId + (SELECT MAX(Vareid) FROM NotInMem.Ordrelinie) % 200,
			Antalenheder
		FROM NotInMem.Ordrelinie;
GO 15
INSERT INTO NotInMem.Vare (Vareid)
	SELECT DISTINCT 
			Vareid
		FROM NotInMem.Ordrelinie;
GO
ALTER TABLE NotInMem.Ordrelinie 
	ADD CONSTRAINT fk_Ordrelinie_Vare  FOREIGN KEY (Vareid) REFERENCES NotInMem.Vare(Vareid);
GO
INSERT INTO InMem.Postopl
	SELECT *
		FROM NotInMem.Postopl;

SET IDENTITY_INSERT InMem.Kunde ON;

INSERT INTO InMem.Kunde (Kundeid, Navn, Adresse, Postnr)
	SELECT Kundeid, Navn, Adresse, Postnr
		FROM NotInMem.Kunde;

SET IDENTITY_INSERT InMem.Kunde OFF;

SET IDENTITY_INSERT InMem.Ordre ON;

INSERT INTO InMem.Ordre (Ordreid,	Bestildato,	Levdato, Kundeid)
	SELECT Ordreid,	Bestildato,	Levdato, Kundeid
		FROM NotInMem.Ordre;

SET IDENTITY_INSERT InMem.Kunde OFF;

INSERT INTO InMem.Ordrelinie
	SELECT *
		FROM NotInMem.Ordrelinie;

INSERT INTO InMem.Vare
	SELECT *
		FROM NotInMem.Vare;
GO
INSERT INTO NotInMem.Moms VALUES
	('1962-1-1', '1966-12-31', 9.00),
	('1967-1-1', '1967-12-31', 10.00),
	('1968-1-1', '1969-12-31', 12.50),
	('1970-1-1', '1976-12-31', 15.00),
	('1977-1-1', '1977-12-31', 18.00),
	('1978-1-1', '1979-12-31', 20.25),
	('1980-1-1', '1991-12-31', 22.00),
	('1992-1-1', NULL, 25.00);
GO
INSERT INTO InMem.Moms VALUES
	('1962-1-1', '1966-12-31', 9.00),
	('1967-1-1', '1967-12-31', 10.00),
	('1968-1-1', '1969-12-31', 12.50),
	('1970-1-1', '1976-12-31', 15.00),
	('1977-1-1', '1977-12-31', 18.00),
	('1978-1-1', '1979-12-31', 20.25),
	('1980-1-1', '1991-12-31', 22.00),
	('1992-1-1', NULL, 25.00);
GO
SELECT 
	(SELECT COUNT(*) FROM NotInMem.Postopl) AS AntalPostopl,
	(SELECT COUNT(*) FROM NotInMem.Kunde) AS AntalKunde,
	(SELECT COUNT(*) FROM NotInMem.Ordre) AS AntalOrdre,
	(SELECT COUNT(*) FROM NotInMem.Ordrelinie) AS AntalOrdrelinie,
	(SELECT COUNT(*) FROM NotInMem.Vare) AS AntalVare,
	(SELECT COUNT(*) FROM NotInMem.Moms) AS AntalMoms;

SELECT 
	(SELECT COUNT(*) FROM InMem.Postopl) AS AntalPostopl,
	(SELECT COUNT(*) FROM InMem.Kunde) AS AntalKunde,
	(SELECT COUNT(*) FROM InMem.Ordre) AS AntalOrdre,
	(SELECT COUNT(*) FROM InMem.Ordrelinie) AS AntalOrdrelinie,
	(SELECT COUNT(*) FROM InMem.Vare) AS AntalVare,
	(SELECT COUNT(*) FROM InMem.Moms) AS AntalMoms;
GO
--DROP PROCEDURE InMem.usp_Native_Compilation_Person;
GO
CREATE PROCEDURE InMem.usp_Native_Compilation_Person
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC
	WITH (TRANSACTION ISOLATION LEVEL = SERIALIZABLE, LANGUAGE = N'us_english')

SELECT  Kunde.Kundeid,
		Kunde.Navn,
		Kunde.Adresse,
		Kunde.Postnr,
		Postopl.Bynavn,
		Ordre.Ordreid,
		Ordre.Bestildato,
		Ordre.Levdato,
		Ordrelinie.Vareid,
		Ordrelinie.Antalenheder,
		Vare.Varenavn,
		Vare.AntalPaalager
	FROM  (InMem.Kunde RIGHT JOIN InMem.Postopl ON Kunde.Postnr = Postopl.Postnr)
		  LEFT JOIN 
		  (InMem.Ordre INNER JOIN InMem.Ordrelinie ON Ordre.Ordreid = Ordrelinie.Ordreid)
		  ON Kunde.Kundeid = Ordre.Kundeid 		 
		  INNER JOIN InMem.Vare ON Ordrelinie.Vareid = Vare.Vareid;
END;
GO
SET STATISTICS TIME ON;

SELECT  Kunde.Kundeid,
		Kunde.Navn,
		Kunde.Adresse,
		Kunde.Postnr,
		Postopl.Bynavn,
		Ordre.Ordreid,
		Ordre.Bestildato,
		Ordre.Levdato,
		Ordrelinie.Vareid,
		Ordrelinie.Antalenheder,
		Vare.Varenavn,
		Vare.AntalPaalager
	FROM  (NotInMem.Kunde RIGHT JOIN NotInMem.Postopl ON Kunde.Postnr = Postopl.Postnr)
		  LEFT JOIN 
		  (NotInMem.Ordre INNER JOIN NotInMem.Ordrelinie ON Ordre.Ordreid = Ordrelinie.Ordreid)
		  ON Kunde.Kundeid = Ordre.Kundeid 		 
		  INNER JOIN NotInMem.Vare ON Ordrelinie.Vareid = Vare.Vareid;

SELECT  Kunde.Kundeid,
		Kunde.Navn,
		Kunde.Adresse,
		Kunde.Postnr,
		Postopl.Bynavn,
		Ordre.Ordreid,
		Ordre.Bestildato,
		Ordre.Levdato,
		Ordrelinie.Vareid,
		Ordrelinie.Antalenheder,
		Vare.Varenavn,
		Vare.AntalPaalager
	FROM  (InMem.Kunde RIGHT JOIN InMem.Postopl ON Kunde.Postnr = Postopl.Postnr)
		  LEFT JOIN 
		  (InMem.Ordre INNER JOIN InMem.Ordrelinie ON Ordre.Ordreid = Ordrelinie.Ordreid)
		  ON Kunde.Kundeid = Ordre.Kundeid 		 
		  INNER JOIN InMem.Vare ON Ordrelinie.Vareid = Vare.Vareid;

EXEC InMem.usp_Native_Compilation_Person;

SET STATISTICS TIME OFF;
GO
CREATE FUNCTION InMem.AktuelMoms
(
@Dato	DATE 
) 
RETURNS DECIMAL(4,2)
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS 
BEGIN	ATOMIC
		WITH (TRANSACTION ISOLATION LEVEL = SERIALIZABLE, LANGUAGE = N'us_english')

	DECLARE @Moms   DECIMAL(4,2);

	IF @Dato IS NULL
		SET @Moms = NULL
	ELSE
		SELECT @Moms = Momspct
			FROM InMem.Moms
			WHERE	@Dato BETWEEN FraDato AND TilDato OR
					(@Dato >= FraDato AND TilDato IS NULL)
	RETURN @Moms
END;
GO
CREATE FUNCTION NotInMem.AktuelMoms
(
@Dato	DATE 
) 
RETURNS DECIMAL(4,2)
AS 
BEGIN
	DECLARE @Moms   DECIMAL(4,2);

	IF @Dato IS NULL
		SET @Moms = NULL
	ELSE
		SELECT @Moms = Momspct
			FROM InMem.Moms
			WHERE	@Dato BETWEEN FraDato AND TilDato OR
					(@Dato >= FraDato AND TilDato IS NULL)
	RETURN @Moms
END;
GO
SET STATISTICS TIME ON;

SELECT  Ordre.Ordreid,
		Ordre.Bestildato,
		Ordre.Levdato,
		Ordrelinie.Vareid,
		Ordrelinie.Antalenheder,
		Vare.Varenavn,
		Vare.AntalPaalager,
		NotInMem.AktuelMoms(Ordre.Bestildato)
	FROM  NotInMem.Ordre INNER JOIN NotInMem.Ordrelinie ON Ordre.Ordreid = Ordrelinie.Ordreid
						 INNER JOIN NotInMem.Vare ON Ordrelinie.Vareid = Vare.Vareid;

SELECT  Ordre.Ordreid,
		Ordre.Bestildato,
		Ordre.Levdato,
		Ordrelinie.Vareid,
		Ordrelinie.Antalenheder,
		Vare.Varenavn,
		Vare.AntalPaalager,
		NotInMem.AktuelMoms(Ordre.Bestildato)
	FROM  InMem.Ordre INNER JOIN InMem.Ordrelinie ON Ordre.Ordreid = Ordrelinie.Ordreid
					  INNER JOIN InMem.Vare ON Ordrelinie.Vareid = Vare.Vareid;

SELECT  Ordre.Ordreid,
		Ordre.Bestildato,
		Ordre.Levdato,
		Ordrelinie.Vareid,
		Ordrelinie.Antalenheder,
		Vare.Varenavn,
		Vare.AntalPaalager,
		InMem.AktuelMoms(Ordre.Bestildato)
	FROM  NotInMem.Ordre INNER JOIN NotInMem.Ordrelinie ON Ordre.Ordreid = Ordrelinie.Ordreid
						 INNER JOIN NotInMem.Vare ON Ordrelinie.Vareid = Vare.Vareid;

SELECT  Ordre.Ordreid,
		Ordre.Bestildato,
		Ordre.Levdato,
		Ordrelinie.Vareid,
		Ordrelinie.Antalenheder,
		Vare.Varenavn,
		Vare.AntalPaalager,
		InMem.AktuelMoms(Ordre.Bestildato)
	FROM  InMem.Ordre INNER JOIN InMem.Ordrelinie ON Ordre.Ordreid = Ordrelinie.Ordreid
					  INNER JOIN InMem.Vare ON Ordrelinie.Vareid = Vare.Vareid;
GO
CREATE PROCEDURE InMem.usp_Native_Compilation_Ordre_Moms
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC
	WITH (TRANSACTION ISOLATION LEVEL = SERIALIZABLE, LANGUAGE = N'us_english')

SELECT  Ordre.Ordreid,
		Ordre.Bestildato,
		Ordre.Levdato,
		Ordrelinie.Vareid,
		Ordrelinie.Antalenheder,
		Vare.Varenavn,
		Vare.AntalPaalager,
		InMem.AktuelMoms(Ordre.Bestildato)
	FROM  InMem.Ordre INNER JOIN InMem.Ordrelinie ON Ordre.Ordreid = Ordrelinie.Ordreid
					  INNER JOIN InMem.Vare ON Ordrelinie.Vareid = Vare.Vareid;
END;
GO
SET STATISTICS TIME ON;

EXEC InMem.usp_Native_Compilation_Ordre_Moms;

SET STATISTICS TIME OFF;
GO
CREATE TRIGGER NotInMem.ins_Moms ON NotInMem.Moms
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Startdato		DATE;
	DECLARE @Slutdato		DATE;

	DECLARE @Datoer TABLE
	(
		Dato		DATE NOT NULL,
		Anvendt		SMALLINT NOT NULL DEFAULT (0)
	);

	SELECT @Startdato = MIN(Fradato) 
		FROM NotInMem.Moms;

	SELECT @Slutdato = MAX(Tildato) 
		FROM NotInMem.Moms;

	WITH Datoer
	AS
	(
	SELECT @Startdato AS Dato
	UNION ALL
	SELECT DATEADD(DAY, 1, Dato)
		FROM Datoer
		WHERE Dato < @Slutdato 
	)
	INSERT INTO @Datoer (Dato)
		SELECT Dato
			FROM Datoer
	OPTION (MAXRECURSION 0);

	UPDATE @Datoer
		SET Anvendt += 1
		FROM @Datoer AS D INNER JOIN NotInMem.Moms AS M
			ON D.Dato BETWEEN M.FraDato AND M.TilDato;

	IF EXISTS (SELECT *
				FROM @Datoer
				WHERE Anvendt <> 1) 
	BEGIN
		ROLLBACK TRANSACTION;
		THROW 56333, 'Moms mangler for nogle datoer', 1;
	END;

	IF DATEADD(DAY, 1, @Slutdato) <> 
				(SELECT Fradato		
					FROM NotInMem.Moms
					WHERE Tildato IS NULL)
	BEGIN
		ROLLBACK TRANSACTION;
		THROW 56334, 'Fejl i aktuel moms fradato', 1
	END;
END;
GO
SELECT *
	FROM NotInMem.Moms;

UPDATE NotInMem.Moms
	SET Tildato = '2016-10-31'
	WHERE Tildato IS NULL;

INSERT INTO NotInMem.Moms (Fradato, Tildato, Momspct)
	VALUES ('2016-11-2', NULL, 22);			--Fejl

INSERT INTO NotInMem.Moms (Fradato, Tildato, Momspct)
	VALUES ('2016-11-1', NULL, 22);			-- OK

UPDATE NotInMem.Moms
	SET Fradato = '1977-1-10'			--Fejl
	WHERE Fradato = '1977-1-1';
GO
CREATE TRIGGER InMem.ins_Moms ON InMem.Moms
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AFTER INSERT, UPDATE, DELETE
AS
BEGIN ATOMIC
	WITH (TRANSACTION ISOLATION LEVEL = SERIALIZABLE, LANGUAGE = N'us_english')

	DECLARE @NyStartdato	DATE;
	DECLARE @GlSlutdato		DATE;

	SET @NyStartdato = (SELECT Fradato		
							FROM InMem.Moms
							WHERE Tildato IS NULL);

	SET @GlSlutdato = (SELECT MAX(Tildato)		
							FROM InMem.Moms);

	IF  @NyStartdato <> @GlSlutdato	
	BEGIN
		THROW 56334, 'Fejl i fradato for aktuel moms ', 1
	END;
END;
GO
