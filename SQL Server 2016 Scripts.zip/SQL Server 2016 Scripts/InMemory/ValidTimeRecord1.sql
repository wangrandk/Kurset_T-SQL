USE master;
DROP DATABASE IF EXISTS ValidInMemoryRecordTimeDB;
GO
CREATE DATABASE ValidInMemoryRecordTimeDB
ON PRIMARY
(
	NAME = ValidInMemoryRecordTimeDB_sys,
	FILENAME = N'C:\Databaser\ValidInMemoryRecordTimeDB_sys.mdf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
),
FILEGROUP ValidInMemoryRecordTimeDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = ValidInMemoryRecordTimeDB_InMem_filegroup_fil1,
    FILENAME = N'C:\Databaser\InMem_Data_ValidInMemoryRecordTimeDB1'
),
( 
	NAME = ValidInMemoryRecordTimeDB_InMem_filegroup_fil2,
    FILENAME = N'C:\Databaser\InMem_Data_ValidInMemoryRecordTimeDB2'
),
( 
	NAME = ValidInMemoryRecordTimeDB_InMem_filegroup_fil3,
    FILENAME = N'C:\Databaser\InMem_Data_ValidInMemoryRecordTimeDB3'
),
( 
	NAME = ValidInMemoryRecordTimeDB_InMem_filegroup_fil4,
    FILENAME = N'C:\Databaser\InMem_Data_ValidInMemoryRecordTimeDB4'
)
LOG ON
( 
	NAME = ValidInMemoryRecordTimeDB_log_file_1,
	FILENAME = N'C:\Databaser\ValidInMemoryRecordTimeDB_log.ldf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
);
GO
USE ValidInMemoryRecordTimeDB;
GO
CREATE TABLE dbo.Kunde 
(
	Kundeid			INT	NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY,
	Navn			VARCHAR (30) NOT NULL,
	Adresse			VARCHAR (30) NULL,
	Postnr			SMALLINT  NULL 
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_AND_DATA);
GO
BEGIN TRANSACTION;

INSERT INTO dbo.Kunde (Navn, Adresse, Postnr) VALUES 
	('Jens Hansen', 'Nygade 3', 2000),
	('Lone Jensen', 'Torvet 12', 2000),
	('Peter Knudsen', 'Torvet 44', 2000),
	('Ole Larsen', 'Vestergade 4', 9000),
	('Karen Olsen', 'Borgergade 13', 8000),
	('Karl Nielsen', 'S�ndergade 67', 9000),
	('Hanne Pedersen', NULL, NULL);

COMMIT TRANSACTION;
GO
-- 1
USE ValidInMemoryRecordTimeDB;

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

BEGIN TRANSACTION;

-- start 2 i scriptet ValidTimeRecord2.sql

-- 3
UPDATE dbo.Kunde WITH (SERIALIZABLE)
	SET Navn = 'Jens J�rgen Hansen', Adresse = 'Nygade 3 4. th'
	WHERE Kundeid = 1;

-- 5

COMMIT TRANSACTION;
GO
