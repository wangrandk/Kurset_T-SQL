USE master;
DROP DATABASE NativelyCompiledDB;
GO
CREATE DATABASE NativelyCompiledDB
ON PRIMARY
(
	NAME = NativelyCompiledDB_sys,
	FILENAME = N'C:\Databaser\NativelyCompiledDB_sys.mdf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
),
FILEGROUP NativelyCompiledDB_NotInMem_filegroup  
(
	NAME = NativelyCompiledDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\NativelyCompiledDB_NativelyCompiledDB_NotInMem_filegroup.ndf',
	SIZE = 1000MB,
	MAXSIZE = 5000MB,
	FILEGROWTH = 10%
),
FILEGROUP NativelyCompiledDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = NativelyCompiledDB_InMem_filegroup_fil1,
    FILENAME = N'C:\Databaser\InMem_Data_NativelyCompiledDB1'
),
( 
	NAME = NativelyCompiledDB_InMem_filegroup_fil2,
    FILENAME = N'C:\Databaser\InMem_Data_NativelyCompiledDB2'
),
( 
	NAME = NativelyCompiledDB_InMem_filegroup_fil3,
    FILENAME = N'C:\Databaser\InMem_Data_NativelyCompiledDB3'
),
( 
	NAME = NativelyCompiledDB_InMem_filegroup_fil4,
    FILENAME = N'C:\Databaser\InMem_Data_NativelyCompiledDB4'
)
LOG ON
( 
	NAME = NativelyCompiledDB_log_file_1,
	FILENAME = N'C:\Databaser\NativelyCompiledDB_log.ldf',
	SIZE = 1000MB,
	MAXSIZE = 5000MB,
	FILEGROWTH = 10%
);
GO
USE NativelyCompiledDB;
GO
CREATE SCHEMA InMem;
GO
CREATE TABLE InMem.Postopl 
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY NONCLUSTERED,	
	Bynavn			VARCHAR (30) NOT NULL
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_AND_DATA);

CREATE TABLE InMem.Kunde 
(
	Kundeid			INT				NOT NULL 
					CONSTRAINT PK_Kunde PRIMARY KEY NONCLUSTERED IDENTITY,
	Navn			VARCHAR (30)	NOT NULL
					INDEX hash_Kunde_Navn HASH WITH (BUCKET_COUNT = 30000),
	Adresse			VARCHAR (30)	NULL,
	Postnr			SMALLINT		NULL,
	INDEX cci_Kunde CLUSTERED COLUMNSTORE
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_AND_DATA);
GO
SET NOCOUNT ON 
INSERT INTO InMem.Postopl (Postnr, Bynavn) VALUES 
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(9000, 'Aalborg');

INSERT INTO InMem.Kunde (Navn, Adresse, Postnr) VALUES 
	('Jens Hansen', 'Nygade 3', 2000),
	('Lone Jensen', 'Torvet 12', 2000),
	('Peter Knudsen', 'Torvet 44', 2000),
	('Ole Larsen', 'Vestergade 4', 9000),
	('Karen Olsen', 'Borgergade 13', 8000),
	('Karl Nielsen', 'S�ndergade 67', 9000),
	('Hanne Pedersen', NULL, NULL);
GO
INSERT INTO InMem.Kunde (Navn, Adresse, Postnr)
	SELECT Navn, Adresse, Postnr
		FROM InMem.Kunde;
GO 17
SELECT COUNT(*)
	FROM InMem.Kunde;
GO
SELECT COUNT(*)
	FROM InMem.Kunde
	WHERE Kundeid > 500000;

SELECT COUNT(*)
	FROM InMem.Kunde
	WHERE Navn = 'Ole Larsen';
