USE master;
DROP DATABASE IF EXISTS TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;

CREATE TABLE dbo.Postopl 
(
	Postnr 		SMALLINT		NOT NULL 
				CONSTRAINT PK_Postopl PRIMARY KEY,
	Bynavn 		VARCHAR (20)	NOT NULL
);

CREATE TABLE dbo.Kunde
(
	KundeId		INT				NOT NULL IDENTITY
				CONSTRAINT PK_Kunde PRIMARY KEY,
	Navn		VARCHAR(30)		NOT NULL,
	Postnr		SMALLINT		NOT NULL
				CONSTRAINT FK_Kunde_Postopl 
				FOREIGN KEY REFERENCES dbo.Postopl (Postnr)
				INDEX nc_Kunde_Postnr
);

CREATE TABLE dbo.Koeb
(
	KoebsId		INT				NOT NULL IDENTITY
				CONSTRAINT PK_Koeb PRIMARY KEY,
	VareId		INT				NOT NULL,
	Antal		INT				NOT NULL,
	Pris		DECIMAL(9,2)	NOT NULL,
	KundeID		INT				NOT NULL
				CONSTRAINT FK_Kunde_Koeb
				FOREIGN KEY REFERENCES dbo.Kunde (KundeId)
				INDEX nc_Kunde_Postnr
);
GO
SET NOCOUNT ON;
GO
INSERT INTO dbo.Postopl VALUES 
	(1127, 'K�benhavn K'),
	(1001, 'K�benhavn K'),
	(1129, 'K�benhavn K'),
	(1130, 'K�benhavn K'),
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(8200, 'Aarhus N'),
	(8210, 'Aarhus V'),
	(8240, 'Risskov'),
	(8270, 'H�jbjerg'),
	(8310, 'Tranbjerg J'),
	(9000, 'Aalborg'),
	(9400, 'N�rresundby'),
	(9600, 'Br�nderslev'),
	(9800, 'Hj�rring'),
	(9990, 'Skagen'),
	(2600, 'Glostrup'),
	(2605, 'Br�ndby'),
	(2610, 'R�dovre'),
	(2620, 'Albertslund'),
	(2625, 'Vallensb�k'),
	(2630, 'Taastrup'),
	(2635, 'Ish�j'),
	(2640, 'Hedehusene'),
	(2650, 'Hvidovre'),
	(2660, 'Br�ndby Strand');
GO
INSERT INTO dbo.Kunde (Navn, Postnr) VALUES
	('Ole Christensen', 2000),
	('Hanne Poulsen', 2625),
	('Carl Olsen', 9800),
	('Carina Larsen', 2610),
	('Knud Christensen', 2650),
	('Peter Didriksen', 2625),
	('Ina Lauersen', 9400),
	('Lise Larsen', 2610),
	('Carl Christensen', 2000),
	('�ge Carlsen', 9990),
	('Tom Petersen', 9800),
	('Hans Larsen', 2610);
GO
INSERT INTO dbo.Kunde (Navn, Postnr)
	SELECT	Navn,
			Postnr
		FROM dbo.Kunde;
GO 7
INSERT INTO dbo.Kunde (Navn, Postnr) VALUES
	('Jens Ole Andersen', 8000),
	('Hanne Louise Poulsen', 8200);
GO 20
INSERT INTO dbo.Kunde (Navn, Postnr) VALUES
	('Carl Otto Olsen', 8270),
	('Carina Elisabeth Larsen', 8240);
GO 10
INSERT INTO dbo.Koeb (VareId, Antal, Pris, KundeID)
	SELECT	(KundeID % 112) + (DATEPART(NANOSECOND, SYSDATETIME()) % 234) + 1,
			(DATEPART(NANOSECOND, SYSDATETIME()) % 6) + 1,
			12.25,
			KundeId
		FROM dbo.Kunde
		WHERE Kunde.KundeId % 4 = 3;
GO 10
INSERT INTO dbo.Koeb (VareId, Antal, Pris, KundeID)
	SELECT	(KundeID % 33) + (DATEPART(NANOSECOND, SYSDATETIME()) % 119) + 1,
			(DATEPART(NANOSECOND, SYSDATETIME()) % 5) + 1,
			7.50,
			KundeId
		FROM dbo.Kunde
		WHERE Kunde.KundeId % 4 = 2;
GO 50
INSERT INTO dbo.Koeb (VareId, Antal, Pris, KundeID)
	SELECT	(KundeID % 33) + (DATEPART(NANOSECOND, SYSDATETIME()) % 77) + 1,
			(DATEPART(NANOSECOND, SYSDATETIME()) % 12) + 1,
			23.00,
			KundeId
		FROM dbo.Kunde
		WHERE Kunde.KundeId % 4 = 1;
GO 2
INSERT INTO dbo.Koeb (VareId, Antal, Pris, KundeID)
	SELECT	(KundeID % 33) + (DATEPART(NANOSECOND, SYSDATETIME()) % 57) + 1,
			(DATEPART(NANOSECOND, SYSDATETIME()) % 6) + 1,
			2.50,
			KundeId
		FROM dbo.Kunde
		WHERE Kunde.KundeId % 4 = 0;
GO 5
SELECT	Navn,
		COUNT(*)
	FROM dbo.Kunde
	GROUP BY Navn;

SELECT	COUNT(*)
	FROM dbo.Koeb;
GO
CREATE NONCLUSTERED COLUMNSTORE INDEX nc_cs_Kunde 
	ON dbo.Kunde(Navn, Postnr);

CREATE NONCLUSTERED COLUMNSTORE INDEX nc_cs_Koeb 
	ON dbo.Koeb(VareId, Antal, Pris, KundeId);
GO
SELECT *
	FROM dbo.Kunde  INNER JOIN dbo.Postopl
		ON Kunde.Postnr = Postopl.Postnr
					INNER JOIN dbo.Koeb 
		ON Kunde.KundeId = Koeb.KundeID
	WHERE Kunde.Navn = 'Hans Larsen'AND 
			Koeb.Antal = 3;

SELECT *
	FROM dbo.Kunde  INNER JOIN dbo.Postopl
		ON Kunde.Postnr = Postopl.Postnr
					LEFT JOIN dbo.Koeb 
		ON Kunde.KundeId = Koeb.KundeID
	WHERE	Kunde.Navn = 'Carina Elisabeth Larsen'AND 
			Koeb.Antal = 3;

SELECT *
	FROM dbo.Kunde  INNER JOIN dbo.Postopl
		ON Kunde.Postnr = Postopl.Postnr
					LEFT JOIN dbo.Koeb 
		ON Kunde.KundeId = Koeb.KundeID
	WHERE	Kunde.Navn = 'Jens Ole Andersen' AND 
			Koeb.Antal = 3;
GO
	