USE master;
GO
DROP DATABASE IF EXISTS TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB
GO
CREATE TABLE dbo.t
(
	ID			INT				NOT NULL IDENTITY
				CONSTRAINT PK_t PRIMARY KEY,
	Fyld		CHAR(500)		NOT NULL
				CONSTRAINT DF_t_Fyld DEFAULT(REPLICATE('x', 500)),
	Dato		DATE			NOT NULL
				CONSTRAINT DF_t_Dato DEFAULT(SYSDATETIME())
);
GO
INSERT INTO dbo.t (Dato) VALUES
	(DATEADD(DAY, -5, SYSDATETIME())),
	(DATEADD(DAY, -5, SYSDATETIME())),
	(DATEADD(DAY, -10, SYSDATETIME())),
	(DATEADD(DAY, -10, SYSDATETIME())),
	(DATEADD(DAY, -10, SYSDATETIME())),
	(DATEADD(DAY, -15, SYSDATETIME())),
	(DATEADD(DAY, -15, SYSDATETIME())),
	(DATEADD(DAY, -15, SYSDATETIME())),
	(DATEADD(DAY, -15, SYSDATETIME())),
	(DATEADD(DAY, -20, SYSDATETIME())),
	(DATEADD(DAY, -20, SYSDATETIME())),
	(DATEADD(DAY, -20, SYSDATETIME())),
	(DATEADD(DAY, -20, SYSDATETIME())),
	(DATEADD(DAY, -20, SYSDATETIME()));
GO
INSERT INTO dbo.t (Dato)
	SELECT Dato
		FROM dbo.t;
GO 14
INSERT INTO dbo.t (Dato) VALUES
	(SYSDATETIME());
GO 10
SELECT	Dato,
		COUNT(*) AS Antal
	FROM dbo.t
	GROUP BY Dato;
GO
CREATE INDEX nc_t_Dato ON dbo.t(Dato);	-- Memory vises ikke, hvis der er index defineret
GO
CREATE PROCEDURE dbo.usp_t
(
	@Dato		DATE
)
AS
BEGIN 
	SELECT	Fyld,
			COUNT(*) AS Antal
		FROM dbo.t
		WHERE Dato >= @Dato
		GROUP BY Fyld;
END;
GO
ALTER DATABASE SCOPED CONFIGURATION 
	CLEAR PROCEDURE_CACHE;
GO
DECLARE @ParamDato	DATE = DATEADD(DAY, 0, SYSDATETIME());

EXEC dbo.usp_t @Dato = @ParamDato;
GO
DECLARE @ParamDato	DATE = DATEADD(DAY, -26, SYSDATETIME());

EXEC dbo.usp_t @Dato = @ParamDato;
GO
------------------------------------------------------------
GO
ALTER DATABASE SCOPED CONFIGURATION 
	CLEAR PROCEDURE_CACHE;
GO
DECLARE @ParamDato	DATE = DATEADD(DAY, -26, SYSDATETIME());

EXEC dbo.usp_t @Dato = @ParamDato;
GO
DECLARE @ParamDato	DATE = DATEADD(DAY, 0, SYSDATETIME());

EXEC dbo.usp_t @Dato = @ParamDato;
GO
SELECT *
	FROM sys.database_scoped_configurations;
	