USE master;
DROP DATABASE IF EXISTS TestDB;
GO
CREATE DATABASE TestDB
ON PRIMARY
	(NAME = TestDB_Primary,
	 FILENAME = N'C:\Databaser\TestDB_Primary.mdf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	 FILEGROWTH = 10%),

FILEGROUP TestDB_filegroup1
	(NAME = TestDB_filegroup1_file1,
	 FILENAME = N'C:\Databaser\TestDB_filegroup1_file1.ndf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	FILEGROWTH = 10%),

FILEGROUP TestDB_filegroup2
	(NAME = TestDB_filegroup2_file1,
	 FILENAME = N'C:\Databaser\TestDB_filegroup2_file1.ndf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	FILEGROWTH = 10%)

LOG ON
	(NAME = TestDB_log_file1,
	 FILENAME = N'C:\Databaser\TestDB_Log1.ldf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	 FILEGROWTH = 10%);
GO
ALTER DATABASE TestDB SET MIXED_PAGE_ALLOCATION OFF;
GO
USE TestDB;
GO
CREATE TABLE dbo.t1
(
	ID			INT				NOT NULL IDENTITY
				CONSTRAINT PK_t PRIMARY KEY,
	Navn		VARCHAR(20)		NOT NULL,
	Dummy		CHAR(1500)		NOT NULL
				CONSTRAINT DF_t_Dummy DEFAULT(REPLICATE('0123456789', 100))
) ON TestDB_filegroup1;
GO
INSERT INTO dbo.t1 (Navn) VALUES
	('Ole Christensen'),
	('Hanne Poulsen'),
	('Carl Olsen'),
	('Carina Larsen');
GO 500
SELECT *
	INTO dbo.t2
	FROM dbo.t1;
GO
DELETE
	FROM dbo.t1
	WHERE ID % 17 = 2;

DELETE
	FROM dbo.t2
	WHERE ID % 11 = 6;

UPDATE dbo.t1
	SET Dummy = REPLICATE('0987654321', 150)
	WHERE ID % 4 = 2;

UPDATE dbo.t2
	SET Dummy = REPLICATE('0987654321', 150)
	WHERE ID % 5 = 2;
GO
SELECT *
	INTO dbo.t3
	FROM dbo.t1;
GO
SELECT	 SUM(unallocated_extent_page_count) AS [free pages],   
		(SUM(unallocated_extent_page_count)* 1.0 / 128) AS [free space in MB]  
	FROM sys.dm_db_file_space_usage;  
GO
SELECT	*
	FROM sys.dm_db_file_space_usage; 
GO
USE master;
GO
DROP DATABASE IF EXISTS TestDB;
GO
CREATE DATABASE TestDB
ON PRIMARY
	(NAME = TestDB_Primary,
	 FILENAME = N'C:\Databaser\TestDB_Primary.mdf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	 FILEGROWTH = 10%),

FILEGROUP TestDB_filegroup1
	(NAME = TestDB_filegroup1_file1,
	 FILENAME = N'C:\Databaser\TestDB_filegroup1_file1.ndf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	FILEGROWTH = 10%),

FILEGROUP TestDB_filegroup2
	(NAME = TestDB_filegroup2_file1,
	 FILENAME = N'C:\Databaser\TestDB_filegroup2_file1.ndf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	FILEGROWTH = 10%)

LOG ON
	(NAME = TestDB_log_file1,
	 FILENAME = N'C:\Databaser\TestDB_Log1.ldf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	 FILEGROWTH = 10%);
GO
ALTER DATABASE TestDB SET MIXED_PAGE_ALLOCATION ON;
GO
USE TestDB;
GO
CREATE TABLE dbo.t1
(
	ID			INT				NOT NULL IDENTITY
				CONSTRAINT PK_t PRIMARY KEY,
	Navn		VARCHAR(20)		NOT NULL,
	Dummy		CHAR(1500)		NOT NULL
				CONSTRAINT DF_t_Dummy DEFAULT(REPLICATE('0123456789', 100))
) ON TestDB_filegroup1;
GO
INSERT INTO dbo.t1 (Navn) VALUES
	('Ole Christensen'),
	('Hanne Poulsen'),
	('Carl Olsen'),
	('Carina Larsen');
GO 500
SELECT *
	INTO dbo.t2
	FROM dbo.t1;
GO
DELETE
	FROM dbo.t1
	WHERE ID % 17 = 2;

DELETE
	FROM dbo.t2
	WHERE ID % 11 = 6;

UPDATE dbo.t1
	SET Dummy = REPLICATE('0987654321', 150)
	WHERE ID % 4 = 2;

UPDATE dbo.t2
	SET Dummy = REPLICATE('0987654321', 150)
	WHERE ID % 5 = 2;
GO
SELECT *
	INTO dbo.t3
	FROM dbo.t1;
GO
SELECT	 SUM(unallocated_extent_page_count) AS [free pages],   
		(SUM(unallocated_extent_page_count)* 1.0 / 128) AS [free space in MB]  
	FROM sys.dm_db_file_space_usage;  
GO
SELECT	*
	FROM sys.dm_db_file_space_usage; 
GO
---  Modified EXTENTS
USE master;
DROP DATABASE IF EXISTS TestDB;
GO
CREATE DATABASE TestDB
ON PRIMARY
	(NAME = TestDB_Primary,
	 FILENAME = N'C:\Databaser\TestDB_Primary.mdf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	 FILEGROWTH = 10%),

FILEGROUP TestDB_filegroup1
	(NAME = TestDB_filegroup1_file1,
	 FILENAME = N'C:\Databaser\TestDB_filegroup1_file1.ndf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	FILEGROWTH = 10%),

FILEGROUP TestDB_filegroup2
	(NAME = TestDB_filegroup2_file1,
	 FILENAME = N'C:\Databaser\TestDB_filegroup2_file1.ndf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	FILEGROWTH = 10%)

LOG ON
	(NAME = TestDB_log_file1,
	 FILENAME = N'C:\Databaser\TestDB_Log1.ldf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	 FILEGROWTH = 10%);
GO
ALTER DATABASE TestDB SET MIXED_PAGE_ALLOCATION OFF;
GO
BACKUP DATABASE TestDB TO DISK = 'c:\rod\TestDB.bak' WITH FORMAT;
GO
USE TestDB;
GO
CREATE TABLE dbo.t1
(
	ID			INT				NOT NULL IDENTITY
				CONSTRAINT PK_t PRIMARY KEY,
	Navn		VARCHAR(20)		NOT NULL,
	Dummy		CHAR(1500)		NOT NULL
				CONSTRAINT DF_t_Dummy DEFAULT(REPLICATE('0123456789', 100))
) ON TestDB_filegroup1;
GO
INSERT INTO dbo.t1 (Navn) VALUES
	('Ole Christensen'),
	('Hanne Poulsen'),
	('Carl Olsen'),
	('Carina Larsen');
GO 500
SELECT *
	INTO dbo.t2
	FROM dbo.t1;
GO
DELETE
	FROM dbo.t1
	WHERE ID % 17 = 2;

DELETE
	FROM dbo.t2
	WHERE ID % 11 = 6;

UPDATE dbo.t1
	SET Dummy = REPLICATE('0987654321', 150)
	WHERE ID % 4 = 2;

UPDATE dbo.t2
	SET Dummy = REPLICATE('0987654321', 150)
	WHERE ID % 5 = 2;
GO
SELECT *
	INTO dbo.t3
	FROM dbo.t1;
GO
SELECT	*
	FROM sys.dm_db_file_space_usage; 
GO
BACKUP DATABASE TestDB TO DISK = 'c:\rod\TestDB.bak' WITH FORMAT;
GO
UPDATE dbo.t1
	SET Dummy = REPLICATE('ABCDEFGH', 20)
	WHERE ID > (SELECT MAX(ID) FROM dbo.t1) - 20;
GO
SELECT	*
	FROM sys.dm_db_file_space_usage; 
GO
