USE IndexDB;
GO
CREATE STATISTICS st_Person_Navn ON dbo.Person(Navn);
CREATE STATISTICS st_Person_Fornavn_Efternavn ON dbo.Person(Fornavn, Efternavn);
GO 
SELECT	hist.step_number, 
		hist.range_high_key, 
		hist.range_rows, 
		hist.equal_rows, 
		hist.distinct_range_rows, 
		hist.average_range_rows
	FROM sys.stats AS s CROSS APPLY sys.dm_db_stats_histogram(s.[object_id], s.stats_id) AS hist
	WHERE s.[name] = N'st_Person_Navn';
GO
SELECT	hist.step_number, 
		hist.range_high_key, 
		hist.range_rows, 
		hist.equal_rows, 
		hist.distinct_range_rows, 
		hist.average_range_rows
	FROM sys.stats AS s CROSS APPLY sys.dm_db_stats_histogram(s.[object_id], s.stats_id) AS hist
	WHERE s.[name] = N'st_Person_Fornavn_Efternavn';
