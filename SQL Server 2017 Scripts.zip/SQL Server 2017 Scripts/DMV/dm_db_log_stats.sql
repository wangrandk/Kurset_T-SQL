USE IndexDb;
GO
SELECT *
	FROM sys.dm_db_log_stats(DB_ID());
