USE master;
GO
DROP DATABASE IF EXISTS TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
CREATE TABLE dbo.t
(
	Id			INT				NOT NULL IDENTITY
				CONSTRAINT PK_t PRIMARY KEY,
	Navn		VARCHAR (20)	NOT NULL 
				CONSTRAINT DF_t_Navn DEFAULT('Marianne Thomsen'),
	Dummy		CHAR (2000)		NOT NULL 
				CONSTRAINT DF_t_Dummy DEFAULT(REPLICATE('x', 2000))
);
GO
SET NOCOUNT ON;
GO
BACKUP DATABASE TestDB TO DISK = 'c:\Rod\TestDb.bak' WITH FORMAT;
GO
INSERT INTO dbo.t DEFAULT VALUES;
GO 20
INSERT INTO dbo.t(Navn)
	SELECT Navn
		FROM dbo.t
GO 10
SELECT *
	FROM  sys.dm_db_log_info(NULL);		-- NULL eller DEFAULT er aktuel DB
GO
UPDATE dbo.t	
	SET Dummy = REPLICATE('y', 2000);
GO
SELECT *
	FROM  sys.dm_db_log_info(NULL);
GO
BACKUP LOG TestDB TO DISK = 'c:\Rod\TestDb.log' WITH FORMAT;
GO
SELECT *
	FROM  sys.dm_db_log_info(NULL);	
GO
UPDATE dbo.t	
	SET Dummy = REPLICATE('a', 2000);

UPDATE dbo.t	
	SET Dummy = REPLICATE('b', 2000);

UPDATE dbo.t	
	SET Dummy = REPLICATE('c', 2000);

UPDATE dbo.t	
	SET Dummy = REPLICATE('d', 2000);
GO
SELECT *
	FROM  sys.dm_db_log_info(NULL);
