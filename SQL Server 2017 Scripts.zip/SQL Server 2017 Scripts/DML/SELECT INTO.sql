USE master;
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB
ON PRIMARY
	(NAME = TestDB_Primary,
	 FILENAME = N'C:\Databaser\TestDB_Primary.mdf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	 FILEGROWTH = 10%),

FILEGROUP TestDB_filegroup1
	(NAME = TestDB_filegroup1_file1,
	 FILENAME = N'C:\Databaser\TestDB_filegroup1_file1.ndf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	FILEGROWTH = 10%),

FILEGROUP TestDB_filegroup2
	(NAME = TestDB_filegroup2_file1,
	 FILENAME = N'C:\Databaser\TestDB_filegroup2_file1.ndf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	FILEGROWTH = 10%)

LOG ON
	(NAME = TestDB_log_file1,
	 FILENAME = N'C:\Databaser\TestDB_Log1.ldf',
	 SIZE = 5MB,
	 MAXSIZE = 50MB,
	 FILEGROWTH = 10%);
GO
USE TestDB;
GO
CREATE SCHEMA Schema_filegroup1;
GO
CREATE SCHEMA Schema_filegroup2;
GO
CREATE TABLE Schema_filegroup1.t_filegroup1
(
	ID			INT				NOT NULL IDENTITY
				CONSTRAINT PK_t PRIMARY KEY,
	Navn		VARCHAR(20)		NOT NULL,
	Dummy		CHAR(2000)		NOT NULL
				CONSTRAINT DF_t_Dummy DEFAULT(REPLICATE('0123456789', 200))
) ON TestDB_filegroup1;
GO
SET NOCOUNT ON;
GO
INSERT INTO Schema_filegroup1.t_filegroup1 (Navn) VALUES
	('Ole Christensen'),
	('Hanne Poulsen'),
	('Carl Olsen'),
	('Carina Larsen');
GO 500
SELECT	file_id,
		name, 
		size AS SizeInPages,
		FILEPROPERTY(name, 'SpaceUsed') AS SpaceUsedInPages,
		physical_name
	FROM sys.database_files;
GO
SELECT *
	INTO Schema_filegroup2.t_filegroup2 ON TestDB_filegroup2
	FROM Schema_filegroup1.t_filegroup1;
GO
SELECT	file_id,
		name, 
		size AS SizeInPages,
		FILEPROPERTY(name, 'SpaceUsed') AS SpaceUsedInPages,
		physical_name
	FROM sys.database_files;

SELECT *
	FROM sys.filegroups;
GO
SELECT *
	INTO Schema_filegroup2.t_default			-- anvender DEFAULT filegroup
	FROM Schema_filegroup1.t_filegroup1;
GO
SELECT	file_id,
		name, 
		size AS SizeInPages,
		FILEPROPERTY(name, 'SpaceUsed') AS SpaceUsedInPages,
		physical_name
	FROM sys.database_files;

SELECT *
	FROM sys.filegroups;
