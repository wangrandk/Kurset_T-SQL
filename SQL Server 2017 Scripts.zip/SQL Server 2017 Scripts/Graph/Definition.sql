USE master;
DROP DATABASE IF EXISTS GraphDB;
GO
CREATE DATABASE GraphDB;
GO
USE GraphDB;
GO
CREATE TABLE dbo.Postopl
(
	Postnr		SMALLINT		NOT NULL
				CONSTRAINT PK_Postopl PRIMARY KEY, 
	Bynavn		VARCHAR(20)		NOT NULL,
);
-- Node
CREATE TABLE dbo.Person 
(
	PersonId		INT			NOT NULL
					CONSTRAINT PK_Person PRIMARY KEY, 
	Navn			VARCHAR(30) NOT NULL,
	Adresse			VARCHAR(30) NULL,
	Postnr			SMALLINT	NULL
					CONSTRAINT FK_Person_Postopl FOREIGN KEY REFERENCES dbo.Postopl(Postnr)
) AS NODE;
GO
-- Relationstyper
CREATE TABLE dbo.KontaktFormType
(
	KontaktForm		VARCHAR(40)	NOT NULL
					CONSTRAINT PK_KontaktFormType PRIMARY KEY
);

CREATE TABLE dbo.FamilieRelationsType
(
	FamilieRelation	VARCHAR(40) NOT NULL
					CONSTRAINT PK_FamilieRelationsType PRIMARY KEY
);
GO
-- Edge
CREATE TABLE dbo.Venner 
(
	StartDate		DATE		NULL,
	KontaktForm		VARCHAR(40) NOT NULL
					CONSTRAINT	FK_Venner_KontaktFormType FOREIGN KEY
								REFERENCES dbo.KontaktFormType(KontaktForm)

) AS EDGE;

CREATE TABLE dbo.Familie
(
	FamilieRelation	VARCHAR(40) NOT NULL
					CONSTRAINT	FK_Familie_FamilieRelationsType FOREIGN KEY
								REFERENCES dbo.FamilieRelationsType(FamilieRelation)
) AS EDGE;

CREATE TABLE dbo.Kollega
(
	Virksomhed		VARCHAR(40) NULL
) AS EDGE;
GO
INSERT INTO dbo.Postopl VALUES
	(2000, 'Frederiksberg'),
	(4000, 'Roskilde'),
	(5000, 'Odense C'),
	(6000, 'Kolding'),
	(8000, 'Aarhus C'),
	(9000, 'Aalborg');

INSERT INTO dbo.KontaktFormType VALUES
	('Skolekammerat'),
	('Nabo'),
	('God ven/veninde'),
	('Sport'),
	('Bekendt');

INSERT INTO dbo.FamilieRelationsType VALUES
	('�gtef�lle'),
	('Mor'),
	('Far'),
	('Datter'),
	('S�n'),
	('Onkel'),
	('Tante'),
	('Bedstefor�ldre'),
	('Svigerfar'),
	('Svigermor'),
	('Svigers�n'),
	('Svigerdatter'),
	('S�ster'),
	('Bror');
GO
 -- Familie Hansen
INSERT INTO dbo.Person VALUES 
	(1, 'Bente Hansen', 'Nygade 42', 6000),			-- For�ldre
	(2, 'Hans Hansen', 'Nygade 42', 6000),			-- For�ldre

	(3, 'Christina Hansen', NULL, NULL),			-- Barn
	(4, 'Peter Hansen', NULL, NULL),				-- Barn

	(10, 'Marie Olsen', 'Torvet 3', 8000),			-- Bedstefor�ldre

	(11, 'Karen Hansen', 'S�ndergade 3', 5000),		-- Bedstefor�ldre
	(12, 'Knud Hansen', 'S�ndergade 3', 5000);		-- Bedstefor�ldre
GO

 -- Create a friend edge, that connect Alice and John
INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 1),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 2), '�gtef�lle');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 1),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 3), 'Datter');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 1),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 4), 'S�n');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 1),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 10), 'Mor');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 1),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 11), 'Svigermor');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 1),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 12), 'Svigerfar');



INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 2),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 1), '�gtef�lle');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 2),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 3), 'Datter');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 2),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 4), 'S�n');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 2),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 11), 'Mor');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 2),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 12), 'Far');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 2),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 10), 'Svigermor');



INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 3),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 1), 'Mor');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 3),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 2), 'Far');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 3),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 4), 'Bror');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 3),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 10), 'Bedstefor�ldre');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 3),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 11), 'Bedstefor�ldre');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 3),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 12), 'Bedstefor�ldre');



INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 4),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 1), 'Mor');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 4),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 2), 'Far');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 4),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 3), 'S�ster');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 4),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 10), 'Bedstefor�ldre');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 4),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 11), 'Bedstefor�ldre');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 4),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 12), 'Bedstefor�ldre');



INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 10),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 1), 'Datter');
	 


INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 11),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 2), 'S�n');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 12),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 2), 'S�n');
GO
-- Find Familie
SELECT	PersonSoeg.Navn, 
		Familie.FamilieRelation,
		PersonRelation.Navn
	FROM	dbo.Person AS PersonSoeg, 
			dbo.Familie, 
			dbo.Person AS PersonRelation

	WHERE	MATCH(PersonSoeg - (Familie) -> PersonRelation) AND

			PersonSoeg.PersonId = 1;


SELECT	PersonSoeg.Navn, 
		Familie.FamilieRelation,
		PersonRelation.Navn
	FROM	dbo.Person AS PersonSoeg, 
			dbo.Familie, 
			dbo.Person AS PersonRelation
	
	WHERE	MATCH(PersonSoeg - (Familie) -> PersonRelation) AND
	
			PersonSoeg.PersonId = 3;
GO
-- Familie Olsen
INSERT INTO dbo.Person VALUES 
	(101, 'Susanne Olsen', 'Vestergade 3', 6000),		-- �gtef�lle
	(102, 'Tom Hansen', 'Vestergade 3', 6000);			-- �gtef�lle
GO
INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 101),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 102), '�gtef�lle');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 102),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 101), '�gtef�lle');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 102),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 2), 'Bror');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 102),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 11), 'Mor');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 102),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 12), 'Far');
GO
-- Venner til familie Hansen
INSERT INTO dbo.Person VALUES 
	(1001, 'Lise Larsen', 'S�ndergade 13', 6000),		
	(1002, 'Ulla Carlsen', 'Bakkegade 24', 6000);
GO
INSERT INTO dbo.Venner VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 1001),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 1), '2012-4-10', 'Sport');

INSERT INTO dbo.Venner VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 1002),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 1), NULL, 'Sport');

INSERT INTO dbo.Venner VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 1),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 1001), '2012-4-10', 'Sport');

INSERT INTO dbo.Venner VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 1),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 1002), '2005-2-28', 'Sport');

INSERT INTO dbo.Venner VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 1002),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 101), NULL, 'Bekendt');

INSERT INTO dbo.Venner VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 2),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 1002), NULL, 'Bekendt');
GO
-- Kollega
INSERT INTO dbo.Kollega VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 2),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 1002), 'Malerbixen aps');

INSERT INTO dbo.Kollega VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 1002),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 2), 'Malerbixen aps');

INSERT INTO dbo.Kollega VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 2),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 101), 'Malerbixen aps');

INSERT INTO dbo.Kollega VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 101),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 2), 'Malerbixen aps');

INSERT INTO dbo.Kollega VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 2),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 102), 'Silvan');

INSERT INTO dbo.Kollega VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 102),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 2), 'Silvan');

INSERT INTO dbo.Kollega VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 102),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 101), 'Silvan');

INSERT INTO dbo.Kollega VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 102),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 1001), 'Silvan');
GO
SELECT *
	FROM dbo.Familie;

SELECT *
	FROM dbo.Venner;

SELECT *
	FROM dbo.Kollega;
GO
CREATE PROCEDURE usp_Relationer
(
	@PersonId		INT
)
AS
BEGIN
	WITH 
	FamilieRelationer
	AS
	(
	SELECT	CONCAT_WS(' - ', PersonSoeg.PersonId, PersonSoeg.Navn) AS Navn, 
			Familie.FamilieRelation,
			CONCAT_WS(' - ', PersonRelation.PersonId, PersonRelation.Navn) AS RelationTil
		FROM	dbo.Person AS PersonSoeg, 
				dbo.Familie, 
				dbo.Person AS PersonRelation
		WHERE	MATCH(PersonSoeg - (Familie) -> PersonRelation) AND
				PersonSoeg.PersonId = @PersonId
	),
	VenneRelationer
	AS
	(
	SELECT	CONCAT_WS(' - ', PersonSoeg.PersonId, PersonSoeg.Navn) AS Navn, 
			Venner.KontaktForm,
			CONCAT_WS(' - ', PersonRelation.PersonId, PersonRelation.Navn) AS RelationTil
		FROM	dbo.Person AS PersonSoeg, 
				dbo.Venner, 
				dbo.Person AS PersonRelation
		WHERE	MATCH(PersonSoeg - (Venner) -> PersonRelation) AND
				PersonSoeg.PersonId = @PersonId
	),
	KollegaRelationer
	AS
	(
	SELECT	CONCAT_WS(' - ', PersonSoeg.PersonId, PersonSoeg.Navn) AS Navn, 
			Kollega.Virksomhed,
			CONCAT_WS(' - ', PersonRelation.PersonId, PersonRelation.Navn) AS RelationTil
		FROM	dbo.Person AS PersonSoeg, 
				dbo.Kollega, 
				dbo.Person AS PersonRelation
		WHERE	MATCH(PersonSoeg - (Kollega) -> PersonRelation) AND
				PersonSoeg.PersonId = @PersonId
	)
	SELECT *, 'Familie' AS Relationstype
		FROM FamilieRelationer
	UNION ALL
	SELECT *, 'Venner'
		FROM VenneRelationer
	UNION ALL
	SELECT *, 'Kollega'
		FROM KollegaRelationer;
END;
GO
EXEC usp_Relationer 2;

DELETE
	FROM dbo.Venner
	WHERE	$from_id = (SELECT $node_id FROM dbo.Person WHERE PersonId = 2) AND
			$to_id =  (SELECT $node_id FROM dbo.Person WHERE PersonId = 1002);

EXEC usp_Relationer 2;
GO
SELECT *
	FROM dbo.KontaktFormType;

EXEC usp_Relationer 1002;

UPDATE dbo.Venner
	SET KontaktForm = 'God ven/veninde'
	WHERE	$from_id = (SELECT $node_id FROM dbo.Person WHERE PersonId = 1002) AND
			$to_id =  (SELECT $node_id FROM dbo.Person WHERE PersonId = 101);

EXEC usp_Relationer 1002;
GO
-- Find Kollega til en Kollega
DECLARE @PersonId		INT = 2;

SELECT	CONCAT_WS(' - ', PersonSoeg.PersonId, PersonSoeg.Navn) AS Navn, 
		Kollega.Virksomhed,
		CONCAT_WS(' - ', PersonRelation.PersonId, PersonRelation.Navn) AS RelationTil,
		KollegaKollega.Virksomhed,
		CONCAT_WS(' - ', PersonRelationRelation.PersonId, PersonRelationRelation.Navn) AS RelationTilRelation
	FROM	dbo.Person AS PersonSoeg,	
			dbo.Kollega AS Kollega, 
			dbo.Person AS PersonRelation, 
			Kollega AS KollegaKollega,
			dbo.Person AS PersonRelationRelation

	WHERE	MATCH(PersonSoeg - (Kollega) -> PersonRelation - (KollegaKollega) -> PersonRelationRelation) AND
			
			PersonSoeg.PersonId = @PersonId AND
			PersonSoeg.Navn <> PersonRelationRelation.Navn;		-- Undg�r af referere tilbage
GO
-- f�lgende er ens
SELECT	PersonSoeg.Navn, 
		Familie.FamilieRelation,
		PersonRelation.Navn
	FROM	dbo.Person AS PersonSoeg, 
			dbo.Familie, 
			dbo.Person AS PersonRelation

	WHERE	MATCH(PersonSoeg - (Familie) -> PersonRelation) AND

			PersonSoeg.PersonId = 1;

SELECT	PersonSoeg.Navn, 
		Familie.FamilieRelation,
		PersonRelation.Navn
	FROM	dbo.Person AS PersonSoeg, 
			dbo.Familie, 
			dbo.Person AS PersonRelation

	WHERE	MATCH(PersonRelation <- (Familie) - PersonSoeg) AND

			PersonSoeg.PersonId = 1;
GO
-- Den moderne familie
INSERT INTO dbo.Person VALUES 
	(100001, 'Kristina Olsen', 'N�rregade 28', 8000),	-- Tidligere �gtef�ller
	(100002, 'Peter Larsen', 'Stationsgade 1', 9000),	-- Tidligere �gtef�ller

	(100003, 'Kurt Thomsen', 'N�rregade 28', 8000),		-- Ny �gtef�lle

	(100004, 'Mie Larsen', 'Stationsgade 1', 9000),		-- Ny �gtef�lle

	(100100, 'Lars Larsen', NULL, NULL),				-- Barn af Kristina og Peter

	(100101, 'Sofus Thomsen', NULL, NULL),				-- Barn af Kristina og Kurt

	(100102, 'Louise Larsen', NULL, NULL),				-- Barn af Peter og Mie
	(100103, 'Christina Larsen', NULL, NULL);			-- Barn af Peter og Mie
GO

 -- Create a friend edge, that connect Alice and John
INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100001),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100003), '�gtef�lle');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100003),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100001), '�gtef�lle');


INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100002),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100004), '�gtef�lle');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100004),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100002), '�gtef�lle');
-----------------------------------------------------------------------------
--	(100001, 'Kristina Olsen', 'N�rregade 28', 8000),	-- Tidligere �gtef�ller
--	(100002, 'Peter Larsen', 'Stationsgade 1', 9000),	-- Tidligere �gtef�ller
--	(100100, 'Lars Larsen', NULL, NULL),				-- Barn af Kristina og Peter

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100001),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100100), 'S�n');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100002),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100100), 'S�n');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100100),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100002), 'Far');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100100),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100001), 'Mor');
-----------------------------------------------------------------------------
--	(100001, 'Kristina Olsen', 'N�rregade 28', 8000),	-- Tidligere �gtef�ller
--	(100003, 'Kurt Thomsen', 'N�rregade 28', 8000),		-- Ny �gtef�lle
--	(100101, 'Sofus Thomsen', NULL, NULL),				-- Barn af Kristina og Kurt

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100003),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100101), 'S�n');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100001),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100101), 'S�n');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100101),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100003), 'Far');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100101),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100001), 'Mor');
---------------------------------------------------------------------------------
--	(100002, 'Peter Larsen', 'Stationsgade 1', 9000),	-- Tidligere �gtef�ller
--	(100004, 'Mie Larsen', 'Stationsgade 1', 9000),		-- Ny �gtef�lle
--	(100102, 'Louise Larsen', NULL, NULL),				-- Barn af Peter og Mie
--	(100103, 'Christina Larsen', NULL, NULL);			-- Barn af Peter og Mie


INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100002),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100103), 'Datter');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100004),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100103), 'Datter');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100103),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100002), 'Far');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100103),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100004), 'Mor');


INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100002),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100102), 'Datter');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100004),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100102), 'Datter');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100102),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100002), 'Far');

INSERT INTO dbo.Familie VALUES 
	((SELECT $node_id FROM dbo.Person WHERE PersonId = 100102),
	 (SELECT $node_id FROM dbo.Person WHERE PersonId = 100004), 'Mor');
GO
-- Find halvs�skende

SELECT	CONCAT_WS(' - ', Person1.PersonId, Person1.Navn) AS Familie1,
		CONCAT_WS(' - ', Person2.PersonId, Person2.Navn) AS Familie2,
		CONCAT_WS(' - ', Person3.PersonId, Person3.Navn) AS Familie3,
		CONCAT_WS(' - ', Person4.PersonId, Person4.Navn) AS Familie4

	FROM	dbo.Person AS Person1, 
			dbo.Familie AS Familie1, 
			dbo.Person AS Person2,

			dbo.Person AS Person3, 
			dbo.Familie AS Familie2, 
			dbo.Person AS Person4

	WHERE	MATCH(Person1 - (Familie1) -> Person2 AND Person3 - (Familie2) -> Person4) AND

			Person1.PersonId <> Person3.PersonId AND
			Person2.PersonId = Person4.PersonId  AND
	
			Familie1.FamilieRelation IN ('Far', 'Mor') AND
			Familie2.FamilieRelation IN ('Far', 'Mor') AND

			Person1.PersonId = 100100;
GO
SELECT	CONCAT_WS(' - ', Person1.PersonId, Person1.Navn) AS Familie1,
		Familie1.FamilieRelation,
		CONCAT_WS(' - ', Person2.PersonId, Person2.Navn) AS Familie2

	FROM	dbo.Person AS Person1, 
			dbo.Familie AS Familie1, 
			dbo.Person AS Person2

	WHERE	MATCH(Person1 - (Familie1) -> Person2 ) AND

			Familie1.FamilieRelation IN ('Far', 'Mor')

