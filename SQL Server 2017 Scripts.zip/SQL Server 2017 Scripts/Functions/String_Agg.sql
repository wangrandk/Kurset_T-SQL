USE master;
GO
DROP DATABASE IF EXISTS StringAggDB;
GO
CREATE DATABASE StringAggDB;
GO
USE StringAggDB;
CREATE TABLE dbo.Foraelder
(
	ForaelderId		INT			NOT NULL
					CONSTRAINT PK_Foraelder PRIMARY KEY,
	Navn			VARCHAR(30) NOT NULL
);

CREATE TABLE dbo.Barn
(
	BarnId			INT			NOT NULL
					CONSTRAINT PK_Barn PRIMARY KEY,
	Navn			VARCHAR(20) NOT NULL,
	Foedselsdato	DATE		NOT NULL,
	ForaelderId		INT			NOT NULL
					CONSTRAINT FK_Barn_Foraelder FOREIGN KEY
					REFERENCES dbo.Foraelder (ForaelderId)
);

CREATE TABLE dbo.ForaelderTlf
(
	ForaelderId		INT			NOT NULL,
	Tlf				CHAR(8)		NOT NULL,
	CONSTRAINT PK_ForaelderTlf PRIMARY KEY (ForaelderId, Tlf)
);
GO
INSERT INTO dbo.Foraelder VALUES
	(1, 'Marianne Hansen');

INSERT INTO dbo.Barn VALUES
	(10, 'Ida', '2006-03-25', 1),
	(11, 'Anne', '2008-07-11', 1), 
	(12, 'Bo', '2014-01-13', 1);

INSERT INTO dbo.ForaelderTlf VALUES
	(1, '11223344');

---------------------------------------------------------
INSERT INTO dbo.Foraelder VALUES
	(2, 'Lars Pedersen');

INSERT INTO dbo.Barn VALUES
	(20, 'Karl', '2013-04-09', 2);

INSERT INTO dbo.ForaelderTlf VALUES
	(2, '22334455'),
	(2, '88772233'),
	(2, '44556677');

---------------------------------------------------------
INSERT INTO dbo.Foraelder VALUES
	(3, 'Sofie Knudsen');

---------------------------------------------------------
INSERT INTO dbo.Foraelder VALUES
	(4, 'Carl Ove Thomsen');

INSERT INTO dbo.ForaelderTlf VALUES
	(4, '77665544');

---------------------------------------------------------
INSERT INTO dbo.Foraelder VALUES
	(5, 'Marianne Hansen');

INSERT INTO dbo.Barn VALUES
	(30, 'Maren', '2012-03-25', 5),
	(31, 'August', '2005-07-11', 5), 
	(32, 'Lea', '2016-01-13', 5),
	(33, 'Michael', '2008-03-01', 5),
	(34, 'Christian', '2008-03-01', 5);
GO
SELECT	Foraelder.ForaelderId,
		STRING_AGG(CONCAT(Barn.Navn + ' - ', Barn.Foedselsdato), ', ') AS B�rn 
	FROM dbo.Foraelder LEFT JOIN dbo.Barn ON Foraelder.ForaelderId = Barn.ForaelderId
	GROUP BY Foraelder.ForaelderId;
GO
SELECT	Foraelder.ForaelderId,
		STRING_AGG(CONCAT(Barn.Navn + ' - ', Barn.Foedselsdato), ', ') 
			WITHIN GROUP (ORDER BY Barn.Foedselsdato ASC) AS B�rn 
	FROM dbo.Foraelder LEFT JOIN dbo.Barn ON Foraelder.ForaelderId = Barn.ForaelderId
	GROUP BY Foraelder.ForaelderId;
GO
SELECT	Foraelder.ForaelderId,
		Foraelder.Navn,
		TlfGrp.Telefonnr
	FROM dbo.Foraelder  OUTER APPLY (SELECT STRING_AGG(Tlf, ', ') WITHIN GROUP (ORDER BY ForaelderTlf.Tlf)AS Telefonnr
										FROM dbo.ForaelderTlf
										WHERE ForaelderTlf.ForaelderId = Foraelder.ForaelderId) AS TlfGrp
	ORDER BY Foraelder.ForaelderId;
GO
SELECT	Foraelder.ForaelderId,
		STRING_AGG(CONCAT(Barn.Navn + ' - ', Barn.Foedselsdato), ', ') 
			WITHIN GROUP (ORDER BY Barn.Foedselsdato ASC) AS B�rn,
		TlfGrp.Telefonnr
	FROM dbo.Foraelder  LEFT JOIN dbo.Barn ON Foraelder.ForaelderId = Barn.ForaelderId
						OUTER APPLY (SELECT STRING_AGG(Tlf, ', ') WITHIN GROUP (ORDER BY ForaelderTlf.Tlf)AS Telefonnr
										FROM dbo.ForaelderTlf
										WHERE ForaelderTlf.ForaelderId = Foraelder.ForaelderId) AS TlfGrp
	GROUP BY Foraelder.ForaelderId, TlfGrp.Telefonnr
	ORDER BY Foraelder.ForaelderId;
GO
