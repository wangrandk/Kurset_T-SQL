USE master
GO
DROP DATABASE IF EXISTS ConcatDB;
GO
CREATE DATABASE ConcatDB;
GO
USE ConcatDB;
CREATE TABLE dbo.Postopl 
(
	Postnr		SMALLINT	NOT NULL 
				CONSTRAINT PK_Postopl PRIMARY KEY,
	Bynavn		VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Kunde 
(
	KundeID		INT			NOT NULL 
				CONSTRAINT PK_Kunde PRIMARY KEY,
	Fornavn		VARCHAR(20) NOT NULL,
	Efternavn	VARCHAR(20) NOT NULL,
	Adresse		VARCHAR(30) NOT NULL,
	Postnr		SMALLINT	NOT NULL 
				CONSTRAINT FK__Kunde_Postopl FOREIGN KEY REFERENCES Postopl(Postnr)
);
GO
INSERT INTO dbo.Postopl(Postnr, Bynavn) VALUES
	(8000, 'Aarhus C'),
	(2000, 'Frederiksberg'),
	(9000, 'Aalborg');

INSERT INTO dbo.Kunde (KundeID, Fornavn, Efternavn, Adresse, Postnr) VALUES 
	(1, 'Ole', 'Olsen', 'Nygade  2', 9000),
	(2, 'Ida', 'Larsen', 'Torvet 12', 2000),
	(3, 'Per', 'Knudsen', 'Vestergade 5', 9000),
	(4, 'Ane', 'Hansen', 'S�ndergade 22', 8000),
	(5, 'Hanne', 'Larsen', 'N�rregade 17', 2000);
GO
SELECT	Kunde.KundeID,
		CONCAT_WS(', ',		Kunde.Fornavn + ' ' + Kunde.Efternavn, 
							Kunde.Adresse, 
							CONCAT_WS(' ', Postopl.Postnr, Postopl.Bynavn)) AS Kundeinfo
	FROM dbo.Kunde INNER JOIN dbo.Postopl
			ON Kunde.Postnr = Postopl.Postnr;
