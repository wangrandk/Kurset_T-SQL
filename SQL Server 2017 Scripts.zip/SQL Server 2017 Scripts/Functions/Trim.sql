SELECT CONCAT('#', TRIM( '     Jens Olsen    '), '#') AS Result;

SELECT CONCAT('#', TRIM( '     Jens          Olsen    '), '#') AS Result;

SELECT CONCAT('#', TRIM( ' +' FROM  '++45 12345678'), '#') AS Result;

SELECT CONCAT('#', TRIM( ' +' FROM  '  ++ 45 12345678'), '#') AS Result;
