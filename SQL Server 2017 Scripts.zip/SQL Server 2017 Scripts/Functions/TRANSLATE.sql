SELECT TRANSLATE('2*[3+4]/{7-2}', '[]{}', '()()');
GO
DECLARE @sql		VARCHAR(8000) =
	'
	CREATE TABLE dbo.t
	(
		[ID]			[INT] NOT NULL PRIMARY KEY,
		[Navn]			VARCHAR(20) NOT NULL,
		[Opretdato]		[DATE] NOT NULL
	)
	';

SELECT TRANSLATE (@sql, '[]', '  ');
