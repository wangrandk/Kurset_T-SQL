USE master;
GO
DROP DATABASE TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
ALTER DATABASE TemporalDB
	SET TEMPORAL_HISTORY_RETENTION ON
GO
USE TemporalDB;
CREATE TABLE dbo.Postopl
(
	Postnr			SMALLINT	NOT NULL PRIMARY KEY,
	Bynavn			VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Person
(
	ID				INT			NOT NULL PRIMARY KEY,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	Adresse			VARCHAR(30) NOT NULL,
	Postnr			SMALLINT	NOT NULL REFERENCES dbo.Postopl(Postnr),
	Navn			AS Fornavn + ' '  + Efternavn,
    SysStartTime	DATETIME2 GENERATED ALWAYS AS ROW START	NOT NULL, 
    SysEndTime		DATETIME2 GENERATED ALWAYS AS ROW END	NOT NULL,   
    PERIOD FOR SYSTEM_TIME (SysStartTime,SysEndTime)   
)
WITH (SYSTEM_VERSIONING = ON (	HISTORY_TABLE = dbo.PersonHistory,
						        HISTORY_RETENTION_PERIOD = 6 MONTHS --DAYS, WEEKS, MONTHS, YEARS, INFINITE 
));

CREATE TABLE dbo.Tider
(
	ID				INT			NOT NULL PRIMARY KEY,
	Tid				DATETIME2 DEFAULT(SYSUTCDATETIME())
);
GO
INSERT INTO dbo.Tider (ID) VALUES
	(1);

WAITFOR DELAY '0:0:0:004';

INSERT INTO dbo.Postopl (Postnr, Bynavn) VALUES
	(2000, 'Frederiksberg'),
	(3000, 'Helsing�r'),
	(4000, 'Roskilde'),
	(5000, 'Odense C'),
	(6000, 'Kolding');

INSERT INTO dbo.Person (ID, Fornavn, Efternavn, Adresse, Postnr) VALUES
	(1, 'Jesper', 'Knudsen', 'Vestergade 13', 2000),
	(2, 'Hanne', 'Poulsen', '�stergade 4', 3000),
	(3, 'Ane', 'Hansen', 'Torvet 45', 4000),
	(4, '�ge', 'Jensen', 'Nygade 12', 2000),
	(5, 'Peter', 'Andersen', 'Nygade 6', 4000),
	(6, 'Maren', 'Pedersen', 'S�ndergade 18', 5000);
GO
SELECT *
	FROM dbo.Tider;

SELECT *
	FROM dbo.Person;
GO
INSERT INTO dbo.Tider (ID) VALUES
	(2);

WAITFOR DELAY '0:0:0:004';

DELETE
	FROM dbo.Person
	WHERE ID = 2;
GO
INSERT INTO dbo.Tider (ID) VALUES
	(3);

WAITFOR DELAY '0:0:0:004';

INSERT INTO dbo.Person (ID, Fornavn, Efternavn, Adresse, Postnr) VALUES
	(7, 'Kit', 'Knudsen', 'Vestergade 3', 3000),
	(8, 'Lars', 'Jensen', 'Torvet 24', 2000);
GO
INSERT INTO dbo.Tider (ID) VALUES
	(4);

WAITFOR DELAY '0:0:0:004';

UPDATE dbo.Person
	SET	Fornavn = 'Ane Marie', 
		Efternavn = 'Hansen'
	WHERE ID = 3;
GO
INSERT INTO dbo.Tider (ID) VALUES
	(5);

WAITFOR DELAY '0:0:0:004';

UPDATE dbo.Person
	SET Adresse = 'Storetorv 1', Postnr = 4000
	WHERE ID = 4;

UPDATE dbo.Person
	SET Adresse = 'Nygade 6 2. tv.', Postnr = 4000
	WHERE ID = 5;
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.PersonHistory;
GO
-- Returns the union of rows that belong to the current and the history table.

SELECT	Id,			-- Retention indg�r i predicate
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		SysStartTime,
		SysEndTime
	FROM dbo.Person FOR SYSTEM_TIME ALL
	ORDER BY ID;
GO
SELECT	Id,				-- Retention indg�r IKKE i predicate
		Fornavn, 
		Efternavn,
		Adresse,
		Postnr,
		SysStartTime,
		SysEndTime
	FROM dbo.PersonHistory
	ORDER BY ID;
