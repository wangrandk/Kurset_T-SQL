USE master;
GO
DROP DATABASE TemporalDB;
GO
CREATE DATABASE TemporalDB;
GO
ALTER DATABASE TemporalDB
	SET TEMPORAL_HISTORY_RETENTION ON;
GO
USE TemporalDB;
CREATE TABLE dbo.Vare
(
	VareId			INT				NOT NULL 
					CONSTRAINT PK_Vare PRIMARY KEY CLUSTERED,
	Varenavn		VARCHAR(40)		NOT NULL,
	EnhedsPris		DECIMAL(11,2)	NOT NULL DEFAULT (0),
    SysStartTime	DATETIME2(0)	NOT NULL, 
    SysEndTime		DATETIME2(0)	NOT NULL
);

CREATE TABLE dbo.VareHistory
(
	VareId			INT				NOT NULL,
	Varenavn		VARCHAR(40)		NOT NULL,
	EnhedsPris		DECIMAL(11,2)	NOT NULL,
    SysStartTime	DATETIME2(0)	NOT NULL, 
    SysEndTime		DATETIME2(0)	NOT NULL
);
GO
CREATE CLUSTERED INDEX ix_VareHistory ON dbo.VareHistory
(
	SysEndTime ASC,
	SysStartTime ASC
);
GO
INSERT INTO dbo.VareHistory (VareId, Varenavn, EnhedsPris, SysStartTime, SysEndTime) VALUES
	(1, 'Jordb�r', 25.00, '2017-05-11', '2017-05-12'),
	(1, 'Jordb�r Danske', 20.00, '2017-05-12', '2017-05-13'), 
	(1, 'Jordb�r Danske', 22.00, '2017-05-13', '2017-05-14'), 
	(1, 'Jordb�r Belgiske', 30.00, '2017-05-14', '2017-05-15'),
	
	(2, 'Nye Danske Kartofler', 15.00, '2017-05-11', '2017-05-14'), 
	(2, 'Nye Danske Kartofler', 13.00, '2017-05-14', '2017-05-15');

INSERT INTO dbo.Vare (VareId, Varenavn, EnhedsPris, SysStartTime, SysEndTime) VALUES
	(1, 'Jordb�r Belgiske', 30.00, '2017-05-15', '9999-12-31 23:59:59.9999999'),
	(2, 'Nye Danske Kartofler', 12.00, '2017-05-15', '9999-12-31 23:59:59.9999999');
GO
ALTER TABLE dbo.Vare
	ADD PERIOD FOR SYSTEM_TIME (SysStartTime, SysEndTime);
ALTER TABLE dbo.Vare
    SET (SYSTEM_VERSIONING = ON (	HISTORY_TABLE = dbo.VareHistory, 
									DATA_CONSISTENCY_CHECK = ON));
GO
UPDATE dbo.Vare
	SET Varenavn = 'Jordb�r Danske', EnhedsPris = 30.00
	WHERE VareId = 1;

UPDATE dbo.Vare
	SET Varenavn = 'Danske Kartofler', EnhedsPris = 16.00
	WHERE VareId = 2;
GO
ALTER TABLE dbo.Vare
    SET (SYSTEM_VERSIONING = ON (HISTORY_RETENTION_PERIOD = 1 DAYS));
GO
SELECT	VareId,			-- Retention indg�r i predicate
		Varenavn,
		EnhedsPris,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare FOR SYSTEM_TIME ALL
	ORDER BY VareId;
GO
SELECT	VareId,	
		Varenavn,
		EnhedsPris,
		SysStartTime,
		SysEndTime
	FROM dbo.Vare
UNION ALL
SELECT	VareId,	
		Varenavn,
		EnhedsPris,
		SysStartTime,
		SysEndTime
	FROM dbo.VareHistory
ORDER BY VareId, SysStartTime;
										