USE master;
GO
DROP DATABASE IndexInlineTVDB;
GO
CREATE DATABASE IndexInlineTVDB;
GO
USE IndexInlineTVDB;
GO
CREATE PROCEDURE usp_Person
AS
DECLARE @Person TABLE
(
	ID			INT NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY,
	Fornavn		VARCHAR(20) NOT NULL INDEX nc_Person_Fornavn,
	Efternavn	VARCHAR(20) NOT NULL INDEX nc_Person_Efternavn,
	Navn		AS Fornavn + ' ' + Efternavn,
	INDEX nc_Person_Fornavn_Efternavn NONCLUSTERED (Fornavn, Efternavn) WITH (FILLFACTOR = 80, DATA_COMPRESSION = PAGE) 
);

DECLARE @i		INT = 1;

SET NOCOUNT ON
WHILE @i < 10000
BEGIN
	INSERT INTO @Person(Fornavn, Efternavn) VALUES
		('Ole', 'Olsen'),
		('Ida', 'Hansen'),	
		('Per', 'Larsen'),
		('Ane', 'Knudsen');

	SET @i += 1;
END;

SELECT	name AS index_name, 
		STATS_DATE(object_id, 2) AS statistics_update_date
	FROM tempdb.sys.indexes
	WHERE name LIKE 'nc*_%' ESCAPE '*';

SELECT *
	FROM @Person
	WHERE Fornavn = 'Ib';

SELECT	name AS index_name, 
		STATS_DATE(object_id, 2) AS statistics_update_date
	FROM tempdb.sys.indexes
	WHERE name LIKE 'nc*_%' ESCAPE '*';
GO
EXEC usp_Person;
GO
CREATE PROCEDURE usp_Person_Indexopl
AS
DECLARE @Person TABLE
(
	ID			INT NOT NULL PRIMARY KEY NONCLUSTERED,
	Fornavn		VARCHAR(20) NOT NULL INDEX nc_Person_Fornavn,
	Efternavn	VARCHAR(20) NOT NULL INDEX nc_Person_Efternavn,
	Navn		AS Fornavn + ' ' + Efternavn,
	INDEX nc_Person_Fornavn_Efternavn NONCLUSTERED (Fornavn, Efternavn) WITH (FILLFACTOR = 80, DATA_COMPRESSION = PAGE) 
);

SELECT	*
	INTO sysTablesDataIn
	FROM tempdb.sys.tables;

SELECT	*
	INTO sysIndexesDataIn
	FROM tempdb.sys.indexes;

SELECT	*
	INTO sysStatsDataIn
	FROM tempdb.sys.stats;
GO
SELECT	*
	INTO sysTablesDataBefore
	FROM tempdb.sys.tables;

SELECT	*
	INTO sysIndexesDataBefore
	FROM tempdb.sys.indexes;

SELECT	*
	INTO sysStatsDataBefore
	FROM tempdb.sys.stats;

EXEC usp_Person_Indexopl;

SELECT	*
	INTO sysTablesDataAfter
	FROM tempdb.sys.tables;

SELECT	*
	INTO sysIndexesDataAfter
	FROM tempdb.sys.indexes;

SELECT	*
	INTO sysStatsDataAfter
	FROM tempdb.sys.stats;
GO
SELECT	isp.name,
		bsp.object_id AS Before_object_id,
		isp.object_id AS In_object_id,
		asp.object_id AS After_object_id
	FROM sysTablesDataBefore AS bsp	FULL JOIN sysTablesDataIn AS isp ON bsp.object_id = isp.object_id
									FULL JOIN sysTablesDataAfter AS asp ON asp.object_id = bsp.object_id OR asp.object_id = isp.object_id
	WHERE bsp.object_id IS NULL;

SELECT	isp.name AS index_name,
		bsp.object_id AS Before_object_id,
		bsp.index_id AS Before_index_id,
		isp.object_id AS In_object_id,
		isp.index_id AS In_index_id,
		asp.object_id AS After_object_id,
		asp.index_id AS After_index_id
	FROM sysIndexesDataBefore AS bsp	FULL JOIN sysIndexesDataIn AS isp		ON	 bsp.object_id = isp.object_id AND bsp.index_id = isp.index_id
										FULL JOIN sysIndexesDataAfter AS asp	ON	(asp.object_id = bsp.object_id AND asp.index_id = bsp.index_id) OR 
																					(asp.object_id = isp.object_id AND asp.index_id = isp.index_id)
	WHERE bsp.object_id IS NULL;

SELECT	isp.name AS stats_name,
		bsp.object_id AS Before_object_id,
		bsp.stats_id AS Before_stats_id,
		isp.object_id AS In_object_id,
		isp.stats_id AS In_stats_id,
		asp.object_id AS After_object_id,
		asp.stats_id AS After_stats_id
	FROM sysStatsDataBefore AS bsp		FULL JOIN sysStatsDataIn AS isp		ON	 bsp.object_id = isp.object_id AND bsp.stats_id = isp.stats_id
										FULL JOIN sysStatsDataAfter AS asp	ON	(asp.object_id = bsp.object_id AND asp.stats_id = bsp.stats_id) OR 
																				(asp.object_id = isp.object_id AND asp.stats_id = isp.stats_id)
	WHERE bsp.object_id IS NULL;
GO
SELECT	*
	FROM tempdb.sys.tables;

SELECT	*
	FROM tempdb.sys.indexes;

SELECT	*
	FROM tempdb.sys.stats;
GO
SELECT	name AS index_name, 
		STATS_DATE(object_id, 2) AS statistics_update_date
	FROM sys.indexes;
