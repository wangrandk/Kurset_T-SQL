USE master;
GO
DROP DATABASE InMemDB;
GO
CREATE DATABASE InMemDB
ON PRIMARY
(
	NAME = InMemDB_sys,
	FILENAME = N'C:\Databaser\InMemDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_NotInMem_filegroup  
(
	NAME = InMemDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\InMemDB_InMemDB_NotInMem_filegroup.ndf',
	SIZE = 1000MB,
	MAXSIZE = 1000MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = InMemDB_InMem_filegroup_1,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB'
)
LOG ON
( 
	NAME = InMemDB_log_file_1,
	FILENAME = N'C:\Databaser\InMemDB_log.ldf',
	SIZE = 1000MB,
	MAXSIZE = 2000MB,
	FILEGROWTH = 10%
);
GO
ALTER DATABASE InMemDB SET RECOVERY SIMPLE;
GO
USE InMemDB;
GO
CREATE TABLE dbo.Person_Hash
(
	ID				INT NOT NULL
					CONSTRAINT PK_Person_Hash PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT = 3000000) IDENTITY,
	Navn			VARCHAR(30) COLLATE Latin1_General_BIN2 NOT NULL,
	Gade 			VARCHAR (30) COLLATE Latin1_General_BIN2 NOT NULL,
	Postnr			SMALLINT NOT NULL,
	Koen			CHAR(1) COLLATE Latin1_General_BIN2 NOT NULL,	
	
	INDEX hash_index_Person_Navn HASH (Navn) WITH (BUCKET_COUNT = 3000000),
	INDEX hash_index_Person_Gade HASH (Gade) WITH (BUCKET_COUNT = 3000000),
	INDEX hash_index_Person_Koen HASH (Koen) WITH (BUCKET_COUNT = 3000000),
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
CREATE SCHEMA Hjaelpedata;
GO
CREATE TABLE Hjaelpedata.Efternavn 
(
	Efternavn 		VARCHAR (20)  NOT NULL
) ON InMemDB_NotInMem_filegroup;
GO
CREATE TABLE Hjaelpedata.Fornavn 
(
	Fornavn 		VARCHAR (50)  NOT NULL,
	Koen			CHAR(1) NULL
) ON InMemDB_NotInMem_filegroup;
GO
CREATE TABLE Hjaelpedata.Gade 
(
	Gade 			VARCHAR (30)  NOT NULL
) ON InMemDB_NotInMem_filegroup;
GO
CREATE TABLE dbo.Postopl 
(
	Postnr 			SMALLINT NOT NULL CONSTRAINT PK_Postopl PRIMARY KEY NONCLUSTERED,
	Bynavn 			VARCHAR (20) NOT NULL
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_AND_DATA);
GO
INSERT INTO Hjaelpedata.Fornavn VALUES 
	('Anne', 'K'),
	('Ane', 'K'),
	('Anni', 'K'),
	('Annemette', 'K'),
	('Anne Mette', 'K'),
	('Anne Marie', 'K'),
	('Anders', 'M'),
	('Andreas', 'M'),
	('August', 'M'),
	('Arne', 'M'),
	('Andreas', 'M'),
	('Asger', 'M'),
	('Allan', 'M'),
	('Bo', NULL),
	('Birte', 'K'),
	('Birthe', 'K'),
	('Bente', 'K'),
	('Bent', 'K'),
	('B�rge', 'M'),
	('Bruno', 'M'),
	('Carl', 'M'),
	('Carina', 'K'),
	('Christian', 'M'),
	('Christina', 'K'),
	('Dorte', 'K'),
	('Dorthe', 'K'),
	('David', 'M'),
	('Daniel', 'M'),
	('Erik', 'M'),
	('Eva', 'K'),
	('Emma', 'K'),
	('Ebba', 'K'),
	('Ebbe', 'M'),
	('Ellen', 'K'),
	('Edvard', 'M'),
	('Edward', 'M'),
	('Egon', 'M'),
	('Esther', 'K'),
	('Frank', 'M'),
	('Frederikke', 'K'),
	('Frede', 'M'),
	('Frode', 'M'),
	('Frida', 'K'),
	('Grete', 'K'),
	('Gitte', 'K'),
	('Grethe', 'K'),
	('Gert', 'M'),
	('Gerd', 'K'),
	('Gunnar', 'M'),
	('Gustav', 'M'),
	('Gudrun', 'K'),
	('Henrik', 'M'),
	('Hans', 'M'),
	('Hans Erik', 'M'),
	('Hans Ole', 'M'),
	('Hanne', 'K'),
	('Henriette', 'K'),
	('Hedvig', 'K'),
	('Henry', 'M'),
	('Hugo', 'M'),
	('Ib', 'M'),
	('Ida', 'K'),
	('Ilse', 'K'),
	('Ivar', 'M'),
	('Ivan', 'M'),
	('Inger', 'K'),
	('Inge', 'K'),
	('Jens', 'M'),
	('Jens Erik', 'M'),
	('Jens Ole', 'M'),
	('Jens Peter', 'M'),
	('Jakob', 'M'),
	('Jacob', 'M'),
	('Jesper', 'M'),
	('Jette', 'K'),
	('Jytte', 'K'),
	('Jane', 'K'),
	('Karl', 'M'),
	('Karen', 'K'),
	('Karin', 'K'),
	('Kis', 'K'),
	('Karina', 'K'),
	('Kristina', 'K'),
	('Kristine', 'K'),
	('Kurt', 'M'),
	('Knud', 'M'),
	('Kenneth', 'M'),
	('Lars', 'M'),
	('Lars Ole', 'M'),
	('Lars Bo', 'M'),
	('Ludvig', 'M'),
	('Line', 'K'),
	('Lise', 'K'),
	('Lisette', 'K'),
	('Lene', 'K'),
	('Lisbeth', 'K'),
	('Lena', 'K'),
	('Liselotte', 'K'),
	('Lise Lotte', 'K'),
	('Morten', 'M'),
	('Marie', 'K'),
	('Mads', 'M'),
	('Maren', 'K'),
	('Malene', 'K'),
	('Mette', 'K'),
	('Michael', 'M'),
	('Mikael', 'M'),
	('Niels', 'M'),
	('Nis', 'M'),
	('Nicolaj', 'M'),
	('Nikolaj', 'M'),
	('Ninna', 'K'),
	('Nette', 'K'),
	('Nanna', 'K'),
	('Ole', 'M'),
	('Oda', 'K'),
	('Olivia', 'K'),
	('Oskar', 'M'),
	('Ove', 'M'),
	('Peter', 'M'),
	('Per', 'M'),
	('Petrea', 'K'),
	('Peder', 'M'),
	('Pil', 'K'),
	('Poul', 'M'),
	('Paul', 'M'),
	('Poula', 'K'),
	('Rasmus', 'M'),
	('Rie', 'K'),
	('Rikke', 'K'),
	('Richard', 'M'),
	('Rune', 'M'),
	('Ruth', 'K'),
	('Rosa', 'K'),
	('Robert', 'M'),
	('Rositta', 'K'),
	('S�ren', 'M'),
	('Sys', 'K'),
	('Sara', 'K'),
	('Simone', 'K'),
	('Susanne', 'K'),
	('Sanne', 'K'),
	('Sofus', 'M'),
	('Solvej', 'K'),
	('Signe', 'K'),
	('Thomas', 'M'),
	('Tove', 'K'),
	('Tommy', 'M'),
	('Tone', 'K'),
	('Trine', 'K'),
	('Tine', 'K'),
	('Tina', 'K'),
	('Tobias', 'M'),
	('Uffe', 'M'),
	('Ulla', 'K'),
	('Ulrik', 'M'),
	('Vera', 'K'),
	('Villy', 'M'),
	('Vagn', 'M'),
	('Willy', 'M'),
	('Yrsa', 'K'),
	('�jvind', 'M'),
	('�ge', 'M'),
	('�se', 'K');

INSERT INTO Hjaelpedata.Efternavn VALUES 
	('Andersen'),
	('Arnesen'),
	('Andreasen'),
	('B�rgesen'),
	('Bentsen'),
	('Christensen'),
	('Christiansen'),
	('Carlsen'),
	('Davidsen'),
	('Danielsen'),
	('Eriksen'),
	('Eskildsen'),
	('Frandsen'),
	('Frederiksen'),
	('Gertsen'),
	('Henriksen'),
	('Hansen'),
	('Hansen'),
	('Iversen'),
	('Ibsen'),
	('Jensen'),
	('Jensen'),
	('Jensen'),
	('Jakobsen'),
	('Jacobsen'),
	('Karlsen'),
	('Knudsen'),
	('Kristensen'),
	('Larsen'),
	('Lassen'),
	('Mortensen'),
	('Madsen'),
	('Mikkelsen'),
	('Nielsen'),
	('Nielsen'),
	('Olsen'),
	('Olesen'),
	('Pedersen'),
	('Petersen'),
	('Petersen'),
	('Rasmussen'),
	('S�rensen'),
	('Thomsen'),
	('�vlisen'),
	('�gesen');

INSERT INTO Hjaelpedata.Gade VALUES 
	('N�rregade 2'),
	('N�rregade 34'),
	('N�rregade 27'),
	('Vestergade 3'),
	('�stergade 23'),
	('�stergade 1'),
	('S�ndergade 78'),
	('Torvet 2'),
	('Torvet 4'),
	('Runddelen 1'),
	('Ved Stranden 3'),
	('Strandvejen 112'),
	('All�gade 29'),
	('Norgesgade 3'),
	('Ungarnsgade 4'),
	('Italiensvej 32'),
	('Strandvejen 2'),
	('All�gade 5'),
	('Norgesgade 38'),
	('Ungarnsgade 7'),
	('Italiensvej 21'),
	('Italiensvej 4'),
	('Bragesgade 1'),
	('Bragesgade 12'),
	('Dortesvej 4'),
	('Dortesvej 3'),
	('Ellebjergvej 114'),
	('Ellebjergvej 98'),
	('Frankrigsgade 14'),
	('Frankrigsgade 6'),
	('Helgolandsgade 54'),
	('Helgolandsgade 8'),
	('K�gevej 4'),
	('K�gevej 48'),
	('M�llegade 3'),
	('M�llegade 34'),
	('Ollerupvej 3'),
	('Sct. Pouls Gade 3'),
	('Sct. Pouls Gade 25'),
	('Willemoesgade 2'),
	('Willemoesgade 23'),
	('N�rregade 11'),
	('N�rregade 36'),
	('N�rregade 72'),
	('Vesterbro 3'),
	('Vesterbrogade 23'),
	('Vesterbrogade 1'),
	('M�llevej 78'),
	('M�llevej 2'),
	('M�llevej 4'),
	('M�llevej 3'),
	('Adelgade 3'),
	('Adelgade 12'),
	('Adelgade 39'),
	('Pilegade 3'),
	('Pilegade 4'),
	('Pilegade 32'),
	('Pilegade 2'),
	('�gade 5'),
	('�gade 38'),
	('�gade 7'),
	('�boulevarden 21'),
	('�boulevarden 4'),
	('�sterbro 1'),
	('�sterbro 12'),
	('�sterbro 4'),
	('Horsensgade 3'),
	('Roskildevej 114'),
	('K�gevej 98'),
	('Nyborgvej 14'),
	('Nyborgvej 16'),
	('T�ndergade 34'),
	('T�ndergade 18'),
	('Ribevej 14'),
	('Thistedvej 8'),
	('Herningvej 2'),
	('Svendborgvej 34'),
	('�benr�vej 4'),
	('Vordingborgvej 13');

INSERT INTO dbo.Postopl VALUES 
	(1127, 'K�benhavn K'),
	(1001, 'K�benhavn K'),
	(1129, 'K�benhavn K'),
	(1130, 'K�benhavn K'),
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(8200, 'Aarhus N'),
	(8210, 'Aarhus V'),
	(8240, 'Risskov'),
	(8270, 'H�jbjerg'),
	(8310, 'Tranbjerg J'),
	(9000, 'Aalborg'),
	(9400, 'N�rresundby'),
	(9600, 'Br�nderslev'),
	(9800, 'Hj�rring'),
	(9990, 'Skagen'),
	(2600, 'Glostrup'),
	(2605, 'Br�ndby'),
	(2610, 'R�dovre'),
	(2620, 'Albertslund'),
	(2625, 'Vallensb�k'),
	(2630, 'Taastrup'),
	(2635, 'Ish�j'),
	(2640, 'Hedehusene'),
	(2650, 'Hvidovre'),
	(2660, 'Br�ndby Strand');

SET NOCOUNT OFF;
GO
SET STATISTICS TIME ON;
INSERT INTO dbo.Person_Hash (Navn, Gade, Postnr, Koen)
	SELECT	Fornavn.Fornavn + ' '  + Efternavn.Efternavn,
			Gade.Gade,
			Postopl.Postnr,
			ISNULL(Fornavn.Koen, 'U')
		FROM Hjaelpedata.Fornavn	INNER JOIN Hjaelpedata.Efternavn ON Fornavn.Fornavn < Efternavn.Efternavn
									INNER JOIN Hjaelpedata.Gade ON Gade.Gade > Fornavn.Fornavn
									INNER JOIN dbo.Postopl ON Efternavn.Efternavn < Postopl.Bynavn;

--INSERT INTO dbo.Person_Hash (Navn, Gade, Postnr, Koen)
--	SELECT	Fornavn.Fornavn + ' '  + Efternavn.Efternavn,
--			Gade.Gade,
--			Postopl.Postnr,
--			ISNULL(Fornavn.Koen, 'U')
--		FROM Hjaelpedata.Fornavn	INNER JOIN Hjaelpedata.Efternavn ON Fornavn.Fornavn > Efternavn.Efternavn
--									INNER JOIN Hjaelpedata.Gade ON Gade.Gade < Fornavn.Fornavn
--									INNER JOIN dbo.Postopl ON Efternavn.Efternavn < Postopl.Bynavn
--		WHERE LEN(Fornavn.Fornavn) < LEN(Efternavn.Efternavn);

--INSERT INTO dbo.Person_Hash (Navn, Gade, Postnr, Koen)
--	SELECT	Fornavn.Fornavn + ' '  + Efternavn.Efternavn,
--			Gade.Gade,
--			Postopl.Postnr,
--			ISNULL(Fornavn.Koen, 'U')
--		FROM Hjaelpedata.Fornavn	INNER JOIN Hjaelpedata.Efternavn ON Fornavn.Fornavn < Efternavn.Efternavn
--									INNER JOIN Hjaelpedata.Gade ON Gade.Gade > Fornavn.Fornavn
--									INNER JOIN dbo.Postopl ON Efternavn.Efternavn < Postopl.Bynavn
--		WHERE LEN(Efternavn.Efternavn) > LEN(Gade.Gade);
GO
USE InMemDB

SELECT	COUNT(*) AS Pk_Ialt,
		COUNT(DISTINCT Navn) AS ForskelligeNavne,
		COUNT(DISTINCT Gade) AS ForskelligeGader,
		COUNT(DISTINCT Koen) AS ForskelligeKoen
	FROM dbo.Person_Hash;
GO
SELECT 
		OBJECT_NAME(hs.object_id) AS 'object name', 
		i.name AS 'index name', 
		hs.total_bucket_count,
		hs.empty_bucket_count,
		hs.total_bucket_count - hs.empty_bucket_count AS used_bucket_count,
		FLOOR((CAST(empty_bucket_count AS FLOAT)/total_bucket_count) * 100) AS 'empty_bucket_percent',
		hs.avg_chain_length, 
		hs.max_chain_length
	FROM sys.dm_db_xtp_hash_index_stats AS hs INNER JOIN sys.indexes AS i 
						ON	hs.object_id = i.object_id AND 
							hs.index_id = i.index_id;
GO
USE master
