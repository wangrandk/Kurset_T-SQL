USE IndexReBuildDB;
GO
BEGIN TRANSACTION;
UPDATE dbo.Person
	SET Fornavn  = 'Jens Erik'
	WHERE PersonID	= 1;

COMMIT TRANSACTION;
GO
BEGIN TRANSACTION;
INSERT INTO dbo.Person VALUES
	(5, '0906680741', 'Peter', 'Knudsen'),
	(6, '0211541328', 'Louise', 'Nygaard');

COMMIT TRANSACTION;
GO
BEGIN TRANSACTION;
UPDATE dbo.Person
	SET Efternavn  = 'Nyg�rd'
	WHERE PersonID	= 6;


SELECT *
	FROM dbo.Person;

--COMMIT TRANSACTION;
GO

USE master;