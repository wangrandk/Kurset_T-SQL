USE IndexFilegrpDB
GO
DBCC SHOW_STATISTICS (Person, nc_Person_Persontype);
DBCC SHOW_STATISTICS (Person, nc_Person_Postnr);
