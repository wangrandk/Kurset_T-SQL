USE master;
GO
DROP DATABASE IndexInlineDB;
GO
CREATE DATABASE IndexInlineDB;
GO
USE IndexInlineDB;
GO
CREATE TABLE dbo.Person
(
	ID			INT NOT NULL CONSTRAINT PK_Person PRIMARY KEY NONCLUSTERED WITH (FILLFACTOR = 100),
	Cprnr		CHAR(10) NOT NULL INDEX nc_Person_Cprnr CLUSTERED WITH (FILLFACTOR = 70),
	Fornavn		VARCHAR(20) NOT NULL INDEX nc_Person_Fornavn WITH (FILLFACTOR = 85, PAD_INDEX = ON),
	Efternavn	VARCHAR(20) NOT NULL INDEX nc_Person_Efternavn WITH (FILLFACTOR = 85, PAD_INDEX = ON),
	Navn		AS Fornavn + ' ' + Efternavn,
	INDEX nc_Person_Fornavn_Efternavn NONCLUSTERED (Fornavn, Efternavn) WITH (FILLFACTOR = 80, DATA_COMPRESSION = PAGE) 
);
GO
SELECT *
	FROM sys.indexes
	WHERE object_id = OBJECT_ID('dbo.Person');
GO
ALTER INDEX nc_Person_Cprnr ON dbo.Person
	REBUILD WITH (	FILLFACTOR = 80, 
					SORT_IN_TEMPDB = ON,
					STATISTICS_NORECOMPUTE = ON);
GO
DROP INDEX nc_Person_Cprnr ON dbo.Person;
GO
CREATE TABLE dbo.Tid1			-- Fejl - Inline index kan ikke defineres p� beregnede kolonner
(
	Dato		DATE CONSTRAINT UQ_Tid_Dato UNIQUE NONCLUSTERED,
	Id			AS DAY(Dato) + MONTH(Dato) * 100 + YEAR(Dato) * 10000 INDEX cl_Tid_Id CLUSTERED
);
GO
CREATE TABLE dbo.Tid2			-- OK - PK kan defineres p� beregnede kolonner
(
	Dato		DATE NOT NULL CONSTRAINT UQ_Tid_Dato UNIQUE NONCLUSTERED,
	Id			AS DAY(Dato) + MONTH(Dato) * 100 + YEAR(Dato) * 10000 PERSISTED CONSTRAINT PK_Tid PRIMARY KEY CLUSTERED
);
GO
SELECT *
	FROM sys.indexes
	WHERE object_id = OBJECT_ID('dbo.Tid2');
