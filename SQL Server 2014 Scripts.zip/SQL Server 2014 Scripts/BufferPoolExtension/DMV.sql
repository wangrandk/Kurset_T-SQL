USE master
GO
SELECT *
	FROM sys.dm_os_buffer_pool_extension_configuration;

SELECT *
	FROM sys.dm_os_buffer_descriptors;
