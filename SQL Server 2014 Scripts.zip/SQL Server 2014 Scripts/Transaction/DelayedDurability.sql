USE master;
GO
DROP DATABASE TransactionDB;
GO
CREATE DATABASE TransactionDB;
GO
USE TransactionDB;
GO
ALTER DATABASE TransactionDB SET DELAYED_DURABILITY = DISABLED;
GO
CREATE TABLE dbo.Person
(
	Id			INT			NOT NULL CONSTRAINT PK_Person PRIMARY KEY IDENTITY,
	Navn		VARCHAR(30) NOT NULL
);
GO
CREATE PROCEDURE usp_Insert_Person
	@AntalInsert		INT = 1000
AS
SET NOCOUNT ON;

DECLARE @i		INT = 1;

WHILE @i < @AntalInsert
BEGIN
	BEGIN TRANSACTION;

	INSERT INTO dbo.Person (Navn) VALUES
		('Ida Andreasen');

	IF @i% 1000 = 0
		PRINT @i;

	COMMIT TRANSACTION;

	SET @i += 1;
END;
GO
EXEC usp_Insert_Person 100000;
GO
------------------------------------------------------------------------------------------
USE master;
GO
DROP DATABASE TransactionDB;
GO
CREATE DATABASE TransactionDB;
GO
USE TransactionDB;
GO
ALTER DATABASE TransactionDB SET DELAYED_DURABILITY = ALLOWED;
GO
CREATE TABLE dbo.Person
(
	Id			INT NOT NULL CONSTRAINT PK_Person PRIMARY KEY IDENTITY,
	Navn		VARCHAR(30) NOT NULL
);
GO
CREATE PROCEDURE usp_Insert_Person_ON
	@AntalInsert		INT = 1000
AS
SET NOCOUNT ON;

DECLARE @i		INT = 1;

WHILE @i < @AntalInsert
BEGIN
	BEGIN TRANSACTION;

	INSERT INTO dbo.Person (Navn) VALUES
		('Ida Andreasen');
		
	IF @i% 1000 = 0
		PRINT @i;
	
	COMMIT TRANSACTION WITH (DELAYED_DURABILITY = ON);

	SET @i += 1;
END;
GO
CREATE PROCEDURE usp_Insert_Person_OFF
	@AntalInsert		INT = 1000
AS
SET NOCOUNT ON;

DECLARE @i		INT = 1;

WHILE @i < @AntalInsert
BEGIN
	BEGIN TRANSACTION;

	INSERT INTO dbo.Person (Navn) VALUES
		('Ida Andreasen');
	
	IF @i% 1000 = 0
		PRINT @i;
	
	COMMIT TRANSACTION WITH (DELAYED_DURABILITY = OFF);

	SET @i += 1;
END;
GO
EXEC usp_Insert_Person_ON 100000;
GO
EXEC usp_Insert_Person_OFF 100000;
GO
--------------------------------------------------------------------------------------
USE master;
GO
DROP DATABASE TransactionDB;
GO
CREATE DATABASE TransactionDB;
GO
USE TransactionDB;
GO
ALTER DATABASE TransactionDB SET DELAYED_DURABILITY = FORCED;
GO
CREATE TABLE dbo.Person
(
	Id			INT NOT NULL CONSTRAINT PK_Person PRIMARY KEY IDENTITY,
	Navn		VARCHAR(30) NOT NULL
);
GO
CREATE PROCEDURE usp_Insert_Person
	@AntalInsert		INT = 1000
AS
SET NOCOUNT ON;

DECLARE @i		INT = 1;

WHILE @i < @AntalInsert
BEGIN
	BEGIN TRANSACTION;

	INSERT INTO dbo.Person (Navn) VALUES
		('Ida Andreasen');
	
	IF @i% 1000 = 0
		PRINT @i;
	
	COMMIT TRANSACTION;

	SET @i += 1;
END;
GO
EXEC usp_Insert_Person 100000;
GO
--------------------------------------------------------------------------------------
USE master;
GO
DROP DATABASE TransactionDB;
GO
CREATE DATABASE TransactionDB;
GO
USE TransactionDB;
GO
ALTER DATABASE TransactionDB SET DELAYED_DURABILITY = FORCED;
GO
CREATE TABLE dbo.Person
(
	Id			INT NOT NULL CONSTRAINT PK_Person PRIMARY KEY IDENTITY,
	Navn		VARCHAR(30) NOT NULL,
	Adresse		VARCHAR(30) NOT NULL,
	Postnr		SMALLINT NOT NULL
);
GO
CREATE PROCEDURE usp_Insert_Person
	@AntalInsert		INT = 1000
AS
SET NOCOUNT ON;

DECLARE @i		INT = 1;

WHILE @i < @AntalInsert
BEGIN
	BEGIN TRANSACTION;

	INSERT INTO dbo.Person (Navn, Adresse, Postnr) VALUES
		('Ida Andreasen', 'S�ndreboulevard 34 1. tv.', 2000);
	
	COMMIT TRANSACTION;

	SET @i += 1;
END;
GO
DBCC SQLPERF(LOGSPACE);
EXEC usp_Insert_Person 100000;
DBCC SQLPERF(LOGSPACE);
EXEC sp_flush_log;
DBCC SQLPERF(LOGSPACE);
GO
