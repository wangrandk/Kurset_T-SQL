USE master;
GO
DROP DATABASE InMemDB;
GO
CREATE DATABASE InMemDB
ON PRIMARY
(
	NAME = InMemDB_sys,
	FILENAME = N'C:\Databaser\InMemDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_NotInMem_filegroup  
(
	NAME = InMemDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\InMemDB_InMemDB_NotInMem_filegroup.ndf',
	SIZE = 10MB,
	MAXSIZE = 200MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = InMemDB_InMem_filegroup_1,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB'
)
LOG ON
( 
	NAME = InMemDB_log_file_1,
	FILENAME = N'C:\Databaser\InMemDB_log.ldf',
	SIZE = 10MB,
	MAXSIZE = 200MB,
	FILEGROWTH = 10%
);
GO
USE InMemDB;
GO
CREATE TABLE dbo.Person
(
	ID				INT NOT NULL
					CONSTRAINT PK_Person PRIMARY KEY NONCLUSTERED IDENTITY(1, 1),
	Navn			VARCHAR(30) COLLATE Latin1_General_BIN2 NOT NULL,
	Gade 			VARCHAR (30)  NOT NULL,
	Postnr			SMALLINT NOT NULL
	
	INDEX hash_index_Person_Navn HASH (Navn) WITH (BUCKET_COUNT = 131072)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
CREATE PROCEDURE dbo.usp_Native_Compilation_Person
(
	@Navn			VARCHAR(30),
	@Gade			VARCHAR(30),
	@Postnr			SMALLINT
)	
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC
	WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

INSERT INTO dbo.Person(Navn, Gade, Postnr)
	VALUES(@Navn, @Gade, @Postnr)
END;
GO
CREATE TABLE dbo.Tid
(
	ID				INT NOT NULL PRIMARY KEY IDENTITY,
	Tid				DATETIME2 NOT NULL DEFAULT(SYSDATETIME())
);
GO
SET NOCOUNT ON;
INSERT INTO dbo.Tid DEFAULT VALUES;
GO
EXEC dbo.usp_Native_Compilation_Person 'Ole Olsen', 'Nygade 7', 9000;
GO 90000
INSERT INTO dbo.Tid DEFAULT VALUES;
GO
EXEC dbo.usp_Native_Compilation_Person @Navn = 'Ida Olsen', @Gade = 'Torvet 4', @Postnr = 8000;
GO 90000
INSERT INTO dbo.Tid DEFAULT VALUES;
GO
SELECT *
	FROM dbo.Tid;

SELECT COUNT(*)
	FROM dbo.Person;

