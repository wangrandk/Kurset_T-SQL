USE BiDbInMem;
GO
CREATE SCHEMA DWDiskCS;
GO
CREATE SCHEMA DWDiskCLNC;
GO
SELECT *
	INTO DWDiskCS.KundeSalg
	FROM DataWarehouse.KundeSalg;

SELECT *
	INTO DWDiskCS.Kunde
	FROM DataWarehouse.Kunde;

SELECT *
	INTO DWDiskCS.Vare
	FROM DataWarehouse.Vare;
GO
CREATE CLUSTERED COLUMNSTORE INDEX cci_Kundesalg
	ON DWDiskCS.KundeSalg;

CREATE CLUSTERED COLUMNSTORE INDEX cci_Kundesalg
	ON DWDiskCS.Kunde;

CREATE CLUSTERED COLUMNSTORE INDEX cci_Kundesalg
	ON DWDiskCS.Vare;
GO
SELECT *
	INTO DWDiskCLNC.KundeSalg
	FROM DataWarehouse.KundeSalg;

SELECT *
	INTO DWDiskCLNC.Kunde
	FROM DataWarehouse.Kunde;

SELECT *
	INTO DWDiskCLNC.Vare
	FROM DataWarehouse.Vare;
GO
CREATE CLUSTERED INDEX cl_Kundesalg ON DWDiskCLNC.KundeSalg(KundeSKey);

CREATE CLUSTERED INDEX cl_Kunde ON DWDiskCLNC.Kunde(KundeSKey);

CREATE CLUSTERED INDEX cl_Vare ON DWDiskCLNC.Vare(VareSKey);
GO
SET STATISTICS TIME ON;
DBCC DROPCLEANBUFFERS;

SELECT *
	FROM DataWarehouse.Vare	INNER JOIN DataWarehouse.KundeSalg ON DataWarehouse.Vare.VareSkey = DataWarehouse.KundeSalg.VareSkey 
							INNER JOIN DataWarehouse.Kunde ON DataWarehouse.KundeSalg.KundeSkey = DataWarehouse.Kunde.KundeSkey

DBCC DROPCLEANBUFFERS;

SELECT *
	FROM DWDiskCS.Vare		INNER JOIN DWDiskCS.KundeSalg ON DWDiskCS.Vare.VareSkey = DWDiskCS.KundeSalg.VareSkey 
							INNER JOIN DWDiskCS.Kunde ON DWDiskCS.KundeSalg.KundeSkey = DWDiskCS.Kunde.KundeSkey

DBCC DROPCLEANBUFFERS;

SELECT *
	FROM DWDiskCLNC.Vare	INNER JOIN DWDiskCLNC.KundeSalg ON DWDiskCLNC.Vare.VareSkey = DWDiskCLNC.KundeSalg.VareSkey 
							INNER JOIN DWDiskCLNC.Kunde ON DWDiskCLNC.KundeSalg.KundeSkey = DWDiskCLNC.Kunde.KundeSkey
GO
SET STATISTICS TIME ON;
DBCC DROPCLEANBUFFERS;

SELECT	DataWarehouse.Vare.Varenavn,
		DataWarehouse.Kunde.Postnr,
		SUM(DataWarehouse.KundeSalg.AntalEnheder) AS Antal		
	FROM DataWarehouse.Vare	INNER JOIN DataWarehouse.KundeSalg ON DataWarehouse.Vare.VareSkey = DataWarehouse.KundeSalg.VareSkey 
							INNER JOIN DataWarehouse.Kunde ON DataWarehouse.KundeSalg.KundeSkey = DataWarehouse.Kunde.KundeSkey
	GROUP BY	DataWarehouse.Vare.Varenavn,
				DataWarehouse.Kunde.Postnr;

DBCC DROPCLEANBUFFERS;

SELECT	DWDiskCS.Vare.Varenavn,
		DWDiskCS.Kunde.Postnr,
		SUM(DWDiskCS.KundeSalg.AntalEnheder) AS Antal	
	FROM DWDiskCS.Vare		INNER JOIN DWDiskCS.KundeSalg ON DWDiskCS.Vare.VareSkey = DWDiskCS.KundeSalg.VareSkey 
							INNER JOIN DWDiskCS.Kunde ON DWDiskCS.KundeSalg.KundeSkey = DWDiskCS.Kunde.KundeSkey
	GROUP BY	DWDiskCS.Vare.Varenavn,
				DWDiskCS.Kunde.Postnr;

DBCC DROPCLEANBUFFERS;

SELECT	DWDiskCLNC.Vare.Varenavn,
		DWDiskCLNC.Kunde.Postnr,
		SUM(DWDiskCLNC.KundeSalg.AntalEnheder) AS Antal	
	FROM DWDiskCLNC.Vare	INNER JOIN DWDiskCLNC.KundeSalg ON DWDiskCLNC.Vare.VareSkey = DWDiskCLNC.KundeSalg.VareSkey 
							INNER JOIN DWDiskCLNC.Kunde ON DWDiskCLNC.KundeSalg.KundeSkey = DWDiskCLNC.Kunde.KundeSkey
	GROUP BY	DWDiskCLNC.Vare.Varenavn,
				DWDiskCLNC.Kunde.Postnr;
