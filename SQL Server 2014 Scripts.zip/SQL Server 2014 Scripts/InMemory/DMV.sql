USE InMemDB
GO
SELECT	OBJECT_NAME(object_id) AS name, 
		*
	FROM sys.dm_db_xtp_table_memory_stats;

SELECT	OBJECT_NAME(object_id) AS name,
		*
	FROM sys.dm_db_xtp_index_stats;

SELECT	OBJECT_NAME(object_id) AS name,
		*
	FROM sys.dm_db_xtp_nonclustered_index_stats;

SELECT	OBJECT_NAME(object_id) AS name,
		*
	FROM sys.dm_db_xtp_hash_index_stats;

SELECT	OBJECT_NAME(object_id) AS name,
		*
	FROM sys.dm_db_xtp_object_stats;

SELECT	OBJECT_NAME(object_id) AS name,
		*
	FROM sys.dm_db_xtp_object_stats;
