USE master;
GO
DROP DATABASE InMemDB;
GO
CREATE DATABASE InMemDB
ON PRIMARY
(
	NAME = InMemDB_sys,
	FILENAME = N'C:\Databaser\InMemDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_NotInMem_filegroup  
(
	NAME = InMemDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\InMemDB_InMemDB_NotInMem_filegroup.ndf',
	SIZE = 10MB,
	MAXSIZE = 30MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = InMemDB_InMem_filegroup_1,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB'
)
LOG ON
( 
	NAME = InMemDB_log_file_1,
	FILENAME = N'C:\Databaser\InMemDB_log.ldf',
	SIZE = 10MB,
	MAXSIZE = 20MB,
	FILEGROWTH = 10%
);
GO
USE InMemDB;
GO
CREATE TABLE dbo.Data
(
	ID				INT NOT NULL
					CONSTRAINT PK_Data PRIMARY KEY NONCLUSTERED IDENTITY,
	i				INT NOT NULL,
	j				INT NOT NULL,
	
	INDEX hash_index_Data__i HASH (i) WITH (BUCKET_COUNT = 1000),
	INDEX hash_index_Data__j HASH (j) WITH (BUCKET_COUNT = 1000)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
SET NOCOUNT ON;

DECLARE @i		INT = 1;
DECLARE @j		INT = 100;

WHILE @i <= 10
BEGIN
	
	SET @j += 1;

	INSERT INTO dbo.Data(i, j)
		VALUES (@i, @j);

	SET @i += 1;
END;
GO 2
SET NOCOUNT ON;

DECLARE @i		INT = 200;
DECLARE @j		INT = 1;

WHILE @j <= 10
BEGIN
	
	SET @i += 1;

	INSERT INTO dbo.Data(i, j)
		VALUES (@i, @j);

	SET @j += 1;
END;
GO 2
SELECT *
	FROM dbo.Data;

SELECT *
	FROM dbo.Data WITH(INDEX = hash_index_Data__i);

SELECT *
	FROM dbo.Data WITH(INDEX = hash_index_Data__j);

SELECT *
	FROM dbo.Data WITH(INDEX = PK_Data);
