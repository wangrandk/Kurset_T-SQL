USE master
GO
SELECT *
	FROM sys.fn_helpcollations()
	WHERE	name LIKE '%BIN2%' AND
			name LIKE '%Danish%'	
GO
USE master;
GO
DROP DATABASE InMemDB;
GO
CREATE DATABASE InMemDB
ON PRIMARY
(
	NAME = InMemDB_sys,
	FILENAME = N'C:\Databaser\InMemDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_NotInMem_filegroup  
(
	NAME = InMemDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\InMemDB_InMemDB_NotInMem_filegroup.ndf',
	SIZE = 10MB,
	MAXSIZE = 200MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = InMemDB_InMem_filegroup_1,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB'
)
LOG ON
( 
	NAME = InMemDB_log_file_1,
	FILENAME = N'C:\Databaser\InMemDB_log.ldf',
	SIZE = 10MB,
	MAXSIZE = 20MB,
	FILEGROWTH = 10%
);
GO
USE InMemDB;
GO
CREATE TABLE dbo.Person_Danish_Norwegian
(
	ID				INT NOT NULL IDENTITY(1, 1)
					CONSTRAINT PK_Person_Norway PRIMARY KEY NONCLUSTERED,
	Navn			NVARCHAR(30) COLLATE Danish_Norwegian_BIN2 NOT NULL,
	
	INDEX hash_index_Person_Navn HASH (Navn) WITH (BUCKET_COUNT = 4000000),
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
CREATE TABLE dbo.Person_Danish_Greenlandic
(
	ID				INT NOT NULL IDENTITY(1, 1)
					CONSTRAINT PK_Person_Greenlandic PRIMARY KEY NONCLUSTERED,
	Navn			NVARCHAR(30) COLLATE Danish_Greenlandic_100_BIN2 NOT NULL,
	
	INDEX hash_index_Person_Navn HASH (Navn) WITH (BUCKET_COUNT = 4000000),
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
INSERT INTO dbo.Person_Danish_Norwegian(Navn) VALUES
	('Aage'),
	('Anne'),
	('Bent'),
	('Carl'),
	('Dorte'),
	('Erik'),
	('Finn'),
	('Grethe'),
	('Hans'),
	('Ida'),
	('Jens'),
	('Karl'),
	('Lone'),
	('Maren'),
	('Niklas'),
	('Ole'),
	('Pia'),
	('Qies'),
	('Rita'),
	('Sanne'),
	('Tine'),
	('Ulla'),
	('Vera'),
	('Willy'),
	('Xia'),
	('Yrsa'),
	('Zara'),
	('�gir'),
	('�jvind'),
	('�ge');

INSERT INTO dbo.Person_Danish_Greenlandic(Navn) VALUES
	('Aage'),
	('Anne'),
	('Bent'),
	('Carl'),
	('Dorte'),
	('Erik'),
	('Finn'),
	('Grethe'),
	('Hans'),
	('Ida'),
	('Jens'),
	('Karl'),
	('Lone'),
	('Maren'),
	('Niklas'),
	('Ole'),
	('Pia'),
	('Qies'),
	('Rita'),
	('Sanne'),
	('Tine'),
	('Ulla'),
	('Vera'),
	('Willy'),
	('Xia'),
	('Yrsa'),
	('Zara'),
	('�gir'),
	('�jvind'),
	('�ge');
GO
SELECT *
	FROM dbo.Person_Danish_Norwegian
	ORDER BY Navn;
GO
SELECT *
	FROM dbo.Person_Danish_Greenlandic
	ORDER BY Navn;
GO
SELECT *
	FROM dbo.Person_Danish_Greenlandic
	ORDER BY Navn COLLATE Danish_Norwegian_CI_AI;
