USE master;
GO
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'usp_Person1')
	DROP PROCEDURE dbo.usp_Person1;

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'usp_Person2')
	DROP PROCEDURE dbo.usp_Person2;
GO
CREATE PROCEDURE dbo.usp_Person1
(
	@Top		INT = 100000
)
AS
BEGIN
	DECLARE @Person					TABLE
					(
					PersonID		INT NOT NULL PRIMARY KEY NONCLUSTERED,
					Fornavn			VARCHAR(20) NOT NULL INDEX nc_Person_Fornavn,
					Efternavn		VARCHAR(20) NOT NULL,
					Gade			VARCHAR(30) NOT NULL,
					Postnr			SMALLINT NOT NULL
					);

	INSERT INTO @Person
		SELECT	TOP (@Top)
				Personid,
				Fornavn,
				Efternavn,
				Gade,
				Postnr
			FROM IndexDB.dbo.Person;

	SELECT DISTINCT Fornavn
		FROM @Person
END;
GO
CREATE PROCEDURE dbo.usp_Person2
(
	@Top		INT = 100000
)
AS
BEGIN
	DECLARE @Person					TABLE
					(
					PersonID		INT NOT NULL PRIMARY KEY NONCLUSTERED,
					Fornavn			VARCHAR(20) NOT NULL,
					Efternavn		VARCHAR(20) NOT NULL,
					Gade			VARCHAR(30) NOT NULL,
					Postnr			SMALLINT NOT NULL
					);

	INSERT INTO @Person
		SELECT	TOP (@Top)
				Personid,
				Fornavn,
				Efternavn,
				Gade,
				Postnr
			FROM IndexDB.dbo.Person;

	SELECT DISTINCT Fornavn
		FROM @Person
END;
GO
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

EXEC dbo.usp_Person1 50000;
EXEC dbo.usp_Person2 50000;

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
