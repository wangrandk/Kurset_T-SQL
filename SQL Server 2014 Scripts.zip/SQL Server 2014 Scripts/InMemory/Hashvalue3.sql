USE master;
GO
DROP DATABASE HashbyteDB;
GO
CREATE DATABASE HashbyteDB
ON PRIMARY
(
	NAME = HashbyteDB_sys,
	FILENAME = N'C:\Databaser\IHashbyteDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP HashbyteDB_filegroup  
(
	NAME = HashbyteDB_filegroup_1,
	FILENAME = N'C:\Databaser\HashbyteDB_filegroup.ndf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
)
LOG ON
( 
	NAME = HashbyteDB_log_file_1,
	FILENAME = N'C:\Databaser\HashbyteDB_log.ldf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
);
GO
USE HashbyteDB;
CREATE TABLE dbo.Hashvalue
(
	ID						INT NOT NULL  PRIMARY KEY NONCLUSTERED IDENTITY ,
	Value					BIGINT NOT NULL,
	Hashvalue				AS HASHBYTES('SHA', CAST(Value AS VARCHAR(20))) PERSISTED,
	Intvalue				AS CAST(HASHBYTES('SHA', CAST(Value AS VARCHAR(20))) AS BIGINT) PERSISTED,
	BucketCount3000000		AS ABS(CAST(HASHBYTES('SHA', CAST(Value AS VARCHAR(20))) AS BIGINT) % 3000000) PERSISTED,
	BucketCount50			AS ABS(CAST(HASHBYTES('SHA', CAST(Value AS VARCHAR(20))) AS BIGINT) % 50) PERSISTED,
	NextBucketCount3000000	INT NULL,
	NextBucketCount50		INT NULL
) ON HashbyteDB_filegroup;
GO
SET NOCOUNT ON;

DECLARE @Antalloop		BIGINT = 3000000;

WHILE @Antalloop > 1
BEGIN
	INSERT 
		INTO dbo.Hashvalue (Value) 
		VALUES (@Antalloop)

	IF @Antalloop % 100000 = 1
		PRINT @Antalloop

	SET @Antalloop -= 1;
END;
GO
SELECT *
	FROM dbo.Hashvalue;
GO
--SELECT Hashvalue, COUNT(*)
--	FROM dbo.Hashvalue
--	GROUP BY Hashvalue
--	HAVING COUNT(*) > 1;

--SELECT Intvalue, COUNT(*)
--	FROM dbo.Hashvalue
--	GROUP BY Intvalue
--	HAVING COUNT(*) > 1;

--SELECT BucketCount, COUNT(*)
--	FROM dbo.Hashvalue
--	GROUP BY BucketCount
--	HAVING COUNT(*) > 1;

SELECT DISTINCT Value
	FROM dbo.Hashvalue
	WHERE BucketCount3000000 = 40;

SELECT DISTINCT Value
	FROM dbo.Hashvalue
	WHERE BucketCount50 = 40;

SELECT Value, COUNT(*)
	FROM dbo.Hashvalue
	WHERE BucketCount3000000 = 40
	GROUP BY Value;

SELECT Value, COUNT(*)
	FROM dbo.Hashvalue
	WHERE BucketCount50 = 40
	GROUP BY Value;

SELECT COUNT(*)
	FROM dbo.Hashvalue
	WHERE BucketCount3000000 = 40;

SELECT COUNT(*)
	FROM dbo.Hashvalue
	WHERE BucketCount50 = 40;
GO
UPDATE Hashres
	SET Hashres.NextBucketCount3000000 = (SELECT MIN(Hashinner.ID) 
										FROM dbo.Hashvalue AS Hashinner
										WHERE	Hashinner.BucketCount3000000 = Hashres.BucketCount3000000 AND
												Hashinner.ID > Hashres.ID),
		Hashres.NextBucketCount50 = (SELECT MIN(Hashinner.ID) 
										FROM dbo.Hashvalue AS Hashinner
										WHERE	Hashinner.BucketCount50 = Hashres.BucketCount50 AND
												Hashinner.ID > Hashres.ID)
	FROM dbo.Hashvalue AS Hashres INNER JOIN Hashvalue AS Hashouter ON Hashres.ID = Hashouter.ID;
GO
DECLARE @Value				VARCHAR(10);

DECLARE @BucketCount3000000	BIGINT;
DECLARE @BucketCount50		BIGINT;

---------------------------------------------- 
WITH v
AS
(
SELECT	BucketCount3000000,
		Value,
		COUNT(*) AS Antal
	FROM dbo.Hashvalue
	GROUP BY BucketCount3000000, Value
)
SELECT	@Value = Value, 
		@BucketCount3000000 = BucketCount3000000
	FROM v
	WHERE Antal = (SELECT MAX(Antal) FROM v);

---------------------------------------------- 
WITH Bucket
AS
(
SELECT	*,
		ROW_NUMBER() OVER(ORDER BY BucketCount3000000, ID) AS Rownumber
	FROM	dbo.Hashvalue
	WHERE	BucketCount3000000 = @BucketCount3000000
)
SELECT	ID,
		Value,
		BucketCount3000000,
		Rownumber,
		(SELECT COUNT(*) FROM Bucket) AS BoucketSize
	FROM Bucket
	WHERE Value = @Value
	ORDER BY ID;

----------------------------------------------
SET @BucketCount50 = ABS(CAST(HASHBYTES('SHA', @Value) AS BIGINT) % 50);

WITH Bucket
AS
(
SELECT	*,
		ROW_NUMBER() OVER(ORDER BY BucketCount50, ID) AS Rownumber
	FROM	dbo.Hashvalue
	WHERE	BucketCount50 = @BucketCount50)
SELECT	ID,
		Value,
		BucketCount50,
		Rownumber,
		(SELECT COUNT(*) FROM Bucket) AS BoucketSize
	FROM Bucket
	WHERE Value = @Value
	ORDER BY ID;
GO
