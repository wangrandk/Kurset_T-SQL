USE master;
GO
DROP DATABASE InMemDB;
GO
CREATE DATABASE InMemDB
ON PRIMARY
(
	NAME = InMemDB_sys,
	FILENAME = N'C:\Databaser\InMemDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_NotInMem_filegroup  
(
	NAME = InMemDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\InMemDB_InMemDB_NotInMem_filegroup.ndf',
	SIZE = 10MB,
	MAXSIZE = 30MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = InMemDB_InMem_filegroup_1,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB'
)
LOG ON
( 
	NAME = InMemDB_log_file_1,
	FILENAME = N'C:\Databaser\InMemDB_log.ldf',
	SIZE = 100MB,
	MAXSIZE = 200MB,
	FILEGROWTH = 10%
);
GO
USE InMemDB;
GO
CREATE TABLE dbo.t1
(
	ID				INT NOT NULL
					CONSTRAINT PK_t1 PRIMARY KEY NONCLUSTERED IDENTITY,
	i				INT NOT NULL,
	j				INT NOT NULL,
	
	INDEX hash_index_t1__i_j HASH (i, j) WITH (BUCKET_COUNT = 1000000)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);

CREATE TABLE dbo.t2
(
	ID				INT NOT NULL
					CONSTRAINT PK_t2 PRIMARY KEY NONCLUSTERED IDENTITY,
	i				INT NOT NULL,
	j				INT NOT NULL,
	
	INDEX hash_index_t2__i_j HASH (i, j) WITH (BUCKET_COUNT = 1000000)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);

CREATE TABLE dbo.t3
(
	ID				INT NOT NULL
					CONSTRAINT PK_t3 PRIMARY KEY NONCLUSTERED IDENTITY,
	i				INT NOT NULL,
	j				INT NOT NULL,
	
	INDEX hash_index_t3__i HASH (i) WITH (BUCKET_COUNT = 1000),
	INDEX hash_index_t3__j HASH (j) WITH (BUCKET_COUNT = 1000)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);

CREATE TABLE dbo.t4
(
	ID				INT NOT NULL
					CONSTRAINT PK_t4 PRIMARY KEY NONCLUSTERED IDENTITY,
	i				INT NOT NULL,
	j				INT NOT NULL,
	
	INDEX hash_index_t4__i HASH (i) WITH (BUCKET_COUNT = 1000),
	INDEX hash_index_t4__j HASH (j) WITH (BUCKET_COUNT = 1000)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
SET NOCOUNT ON;

DECLARE @i		INT = 1;
DECLARE @j		INT = 1;

WHILE @i < 1000
BEGIN
	SET @j = 1;
	
	WHILE @j < 50
	BEGIN
		INSERT INTO dbo.t1 (i, j)
			VALUES (@i, @j);

		INSERT INTO dbo.t3(i, j)
			VALUES (@i, @j);

		SET @j += 1;
	END;

	SET @j = 50;
	
	WHILE @j > 1
	BEGIN
		INSERT INTO dbo.t2 (i, j)
			VALUES (@i, @j);

		INSERT INTO dbo.t4 (i, j)
			VALUES (@i, @j);

		SET @j -= 1;
	END;
	SET @i += 1;
END;
GO
SELECT *
	FROM sys.indexes;

EXEC sp_updatestats;
GO
SELECT ID, j
	FROM dbo.t1
	WHERE j = 10;

SELECT ID, j
	FROM dbo.t2
	WHERE j = 10;

SELECT ID, j
	FROM dbo.t3
	WHERE j = 10;

SELECT ID, j
	FROM dbo.t4
	WHERE j = 10;
GO
