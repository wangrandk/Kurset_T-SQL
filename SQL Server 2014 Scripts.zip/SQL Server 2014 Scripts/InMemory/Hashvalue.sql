USE master;
GO
DROP DATABASE HashbyteDB;
GO
CREATE DATABASE HashbyteDB
ON PRIMARY
(
	NAME = HashbyteDB_sys,
	FILENAME = N'C:\Databaser\IHashbyteDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP HashbyteDB_filegroup  
(
	NAME = HashbyteDB_filegroup_1,
	FILENAME = N'C:\Databaser\HashbyteDB_filegroup.ndf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
)
LOG ON
( 
	NAME = HashbyteDB_log_file_1,
	FILENAME = N'C:\Databaser\HashbyteDB_log.ldf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
);
GO
USE HashbyteDB;
CREATE TABLE dbo.Hashvalue
(
	ID						INT NOT NULL  PRIMARY KEY NONCLUSTERED IDENTITY ,
	Value					VARCHAR(10) NOT NULL,
	Hashvalue				AS HASHBYTES('SHA', Value) PERSISTED,
	Intvalue				AS CAST(HASHBYTES('SHA', Value) AS BIGINT) PERSISTED,
	BucketCount9999			AS ABS(CAST(HASHBYTES('SHA', Value) AS BIGINT) % 9999) PERSISTED,
	BucketCount50			AS ABS(CAST(HASHBYTES('SHA', Value) AS BIGINT) % 50) PERSISTED,
	NextBucketCount9999		INT NULL,
	NextBucketCount50		INT NULL
) ON HashbyteDB_filegroup;
GO
SET NOCOUNT ON;

DECLARE @i				SMALLINT;
DECLARE @j				SMALLINT;
DECLARE @Antalloop		SMALLINT = 15; 

WHILE @Antalloop > 1
BEGIN
	SET @i = 65;
	
	WHILE @i < 122
	BEGIN
		SET @j = 65;

		WHILE @j < 122
		BEGIN
			INSERT 
				INTO dbo.Hashvalue (Value) 
				VALUES (SUBSTRING	(CHAR(@i) + CHAR(@j) + CHAR(@i) + CHAR(@j) + CHAR(@i) + CHAR(@j) + CHAR(@i) + CHAR(@j) + CHAR(@i) + CHAR(@j),
									(DATEPART(NANOSECOND, SYSDATETIME()) % 10) + 1,
									(DATEPART(MICROSECOND, SYSDATETIME()) % 10) + 3));

			SET @j += 1;
		END;
		SET @i += 1;
	END;

	SET @Antalloop -= 1;
END;
GO
SELECT *
	FROM dbo.Hashvalue;
GO
--SELECT Hashvalue, COUNT(*)
--	FROM dbo.Hashvalue
--	GROUP BY Hashvalue
--	HAVING COUNT(*) > 1;

--SELECT Intvalue, COUNT(*)
--	FROM dbo.Hashvalue
--	GROUP BY Intvalue
--	HAVING COUNT(*) > 1;

--SELECT BucketCount, COUNT(*)
--	FROM dbo.Hashvalue
--	GROUP BY BucketCount
--	HAVING COUNT(*) > 1;

SELECT DISTINCT Value
	FROM dbo.Hashvalue
	WHERE BucketCount9999 = 40;

SELECT DISTINCT Value
	FROM dbo.Hashvalue
	WHERE BucketCount50 = 40;

SELECT Value, COUNT(*)
	FROM dbo.Hashvalue
	WHERE BucketCount9999 = 40
	GROUP BY Value;

SELECT Value, COUNT(*)
	FROM dbo.Hashvalue
	WHERE BucketCount50 = 40
	GROUP BY Value;

SELECT COUNT(*)
	FROM dbo.Hashvalue
	WHERE BucketCount9999 = 40;

SELECT COUNT(*)
	FROM dbo.Hashvalue
	WHERE BucketCount50 = 40;
GO
UPDATE Hashres
	SET Hashres.NextBucketCount9999 = (SELECT MIN(Hashinner.ID) 
										FROM dbo.Hashvalue AS Hashinner
										WHERE	Hashinner.BucketCount9999 = Hashres.BucketCount9999 AND
												Hashinner.ID > Hashres.ID),
		Hashres.NextBucketCount50 = (SELECT MIN(Hashinner.ID) 
										FROM dbo.Hashvalue AS Hashinner
										WHERE	Hashinner.BucketCount50 = Hashres.BucketCount50 AND
												Hashinner.ID > Hashres.ID)
	FROM dbo.Hashvalue AS Hashres INNER JOIN Hashvalue AS Hashouter ON Hashres.ID = Hashouter.ID;
GO
DECLARE @Value				VARCHAR(10);

DECLARE @BucketCount9999	BIGINT;
DECLARE @BucketCount50		BIGINT;

---------------------------------------------- 
WITH v
AS
(
SELECT	BucketCount9999,
		Value,
		COUNT(*) AS Antal
	FROM dbo.Hashvalue
	GROUP BY BucketCount9999, Value
)
SELECT	@Value = Value, 
		@BucketCount9999 = BucketCount9999
	FROM v
	WHERE Antal = (SELECT MAX(Antal) FROM v);

---------------------------------------------- 
WITH Bucket
AS
(
SELECT	*,
		ROW_NUMBER() OVER(ORDER BY BucketCount9999, ID) AS Rownumber
	FROM	dbo.Hashvalue
	WHERE	BucketCount9999 = @BucketCount9999
)
SELECT	ID,
		Value,
		BucketCount9999,
		Rownumber,
		(SELECT COUNT(*) FROM Bucket) AS BoucketSize
	FROM Bucket
	WHERE Value = @Value
	ORDER BY ID;

----------------------------------------------
SET @BucketCount50 = ABS(CAST(HASHBYTES('SHA', @Value) AS BIGINT) % 50);

WITH Bucket
AS
(
SELECT	*,
		ROW_NUMBER() OVER(ORDER BY BucketCount50, ID) AS Rownumber
	FROM	dbo.Hashvalue
	WHERE	BucketCount50 = @BucketCount50
)
SELECT	ID,
		Value,
		BucketCount50,
		Rownumber,
		(SELECT COUNT(*) FROM Bucket) AS BoucketSize
	FROM Bucket
	WHERE Value = @Value
	ORDER BY ID;
GO
