USE master;
GO
DROP DATABASE InMemDB;
GO
CREATE DATABASE InMemDB
ON PRIMARY
(
	NAME = InMemDB_sys,
	FILENAME = N'C:\Databaser\InMemDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_NotInMem_filegroup  
(
	NAME = InMemDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\InMemDB_InMemDB_NotInMem_filegroup.ndf',
	SIZE = 10MB,
	MAXSIZE = 200MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = InMemDB_InMem_filegroup_1,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB'
)
LOG ON
( 
	NAME = InMemDB_log_file_1,
	FILENAME = N'C:\Databaser\InMemDB_log.ldf',
	SIZE = 10MB,
	MAXSIZE = 200MB,
	FILEGROWTH = 10%
);
GO
USE InMemDB;
GO
CREATE TABLE dbo.Person
(
	ID				INT NOT NULL
					CONSTRAINT PK_Person PRIMARY KEY NONCLUSTERED IDENTITY(1, 1),
	Navn			VARCHAR(30) COLLATE Latin1_General_BIN2 NOT NULL,
	Gade 			VARCHAR (30)  NOT NULL,
	Postnr			SMALLINT NOT NULL
	
	INDEX hash_index_Person_Navn HASH (Navn) WITH (BUCKET_COUNT = 131072)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);

CREATE TABLE dbo.Postopl
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY NONCLUSTERED,
	Bynavn			VARCHAR(20) COLLATE Latin1_General_BIN2 NOT NULL
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
INSERT INTO dbo.Postopl VALUES
	(2000, 'Frederiksberg'),
	(2300, 'K�benhavn S'),
	(4000, 'Roskilde'),
	(5000, 'Odense C'),
	(8000, 'Aarhus C'),
	(8240, 'Risskov'),
	(8270, 'H�jbjerg'),
	(9000, 'Aalborg'),
	(9990, 'Skagen');
GO
CREATE PROCEDURE dbo.usp_Native_Compilation_Person
(
	@Navn			VARCHAR(30),
	@Gade			VARCHAR(30),
	@Postnr			SMALLINT
)	
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC
	WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

INSERT INTO dbo.Person(Navn, Gade, Postnr)
	VALUES(@Navn, @Gade, @Postnr)
END;
GO
EXEC dbo.usp_Native_Compilation_Person 'Ole Olsen', 'Nygade 7', 9000;
EXEC dbo.usp_Native_Compilation_Person 'Hanne Larsen', 'Vestergade 17', 8000;
EXEC dbo.usp_Native_Compilation_Person 'Lars Petersen', 'Torvet 3', 2000;
EXEC dbo.usp_Native_Compilation_Person 'Pia Knudsen', 'S�ndergade 33', 5000;
EXEC dbo.usp_Native_Compilation_Person '�jvind Carlsen', 'Storegade 34', 2000;
EXEC dbo.usp_Native_Compilation_Person 'Zara Hansen', 'Pilestr�de 76', 2000;
EXEC dbo.usp_Native_Compilation_Person 'Ane Ibsen', 'Nygade 4', 2000;
EXEC dbo.usp_Native_Compilation_Person '�ge Hansen', 'Torvet 28', 2000;
GO
SELECT *
	FROM dbo.Person;

SELECT *
	FROM dbo.Postopl;
GO
DROP PROCEDURE dbo.usp_Native_Compilation_Person
GO
CREATE PROCEDURE dbo.usp_Native_Compilation_Person
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC
	WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

SELECT	Person.ID,
		Person.Navn,
		Person.Gade,
		Postopl.Postnr,
		Postopl.Bynavn
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
END;
GO
EXEC usp_Native_Compilation_Person
GO
DROP PROCEDURE dbo.usp_Native_Compilation_Person
GO
CREATE PROCEDURE dbo.usp_Native_Compilation_Person
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC
	WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

SELECT	Person.ID,
		Person.Navn,
		Person.Gade,
		Postopl.Postnr,
		Postopl.Bynavn
	FROM dbo.Person INNER JOIN dbo.Postopl ON Person.Postnr = Postopl.Postnr
	ORDER BY Postopl.Bynavn COLLATE Latin1_General_BIN2, Person.Navn COLLATE Latin1_General_BIN2
END;
GO
EXEC usp_Native_Compilation_Person
GO
DROP PROCEDURE dbo.usp_Native_Compilation_Person
GO
CREATE TYPE dbo.PersonTable AS TABLE 
(
	ID				INT NOT NULL PRIMARY KEY NONCLUSTERED,
	Navn			VARCHAR(30) NOT NULL,
	Gade 			VARCHAR (30)  NOT NULL,
	Postnr			SMALLINT NOT NULL
)
WITH (MEMORY_OPTIMIZED = ON);
GO
CREATE PROCEDURE dbo.usp_Native_Compilation_Person
(
	@Personer		dbo.PersonTable READONLY
)
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC
	WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'danish')

INSERT INTO dbo.Person (Navn, Gade, Postnr)
	SELECT	Navn,
			Gade,
			Postnr
		FROM @Personer
END;
GO
DECLARE @Personer		dbo.PersonTable;

INSERT INTO @Personer VALUES
	(1, 'Ole Larsen', 'Nygade 45', 2000),
	(2, 'Maren Olsen', 'Tovet 23', 5000),
	(3, 'Lars Petersen', 'Vestergade 11', 2000);

EXEC usp_Native_Compilation_Person @Personer
GO
SELECT *
	FROM dbo.Person;
