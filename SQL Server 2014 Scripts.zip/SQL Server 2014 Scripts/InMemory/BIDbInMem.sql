USE master;
GO
DROP DATABASE BIDbInMem;
GO
CREATE DATABASE BIDbInMem
ON PRIMARY
(
	NAME = BIDbInMem_sys,
	FILENAME = N'C:\Databaser\BIDbInMem_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP BIDbInMem_NotInMem_filegroup  
(
	NAME = BIDbInMem_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\BIDbInMem_BIDbInMem_NotInMem_filegroup.ndf',
	SIZE = 1000MB,
	MAXSIZE = 2000MB,
	FILEGROWTH = 10%
),
FILEGROUP BIDbInMem_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = BIDbInMem_InMem_filegroup_1,
    FILENAME = N'C:\Databaser\InMem_Data_BIDbInMem'
)
LOG ON
( 
	NAME = BIDbInMem_log_file_1,
	FILENAME = N'C:\Databaser\BIDbInMem_log.ldf',
	SIZE = 1000MB,
	MAXSIZE = 2000MB,
	FILEGROWTH = 10%
);
GO
ALTER DATABASE BIDbInMem SET RECOVERY SIMPLE;
GO
ALTER DATABASE BIDbInMem MODIFY FILEGROUP BIDbInMem_NotInMem_filegroup DEFAULT;
GO
USE BiDbInMem;
GO
CREATE SCHEMA DataWarehouse;
GO
CREATE SCHEMA HjaelpeTabeller;
GO
CREATE TABLE HjaelpeTabeller.Efternavn 
(
	Efternavn 		VARCHAR(20) NOT NULL
);

CREATE TABLE HjaelpeTabeller.Fornavn 
(
	Fornavn 		VARCHAR(50) NOT NULL,
	Koen			CHAR(1) NOT NULL
); 

CREATE TABLE HjaelpeTabeller.Gade 
(
	Gade 			VARCHAR(30) NOT NULL
);

CREATE TABLE DataWarehouse.Region 
(
	DelRegionSkey	SMALLINT NOT NULL IDENTITY(1,1)
					CONSTRAINT PK_Region PRIMARY KEY,
	DelRegionID		SMALLINT NOT NULL
					CONSTRAINT UQ_Region_DelRegionID UNIQUE,
	DelRegionsnavn	VARCHAR(20) NULL
					CONSTRAINT UQ_Region_DelRegionsnavn UNIQUE,
	Regionsnavn		VARCHAR(20) NOT NULL,
	DelRegionSort	SMALLINT NOT NULL
);

CREATE TABLE DataWarehouse.Postopl 
(
	Postnr 			SMALLINT NOT NULL 
					CONSTRAINT PK_Postopl PRIMARY KEY (Postnr),
	Bynavn 			VARCHAR (20) NOT NULL,
	DelRegionID		SMALLINT NOT NULL 
					CONSTRAINT FK_Postopl_Region REFERENCES DataWarehouse.Region(DelRegionID)
);

CREATE TABLE DataWarehouse.Kundetypekode 
(
	KundeTypeSkey	INT NOT NULL IDENTITY(1,1)
					CONSTRAINT PK_Kundetypekode PRIMARY KEY,
	Kundetype		CHAR(1) NOT NULL 
					CONSTRAINT UQ_Kundetypekode_Kundetype UNIQUE,
	Kundetypetxt	VARCHAR(20) NOT NULL
					CONSTRAINT UQ_Kundetypekode_Kundetypetxt UNIQUE
);

CREATE TABLE DataWarehouse.Koen 
(
	KoenSkey		INT NOT NULL IDENTITY(1,1)
					CONSTRAINT PK_Koen PRIMARY KEY,
	Koen			CHAR(1) NOT NULL 
					CONSTRAINT UQ_Koen_Koen UNIQUE,
	KoenText		VARCHAR(10) NOT NULL
);

CREATE TABLE DataWarehouse.Kunde 
(
	KundeSkey 		INT IDENTITY(1, 1) NOT NULL
					CONSTRAINT PK_Kunde PRIMARY KEY NONCLUSTERED,
	KundeBkey 		INT NOT NULL,
	Fornavn			VARCHAR(20) COLLATE Latin1_General_BIN2 NOT NULL INDEX nc_Person_Fornavn,
	Efternavn		VARCHAR(20) COLLATE Latin1_General_BIN2 NOT NULL INDEX nc_Person_Efternavn,
	Gade 			VARCHAR(30) COLLATE Latin1_General_BIN2 NOT NULL INDEX nc_Person_Gade,
	Postnr 			SMALLINT NOT NULL INDEX nc_Person_Postnr,
	Kundetype		CHAR(1) NOT NULL,
	Koen			CHAR(1) NULL,
	GaeldendeFra	DATE NOT NULL DEFAULT(SYSDATETIME()),
	GaeldendeTil	DATE NULL
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
SET NOCOUNT ON;
IF EXISTS (SELECT * FROM HjaelpeTabeller.Fornavn)
	RETURN;
	
INSERT INTO HjaelpeTabeller.Fornavn VALUES 
	('Anne', 'K'),
	('Ane', 'K'),
	('Annemette', 'K'),
	('Anne Mette', 'K'),
	('Anne Marie', 'K'),
	('Anders', 'M'),
	('Andreas', 'M'),
	('Arne', 'M'),
	('Allan', 'M'),
	('Birte', 'K'),
	('Birthe', 'K'),
	('Bente', 'K'),
	('Bent', 'K'),
	('B�rge', 'M'),
	('Bruno', 'M'),
	('Carl', 'M'),
	('Carina', 'K'),
	('Christian', 'M'),
	('Christina', 'K'),
	('Dorte', 'K'),
	('Dorthe', 'K'),
	('David', 'M'),
	('Daniel', 'M'),
	('Erik', 'M'),
	('Eva', 'K'),
	('Emma', 'K'),
	('Ebba', 'K'),
	('Ebbe', 'M'),
	('Ellen', 'K'),
	('Edvard', 'M'),
	('Edward', 'M'),
	('Egon', 'M'),
	('Esther', 'K'),
	('Frank', 'M'),
	('Frederikke', 'K'),
	('Frede', 'M'),
	('Frode', 'M'),
	('Frida', 'K'),
	('Grete', 'K'),
	('Gitte', 'K'),
	('Grethe', 'K'),
	('Gert', 'M'),
	('Gerd', 'K'),
	('Gunnar', 'M'),
	('Gustav', 'M'),
	('Gudrun', 'K'),
	('Henrik', 'M'),
	('Hans', 'M'),
	('Hans Erik', 'M'),
	('Hans Ole', 'M'),
	('Hanne', 'K'),
	('Henriette', 'K'),
	('Hedvig', 'K'),
	('Henry', 'M'),
	('Hugo', 'M'),
	('Ib', 'M'),
	('Ida', 'K'),
	('Ilse', 'K'),
	('Ivar', 'M'),
	('Ivan', 'M'),
	('Inger', 'K'),
	('Inge', 'K'),
	('Jens', 'M'),
	('Jens Erik', 'M'),
	('Jens Ole', 'M'),
	('Jens Peter', 'M'),
	('Jakob', 'M'),
	('Jacob', 'M'),
	('Jesper', 'M'),
	('Jette', 'K'),
	('Jytte', 'K'),
	('Jane', 'K'),
	('Karl', 'M'),
	('Karen', 'K'),
	('Karin', 'K'),
	('Kis', 'K'),
	('Karina', 'K'),
	('Kristina', 'K'),
	('Kristine', 'K'),
	('Kurt', 'M'),
	('Knud', 'M'),
	('Kenneth', 'M'),
	('Lars', 'M'),
	('Lars Ole', 'M'),
	('Lars Bo', 'M'),
	('Ludvig', 'M'),
	('Line', 'K'),
	('Lise', 'K'),
	('Lisette', 'K'),
	('Lene', 'K'),
	('Lisbeth', 'K'),
	('Lena', 'K'),
	('Liselotte', 'K'),
	('Lise Lotte', 'K'),
	('Morten', 'M'),
	('Marie', 'K'),
	('Mads', 'M'),
	('Maren', 'K'),
	('Malene', 'K'),
	('Mette', 'K'),
	('Michael', 'M'),
	('Mikael', 'M'),
	('Niels', 'M'),
	('Nis', 'M'),
	('Nicolaj', 'M'),
	('Nikolaj', 'M'),
	('Ninna', 'K'),
	('Nette', 'K'),
	('Nanna', 'K'),
	('Ole', 'M'),
	('Oda', 'K'),
	('Olivia', 'K'),
	('Oskar', 'M'),
	('Ove', 'M'),
	('Peter', 'M'),
	('Per', 'M'),
	('Petrea', 'K'),
	('Peder', 'M'),
	('Pil', 'K'),
	('Poul', 'M'),
	('Paul', 'M'),
	('Poula', 'K'),
	('Rasmus', 'M'),
	('Rie', 'K'),
	('Rikke', 'K'),
	('Richard', 'M'),
	('Rune', 'M'),
	('Ruth', 'K'),
	('Rosa', 'K'),
	('Robert', 'M'),
	('Rositta', 'K'),
	('S�ren', 'M'),
	('Sys', 'K'),
	('Sara', 'K'),
	('Simone', 'K'),
	('Susanne', 'K'),
	('Sanne', 'K'),
	('Sofus', 'M'),
	('Solvej', 'K'),
	('Signe', 'K'),
	('Thomas', 'M'),
	('Tove', 'K'),
	('Tommy', 'M'),
	('Tone', 'K'),
	('Trine', 'K'),
	('Tine', 'K'),
	('Tina', 'K'),
	('Tobias', 'M'),
	('Uffe', 'M'),
	('Ulla', 'K'),
	('Ulrik', 'M'),
	('Vera', 'K'),
	('Villy', 'M'),
	('Vagn', 'M'),
	('Willy', 'M'),
	('Yrsa', 'K'),
	('�jvind', 'M'),
	('�ge', 'M'),
	('�se', 'K');
GO
IF EXISTS (SELECT * FROM HjaelpeTabeller.Efternavn) 
	RETURN;

INSERT INTO HjaelpeTabeller.Efternavn VALUES 
	('Andersen'),
	('B�rgesen'),
	('Bentsen'),
	('Christensen'),
	('Christiansen'),
	('Carlsen'),
	('Davidsen'),
	('Danielsen'),
	('Eriksen'),
	('Frandsen'),
	('Frederiksen'),
	('Gertsen'),
	('Henriksen'),
	('Hansen'),
	('Iversen'),
	('Ibsen'),
	('Jensen'),
	('Jensen'),
	('Jakobsen'),
	('Jacobsen'),
	('Karlsen'),
	('Knudsen'),
	('Kristensen'),
	('Larsen'),
	('Lassen'),
	('Mortensen'),
	('Madsen'),
	('Mikkelsen'),
	('Nielsen'),
	('Nyborg'),
	('Olsen'),
	('Olesen'),
	('Pedersen'),
	('Petersen'),
	('Rasmussen'),
	('S�rensen'),
	('Thomsen'),
	('Vognsen'),
	('Vesterg�rd'),
	('Westergaard'),
	('�vlisen'),
	('�gesen'),
	('�berg');
GO
IF EXISTS (SELECT * FROM HjaelpeTabeller.Gade)
	RETURN;
	
INSERT INTO HjaelpeTabeller.Gade VALUES
	('N�rregade 2'),
	('N�rregade 34'),
	('N�rregade 27'),
	('N�rregade 67'),
	('Vestergade 3'),
	('Vestergade 56'),
	('Vestergade 5'),
	('�stergade 23'),
	('�stergade 1'),
	('S�ndergade 6'),
	('S�ndergade 78'),
	('Torvet 2'),
	('Torvet 4'),
	('Runddelen 1'),
	('Ved Stranden 3'),
	('Ved Stranden 5'),
	('Strandvejen 112'),
	('All�gade 29'),
	('Norgesgade 3'),
	('Ungarnsgade 4'),
	('Italiensvej 32'),
	('Strandvejen 2'),
	('All�gade 5'),
	('Norgesgade 38'),
	('Ungarnsgade 7'),
	('Italiensvej 21'),
	('Italiensvej 4'),
	('Bragesgade 1'),
	('Bragesgade 12'),
	('Dortesvej 4'),
	('Dortesvej 3'),
	('Ellebjergvej 114'),
	('Ellebjergvej 34'),
	('Ellebjergvej 65'),
	('Ellebjergvej 87'),
	('Frankrigsgade 14'),
	('Frankrigsgade 6'),
	('Frankrigsgade 115'),
	('Helgolandsgade 54'),
	('Helgolandsgade 19'),
	('Helgolandsgade 8'),
	('K�gevej 4'),
	('K�gevej 48'),
	('M�llegade 13'),
	('M�llegade 33'),
	('M�llegade 34'),
	('Ollerupvej 3'),
	('Sct. Pouls Gade 2'),
	('Sct. Pouls Gade 3'),
	('Sct. Pouls Gade 25'),
	('Willemoesgade 2'),
	('Willemoesgade 17');
GO
INSERT INTO DataWarehouse.Region VALUES 
	(1, 'Stork�benhavn', 'Stork�benhavn', 1),
	(2, 'Sj�lland', 'Sj�lland', 2),
	(3, 'Fyn', 'Fyn', 3),
	(4, 'Nordjylland', 'Jylland', 6),
	(5, 'Midtjylland', 'Jylland', 5),
	(6, 'S�nderjylland', 'Jylland', 4);
GO
INSERT INTO DataWarehouse.Postopl VALUES
	(1127, 'K�benhavn K', 1),
	(1001, 'K�benhavn K', 1),
	(1129, 'K�benhavn K', 1),
	(1130, 'K�benhavn K', 1),
	(2000, 'Frederiksberg', 1),
	(3400, 'Hiller�d', 2),
	(3050, 'Humleb�k', 2),
	(2600, 'Glostrup', 1),
	(2605, 'Br�ndby', 1),
	(2610, 'R�dovre', 1),
	(2620, 'Albertslund', 1),
	(2625, 'Vallensb�k', 1),
	(2630, 'Taastrup', 1),
	(2635, 'Ish�j', 1),
	(2640, 'Hedehusene', 1),
	(2650, 'Hvidovre', 1),
	(2660, 'Br�ndby Strand', 1),
	(2665, 'Vallensb�k Strand', 1),
	(2670, 'Greve', 1),
	(2680, 'Solr�d Strand', 1),
	(2800, 'Kongens Lyngby', 1),
	(2820, 'Gentofte', 1),
	(2830, 'Virum', 1),
	(2840, 'Holte', 1),
	(2850, 'N�rum', 1),
	(2860, 'S�borg', 1),
	(2870, 'Dysseg�rd', 1),
	(2880, 'Bagsv�rd', 1),
	(2900, 'Hellerup', 1),
	(2920, 'Charlottenlund', 1),
	(2930, 'Klampenborg', 1),
	(2942, 'Skodsborg', 1),
	(2950, 'Vedb�k', 1),
	(5000, 'Odense C', 3),
	(5220, 'Odense S�', 3),
	(5700, 'Svendborg', 3),
	(2300, 'K�benhavn S', 1),
	(6051, 'Almind', 6),
	(6000, 'Kolding', 6),
	(6950, 'Ringk�bing', 5),
	(8000, 'Aarhus C', 5),
	(8200, 'Aarhus N', 5),
	(8240, 'Risskov', 5),
	(8270, 'H�jbjerg', 5),
	(8310, 'Tranbjerg J', 5),
	(9000, 'Aalborg', 4),
	(9400, 'N�rresundby', 4),
	(9600, 'Br�nderslev', 4),
	(9800, 'Hj�rring', 4),
	(9990, 'Skagen', 4),
	(8700, 'Horsens', 5);
GO
INSERT INTO DataWarehouse.Kundetypekode VALUES
	('A', 'Almindelig'),
	('B', 'Firma'),
	('C', 'Storkunde'),
	('D', 'Ung - 14-18'),
	('E', 'Barn - 0-13');
GO
INSERT INTO DataWarehouse.Koen VALUES
	('K', 'Kvinde'),
	('M', 'Mand');
GO
INSERT INTO DataWarehouse.Kunde (KundeBkey, Fornavn, Efternavn, Gade, Postnr, Koen, Kundetype)
   SELECT  1 AS ForeloebigKundeID, Fornavn, Efternavn, Gade, Postnr, Koen, 'A'
      FROM HjaelpeTabeller.Fornavn	
				INNER JOIN HjaelpeTabeller.Efternavn	ON Fornavn.Fornavn > Efternavn.Efternavn
				INNER JOIN HjaelpeTabeller.Gade			ON Efternavn.Efternavn > Gade.Gade
				INNER JOIN DataWarehouse.Postopl		ON Gade.Gade <> Postopl.Bynavn
      WHERE LEN(Fornavn) + LEN(Efternavn) < 11;

INSERT INTO DataWarehouse.Kunde (KundeBkey, Fornavn, Efternavn, Gade, Postnr, Koen, Kundetype)
   SELECT   1 AS ForeloebigKundeID, Fornavn, Efternavn, Gade, Postnr, Koen, 'A'
      FROM HjaelpeTabeller.Fornavn	
				INNER JOIN HjaelpeTabeller.Efternavn	ON Fornavn.Fornavn < Efternavn.Efternavn
				INNER JOIN HjaelpeTabeller.Gade			ON Efternavn.Efternavn < Gade.Gade
				INNER JOIN DataWarehouse.Postopl		ON Gade.Gade < Postopl.Bynavn
      WHERE LEN(Fornavn) + LEN(Efternavn) BETWEEN 11 AND 16;
      
INSERT INTO DataWarehouse.Kunde (KundeBkey, Fornavn, Efternavn, Gade, Postnr, Koen, Kundetype)
   SELECT	1 AS ForeloebigKundeID,	Fornavn, Efternavn, Gade, Postnr, Koen, 'A'
      FROM HjaelpeTabeller.Fornavn	
				INNER JOIN HjaelpeTabeller.Efternavn	ON Fornavn.Fornavn > Efternavn.Efternavn
				INNER JOIN HjaelpeTabeller.Gade			ON Efternavn.Efternavn < Gade.Gade
				INNER JOIN DataWarehouse.Postopl		ON Gade.Gade > Postopl.Bynavn
      WHERE LEN(Fornavn) + LEN(Efternavn) > 16;
  
UPDATE  DataWarehouse.Kunde
	SET KundeBkey = KundeSkey, GaeldendeFra = DATEADD(DAY, - (KundeSkey % 3287) - 12, SYSDATETIME());
GO
WITH 
KundeDubletter
AS
(
SELECT Fornavn, Efternavn, Gade, Postnr, COUNT(*) AS Antal
	FROM DataWarehouse.Kunde
	GROUP BY Fornavn, Efternavn, Gade, Postnr
	HAVING COUNT(*) > 1),

SletKundeBkey
AS
(
SELECT KundeBkey
	FROM  KundeDubletter AS KD CROSS APPLY (SELECT TOP (Antal - 1) KundeBkey 
												FROM	DataWarehouse.Kunde AS K
												WHERE	KD.Fornavn = K.Fornavn AND
														KD.Efternavn = K.Efternavn AND
														KD.Gade = K.Gade AND
														KD.Postnr = K.Postnr) AS TopKunde)
DELETE
	FROM DataWarehouse.Kunde 
	WHERE KundeBkey IN (SELECT KundeBkey 
						FROM SletKundeBkey);
GO
UPDATE DataWarehouse.Kunde
	SET Kundetype = 'B'
	WHERE KundeBkey % 95 = 1;

UPDATE DataWarehouse.Kunde
	SET Kundetype = 'C'
	WHERE KundeBkey % 997 = 2;

UPDATE DataWarehouse.Kunde
	SET Kundetype = 'D'
	WHERE KundeBkey % 9999 = 1;

UPDATE DataWarehouse.Kunde
	SET Koen = NULL
	WHERE KundeBkey % 37834 = 9;
GO
INSERT INTO DataWarehouse.Kunde (KundeBkey, Fornavn, Efternavn, Gade, Postnr, Kundetype, Koen, GaeldendeFra, GaeldendeTil)
		SELECT	KundeBkey, Fornavn, Efternavn, 
				'Parkvejen ' + CAST(KundeBkey % 45 AS VARCHAR(10)), 
				(SELECT TOP 1 Postnr
					FROM (SELECT TOP (KundeBkey % (SELECT COUNT(*) 
												FROM DataWarehouse.Postopl) + 1) Postnr
							FROM DataWarehouse.Postopl
							ORDER BY Postnr ASC) AS p
					ORDER BY Postnr DESC),
				Kundetype,
				Koen,
				SYSDATETIME(),
				NULL					
			FROM DataWarehouse.Kunde
			WHERE KundeSkey % 36912 = 682;
			
INSERT INTO DataWarehouse.Kunde (KundeBkey, Fornavn, Efternavn, Gade, Postnr, Kundetype, Koen, GaeldendeFra, GaeldendeTil)
		SELECT	KundeBkey, Fornavn, Efternavn, 
				'S�ndre Boulevard ' + CAST(KundeBkey % 23 AS VARCHAR(10)), 
				(SELECT TOP 1 Postnr
					FROM (SELECT TOP (KundeBkey % (SELECT COUNT(*) 
												FROM DataWarehouse.Postopl) + 1) Postnr
							FROM DataWarehouse.Postopl
							ORDER BY Postnr ASC) AS p
					ORDER BY Postnr DESC),
				Kundetype,
				Koen,
				SYSDATETIME(),
				NULL					
			FROM DataWarehouse.Kunde
			WHERE KundeSkey % 8999 = 7001;
			
INSERT INTO DataWarehouse.Kunde (KundeBkey, Fornavn, Efternavn, Gade, Postnr, Kundetype, Koen, GaeldendeFra, GaeldendeTil)
		SELECT	KundeBkey, Fornavn, Efternavn, 
				'Polensgade ' + CAST(KundeBkey % 59 AS VARCHAR(10)), 
				(SELECT TOP 1 Postnr
					FROM (SELECT TOP (KundeBkey % (SELECT COUNT(*) 
												FROM DataWarehouse.Postopl) + 1) Postnr
							FROM DataWarehouse.Postopl
							ORDER BY Postnr ASC) AS p
					ORDER BY Postnr DESC),
				Kundetype,
				Koen,
				SYSDATETIME(),
				NULL					
			FROM DataWarehouse.Kunde
			WHERE KundeSkey % 15243 = 1222;
GO
DROP TABLE HjaelpeTabeller.Fornavn;
DROP TABLE HjaelpeTabeller.Efternavn;
DROP TABLE HjaelpeTabeller.Gade;
GO
CREATE TABLE DataWarehouse.Medarbejder 
(
	MedarbejderID		SMALLINT NOT NULL PRIMARY KEY,
	Fornavn				VARCHAR(20) NOT NULL, 
	Efternavn			VARCHAR(20) NOT NULL, 
	Gade				VARCHAR(30) NOT NULL, 
	Postnr				SMALLINT NOT NULL REFERENCES DataWarehouse.Postopl, 
	ChefId				SMALLINT NULL,
	CONSTRAINT FK_Medarbejder_Chef FOREIGN KEY (Chefid) REFERENCES DataWarehouse.Medarbejder(MedarbejderID)
);
GO
INSERT INTO DataWarehouse.Medarbejder VALUES
	(1, 'Ida', 'Andersen', 'Vestergade 23', 2000, NULL),
	(2, 'Jens', 'Pedersen', 'Torvet 2', 1127, 1),
	(3, 'Ane', 'Larsen', '�stergade 4', 1129, 1),
	(4, 'Peter', 'Madsen', 'S�ndergade 11', 2605, 1),
	(5, 'Lone', 'Olsen', 'Sankt Peders Str�de 1', 2610, 2),
	(6, 'Tina', 'Olesen', 'Kirkevej 14', 2600, 2),
	(7, 'Carl', 'Thomsen', 'Nygade 6', 2000, 3),
	(8, 'Lars', 'Jensen', 'Vestergade 1', 1127, 3),
	(9, 'Hans', 'Hansen', '�stergade 9', 1129, 3),
	(10, 'Sofie', 'Carlsen', 'Vejlevej 4', 2000, 4),
	(11, 'Rita', 'Knudsen', 'Irlandsvej 78', 2630, 4),
	(12, '�ge', 'Rasmussen', 'Christiansgade 3', 2000, 4),
	(13, 'Per', 'Aagaard', 'S�ndergade 17', 2635, 10),
	(14, 'Dorthe', 'Ibsen', 'Lille Str�de 6', 2000, 10),
	(15, 'Vivi', 'Davidsen', '�stergade 24 23', 1127, 11),
	(16, 'Bo', 'Jensen', 'Torvet 7', 1129, 11),
	(17, 'Michael', 'Christensen', 'Bredgade 112', 2000, 11),
	(18, 'Irene', 'Eriksen', 'S�ndergade 34', 2600, 11);
GO
CREATE TABLE DataWarehouse.Kategori 
(
	KategoriSkey		SMALLINT NOT NULL IDENTITY 
						CONSTRAINT PK_Kategori PRIMARY KEY,
	KategoriID			SMALLINT NOT NULL 
						CONSTRAINT UQ_Kategori_KategoriID UNIQUE,
	Kategorinavn		VARCHAR(30) NOT NULL
);

CREATE TABLE DataWarehouse.Subkategori
(
	SubkategoriSkey		SMALLINT NOT NULL IDENTITY 
						CONSTRAINT PK_Subkategori PRIMARY KEY,
	SubkategoriID		SMALLINT NOT NULL 
						CONSTRAINT UQ_Subkategori_SubkategoriID UNIQUE,
	SubKategorinavn		VARCHAR(30) NOT NULL,
	KategoriSkey		SMALLINT NOT NULL
						CONSTRAINT FK_SubKategori_Kategori
						REFERENCES DataWarehouse.Kategori (KategoriSKey)
);

CREATE TABLE DataWarehouse.Indkoeb 
(
	IndkoebsType		CHAR(1) NOT NULL PRIMARY KEY,
	IndkoebsTypenavn	VARCHAR(20) NOT NULL
);

CREATE TABLE DataWarehouse.Vare 
(
	VareSkey			INT NOT NULL IDENTITY
						CONSTRAINT PK_Vare PRIMARY KEY NONCLUSTERED,
	VareBkey			SMALLINT NOT NULL,
	Varenavn			VARCHAR(30) NOT NULL,
	Vejledendepris		DECIMAL(9,2) NULL,
	IndkoebsType		CHAR(1) NOT NULL DEFAULT('I'),
	SubKategoriSkey		SMALLINT NOT NULL
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);

CREATE TABLE DataWarehouse.Salgskanal 
(
	SalgskanalSkey		SMALLINT NOT NULL IDENTITY (1,1)
						CONSTRAINT PK_Salgskanal PRIMARY KEY,
	SalgskanalID		SMALLINT NOT NULL 
						CONSTRAINT UQ_Salgskanal_SalgskanalID UNIQUE,
	SalgskanalNavn		VARCHAR(30) NOT NULL,
	SorteringsOrden		SMALLINT NOT NULL
);
GO
CREATE TABLE DataWarehouse.Tid 
(
	TidSkey				INT NOT NULL IDENTITY (1,1)
						CONSTRAINT PK_Time PRIMARY KEY,
	Dato				DATETIME2 NOT NULL,
	Aar					SMALLINT NOT NULL,
	KvartalsNr			SMALLINT NOT NULL,
	MaanedsNr			SMALLINT NOT NULL,
	MaanedsNavn			VARCHAR(12) NOT NULL,
	DagNrIMaaned		SMALLINT NOT NULL,
	DagnrIUge			SMALLINT NOT NULL,
	DagNavn				VARCHAR(12) NOT NULL
);
GO
CREATE TABLE DataWarehouse.Maanedsnavn 
(
	Maanedsnr			SMALLINT NOT NULL
						CONSTRAINT PK_Maanedsnavn PRIMARY KEY,
	Maanedsnavn_da		VARCHAR(12) NOT NULL
);
GO
CREATE TABLE DataWarehouse.Ugedagsnavn 
(
	Ugedagsnr			SMALLINT NOT NULL
						CONSTRAINT PK_Ugedagsnavn PRIMARY KEY,
	Ugedagsnavn_da		VARCHAR(12) NOT NULL
);
GO
SET NOCOUNT ON
INSERT INTO DataWarehouse.Indkoeb VALUES
	('A', 'Automatisk indk�b'),
	('I', 'Indk�ber');
GO
INSERT INTO DataWarehouse.Salgskanal VALUES
	(0, 'Ukendt', 4),
	(1, 'Butik', 1),
	(2, 'Internet', 3),
	(3, 'Telefon', 2);
GO
SET IDENTITY_INSERT DataWarehouse.Kategori ON;

INSERT INTO DataWarehouse.Kategori 
	(KategoriSkey, KategoriID, Kategorinavn) VALUES
	(1, 1, 'Frugt og Gr�ntsager'),
	(2, 2, 'Dagligvarer'),
	(3, 3, 'Husholdningsartikler');
	
SET IDENTITY_INSERT DataWarehouse.Kategori OFF;
GO
SET IDENTITY_INSERT DataWarehouse.Subkategori ON;

INSERT INTO DataWarehouse.Subkategori 
	(SubkategoriSkey, SubkategoriID, SubKategorinavn, KategoriSkey) VALUES
	(1, 1, 'Frugt', 1),
	(2, 2, 'Gr�ntsager', 1),
	(3, 3, 'Kaffe og Te', 2),
	(4, 4, 'Mel, Gryn, mv.', 2),
	(5, 5, 'Vand og Juice', 2),
	(6, 6, '�l og Vin', 2),
	(7, 7, 'Toiletartikler', 3),
	(8, 8, 'Reng�ringsmidler', 3),
	(9, 9, 'Plasticposer mv.', 3);
	
SET IDENTITY_INSERT DataWarehouse.Subkategori OFF;
GO
SET IDENTITY_INSERT DataWarehouse.Vare ON;

INSERT INTO DataWarehouse.Vare 
	(VareSkey, VareBkey, Varenavn, Vejledendepris, IndkoebsType, SubKategoriSkey) VALUES
	(1, 1, '�ble', 20.00, 'I', 1),
	(2, 2, 'Appelsin', 30.00, 'I', 1),
	(3, 3, 'Blomme', 15.00, 'I', 1),
	(4, 4, 'Jordb�r', 25.00, 'I', 1),
	(5, 5, 'Kiwi', 8.00, 'I', 1),
	(6, 6, 'Vandmelon', 10.00, 'I', 1),
	(7, 7, 'Fersken', 10.00, 'I', 1),
	(8, 8, 'Honningmelon', 15.00, 'I', 1),
	(9, 9, 'Netmelon', 13.00, 'I', 1),
	(10, 10, 'Vindruer - gr�nne', 17.25, 'I', 1),
	(11, 11, 'Vindruer - bl�', 18.50, 'I', 1),
	(12, 12, 'Grapefrugt', 8.00, 'I', 1),

	(13, 13, 'Guler�dder', 15.00, 'I', 2),
	(14, 14, 'Kartofler', 9.00, 'I', 2),
	(15, 15, 'L�g', 10.00, 'I', 2),
	(16, 16, 'For�rsl�g', 12.00, 'I', 2),
	(17, 17, 'Porer', 18.00, 'I', 2),
	(18, 18, 'Pastinak', 6.00, 'I', 2),
	(19, 19, 'Jordskok', 8.00, 'I', 2),
	(20, 20, 'Selleri', 13.25, 'I', 2),
	(21, 21, 'Bagekartofler', 13.00, 'I', 2),

	(22, 22, 'Kaffe', 27.00, 'I', 3),
	(23, 23, 'Te', 15.00, 'I', 3),
	(24, 24, 'Urtete', 20.00, 'I', 3),
	(25, 25, '�kologisk kaffe', 37.00, 'I', 3),

	(26, 26, 'Rugmel', 9.75, 'A', 4),
	(27, 27, 'Sukker', 8.50, 'A', 4),
	(28, 28, 'Havregryn', 19.75, 'A', 4),
	(29, 29, 'Bygmel', 14.00, 'A', 4),
	(30, 30, 'R�rsukker', 22.50, 'A', 4),
	(31, 31, 'Hvedemel', 8.75, 'A', 4),
	(32, 32, '3-korns mel', 16.25, 'A', 4),

	(33, 33, 'Sodavand - 30cl', 3.00, 'I', 5),
	(34, 34, 'Sodavand - 50cl', 5.00, 'I', 5),
	(35, 35, 'Sodavand - 1 liter', 9.00, 'I', 5),
	(36, 36, '�blejuice', 5.00, 'A', 5),
	(37, 37, 'Appelsinjuice', 4.50, 'A', 5),
	(38, 38, 'Gulerodsjuice', 7.50, 'A', 5),
	(39, 39, '�kologisk �blejuice', 7.00, 'I', 5),
	(40, 40, '�kologisk Appelsinjuice', 6.50, 'I', 5),
	(41, 41, 'Blandet juice', 7.75, 'I', 5),

	(42, 42, '�l', 4.00, 'I', 6),
	(43, 43, 'R�dvin', 65.00, 'I', 6),
	(44, 44, 'Hvidvin', 45.00, 'I', 6),
	(45, 45, 'Rose', 39.75, 'I', 6),

	(46, 46, 'Toiletpapir', 40.00, 'A', 7),
	(47, 47, 'Papirslommet�rkl�de', 2.50, 'A', 7),
	(48, 48, 'Vatpinde', 12.25, 'A', 7),
	(49, 49, 'Vat', 10.00, 'A', 7),
	(50, 50, 'S�be', 8.00, 'A', 7),
	(51, 51, 'H�rshampoo', 29.75, 'A', 7),
	(52, 52, 'Badesalt', 35.50, 'A', 7),

	(53, 53, 'Opvaskemiddel', 12.00, 'A', 8),
	(54, 54, 'WC-rens', 23.50, 'A', 8),
	(55, 55, 'Brun s�be', 6.50, 'A', 8),
	(56, 56, 'S�besp�ner', 8.75, 'A', 8),
	(57, 57, 'Reng�ringssvamp', 9.50, 'A', 8),
	(58, 58, 'Karklud - bomuld', 19.50, 'A', 8),
	(59, 59, 'Karklud - fiber', 14.50, 'A', 8),
	(60, 60, 'Gulvklud', 19.50, 'A', 8),

	(61, 61, 'Affaldsposer - alm.', 6.00, 'A', 9),
	(62, 62, 'Affaldsposer - store', 8.00, 'A', 9),
	(63, 63, 'Sorte Affaldss�kke', 13.00, 'A', 9),
	(64, 64, 'Klare Affaldss�kke', 13.00, 'A', 9),
	(65, 65, 'Frostposer 1 liter', 9.00, 'A', 9),
	(66, 66, 'Frostposer 2 liter', 14.00, 'A', 9),
	(67, 67, 'Frostposer 5 liter', 19.00, 'A', 9),
	(68, 68, 'Frostposer 8 liter', 29.00, 'A', 9);
	
SET IDENTITY_INSERT DataWarehouse.Vare OFF;
GO
INSERT INTO DataWarehouse.Maanedsnavn VALUES
	(1, 'Januar'),
	(2, 'Februar'),
	(3, 'Marts'),
	(4, 'April'),
	(5, 'Maj'),
	(6, 'Juni'),
	(7, 'Juli'),
	(8, 'August'),
	(9, 'September'),
	(10, 'Oktober'),
	(11, 'November'),
	(12, 'December');

INSERT INTO DataWarehouse.Ugedagsnavn VALUES
	(1, 'Mandag'),
	(2, 'Tirsdag'),
	(3, 'Onsdag'),
	(4, 'Torsdag'),
	(5, 'Fredag'),
	(6, 'L�rdag'),
	(7, 'S�ndag');

SET NOCOUNT OFF;
GO
CREATE TABLE DataWarehouse.KundeSalg 
(
	SalgId			INT NOT NULL IDENTITY (1,1)
					CONSTRAINT PK_KundeSalg PRIMARY KEY NONCLUSTERED,
	KundeSkey		INT NOT NULL INDEX nc_Kundesalg_KundeSKey,
	VareSkey		INT NOT NULL INDEX nc_Kundesalg_VareSKey,
	SalgskanalSkey	SMALLINT NULL,
	MedarbejderID	SMALLINT NULL,
	BestillingsDato	DATE NOT NULL DEFAULT (SYSDATETIME()),
	LeveringsDato	DATE NOT NULL DEFAULT (SYSDATETIME()),
	Antalenheder	SMALLINT NOT NULL,
	Enhedspris		DECIMAL(9,2) NOT NULL,
	INDEX nc_Kundesalg_ NONCLUSTERED (KundeSKey, VareSKey, Antalenheder) 
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
INSERT INTO DataWarehouse.KundeSalg(KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, BestillingsDato, LeveringsDato, Antalenheder, Enhedspris)
	SELECT	Kunde.KundeSkey, 
			Vare.VareSkey, 
			3 AS SalgskanalSkey, 
			Medarbejder.MedarbejderID,
			GaeldendeFra AS BestillingsDato, 
			GaeldendeFra AS LeveringsDato, 
			2 AS Antalenheder,
			VejledendePris
		FROM DataWarehouse.Kunde, DataWarehouse.Vare, DataWarehouse.Medarbejder
		WHERE	Kunde.KundeBkey % 201 = 37 AND
				Vare.VareBkey % 6 = 2 AND
				Medarbejder.MedarbejderID % 5 = 1;

INSERT INTO DataWarehouse.KundeSalg(KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, BestillingsDato, LeveringsDato, Antalenheder, Enhedspris)
	SELECT	Kunde.KundeSkey, 
			Vare.VareSkey, 
			2 AS SalgskanalSkey, 
			Medarbejder.MedarbejderID,
			DATEADD(DAY, DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) / 2, GaeldendeFra) AS BestillingsDato, 
			DATEADD(DAY, DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) / 2, GaeldendeFra) AS LeveringsDato, 
			1 AS Antalenheder,
			VejledendePris
		FROM DataWarehouse.Kunde, DataWarehouse.Vare, DataWarehouse.Medarbejder
		WHERE	Kunde.KundeSkey % 43 = 11 AND
				Vare.VareBkey % 9 = 1 AND
				Medarbejder.MedarbejderID % 7 = 1;

INSERT INTO DataWarehouse.KundeSalg(KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, BestillingsDato, LeveringsDato, Antalenheder, Enhedspris)
	SELECT	Kunde.KundeSkey, 
			Vare.VareSkey, 
			2 AS SalgskanalSkey, 
			Medarbejder.MedarbejderID,
			DATEADD(DAY, - DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % 3, ISNULL(GaeldendeTil, SYSDATETIME())) AS BestillingsDato, 
			DATEADD(DAY, - DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % 3, ISNULL(GaeldendeTil, SYSDATETIME())) AS LeveringsDato, 
			1 AS Antalenheder,
			VejledendePris
		FROM DataWarehouse.Kunde, DataWarehouse.Vare, DataWarehouse.Medarbejder
		WHERE	Kunde.KundeSkey % 765 = 123 AND
				Vare.VareBkey % 34 = 22 AND
				Medarbejder.MedarbejderID % 13 = 4;
GO
DECLARE @i	INT;

SET @i = 24;

WHILE @i < 320
BEGIN
	INSERT INTO DataWarehouse.KundeSalg(KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, BestillingsDato, LeveringsDato, Antalenheder, Enhedspris)
		SELECT	Kunde.KundeSkey, 
				Vare.VareBkey, 
				1 AS SalgskanalSkey, 
				Medarbejder.MedarbejderID,
				DATEADD(DAY, DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % @i, GaeldendeFra) AS BestillingsDato, 
				DATEADD(DAY, DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % @i, GaeldendeFra) AS LeveringsDato, 
				(@i %  4) + 1 AS AntalEnheder,
				VejledendePris
			FROM DataWarehouse.Kunde, DataWarehouse.Vare, DataWarehouse.Medarbejder
			WHERE	Kunde.KundeSkey % @i = 6 AND
					Vare.VareBkey % 33 = @i % 23  AND
					Medarbejder.MedarbejderID % 9 = @i % 5;

		SET @i = @i + 10;
END
GO
INSERT INTO DataWarehouse.KundeSalg (KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, BestillingsDato, LeveringsDato, AntalEnheder, EnhedsPris)
	SELECT	Kunde.KundeSkey, 
			Vare.VareBkey, 
			2 AS SalgskanalSkey, 
			Medarbejder.MedarbejderID,
			DATEADD(DAY, - DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % 6, ISNULL(GaeldendeTil, SYSDATETIME())) AS BestillingsDato,
			DATEADD(DAY, - DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % 6, ISNULL(GaeldendeTil, SYSDATETIME())) AS LeveringsDato,
			3 AS AntalEnheder,
			CAST(VejledendePris AS DECIMAL(7,0))
		FROM DataWarehouse.Kunde, DataWarehouse.Vare, DataWarehouse.Medarbejder
		WHERE	Kunde.KundeBkey % 43600 = 234 AND
				Vare.VareBkey % 11 = 4 AND
				Medarbejder.MedarbejderID % 9 = 5;

INSERT INTO DataWarehouse.KundeSalg (KundeSkey, VareSkey, SalgskanalSkey, MedarbejderID, BestillingsDato,LeveringsDato, AntalEnheder, EnhedsPris)
	SELECT	Kunde.KundeSkey, 
			Vare.VareBkey, 
			3 AS SalgskanalSkey, 
			Medarbejder.MedarbejderID,
			DATEADD(DAY, - DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % 4, ISNULL(GaeldendeTil, SYSDATETIME())) AS BestillingsDato,			
			DATEADD(DAY, - DATEDIFF(d, GaeldendeFra, ISNULL(GaeldendeTil, SYSDATETIME())) % 4, ISNULL(GaeldendeTil, SYSDATETIME())) AS LeveringsDato,
			5 AS AntalEnheder,
			CAST(VejledendePris AS DECIMAL(7,0)) - 0.5
		FROM DataWarehouse.Kunde, DataWarehouse.Vare, DataWarehouse.Medarbejder
		WHERE	Kunde.KundeBkey % 57500 = 6890 AND
				Vare.VareBkey % 16 = 3 AND
				Medarbejder.MedarbejderID % 8 = 2;
GO
UPDATE DataWarehouse.KundeSalg
	SET BestillingsDato = DATEADD(DAY, -3, LeveringsDato)
	WHERE SalgskanalSkey = 2;
	
UPDATE DataWarehouse.KundeSalg
	SET BestillingsDato = DATEADD(DAY, -2, LeveringsDato)
	WHERE SalgskanalSkey = 3;
GO
UPDATE DataWarehouse.KundeSalg
	SET EnhedsPris = EnhedsPris * 0.97
	WHERE AntalEnheder = 3;
GO
UPDATE DataWarehouse.KundeSalg
	SET EnhedsPris = EnhedsPris * 0.9
	WHERE AntalEnheder = 5;
GO
DELETE TOP (80) PERCENT
	FROM DataWarehouse.Kunde
	WHERE KundeBkey NOT IN (SELECT KundeBkey FROM DataWarehouse.KundeSalg);
GO
UPDATE DataWarehouse.KundeSalg
	SET SalgskanalSkey = NULL
	WHERE	SalgId % 123 = 87;
GO
SET NOCOUNT ON
DECLARE @StartDato		DATETIME2;
DECLARE @SlutDato		DATETIME2;
DECLARE @Maanedsnr		SMALLINT;
DECLARE @DagnrUge		SMALLINT;
DECLARE @Maanedsnavn	VARCHAR(12);
DECLARE @Dagnavn		VARCHAR(12);

SET DATEFIRST 1

SET @StartDato	= DATEADD(DAY, -1030, (SELECT MIN(LeveringsDato) FROM DataWarehouse.KundeSalg));
SET @SlutDato	= DATEADD(DAY, 15, (SELECT MAX(LeveringsDato) FROM DataWarehouse.KundeSalg));
SET @SlutDato	= DATEADD(YEAR, 1, @SlutDato);

WHILE @StartDato <= @SlutDato
BEGIN
	SET @Maanedsnr = MONTH(@StartDato);
	SET @Maanedsnavn = (SELECT Maanedsnavn_da 
							FROM DataWarehouse.Maanedsnavn 
							WHERE Maanedsnr = @Maanedsnr);

	SET @DagnrUge = DATEPART(WEEKDAY, @Startdato);
	SET @Dagnavn = (SELECT Ugedagsnavn_da 
						FROM DataWarehouse.Ugedagsnavn 
						WHERE Ugedagsnr = @DagnrUge);

	INSERT INTO DataWarehouse.Tid(Dato, Aar, KvartalsNr, MaanedsNr, MaanedsNavn, DagNrIMaaned, DagNrIUge, DagNavn)
		VALUES (@Startdato, 
				YEAR(@Startdato),
				DATEPART(QUARTER, @Startdato),
				@Maanedsnr, 
				@Maanedsnavn,
				DAY(@Startdato), 
				@DagnrUge, 
				@Dagnavn);

	SET @Startdato = DATEADD(DAY, 1, @Startdato);
END
SET NOCOUNT OFF
GO
SELECT *
	FROM sys.tables;
GO
SET NOCOUNT ON
DECLARE @TableName	SYSNAME;
DECLARE @SchemaName	SYSNAME;
DECLARE @Antal		INT;
DECLARE @SQLString	NVARCHAR(500);

DECLARE @t TABLE
(
	ID				INT NOT NULL IDENTITY,
	Object_id		INT NOT NULL,
	TableName		SYSNAME NOT NULL, 
	SchemaName		SYSNAME NOT NULL,
	AntalForkomster INT NULL,
	Brugt			CHAR(1) DEFAULT('N')
);

INSERT INTO @t (Object_id, TableName, SchemaName)
	SELECT t.object_id, t.name, s.name 
		FROM sys.tables as t INNER JOIN sys.schemas as s 
			ON t.schema_id = s.schema_id
		ORDER BY t.name;

WHILE EXISTS (SELECT * 
				FROM @t 
				WHERE Brugt = 'N')
BEGIN
	SELECT @TableName = TableName, 
			@SchemaName = SchemaName
		FROM @t
		WHERE ID = (SELECT MIN(ID) 
						FROM @t 
						WHERE Brugt = 'N');
		
	SET @SQLString = 'SET @Antal = (SELECT COUNT(*) FROM ' + @SchemaName + '.' + @TableName + ')';
	EXECUTE sp_executesql @SqlString, N'@Antal INT OUTPUT', @Antal OUTPUT;

	UPDATE @t
		SET AntalForkomster = @Antal, Brugt = 'Y'
		WHERE TableName = @TableName AND SchemaName = @SchemaName;
END
SELECT TableName, SchemaName, AntalForkomster 
	FROM @t
	ORDER BY TableName, SchemaName;
GO