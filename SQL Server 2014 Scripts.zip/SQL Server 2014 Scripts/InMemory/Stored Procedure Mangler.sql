USE master;
GO
DROP DATABASE InMemDB;
GO
CREATE DATABASE InMemDB
ON PRIMARY
(
	NAME = InMemDB_sys,
	FILENAME = N'C:\Databaser\InMemDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_NotInMem_filegroup  
(
	NAME = InMemDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\InMemDB_InMemDB_NotInMem_filegroup.ndf',
	SIZE = 10MB,
	MAXSIZE = 200MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = InMemDB_InMem_filegroup_1,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB'
)
LOG ON
( 
	NAME = InMemDB_log_file_1,
	FILENAME = N'C:\Databaser\InMemDB_log.ldf',
	SIZE = 10MB,
	MAXSIZE = 200MB,
	FILEGROWTH = 10%
);
GO
USE InMemDB;
GO
CREATE TABLE dbo.Medarbejder
(
	ID				INT NOT NULL
					CONSTRAINT PK_Medarbejder PRIMARY KEY NONCLUSTERED IDENTITY(1, 1),
	Navn			VARCHAR(30) COLLATE Latin1_General_BIN2 NOT NULL,
	Gade 			VARCHAR (30) NOT NULL,
	Postnr			SMALLINT NOT NULL,
	LoenKode		SMALLINT NULL,
	Loen			INT NULL
	
	INDEX hash_index_Medarbejder_Navn HASH (Navn) WITH (BUCKET_COUNT = 131072)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);

CREATE TABLE dbo.Postopl
(
	Postnr			SMALLINT NOT NULL PRIMARY KEY NONCLUSTERED,
	Bynavn			VARCHAR(20) COLLATE Latin1_General_BIN2 NOT NULL
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
INSERT INTO dbo.Postopl VALUES
	(2000, 'Frederiksberg'),
	(2300, 'K�benhavn S'),
	(4000, 'Roskilde'),
	(5000, 'Odense C'),
	(8000, 'Aarhus C'),
	(8240, 'Risskov'),
	(8270, 'H�jbjerg'),
	(9000, 'Aalborg'),
	(9990, 'Skagen');
GO
CREATE TABLE dbo.Loen
(
	LoenKode		SMALLINT NOT NULL PRIMARY KEY NONCLUSTERED,
	MinLoen			INT NOT NULL,
	MaxLoen			INT NOT NULL

) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
INSERT INTO dbo.Loen VALUES
	(27, 17000, 27000),
	(33, 20000, 40000),
	(35, 25000, 75000),
	(72, 0, 99999999); 
GO
CREATE PROCEDURE dbo.usp_Insert_Medarbejder
(
	@Navn			VARCHAR(30),
	@Gade			VARCHAR(30),
	@Postnr			SMALLINT,
	@Loenkode		SMALLINT,
	@Loen			INT
)	
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC
	WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

INSERT INTO dbo.Medarbejder(Navn, Gade, Postnr, LoenKode, Loen)
	VALUES(@Navn, @Gade, @Postnr, @Loenkode, @Loen);
END;
GO
EXEC dbo.usp_Insert_Medarbejder 'Ole Olsen', 'Nygade 7', 9000, 27, 22500;
EXEC dbo.usp_Insert_Medarbejder 'Hanne Larsen', 'Vestergade 17', 8000, 28, 20000;
EXEC dbo.usp_Insert_Medarbejder 'Lars Petersen', 'Torvet 3', 2000, 35, 23000;
EXEC dbo.usp_Insert_Medarbejder 'Pia Knudsen', 'S�ndergade 33', 5000, 33, 39000;
EXEC dbo.usp_Insert_Medarbejder '�jvind Carlsen', 'Storegade 34', 2000, 33, 40000;
GO
SELECT *
	FROM dbo.Medarbejder;
GO
-- TRUNCATE TABLE dbo.Medarbejder;		-- TRUNCATE ikke supportet

DELETE
	FROM dbo.Medarbejder;
GO
---------------------------------------------------------------------------------------------------------
-- Foreign Key og Check

DROP PROCEDURE dbo.usp_Insert_Medarbejder;
GO
CREATE PROCEDURE dbo.usp_Insert_Medarbejder
(
	@Navn			VARCHAR(30),
	@Gade			VARCHAR(30),
	@Postnr			SMALLINT,
	@Loenkode		SMALLINT,
	@Loen			INT
)	
AS
DECLARE @Fejlmeddelelse		VARCHAR(2000);

BEGIN TRY
	BEGIN TRANSACTION;

	IF NOT EXISTS (SELECT * 
						FROM dbo.Postopl  WITH (SERIALIZABLE)
						WHERE Postnr = @Postnr)
	BEGIN
		SET @Fejlmeddelelse = FORMATMESSAGE('Postnr %i eksisterer ikke', @Postnr); 
		THROW 67432, @Fejlmeddelelse, 1
	END;

	IF NOT EXISTS (SELECT * 
						FROM dbo.Loen  WITH (SERIALIZABLE)
						WHERE Loenkode = @Loenkode)
	BEGIN
		SET @Fejlmeddelelse = FORMATMESSAGE('Loenkode %i eksisterer ikke', @Loenkode); 
		THROW 67433, @Fejlmeddelelse, 1
	END;

	IF NOT EXISTS (SELECT * 
						FROM dbo.Loen  WITH (SERIALIZABLE)
						WHERE Loenkode = @Loenkode AND @Loen BETWEEN MinLoen AND MaxLoen)
	BEGIN
		SET @Fejlmeddelelse = FORMATMESSAGE('L�n %i er ikke i det tilladte interval for l�nkode %i', @Loen, @Loenkode); 
		THROW 67434, @Fejlmeddelelse, 1
	END;

	INSERT INTO dbo.Medarbejder WITH (SERIALIZABLE) (Navn, Gade, Postnr, LoenKode, Loen)
		VALUES(@Navn, @Gade, @Postnr, @Loenkode, @Loen)

	COMMIT TRANSACTION;
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	THROW;
END CATCH
GO
EXEC dbo.usp_Insert_Medarbejder 'Ole Olsen', 'Nygade 7', 900, 27, 22500;
GO
EXEC dbo.usp_Insert_Medarbejder 'Ole Olsen', 'Nygade 7', 9000, 27, 22500;
GO
EXEC dbo.usp_Insert_Medarbejder 'Hanne Larsen', 'Vestergade 17', 8000, 28, 20000;
GO
EXEC dbo.usp_Insert_Medarbejder 'Lars Petersen', 'Torvet 3', 2000, 35, 23000;
GO
EXEC dbo.usp_Insert_Medarbejder 'Pia Knudsen', 'S�ndergade 33', 5000, 33, 39000;
GO
EXEC dbo.usp_Insert_Medarbejder '�jvind Carlsen', 'Storegade 34', 2000, 33, 40000;
GO
SELECT *
	FROM dbo.Medarbejder;
GO
DELETE
	FROM dbo.Medarbejder;
GO
DROP PROCEDURE dbo.usp_Insert_Medarbejder;
GO
CREATE PROCEDURE dbo.usp_Insert_Medarbejder
(
	@Navn			VARCHAR(30),
	@Gade			VARCHAR(30),
	@Postnr			SMALLINT,
	@Loenkode		SMALLINT,
	@Loen			INT
) 
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC
	WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

DECLARE @Exists				BIT

BEGIN TRY

	SET @Exists = 0;
	SELECT	TOP 1  
			@Exists = 1
		FROM dbo.Postopl
		WHERE Postnr = @Postnr;

	IF @Exists = 0
		THROW 67432, 'Postnr eksisterer ikke', 1; 


	SET @Exists = 0;
	SELECT	TOP 1  
			@Exists = 1
		FROM dbo.Loen
		WHERE Loenkode = @Loenkode;

	IF @Exists = 0
		THROW 67433, 'Loenkode eksisterer ikke', 1; 

	
	SET @Exists = 0;
	SELECT	TOP 1  
			@Exists = 1
		FROM dbo.Loen
		WHERE Loenkode = @Loenkode AND @Loen BETWEEN MinLoen AND MaxLoen;

	IF @Exists = 0
		THROW 67434, 'L�n er ikke i det tilladte interval for l�nkode', 1;


	INSERT INTO dbo.Medarbejder (Navn, Gade, Postnr, LoenKode, Loen)
		VALUES(@Navn, @Gade, @Postnr, @Loenkode, @Loen)

END TRY
BEGIN CATCH
	THROW;
END CATCH
END;
GO
EXEC dbo.usp_Insert_Medarbejder 'Ole Olsen', 'Nygade 7', 900, 27, 22500;
GO
EXEC dbo.usp_Insert_Medarbejder 'Ole Olsen', 'Nygade 7', 9000, 27, 22500;
GO
EXEC dbo.usp_Insert_Medarbejder 'Hanne Larsen', 'Vestergade 17', 8000, 28, 20000;
GO
EXEC dbo.usp_Insert_Medarbejder 'Lars Petersen', 'Torvet 3', 2000, 35, 23000;
GO
EXEC dbo.usp_Insert_Medarbejder 'Pia Knudsen', 'S�ndergade 33', 5000, 33, 39000;
GO
EXEC dbo.usp_Insert_Medarbejder '�jvind Carlsen', 'Storegade 34', 2000, 33, 40000;
GO
SELECT *
	FROM dbo.Medarbejder;
GO
--------------------------------------------------------------------------------------
-- outer join
CREATE TYPE dbo.MedarbejderPostoplType
AS TABLE
(	
	SID			INT NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY,
	ID			INT NULL,
	Navn		VARCHAR(30) NULL,
	Gade		VARCHAR(30) NULL,
	Postnr		SMALLINT NOT NULL,
	Bynavn		VARCHAR(30) NOT NULL,
	Loenkode	SMALLINT NULL,
	Loen		INT NULL
) WITH (MEMORY_OPTIMIZED = ON);

CREATE TYPE dbo.PostoplType
AS TABLE
(
	SID			INT NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY,
	Postnr		SMALLINT NOT NULL,
	Bynavn		VARCHAR(30) NOT NULL
) WITH (MEMORY_OPTIMIZED = ON);

GO
CREATE PROCEDURE dbo.usp_RightJOIN_Medarbejder_Postopl
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC
	WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

DECLARE @Resultat	dbo.MedarbejderPostoplType;
DECLARE @Postopl	dbo.PostoplType;		

DECLARE @PostnrSID		SMALLINT = 1;
DECLARE @Postnr			SMALLINT;
DECLARE @MaxPostnrSID	SMALLINT = 0;
DECLARE @Bynavn			VARCHAR(20);

DECLARE @Exists			bit;

--INNER JOIN resultat
INSERT INTO @Resultat (ID, Navn, Gade, Postnr, Bynavn, Loenkode, Loen)
	SELECT	Medarbejder.ID,
			Medarbejder.Navn,
			Medarbejder.Gade,
			Medarbejder.Postnr,
			Postopl.Bynavn,
			Medarbejder.Loenkode,
			Medarbejder.Loen
		FROM dbo.Medarbejder INNER JOIN dbo.Postopl ON Medarbejder.Postnr = Postopl.Postnr;

-- resultat af 'Right outer join' 
INSERT INTO @Postopl (Postnr, Bynavn)
	SELECT	Postnr,
			Bynavn
		FROM dbo.Postopl;

SET @MaxPostnrSID = SCOPE_IDENTITY();

WHILE @PostnrSID <= @MaxPostnrSID
BEGIN
	SET @Exists = 0;

	SELECT	@Postnr = Postnr,
			@Bynavn	= Bynavn
		FROM @Postopl
		WHERE SID = @PostnrSID;

	SELECT	TOP 1
			@Exists = 1
		FROM @Resultat
		WHERE Postnr = @Postnr;

	IF @Exists = 0
		INSERT INTO @Resultat (Postnr, Bynavn)
			VALUES(@Postnr, @Bynavn);

	SET @PostnrSID += 1;
END;

--resultat returneres

SELECT	ID,
		Navn,
		Gade,
		Postnr,
		Bynavn,
		Loenkode,
		Loen
	FROM @Resultat;
END;
GO
EXEC dbo.usp_RightJOIN_Medarbejder_Postopl;
GO
SELECT	Medarbejder.ID,
		Medarbejder.Navn,
		Medarbejder.Gade,
		Postopl.Postnr,
		Postopl.Bynavn,
		Medarbejder.Loenkode,
		Medarbejder.Loen
	FROM dbo.Medarbejder RIGHT JOIN dbo.Postopl ON Medarbejder.Postnr = Postopl.Postnr;
GO
INSERT INTO Medarbejder (Navn, Gade, Postnr, Loenkode, Loen)
	SELECT	Navn,
			Gade,
			Postnr,
			Loenkode,
			Loen
		FROM dbo.Medarbejder;
GO 19
SELECT COUNT(*)
	FROM dbo.Medarbejder;
GO
SET STATISTICS TIME ON;
GO
EXEC dbo.usp_RightJOIN_Medarbejder_Postopl;
GO
SELECT	Medarbejder.ID,
		Medarbejder.Navn,
		Medarbejder.Gade,
		Postopl.Postnr,
		Postopl.Bynavn,
		Medarbejder.Loenkode,
		Medarbejder.Loen
	FROM dbo.Medarbejder RIGHT JOIN dbo.Postopl ON Medarbejder.Postnr = Postopl.Postnr;
GO
SET STATISTICS TIME OFF;
