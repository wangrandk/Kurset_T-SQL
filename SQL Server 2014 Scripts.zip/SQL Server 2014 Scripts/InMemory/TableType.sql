USE master;
GO
DROP DATABASE IF EXISTS TableTypeDB;
GO
CREATE DATABASE TableTypeDB
ON PRIMARY
(
	NAME = TableTypeDB_sys,
	FILENAME = N'C:\Databaser\TableTypeDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP TableTypeDB_NotInMem_filegroup DEFAULT
(
	NAME = TableTypeDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\TableTypeDB_TableTypeDB_NotInMem_filegroup.ndf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
),
FILEGROUP TableTypeDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = TableTypeDB_InMem_filegroup_1,
    FILENAME = N'C:\Databaser\InMem_Data_TableTypeDB'
)
LOG ON
( 
	NAME = TableTypeDB_log_file_1,
	FILENAME = N'C:\Databaser\TableTypeDB_log.ldf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
);
GO
ALTER DATABASE TableTypeDB SET RECOVERY SIMPLE;
GO
USE TableTypeDB
SET NOCOUNT ON
GO
CREATE TYPE dbo.KundeInMem_Type_NC
AS TABLE
(
	KundeID			INT NOT NULL PRIMARY KEY NONCLUSTERED,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL
)
WITH (MEMORY_OPTIMIZED = ON);

CREATE TYPE dbo.KundeInMem_Type_Hash
AS TABLE
(
	KundeID			INT NOT NULL PRIMARY KEY NONCLUSTERED  
								HASH WITH (BUCKET_COUNT = 100000),
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL
)
WITH (MEMORY_OPTIMIZED = ON);

CREATE TYPE dbo.KundeNotInMem_Type
AS TABLE
(
	KundeID			INT NOT NULL PRIMARY KEY NONCLUSTERED,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Tider
(
	ID			INT NOT NULL PRIMARY KEY IDENTITY,
	Type		VARCHAR(50) NOT NULL,
	Tid			BIGINT NOT NULL
);
GO
DECLARE @Kunde		dbo.KundeInMem_Type_NC;
DECLARE @i			INT = 1;
DECLARE @Starttid	DATETIME2 = SYSDATETIME();

WHILE @i <= 10000
BEGIN
	INSERT INTO @Kunde VALUES 
		(@i, 'Ole', 'Hansen')
	SET @i += 1;
END;
--SELECT * 
--	FROM @Kunde;
INSERT INTO dbo.Tider(Type, Tid) VALUES
	('InMem NC', DATEDIFF(MICROSECOND, @Starttid, SYSDATETIME()));
PRINT 'InMem NC';
GO 10
-------------------------------------------------------------------------------------------
DECLARE @Kunde		dbo.KundeInMem_Type_Hash;
DECLARE @i			INT = 1;
DECLARE @Starttid	DATETIME2 = SYSDATETIME();

WHILE @i <= 10000
BEGIN
	INSERT INTO @Kunde VALUES 
		(@i, 'Ole', 'Hansen')
	SET @i += 1;
END;
--SELECT * 
--	FROM @Kunde;
INSERT INTO dbo.Tider(Type, Tid) VALUES
	('InMem Hash', DATEDIFF(MICROSECOND, @Starttid, SYSDATETIME()));
PRINT 'InMem Hash';
GO 10
-------------------------------------------------------------------------------------------
DECLARE @Kunde		dbo.KundeNotInMem_Type;
DECLARE @i			INT = 1;
DECLARE @Starttid	DATETIME2 = SYSDATETIME();

WHILE @i <= 10000
BEGIN
	INSERT INTO @Kunde VALUES 
		(@i, 'Ida', 'Larsen')
	SET @i += 1;
END;
--SELECT * 
--	FROM @Kunde;

INSERT INTO dbo.Tider(Type, Tid) VALUES
	('NotInMem', DATEDIFF(MICROSECOND, @Starttid, SYSDATETIME()));
PRINT 'NotInMem';
GO 10
-------------------------------------------------------------------------------------------
CREATE Table #Kunde_Type
(
	KundeID			INT NOT NULL PRIMARY KEY NONCLUSTERED,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL
)

DECLARE @i			INT = 1;
DECLARE @Starttid	DATETIME2 = SYSDATETIME();

WHILE @i <= 10000
BEGIN
	INSERT INTO #Kunde_Type VALUES 
		(@i, 'Ida', 'Larsen')
	SET @i += 1;
END;
--SELECT * 
--	FROM #Kunde_Type;

INSERT INTO dbo.Tider(Type, Tid) VALUES
	('TempTable', DATEDIFF(MICROSECOND, @Starttid, SYSDATETIME()));

PRINT 'TempTable';

DROP TABLE #Kunde_Type;
GO 10
-------------------------------------------------------------------------------------------
CREATE Table Kunde_Type
(
	KundeID			INT NOT NULL PRIMARY KEY NONCLUSTERED,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL
)

DECLARE @i			INT = 1;
DECLARE @Starttid	DATETIME2 = SYSDATETIME();

WHILE @i <= 10000
BEGIN
	INSERT INTO Kunde_Type VALUES 
		(@i, 'Ida', 'Larsen')
	SET @i += 1;
END;
--SELECT * 
--	FROM Kunde_Type;

INSERT INTO dbo.Tider(Type, Tid) VALUES
	('DiskTabel Delayed Durability OFF', DATEDIFF(MICROSECOND, @Starttid, SYSDATETIME()));

PRINT 'DiskTabel Delayed Durability OFF';

DROP TABLE Kunde_Type;
GO 10
ALTER DATABASE TableTypeDB SET DELAYED_DURABILITY = FORCED;
GO
-------------------------------------------------------------------------------------------
CREATE Table Kunde_Type
(
	KundeID			INT NOT NULL PRIMARY KEY NONCLUSTERED,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL
)

DECLARE @i			INT = 1;
DECLARE @Starttid	DATETIME2 = SYSDATETIME();

WHILE @i <= 10000
BEGIN
	INSERT INTO Kunde_Type VALUES 
		(@i, 'Ida', 'Larsen')
	SET @i += 1;
END;
--SELECT * 
--	FROM Kunde_Type;

INSERT INTO dbo.Tider(Type, Tid) VALUES
	('DiskTabel Delayed Durability ON', DATEDIFF(MICROSECOND, @Starttid, SYSDATETIME()));

PRINT 'DiskTabel Delayed Durability ON';

DROP TABLE Kunde_Type;
GO 10
SELECT	Type, 
		AVG(Tid) AS Gennemsnitstid,
		COUNT(*) AS AntalForsoeg,
		MIN(Tid) AS MindsteTid,
		MAX(Tid) AS StoersteTid
	FROM dbo.Tider
	GROUP BY Type;
