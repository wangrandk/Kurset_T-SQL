USE master;
GO
DROP DATABASE HashDB;
GO
CREATE DATABASE HashDB
ON PRIMARY
(
	NAME = HashDB_sys,
	FILENAME = N'C:\Databaser\HashDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP HashDB_filegroup  
(
	NAME = HashDB_filegroup_1,
	FILENAME = N'C:\Databaser\HashDB_filegroup.ndf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
)
LOG ON
( 
	NAME = HashDB_log_file_1,
	FILENAME = N'C:\Databaser\HashDB_log.ldf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
);
GO
USE HashDB;
CREATE TABLE dbo.HashTableNavn
(
	HashValue			SMALLINT NOT NULL PRIMARY KEY,
	FirstID				INT NULL
) ON HashDB_filegroup;

CREATE TABLE dbo.HashTableGade
(
	HashValue			SMALLINT NOT NULL PRIMARY KEY,
	FirstID				INT NULL
) ON HashDB_filegroup;

CREATE TABLE dbo.Data
(
	DataID					INT NOT NULL PRIMARY KEY IDENTITY,
	StartTrannsactionID		INT NOT NULL,
	EndTransactionID		INT NULL,
	Indexcount				SMALLINT NOT NULL DEFAULT(2),
	NextIDNavn				INT NULL,
	NextIDGade				INT NULL,
	ID						INT NOT NULL,
	Navn					VARCHAR(20) NOT NULL,
	Gade					VARCHAR(30) NOT NULL,
) ON HashDB_filegroup;
GO
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'BucketSizeTable')
BEGIN
	DROP TABLE BucketSizeTable;
	TRUNCATE TABLE dbo.HashTableNavn;
	TRUNCATE TABLE dbo.Data;
END;
SELECT BucketCountNavn, BucketCountGade
	INTO dbo.BucketSizeTable
	FROM (VALUES (20, 30)) AS bz(BucketCountNavn, BucketCountGade);
GO
DECLARE @BucketCount	SMALLINT = (SELECT BucketCountNavn FROM dbo.BucketSizeTable);
 
WITH BucketCount
AS
(
SELECT	0 AS HashValue,
		NULL AS ID
UNION ALL
SELECT	HashValue + 1,
		ID
	FROM BucketCount
	WHERE HashValue < @BucketCount - 1
)
INSERT INTO dbo.HashTableNavn
	SELECT *
		FROM BucketCount
		OPTION (MAXRECURSION 0);
GO
DECLARE @BucketCount	SMALLINT = (SELECT BucketCountGade FROM dbo.BucketSizeTable);
 
WITH BucketCount
AS
(
SELECT	0 AS HashValue,
		NULL AS ID
UNION ALL
SELECT	HashValue + 1,
		ID
	FROM BucketCount
	WHERE HashValue < @BucketCount - 1
)
INSERT INTO dbo.HashTableGade
	SELECT *
		FROM BucketCount
		OPTION (MAXRECURSION 0);
GO
SELECT *
	FROM dbo.HashTableNavn;

SELECT *
	FROM dbo.HashTableGade;
GO
CREATE SEQUENCE TransactionsID
    AS INT
    START WITH 1
    INCREMENT BY 1;
GO
CREATE PROCEDURE dbo.usp_Insert
(
	@ID								INT,
	@Navn							VARCHAR(20),
	@Gade							VARCHAR(30),
	@TrannsactionsID				INT	
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @BucketCountNavn		SMALLINT = ABS(CAST(HASHBYTES('SHA', @Navn) AS SMALLINT) % (SELECT BucketCountNavn FROM dbo.BucketSizeTable));
	DECLARE @BucketCountGade		SMALLINT = ABS(CAST(HASHBYTES('SHA', @Gade) AS SMALLINT) % (SELECT BucketCountGade FROM dbo.BucketSizeTable));
	
	DECLARE @DataIDNavn				INT;
	
	DECLARE @DataIDGade				INT;

	DECLARE @ScopeID				INT;

	IF EXISTS(SELECT *							-- F�rste forekomst for BucketCountNavn
				FROM dbo.HashTableNavn
				WHERE	HashValue = @BucketCountNavn AND
						FirstID IS NULL)
	BEGIN
		SET @DataIDNavn = NULL;
	END
	ELSE
	BEGIN
		SELECT @DataIDNavn = FirstID
			FROM dbo.HashTableNavn
			WHERE HashValue = @BucketCountNavn;

		WHILE EXISTS (SELECT *
						FROM dbo.Data
						WHERE	DataID = @DataIDNavn AND
								NextIDNavn IS NOT NULL)
		BEGIN
			SELECT	@DataIDNavn = NextIDNavn
				FROM dbo.Data
				WHERE DataId = @DataIDNavn;
		END;
	END;

	IF EXISTS(SELECT *							-- F�rste forekomst for BucketCountGade
				FROM dbo.HashTableGade
				WHERE	HashValue = @BucketCountGade AND
						FirstID IS NULL)
	BEGIN
		SET @DataIDGade = NULL;
	END
	ELSE
	BEGIN
		SELECT @DataIDGade = FirstID
			FROM dbo.HashTableGade
			WHERE HashValue = @BucketCountGade;

		WHILE EXISTS (SELECT *
						FROM dbo.Data
						WHERE	DataID = @DataIDGade AND
								NextIDGade IS NOT NULL)
		BEGIN
			SELECT	@DataIDGade = NextIDGade
				FROM dbo.Data
				WHERE DataId = @DataIDGade;
		END;
	END;
	
	INSERT
		INTO dbo.Data (StartTrannsactionID, EndTransactionID, NextIDNavn, NextIDGade,Id, Navn, Gade) VALUES
			(@TrannsactionsID, NULL, NULL, NULL, @ID, @Navn, @Gade);

	SET @ScopeID = SCOPE_IDENTITY();

	IF @DataIDNavn IS NULL
		UPDATE dbo.HashTableNavn
			SET FirstID = @ScopeID
			WHERE HashValue = @BucketCountNavn
	ELSE
		UPDATE dbo.Data
			SET NextIDNavn = @ScopeID
			WHERE Dataid = @DataIDNavn;		

	IF @DataIDGade IS NULL
		UPDATE dbo.HashTableGade
			SET FirstID = @ScopeID
			WHERE HashValue = @BucketCountGade;
	ELSE
		UPDATE dbo.Data
			SET NextIDGade = @ScopeID
			WHERE Dataid = @DataIDGade;		
END;
GO
CREATE PROCEDURE dbo.usp_Delete
(
	@ID						INT,
	@TrannsactionsID		INT	
)
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE dbo.Data
		SET EndTransactionID = @TrannsactionsID
		WHERE	ID = @ID AND
				EndTransactionID IS NULL;

	RETURN @@ROWCOUNT;
END;
GO
CREATE PROCEDURE dbo.usp_Update_Navn
(
	@ID						INT,
	@Navn					VARCHAR(20),
	@Gade					VARCHAR(30),		
	@TrannsactionsID		INT	
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @AntalSlettet		INT;

	EXEC @AntalSlettet = dbo.usp_Delete @ID, @TrannsactionsID;

	IF @AntalSlettet > 0
		EXEC dbo.usp_Insert @ID, @Navn, @Gade, @TrannsactionsID;
END;
GO
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Insert 7, 'Ole', 'Vestergade 22', @TransactionID;

SELECT *
	FROM dbo.Data;

SELECT *
	FROM dbo.HashTableNavn
	WHERE FirstID IS NOT NULL;

SELECT *
	FROM dbo.HashTableGade
	WHERE FirstID IS NOT NULL;
GO
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Insert 10, 'Ole', 'Nygade 3', @TransactionID;

SELECT *
	FROM dbo.Data;

SELECT *
	FROM dbo.HashTableNavn
	WHERE FirstID IS NOT NULL;

SELECT *
	FROM dbo.HashTableGade
	WHERE FirstID IS NOT NULL;
GO
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Insert 12, 'Per', 'Nygade 3', @TransactionID;

SELECT *
	FROM dbo.Data;

SELECT *
	FROM dbo.HashTableNavn
	WHERE FirstID IS NOT NULL;

SELECT *
	FROM dbo.HashTableGade
	WHERE FirstID IS NOT NULL;
GO
SET NOCOUNT ON;
-- BEGIN TRANSACTION 
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Insert 33, 'Ole', 'Torvet 23', @TransactionID;
EXEC dbo.usp_Insert 37, 'Ole', 'Torvet 24', @TransactionID;
EXEC dbo.usp_Insert 39, 'Ole', 'Bredgade 14', @TransactionID;
-- END TRANSACTION 

SELECT *
	FROM dbo.Data;

SELECT *
	FROM dbo.HashTableNavn
	WHERE FirstID IS NOT NULL;

SELECT *
	FROM dbo.HashTableGade
	WHERE FirstID IS NOT NULL;
GO
-- BEGIN TRANSACTION
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Insert 13, 'Ane', 'S�gade 112', @TransactionID;
-- END TRANSACTION

SELECT *
	FROM dbo.Data;

SELECT *
	FROM dbo.HashTableNavn
	WHERE FirstID IS NOT NULL;

SELECT *
	FROM dbo.HashTableGade
	WHERE FirstID IS NOT NULL;
GO
-- BEGIN TRANSACTION
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Insert 11, 'Per', 'S�ndergade 44 2. tv.', @TransactionID;
EXEC dbo.usp_Insert 14, 'Lars', 'Aarhusgade 25',  @TransactionID;
EXEC dbo.usp_Insert 15, 'Hanne', 'Torvet 56',  @TransactionID;
EXEC dbo.usp_Insert 21, 'Knud', 'Poulsgade 1',  @TransactionID;
EXEC dbo.usp_Insert 22, 'Hanne', 'S�nder Boulevard 77',  @TransactionID;
EXEC dbo.usp_Insert 32, 'Hanne', 'N�rregade 2 4 mf',  @TransactionID;
-- END TRANSACTION

SELECT *
	FROM dbo.Data
	ORDER BY Navn, ISNULL(NextIDNavn, 9999);

SELECT *
	FROM dbo.HashTableNavn
	WHERE FirstID IS NOT NULL;

SELECT *
	FROM dbo.HashTableGade
	WHERE FirstID IS NOT NULL;
GO
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Delete 33, @TransactionID;

SELECT *
	FROM dbo.Data
	ORDER BY Navn, ISNULL(NextIDNavn, 9999);

SELECT *
	FROM dbo.HashTableNavn
	WHERE FirstID IS NOT NULL;

SELECT *
	FROM dbo.HashTableGade
	WHERE FirstID IS NOT NULL;
GO
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Update_Navn 37, 'Ole Erik', 'Torvet 44', @TransactionID;
EXEC dbo.usp_Update_Navn 14, 'Lars Emil', 'Vestergade 26', @TransactionID;

EXEC dbo.usp_Update_Navn 33, 'Ole Viggo', 'Randersvej 324', @TransactionID;

SELECT *
	FROM dbo.Data
	ORDER BY Navn, ISNULL(NextIDNavn, 9999);

SELECT *
	FROM dbo.HashTableNavn
	WHERE FirstID IS NOT NULL;

SELECT *
	FROM dbo.HashTableGade
	WHERE FirstID IS NOT NULL;
GO
CREATE PROCEDURE dbo.usp_Select_Alle
(
	@TransactionID			INT,
	@Index					SYSNAME = NULL
)
AS
DECLARE @Person TABLE
(
	PK						INT NOT NULL IDENTITY,
	ID						INT NOT NULL PRIMARY KEY,
	Navn					VARCHAR(20) NOT NULL,
	Gade					VARCHAR(30) NOT NULL
);
 
BEGIN
	DECLARE @HashValue		INT = -1;
	DECLARE @DataID			INT;

	IF @Index = 'HashNavn'
	BEGIN
		WHILE EXISTS (SELECT *
						FROM dbo.HashTableNavn
						WHERE	HashValue > @HashValue AND
								FirstID IS NOT NULL)
		BEGIN
			SELECT	@DataId = FirstID,
					@HashValue = HashValue
				FROM dbo.HashTableNavn
				WHERE	HashValue = (SELECT MIN(HashValue) 
										FROM dbo.HashTableNavn
										WHERE	HashValue > @HashValue AND
												FirstID IS NOT NULL);

			WHILE @DataID IS NOT NULL
			BEGIN
				IF EXISTS (SELECT * 
							FROM dbo.Data
							WHERE	DataID = @DataID AND
									(@TransactionID BETWEEN StartTrannsactionID AND EndTransactionID OR
									(@TransactionID >= StartTrannsactionID AND
									 EndTransactionID IS NULL)))
					INSERT INTO @Person (ID, Navn, Gade)
						SELECT	ID,
								Navn,
								Gade
							FROM dbo.Data
							WHERE DataID = @DataID;

				SET @DataID = (SELECT NextIDNavn
									FROM dbo.Data
									WHERE DataID = @DataID)
			END;
		END;
	END
	ELSE
		IF @Index = 'HashGade'
		BEGIN
			WHILE EXISTS (SELECT *
						FROM dbo.HashTableGade
						WHERE	HashValue > @HashValue AND
								FirstID IS NOT NULL)
			BEGIN
				SELECT	@DataId = FirstID,
						@HashValue = HashValue
					FROM dbo.HashTableGade
					WHERE	HashValue = (SELECT MIN(HashValue) 
											FROM dbo.HashTableGade
											WHERE	HashValue > @HashValue AND
													FirstID IS NOT NULL);

				WHILE @DataID IS NOT NULL
				BEGIN
					IF EXISTS (SELECT * 
								FROM dbo.Data
								WHERE	DataID = @DataID AND
										(@TransactionID BETWEEN StartTrannsactionID AND EndTransactionID OR
										(@TransactionID >= StartTrannsactionID AND
										 EndTransactionID IS NULL)))
						INSERT INTO @Person (ID, Navn, Gade)
							SELECT	ID,
									Navn,
									Gade
								FROM dbo.Data
								WHERE DataID = @DataID;

					SET @DataID = (SELECT NextIDGade
										FROM dbo.Data
										WHERE DataID = @DataID)
				END;
			END;
		END
		ELSE
		BEGIN
			INSERT INTO @Person (ID, Navn, Gade)
				SELECT	ID,
						Navn,
						Gade
					FROM dbo.Data
					WHERE EndTransactionID IS NULL AND
						  StartTrannsactionID <= @TransactionID
				UNION ALL
				SELECT	ID,
						Navn,
						Gade
					FROM dbo.Data
					WHERE @TransactionID BETWEEN StartTrannsactionID AND EndTransactionID;
		END;
	SELECT *
		FROM @Person
		ORDER BY PK;
END;
GO
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Select_Alle @TransactionID;

--SELECT *, @TransactionID AS AktuelTransactionID
--	FROM dbo.Data;
GO
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Select_Alle @TransactionID, 'HashNavn';
GO
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Select_Alle @TransactionID, 'HashGade';
GO
DECLARE @TransactionID		INT = 4;

EXEC dbo.usp_Select_Alle @TransactionID;

SELECT *
	FROM dbo.Data
	WHERE StartTrannsactionID >= @TransactionID
	ORDER BY ID;

SELECT *
	FROM dbo.Data
	WHERE @TransactionID BETWEEN StartTrannsactionID AND EndTransactionID
	ORDER BY ID;

SELECT *
	FROM dbo.Data
	WHERE ID IN (SELECT ID
					FROM dbo.Data
					WHERE StartTrannsactionID > @TransactionID)
	ORDER BY ID;

SELECT *
	FROM dbo.Data
	WHERE ID IN (SELECT ID
					FROM dbo.Data
					WHERE @TransactionID BETWEEN StartTrannsactionID AND EndTransactionID)
	ORDER BY ID;
