USE master;
GO
DROP DATABASE HashbyteDB;
GO
CREATE DATABASE HashbyteDB;
GO
USE HashbyteDB;
SELECT	*,
		HASHBYTES('SHA', Value) AS Hash
	FROM (VALUES ('A'), ('B'), ('C'), ('D'), ('E'), ('F')) AS t(Value)
	ORDER BY Hash;
