USE master;
GO
DROP DATABASE InMemDB;
GO
CREATE DATABASE InMemDB
ON PRIMARY
(
	NAME = InMemDB_sys,
	FILENAME = N'C:\Databaser\InMemDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_NotInMem_filegroup  
(
	NAME = InMemDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\InMemDB_InMemDB_NotInMem_filegroup.ndf',
	SIZE = 10MB,
	MAXSIZE = 30MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = InMemDB_InMem_filegroup_1,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB'
)
LOG ON
( 
	NAME = InMemDB_log_file_1,
	FILENAME = N'C:\Databaser\InMemDB_log.ldf',
	SIZE = 10MB,
	MAXSIZE = 20MB,
	FILEGROWTH = 10%
);
GO
USE InMemDB;
GO
CREATE TABLE dbo.Vare1
(
	ID				INT NOT NULL
					CONSTRAINT PK_Vare PRIMARY KEY NONCLUSTERED IDENTITY,
	Varenavn		VARCHAR(100)	COLLATE Danish_Norwegian_BIN2 NOT NULL,
	Varebeskriv		VARCHAR(5000)	COLLATE Danish_Norwegian_BIN2 NOT NULL,
	VedligeholdBesk	VARCHAR(5000)	COLLATE Danish_Norwegian_BIN2 NOT NULL,
	
	INDEX hash_index_Vare_Navn HASH (Navn) WITH (BUCKET_COUNT = 131072)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_AND_DATA);
GO
CREATE TABLE dbo.Vare2 
(
	ID				INT NOT NULL
					CONSTRAINT PK_Vare PRIMARY KEY NONCLUSTERED IDENTITY,
	Varenavn		VARCHAR(100) NOT NULL,
	Varebeskriv		VARCHAR(5000) NOT NULL,
	VedligeholdBesk	VARCHAR(5000) NOT NULL,
) ON InMemDB_NotInMem_filegroup;
GO