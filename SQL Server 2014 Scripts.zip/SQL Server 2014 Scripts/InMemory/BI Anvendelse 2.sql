USE BiDbInMem;
GO
SET STATISTICS TIME ON;
GO
WITH 
StatGrundData
AS
(
SELECT	YEAR(DataWarehouse.KundeSalg.LeveringsDato) AS Aar,
		MONTH(DataWarehouse.KundeSalg.LeveringsDato) AS Maaned,
		DataWarehouse.Maanedsnavn.Maanedsnavn_da AS Maanedsnavn,
		DataWarehouse.KundeSalg.Antalenheder * DataWarehouse.KundeSalg.Enhedspris AS PrisIalt
	FROM DataWarehouse.KundeSalg INNER JOIN DataWarehouse.Maanedsnavn
						ON MONTH(DataWarehouse.KundeSalg.LeveringsDato)  = DataWarehouse.Maanedsnavn.Maanedsnr
),
StatAggData
AS
(
SELECT	Aar,
		Maaned,
		Maanedsnavn,
		SUM(PrisIalt) AS PrisIalt
	FROM StatGrundData
	GROUP BY Aar, Maaned, Maanedsnavn
)
SELECT	*,
		AVG(PrisIalt) OVER (PARTITION BY Aar ORDER BY Maaned ROWS BETWEEN 3 PRECEDING AND 1 PRECEDING)  AS Gennemsnit3Mdr,
		AVG(PrisIalt) OVER (ORDER BY Aar, Maaned ROWS BETWEEN 12 PRECEDING AND 12 PRECEDING)  AS SammeMdSidsteAar,
		SUM(PrisIalt) OVER (PARTITION BY Aar ORDER BY Maaned ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS LoebendeSum
	FROM StatAggData;
GO
USE BiDb;
GO
WITH 
StatGrundData
AS
(
SELECT	YEAR(DataWarehouse.KundeSalg.LeveringsDato) AS Aar,
		MONTH(DataWarehouse.KundeSalg.LeveringsDato) AS Maaned,
		DataWarehouse.Maanedsnavn.Maanedsnavn_da AS Maanedsnavn,
		DataWarehouse.KundeSalg.Antalenheder * DataWarehouse.KundeSalg.Enhedspris AS PrisIalt
	FROM DataWarehouse.KundeSalg INNER JOIN DataWarehouse.Maanedsnavn
						ON MONTH(DataWarehouse.KundeSalg.LeveringsDato)  = DataWarehouse.Maanedsnavn.Maanedsnr
),
StatAggData
AS
(
SELECT	Aar,
		Maaned,
		Maanedsnavn,
		SUM(PrisIalt) AS PrisIalt
	FROM StatGrundData
	GROUP BY Aar, Maaned, Maanedsnavn
)
SELECT	*,
		AVG(PrisIalt) OVER (PARTITION BY Aar ORDER BY Maaned ROWS BETWEEN 3 PRECEDING AND 1 PRECEDING)  AS Gennemsnit3Mdr,
		AVG(PrisIalt) OVER (ORDER BY Aar, Maaned ROWS BETWEEN 12 PRECEDING AND 12 PRECEDING)  AS SammeMdSidsteAar,
		SUM(PrisIalt) OVER (PARTITION BY Aar ORDER BY Maaned ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS LoebendeSum
	FROM StatAggData;
GO
USE BIDbInMem;
-- Agg i InMemory Tabel
CREATE TABLE DataWarehouse.StatAggData 
(
	ID			INT NOT NULL IDENTITY PRIMARY KEY NONCLUSTERED,
	Aar			SMALLINT NOT NULL INDEX nc_StatAggData_Aar,
	Maaned		SMALLINT NOT NULL,
	Maanedsnavn	VARCHAR(20) NOT NULL,
	PrisIalt	DECIMAL(13,2) NOT NULL
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
GO
WITH 
StatGrundData
AS
(
SELECT	YEAR(DataWarehouse.KundeSalg.LeveringsDato) AS Aar,
		MONTH(DataWarehouse.KundeSalg.LeveringsDato) AS Maaned,
		DataWarehouse.Maanedsnavn.Maanedsnavn_da AS Maanedsnavn,
		DataWarehouse.KundeSalg.Antalenheder * DataWarehouse.KundeSalg.Enhedspris AS PrisIalt
	FROM DataWarehouse.KundeSalg INNER JOIN DataWarehouse.Maanedsnavn
						ON MONTH(DataWarehouse.KundeSalg.LeveringsDato)  = DataWarehouse.Maanedsnavn.Maanedsnr
),
StatAggData
AS
(
SELECT	Aar,
		Maaned,
		Maanedsnavn,
		SUM(PrisIalt) AS PrisIalt
	FROM StatGrundData
	GROUP BY Aar, Maaned, Maanedsnavn
)
INSERT INTO DataWarehouse.StatAggData (Aar, Maaned, Maanedsnavn, PrisIalt)
	SELECT	Aar, 
			Maaned, 
			Maanedsnavn, 
			PrisIalt
		FROM StatAggData;
GO
SET STATISTICS TIME ON;

SELECT	*,
		AVG(PrisIalt) OVER (PARTITION BY Aar ORDER BY Maaned ROWS BETWEEN 3 PRECEDING AND 1 PRECEDING)  AS Gennemsnit3Mdr,
		AVG(PrisIalt) OVER (ORDER BY Aar, Maaned ROWS BETWEEN 12 PRECEDING AND 12 PRECEDING)  AS SammeMdSidsteAar,
		SUM(PrisIalt) OVER (PARTITION BY Aar ORDER BY Maaned ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS LoebendeSum
	FROM DataWarehouse.StatAggData;
GO
USE BIDb;
-- Agg i disk Tabel
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'StatAggData')
	DROP TABLE DataWarehouse.StatAggData;

CREATE TABLE DataWarehouse.StatAggData 
(
	ID			INT NOT NULL IDENTITY PRIMARY KEY NONCLUSTERED,
	Aar			SMALLINT NOT NULL INDEX nc_StatAggData_Aar,
	Maaned		SMALLINT NOT NULL,
	Maanedsnavn	VARCHAR(20) NOT NULL,
	PrisIalt	DECIMAL(13,2) NOT NULL
);
GO
WITH 
StatGrundData
AS
(
SELECT	YEAR(DataWarehouse.KundeSalg.LeveringsDato) AS Aar,
		MONTH(DataWarehouse.KundeSalg.LeveringsDato) AS Maaned,
		DataWarehouse.Maanedsnavn.Maanedsnavn_da AS Maanedsnavn,
		DataWarehouse.KundeSalg.Antalenheder * DataWarehouse.KundeSalg.Enhedspris AS PrisIalt
	FROM DataWarehouse.KundeSalg INNER JOIN DataWarehouse.Maanedsnavn
						ON MONTH(DataWarehouse.KundeSalg.LeveringsDato)  = DataWarehouse.Maanedsnavn.Maanedsnr
),
StatAggData
AS
(
SELECT	Aar,
		Maaned,
		Maanedsnavn,
		SUM(PrisIalt) AS PrisIalt
	FROM StatGrundData
	GROUP BY Aar, Maaned, Maanedsnavn
)
INSERT INTO DataWarehouse.StatAggData (Aar, Maaned, Maanedsnavn, PrisIalt)
	SELECT	Aar, 
			Maaned, 
			Maanedsnavn, 
			PrisIalt
		FROM StatAggData;
GO
SET STATISTICS TIME ON;

SELECT	*,
		AVG(PrisIalt) OVER (PARTITION BY Aar ORDER BY Maaned ROWS BETWEEN 3 PRECEDING AND 1 PRECEDING)  AS Gennemsnit3Mdr,
		AVG(PrisIalt) OVER (ORDER BY Aar, Maaned ROWS BETWEEN 12 PRECEDING AND 12 PRECEDING)  AS SammeMdSidsteAar,
		SUM(PrisIalt) OVER (PARTITION BY Aar ORDER BY Maaned ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS LoebendeSum
	FROM DataWarehouse.StatAggData;
GO
--- Performance
SET STATISTICS TIME ON;
USE BIDbInMem;
GO
SELECT *
	FROM DataWarehouse.Kunde INNER JOIN DataWarehouse.KundeSalg ON Kunde.KundeSkey = Kundesalg.KundeSkey;

-- SQL Server Execution Times:
--   CPU time = 0 ms,  elapsed time = 0 ms.
--SQL Server parse and compile time: 
--   CPU time = 5610 ms, elapsed time = 5701 ms.

--(2967389 row(s) affected)

-- SQL Server Execution Times:
--   CPU time = 16312 ms,  elapsed time = 83101 ms.
GO
USE BIDB;
GO
SELECT *
	FROM DataWarehouse.Kunde INNER JOIN DataWarehouse.KundeSalg ON Kunde.KundeSkey = Kundesalg.KundeSkey;

--SQL Server parse and compile time: 
--   CPU time = 0 ms, elapsed time = 0 ms.

-- SQL Server Execution Times:
--   CPU time = 0 ms,  elapsed time = 0 ms.
--SQL Server parse and compile time: 
--   CPU time = 0 ms, elapsed time = 8 ms.

--(2451065 row(s) affected)

-- SQL Server Execution Times:
--   CPU time = 34953 ms,  elapsed time = 67904 ms.
GO
DROP DATABASE BIDbInMem;
