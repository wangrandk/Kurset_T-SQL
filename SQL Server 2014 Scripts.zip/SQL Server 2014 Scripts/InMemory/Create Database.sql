USE master;
GO
DROP DATABASE InMemDB;
GO
CREATE DATABASE InMemDB
ON PRIMARY
(
	NAME = InMemDB_sys,
	FILENAME = N'C:\Databaser\InMemDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_NotInMem_filegroup  
(
	NAME = InMemDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\InMemDB_InMemDB_NotInMem_filegroup.ndf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = InMemDB_InMem_filegroup_fil1,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB1'
),
( 
	NAME = InMemDB_InMem_filegroup_fil2,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB2'
),
( 
	NAME = InMemDB_InMem_filegroup_fil3,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB3'
),
( 
	NAME = InMemDB_InMem_filegroup_fil4,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB4'
)
LOG ON
( 
	NAME = InMemDB_log_file_1,
	FILENAME = N'C:\Databaser\InMemDB_log.ldf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
)
COLLATE Danish_Greenlandic_100_BIN2;
GO
