USE master;
DROP DATABASE TestDB;
GO
CREATE DATABASE TestDB;
GO
USE TestDB;
CREATE TABLE dbo.t
(
	ID		INT NOT NULL PRIMARY KEY IDENTITY,
	Navn	VARCHAR(20) NOT NULL
);
GO
INSERT INTO dbo.t(Navn) VALUES
	('Ole'),
	('Ida');
GO
USE master;
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Pa$$w0rd';
GO
CREATE CERTIFICATE BackupEncryptCert
	WITH SUBJECT = 'Backup Encryption Certificate';
GO
BACKUP DATABASE TestDB
TO DISK = 'C:\Rod\TestDB.bak'
WITH
	COMPRESSION,
	ENCRYPTION 
	(
	ALGORITHM = AES_256,
	SERVER CERTIFICATE = BackupEncryptCert
	),
	STATS = 10;
GO
USE master
DROP DATABASE TestDB;
GO
-- P� samme server med samme masterkey, er der ikke noget specielt der skal foretages
RESTORE DATABASE TestDB
	FROM DISK = 'C:\Rod\TestDB.bak'
GO
USE TestDB;
SELECT *
	FROM dbo.t;
GO
-----------------------------
-- Backup af diverse keys, som skal anvendes hvis backup skal restores p� anden server
USE master
GO
BACKUP SERVICE MASTER KEY
	TO FILE = 'C:\Rod\service_master_key.key'
	ENCRYPTION BY PASSWORD = '�#��#$!5aGFbn1287))!jjjk';
GO
BACKUP MASTER KEY
	TO FILE = 'C:\Rod\master_key.key'
	ENCRYPTION BY PASSWORD = '�#��#$!5aGFbn1287))!jjjk';
GO
BACKUP CERTIFICATE BackupEncryptCert
TO FILE = 'C:\Rod\BackupEncryptCert.cer'
WITH PRIVATE KEY
	(
	FILE = 'C:\Rod\certificate_private_key.key',
	ENCRYPTION BY PASSWORD = '�#��#$!5aGFbn1287))!jjjk'
	);
GO
-- Restore diverse keys
RESTORE MASTER KEY
	FROM FILE = 'C:\Rod\service_master_key.key'
	DECRYPTION BY PASSWORD = '�#��#$!5aGFbn1287))!jjjk'
	ENCRYPTION BY PASSWORD = '@n0therStrongP@$$w0r2!';
GO
OPEN MASTER KEY
	DECRYPTION BY PASSWORD = '@n0therStrongP@$$w0r2!';
GO
CREATE CERTIFICATE Contoso_BackupEncryptionWithSQLServer2014
	FROM FILE = 'C:\Rod\BackupEncryptCert.cer'
	WITH PRIVATE KEY
	(
	FILE = 'c:\Rod\certificate_private_key.key',
	DECRYPTION BY PASSWORD = '�#��#$!5aGFbn1287))!jjjk'
	);
GO
-- Getting the list of files in the backup file
-- The instruction is identical for a non-encrypted database
RESTORE FILELISTONLY
	FROM DISK = 'C:\Rod\TestDB.bak';
GO
CLOSE MASTER KEY;
GO
ALTER MASTER KEY REGENERATE
	WITH ENCRYPTION BY PASSWORD = '�#��#$!5aGFbn1287))!jjjk';
