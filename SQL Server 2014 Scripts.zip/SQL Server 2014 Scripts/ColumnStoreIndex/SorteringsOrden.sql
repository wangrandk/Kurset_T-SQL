USE master;
GO
DROP DATABASE ColumnStoreDB;
GO
CREATE DATABASE ColumnStoreDB;
GO
ALTER DATABASE ColumnStoreDB SET DELAYED_DURABILITY = FORCED;
GO
USE ColumnStoreDB;
CREATE TABLE dbo.t
(
	ID			INT NOT NULL,
	Txt1		VARCHAR(20) NOT NULL,
	Txt2		VARCHAR(20) NOT NULL
);
GO
SET NOCOUNT ON;

DECLARE @s1		VARCHAR(40) = '157a324w9e8rfJJHGF0O/%fr45fd(/0=?JNnfdse';
DECLARE @s2		VARCHAR(40) = 'poIal7256#".,.mbbhhhhjafsr�)(/&%���l�kkk';
DECLARE @s3		VARCHAR(40) = 'FD43nngds7665L.,,976TR832sdEGbcxRTddoihk';

DECLARE @i			INT = 1;

WHILE @i < 1000000
BEGIN
	INSERT INTO dbo.t (ID, Txt1, Txt2) 
		VALUES (@i,	LEFT(@s1,(@i % 5) + 4), 
				LEFT(@s2, (@i % 3) + 3));
	INSERT INTO dbo.t (ID, Txt1, Txt2) 
		VALUES (@i + 1, 
				SUBSTRING(@s1, (@i % 20) + 1, (@i % DATEPART(NANOSECOND,SYSDATETIME())) % 9),
				LEFT(@s3, (@i % 11) + 3));
	INSERT INTO dbo.t (ID, Txt1, Txt2) 
		VALUES (@i + 2, 
				LEFT(@s1, (@i % 6) + 4),
				SUBSTRING(@s2, (@i % 12) + 3, (@i % DATEPART(NANOSECOND,SYSDATETIME())) % 13));

	SET @i += 3;
END;
GO
INSERT INTO dbo.t (ID, Txt1, Txt2)
	SELECT	ID + (SELECT MAX(ID) FROM dbo.t),
			Txt2,
			Txt1
		FROM dbo.t;

INSERT INTO dbo.t (ID, Txt1, Txt2)
	SELECT	ID + (SELECT MAX(ID) FROM dbo.t),
			LEFT(REVERSE(Txt2) + Txt1, (ID % 17) + 1),
			REVERSE(RIGHT(Txt2 + Txt1, (ID % 16) + 1))
		FROM dbo.t;
GO
SELECT COUNT(*)
	FROM dbo.t;
GO
CREATE CLUSTERED COLUMNSTORE INDEX cci_t
	ON dbo.t;
GO
SELECT *
	FROM sys.column_store_segments;

SELECT *
	FROM sys.column_store_dictionaries;

SELECT *
	FROM sys.column_store_row_groups;
GO
ALTER INDEX cci_t ON dbo.t REBUILD;
GO
DELETE
	FROM dbo.t
	WHERE ID < 300000;
