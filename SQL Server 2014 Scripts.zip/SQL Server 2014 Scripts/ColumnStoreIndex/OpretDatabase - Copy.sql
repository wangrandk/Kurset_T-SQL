USE master
GO
IF EXISTS (SELECT * 
				FROM sys.databases 
				WHERE name = 'ColumnStoreDB')
	DROP DATABASE ColumnStoreDB;
GO
CREATE DATABASE ColumnStoreDB
GO
USE ColumnStoreDB
GO
USE ColumnStoreDB;

CREATE TABLE dbo.Efternavn 
(
	Efternavn 		VARCHAR(20) NOT NULL
);

CREATE TABLE dbo.Fornavn 
(
	Fornavn 		VARCHAR(50) NOT NULL,
	Koen			CHAR(1) NOT NULL
);

CREATE TABLE dbo.Gade 
(
	Gade 			VARCHAR(30) NOT NULL
);

CREATE TABLE dbo.Postopl 
(
	PostNr 			SMALLINT		NOT NULL 
					CONSTRAINT PK_Postopl PRIMARY KEY (PostNr),
	Bynavn 			VARCHAR (20)	NOT NULL,
);

CREATE TABLE dbo.KundeType 
(
	KundeTypeKode	CHAR(1)			NOT NULL 
					CONSTRAINT PK_KundeTypeKode PRIMARY KEY,
	KundeTypeTxt	VARCHAR(20)		NOT NULL
);

CREATE TABLE dbo.Koen 
(
	KoenKode		CHAR(1)			NOT NULL 
					CONSTRAINT PK_Koen PRIMARY KEY,
	KoenText		VARCHAR(10)		NOT NULL
);

CREATE TABLE dbo.Kunde 
(
	KundeID 		INT 
					IDENTITY(1, 1)	NOT NULL
					CONSTRAINT PK_Kubde PRIMARY KEY,
	Fornavn 		VARCHAR(20)		NOT NULL,
	Efternavn 		VARCHAR(20)		NOT NULL,
	Gade 			VARCHAR(30)		NOT NULL,
	Postnr 			SMALLINT		NOT NULL 
					CONSTRAINT FK_Kunde_Postopl REFERENCES dbo.Postopl(Postnr),
	KundeTypeKode	CHAR(1)			NOT NULL
					CONSTRAINT FK_Kunde_KundeTypeKode REFERENCES dbo.KundeType(KundeTypeKode),
	KoenKode		CHAR(1)			NULL
					CONSTRAINT FK_Kunde_Koen REFERENCES dbo.Koen(KoenKode),
	Navn 			AS Fornavn + ' ' + Efternavn
);
GO
SET NOCOUNT ON;
IF (SELECT COUNT(*) 
		FROM dbo.Fornavn) > 0
	RETURN;
INSERT INTO dbo.Fornavn VALUES 
	('Anne', 'K'),
	('Ane', 'K'),
	('Annemette', 'K'),
	('Anne Mette', 'K'),
	('Anne Marie', 'K'),
	('Anders', 'M'),
	('And', 'M'),
	('Arne', 'M'),
	('Arvid', 'M'),
	('Allan', 'M'),
	('Birte', 'K'),
	('Birthe', 'K'),
	('Bente', 'K'),
	('Bent', 'K'),
	('B�rge', 'M'),
	('Bruno', 'M'),
	('Carl', 'M'),
	('Carina', 'K'),
	('Christian', 'M'),
	('Christina', 'K'),
	('Dorte', 'K'),
	('Dorthe', 'K'),
	('David', 'M'),
	('Daniel', 'M'),
	('Erik', 'M'),
	('Eva', 'K'),
	('Emma', 'K'),
	('Ebba', 'K'),
	('Ebbe', 'M'),
	('Ellen', 'K'),
	('Edvard', 'M'),
	('Edward', 'M'),
	('Egon', 'M'),
	('Esther', 'K'),
	('Frank', 'M'),
	('Frederikke', 'K'),
	('Frede', 'M'),
	('Frode', 'M'),
	('Frida', 'K'),
	('Grete', 'K'),
	('Gitte', 'K'),
	('Grethe', 'K'),
	('Gert', 'M'),
	('Gerd', 'K'),
	('Gunnar', 'M'),
	('Gustav', 'M'),
	('Gudrun', 'K'),
	('Henrik', 'M'),
	('Hans', 'M'),
	('Hanne', 'K'),
	('Henriette', 'K'),
	('Hedvig', 'K'),
	('Henry', 'M'),
	('Hugo', 'M'),
	('Ib', 'M'),
	('Ida', 'K'),
	('Ilse', 'K'),
	('Ivar', 'M'),
	('Ivan', 'M'),
	('Inger', 'K'),
	('Inge', 'K'),
	('Jens', 'M'),
	('Jakob', 'M'),
	('Jacob', 'M'),
	('Jesper', 'M'),
	('Jette', 'K'),
	('Jytte', 'K'),
	('Jane', 'K'),
	('Karl', 'M'),
	('Karen', 'K'),
	('Karin', 'K'),
	('Kis', 'K'),
	('Karina', 'K'),
	('Kurt', 'M'),
	('Knud', 'M'),
	('Kenneth', 'M'),
	('Lars', 'M'),
	('Lars Ole', 'M'),
	('Lars Bo', 'M'),
	('Ludvig', 'M'),
	('Line', 'K'),
	('Lise', 'K'),
	('Lisette', 'K'),
	('Lene', 'K'),
	('Lisbeth', 'K'),
	('Lena', 'K'),
	('Liselotte', 'K'),
	('Lise Lotte', 'K'),
	('Morten', 'M'),
	('Marie', 'K'),
	('Mads', 'M'),
	('Maren', 'K'),
	('Malene', 'K'),
	('Michael', 'M'),
	('Mikael', 'M'),
	('Niels', 'M'),
	('Nis', 'M'),
	('Nicolaj', 'M'),
	('Ninna', 'K'),
	('Nette', 'K'),
	('Nanna', 'K'),
	('Ole', 'M'),
	('Oda', 'K'),
	('Olivia', 'K'),
	('Oskar', 'M'),
	('Ove', 'M'),
	('Peter', 'M'),
	('Per', 'M'),
	('Petrea', 'K'),
	('Peder', 'M'),
	('Pil', 'K'),
	('Poul', 'M'),
	('Paul', 'M'),
	('Poula', 'K'),
	('Rasmus', 'M'),
	('Rie', 'K'),
	('Rikke', 'K'),
	('Richard', 'M'),
	('Rune', 'M'),
	('Ruth', 'K'),
	('Rosa', 'K'),
	('Robert', 'M'),
	('Rosita', 'K'),
	('S�ren', 'M'),
	('Sys', 'K'),
	('Sara', 'K'),
	('Simone', 'K'),
	('Susanne', 'K'),
	('Sanne', 'K'),
	('Sofus', 'M'),
	('Solvej', 'K'),
	('Signe', 'K'),
	('Thomas', 'M'),
	('Tove', 'K'),
	('Tommy', 'M'),
	('Tone', 'K'),
	('Trine', 'K'),
	('Tine', 'K'),
	('Tina', 'K'),
	('Tobias', 'M'),
	('Uffe', 'M'),
	('Ulla', 'K'),
	('Ulrik', 'M'),
	('Vera', 'K'),
	('Villy', 'M'),
	('Vagn', 'M'),
	('Willy', 'M'),
	('Yrsa', 'K'),
	('�jvind', 'M'),
	('�ge', 'M'),
	('�se', 'K');
GO
IF (SELECT COUNT(*) 
		FROM dbo.Efternavn) > 0
	RETURN;
INSERT INTO dbo.Efternavn VALUES 
	('Andersen'),
	('B�rgesen'),
	('Bentsen'),
	('Christensen'),
	('Christiansen'),
	('Carlsen'),
	('Davidsen'),
	('Danielsen'),
	('Eriksen'),
	('Frandsen'),
	('Frederiksen'),
	('Gertsen'),
	('Henriksen'),
	('Hansen'),
	('Iversen'),
	('Ibsen'),
	('Jensen'),
	('Jensen'),
	('Jakobsen'),
	('Jacobsen'),
	('Karlsen'),
	('Knudsen'),
	('Kristensen'),
	('Larsen'),
	('Lassen'),
	('Mortensen'),
	('Madsen'),
	('Mikkelsen'),
	('Nielsen'),
	('Nyborg'),
	('Olsen'),
	('Olesen'),
	('Pedersen'),
	('Petersen'),
	('Rasmussen'),
	('S�rensen'),
	('Thomsen'),
	('�vlisen'),
	('�gesen'),
	('�berg');
GO
IF (SELECT COUNT(*) 
		FROM dbo.Gade) > 0
	RETURN
INSERT INTO dbo.Gade VALUES 
	('N�rregade 2'),
	('N�rregade 34'),
	('N�rregade 27'),
	('N�rregade 67'),
	('Vestergade 3'),
	('Vestergade 56'),
	('Vestergade 5'),
	('�stergade 23'),
	('�stergade 1'),
	('S�ndergade 6'),
	('S�ndergade 78'),
	('Torvet 2'),
	('Torvet 4'),
	('Runddelen 1'),
	('Ved Stranden 3'),
	('Ved Stranden 5'),
	('Strandvejen 112'),
	('All�gade 29'),
	('Norgesgade 3'),
	('Ungarnsgade 4'),
	('Italiensvej 32'),
	('Strandvejen 2'),
	('All�gade 5'),
	('Norgesgade 38'),
	('Ungarnsgade 7'),
	('Italiensvej 21'),
	('Italiensvej 4'),
	('Bragesgade 1'),
	('Bragesgade 12'),
	('Dortesvej 4'),
	('Dortesvej 3'),
	('Ellebjergvej 114'),
	('Ellebjergvej 34'),
	('Ellebjergvej 65'),
	('Ellebjergvej 87'),
	('Frankrigsgade 14'),
	('Frankrigsgade 6'),
	('Frankrigsgade 115'),
	('Helgolandsgade 54'),
	('Helgolandsgade 19'),
	('Helgolandsgade 8'),
	('K�gevej 4'),
	('K�gevej 48'),
	('M�llegade 13'),
	('M�llegade 33'),
	('M�llegade 34'),
	('Ollerupvej 3'),
	('Sct. Pouls Gade 2'),
	('Sct. Pouls Gade 3'),
	('Sct. Pouls Gade 25'),
	('Willemoesgade 2'),
	('Willemoesgade 17');
GO
INSERT INTO dbo.Postopl VALUES 
	(1127, 'K�benhavn K'),
	(1001, 'K�benhavn K'),
	(1129, 'K�benhavn K'),
	(1130, 'K�benhavn K'),
	(2000, 'Frederiksberg'),
	(8000, 'Aarhus C'),
	(8200, 'Aarhus N'),
	(8240, 'Risskov'),
	(8270, 'H�jbjerg'),
	(8310, 'Tranbjerg J'),
	(9000, 'Aalborg'),
	(9400, 'N�rresundby'),
	(9600, 'Br�nderslev'),
	(9800, 'Hj�rring'),
	(9990, 'Skagen'),
	(3400, 'Hiller�d'),
	(3050, 'Humleb�k'),
	(2600, 'Glostrup'),
	(2605, 'Br�ndby'),
	(2610, 'R�dovre'),
	(2620, 'Albertslund'),
	(2625, 'Vallensb�k'),
	(2630, 'Taastrup'),
	(2635, 'Ish�j'),
	(2640, 'Hedehusene'),
	(2650, 'Hvidovre'),
	(2660, 'Br�ndby Strand'),
	(2665, 'Vallensb�k Strand'),
	(2670, 'Greve'),
	(2680, 'Solr�d Strand'),
	(2800, 'Kongens Lyngby'),
	(2820, 'Gentofte'),
	(2830, 'Virum'),
	(2840, 'Holte'),
	(2850, 'N�rum'),
	(2860, 'S�borg'),
	(2870, 'Dysseg�rd'),
	(2880, 'Bagsv�rd'),
	(2900, 'Hellerup'),
	(2920, 'Charlottenlund'),
	(2930, 'Klampenborg'),
	(2942, 'Skodsborg'),
	(2950, 'Vedb�k'),
	(5000, 'Odense C'),
	(5220, 'Odense S�'),
	(5700, 'Svendborg'),
	(2300, 'K�benhavn S'),
	(6051, 'Almind'),
	(6000, 'Kolding'),
	(6950, 'Ringk�bing'),
	(8700, 'Horsens');
GO
INSERT INTO dbo.KundeType VALUES
	('A', 'Almindelig'),
	('B', 'Firma'),
	('C', 'Storkunde'),
	('D', 'Ung - 14-18'),
	('E', 'Barn - 0-13');
GO
CREATE CLUSTERED INDEX cl_Fornavn ON dbo.Fornavn (Fornavn);
CREATE CLUSTERED INDEX cl_Efternavn ON dbo.Efternavn (Efternavn);
CREATE CLUSTERED INDEX cl_Gade ON dbo.Gade (Gade);
CREATE NONCLUSTERED INDEX nc_Postopl_Bynavn ON dbo.Postopl (Bynavn);
GO
INSERT INTO dbo.Koen VALUES 
	('K', 'Kvinde'),
	('M', 'Mand');
GO
SET NOCOUNT OFF;
GO
--INSERT INTO dbo.Kunde (Fornavn, Efternavn, Gade, Postnr, KoenKode, KundeTypeKode)
--   SELECT	Fornavn, 
--			Efternavn, 
--			Gade, 
--			Postnr, 
--			Koen, 
--			'A'
--      FROM dbo.Fornavn	INNER JOIN dbo.Efternavn		ON Fornavn.Fornavn > Efternavn.Efternavn
--					INNER JOIN dbo.Gade				ON Efternavn.Efternavn > Gade.Gade
--					INNER JOIN dbo.Postopl			ON Gade.Gade <> Postopl.Bynavn
--      WHERE LEN(Fornavn) + LEN(Efternavn) < 13;

--INSERT INTO dbo.Kunde (Fornavn, Efternavn, Gade, Postnr, KoenKode, KundeTypeKode)
--   SELECT	Fornavn, 
--			Efternavn, 
--			Gade, 
--			Postnr, 
--			Koen, 
--			'A'
--      FROM dbo.Fornavn INNER JOIN dbo.Efternavn		ON Fornavn.Fornavn < Efternavn.Efternavn
--                 INNER JOIN dbo.Gade			ON Efternavn.Efternavn < Gade.Gade
--                 INNER JOIN dbo.Postopl			ON Gade.Gade < Postopl.Bynavn;

INSERT INTO dbo.Kunde (Fornavn, Efternavn, Gade, Postnr, KoenKode, KundeTypeKode)
   SELECT	Fornavn, 
			Efternavn, 
			Gade, 
			Postnr, 
			Koen, 
			'A'
      FROM dbo.Fornavn	INNER JOIN dbo.Efternavn	ON Fornavn.Fornavn > Efternavn.Efternavn
					INNER JOIN dbo.Gade			ON Efternavn.Efternavn < Gade.Gade
					INNER JOIN dbo.Postopl		ON Gade.Gade > Postopl.Bynavn
      WHERE LEN(Fornavn) + LEN(Efternavn) > 16;
GO
CREATE NONCLUSTERED INDEX nc_Kunde__KundeID ON dbo.Kunde(KundeID);
CREATE NONCLUSTERED INDEX nc_Kunde__Postnr ON dbo.Kunde(Postnr);
GO
UPDATE dbo.Kunde
	SET KundeTypeKode = 'B'
	WHERE KundeID % 95 = 1;

UPDATE dbo.Kunde
	SET KundeTypeKode = 'C'
	WHERE KundeID % 997 = 1;

UPDATE dbo.Kunde
	SET KundeTypeKode = 'D'
	WHERE KundeID % 9999 = 1;

UPDATE dbo.Kunde
	SET KoenKode = NULL
	WHERE KundeID % 37834 = 1;
GO
CREATE NONCLUSTERED INDEX nc_Kunde__KundeType ON dbo.Kunde (KundeTypeKode);
GO
DROP TABLE dbo.Fornavn;
DROP TABLE dbo.Efternavn;
DROP TABLE dbo.Gade;
GO
CREATE TABLE dbo.Medarbejder 
(
	MedarbejderID		SMALLINT	NOT NULL PRIMARY KEY,
	Fornavn				VARCHAR(20) NOT NULL, 
	Efternavn			VARCHAR(20) NOT NULL, 
	Gade				VARCHAR(30) NOT NULL, 
	Postnr				SMALLINT	NOT NULL REFERENCES Postopl, 
	ChefId				SMALLINT	NULL,
	CONSTRAINT FK_Medarbejder_Chef FOREIGN KEY (Chefid) REFERENCES dbo.Medarbejder(MedarbejderID)
);
GO
INSERT INTO dbo.Medarbejder VALUES 
	(1, 'Ida', 'Andersen', 'Vestergade 23', 2000, NULL),
	(2, 'Jens', 'Pedersen', 'Torvet 2', 1127, 1),
	(3, 'Ane', 'Larsen', '�stergade 4', 1129, 1),
	(4, 'Peter', 'Madsen', 'S�ndergade 11', 2605, 1),
	(5, 'Lone', 'Olsen', 'Sankt Peders Str�de 1', 2610, 2),
	(6, 'Tina', 'Olesen', 'Kirkevej 14', 2600, 2),
	(7, 'Carl', 'Thomsen', 'Nygade 6', 2000, 3),
	(8, 'Lars', 'Jensen', 'Vestergade 1', 1127, 3),
	(9, 'Hans', 'Hansen', '�stergade 9', 1129, 3),
	(10, 'Sofie', 'Carlsen', 'Vejlevej 4', 2000, 4),
	(11, 'Rita', 'Knudsen', 'Irlandsvej 78', 2630, 4),
	(12, '�ge', 'Rasmussen', 'Christiansgade 3', 2000, 4),
	(13, 'Per', 'Aagaard', 'S�ndergade 17', 2635, 10),
	(14, 'Dorthe', 'Ibsen', 'Lille Str�de 6', 2000, 10),
	(15, 'Vivi', 'Davidsen', '�stergade 24 23', 1127, 11),
	(16, 'Bo', 'Jensen', 'Torvet 7', 1129, 11),
	(17, 'Michael', 'Christensen', 'Bredgade 112', 2000, 11),
	(18, 'Irene', 'Eriksen', 'S�ndergade 34', 2600, 11);
GO
CREATE TABLE dbo.Kategori 
(
	KategoriID		SMALLINT		NOT NULL 
					CONSTRAINT PK_Kategori PRIMARY KEY,
	KategoriNavn	VARCHAR(30)		NOT NULL
);

CREATE TABLE dbo.SubKategori 
(
	SubKategoriID	SMALLINT		NOT NULL 
					CONSTRAINT PK_SubKategori PRIMARY KEY,
	SubKategoriNavn	VARCHAR(30)		NOT NULL,
	KategoriID		SMALLINT		NOT NULL
					CONSTRAINT FK_SubKategori_Kategori REFERENCES dbo.Kategori (KategoriID)
);

CREATE TABLE dbo.Vare 
(
	VareID			SMALLINT		NOT NULL IDENTITY
					CONSTRAINT PK_Vare PRIMARY KEY,
	Varenavn		VARCHAR(30)		NOT NULL,
	VejledendePris	DECIMAL(9,2)	NULL,
	SubKategoriID	SMALLINT		NOT NULL
					CONSTRAINT FK_Vare_SubKategori REFERENCES dbo.SubKategori (SubKategoriID)
);

CREATE TABLE dbo.Salgskanal 
(
	SalgskanalID	SMALLINT		NOT NULL 
					CONSTRAINT PK_Salgskanal PRIMARY KEY,
	SalgskanalNavn	VARCHAR(30)		NOT NULL,
	SorteringsOrden	SMALLINT		NOT NULL
);

CREATE TABLE dbo.KundeSalg 
(
	SalgId			INT				NOT NULL IDENTITY (1,1),
	KundeID			INT				NOT NULL,
	VareID			SMALLINT		NOT NULL,
	SalgskanalID	SMALLINT		NOT NULL,
	MedarbejderID	SMALLINT		NULL,
	BestillingsDato	DATE			NULL,
	SalgsDato		DATE			NOT NULL DEFAULT (SYSDATETIME()),
	AntalEnheder	SMALLINT		NOT NULL
					CONSTRAINT CK_Salg_AntalEnheder CHECK (AntalEnheder > 0),
	EnhedsPris		DECIMAL(9,2)	NOT NULL
);
GO
CREATE TABLE dbo.Tid 
(
	TidID			INT				NOT NULL IDENTITY (1,1)
					CONSTRAINT PK_Time PRIMARY KEY,
	Dato			DATE			NOT NULL,
	Aar				SMALLINT		NOT NULL,
	KvartalsNr		SMALLINT		NOT NULL,
	MaanedsNr		SMALLINT		NOT NULL,
	MaanedsNavn		VARCHAR(12)		NOT NULL,
	DagNrIMaaned	SMALLINT		NOT NULL,
	DagnrIUge		SMALLINT		NOT NULL,
	DagNavn			VARCHAR(12)		NOT NULL
);
GO
CREATE TABLE dbo.Maanedsnavn 
(
	Maanedsnr		SMALLINT		NOT NULL
					CONSTRAINT PK_Maanedsnavn PRIMARY KEY,
	Maanedsnavn_da	VARCHAR(12)		NOT NULL
);
GO
CREATE TABLE dbo.Ugedagsnavn 
(
	Ugedagsnr		SMALLINT		NOT NULL
					CONSTRAINT PK_Ugedagsnavn PRIMARY KEY,
	Ugedagsnavn_da	VARCHAR(12)		NOT NULL
);
GO
SET NOCOUNT ON
INSERT INTO dbo.Salgskanal VALUES 
	(0, 'Ukendt', 4),
	(1, 'Butik', 1),
	(2, 'Internet', 3),
	(3, 'Telefon', 2);
GO
INSERT INTO dbo.Kategori VALUES 
	(1, 'Frugt og Gr�ntsager'),
	(2, 'Dagligvarer'),
	(3, 'Husholdningsartikler');
GO
INSERT INTO dbo.SubKategori VALUES 
	(1, 'Frugt', 1),
	(2, 'Gr�ntsager', 1),
	(3, 'Kaffe og Te', 2),
	(4, 'Mel, Gryn, mv.', 2),
	(5, 'Vand og Juice', 2),
	(6, '�l og Vin', 2),
	(7, 'Toiletartikler', 3),
	(8, 'Reng�ringsmidler', 3),
	(9, 'Plasticposer mv.', 3);
GO
INSERT INTO dbo.Vare VALUES 
	('�ble', 20.00, 1),
	('Appelsin', 30.00, 1),
	('Blomme', 15.00, 1),
	('Jordb�r', 27.00, 1),
	('Kiwi', 8.00, 1),
	('Vandmelon', 10.00, 1),
	('Fersken', 10.00, 1),
	('Honningmelon', 15.00, 1),
	('Netmelon', 13.00, 1),
	('Vindruer - gr�nne', 17.25, 1),
	('Vindruer - bl�', 18.50, 1),
	('Grapefrugt', 8.00, 1);

INSERT INTO dbo.Vare VALUES 
	('Guler�dder', 15.00, 2),
	('Kartofler', 9.00, 2),
	('L�g', 10.00, 2),
	('For�rsl�g', 12.00, 2),
	('Porer', 18.00, 2),
	('Pastinak', 6.00, 2),
	 ('Jordskok', 8.00, 2),
	('Selleri', 13.25, 2),
	('Bagekartofler', 13.00, 2);

INSERT INTO dbo.Vare VALUES 
	('Kaffe', 27.00, 3),
	('Te', 15.00, 3),
	('Urtete', 20.00, 3),
	('�kologisk kaffe', 37.00, 3);

INSERT INTO dbo.Vare VALUES 
	('Rugmel', 9.75, 4),
	('Sukker', 8.50, 4),
	('Havregryn', 19.75, 4),
	('Bygmel', 14.00, 4),
	('R�rsukker', 22.50, 4),
	('Hvedemel', 8.75, 4),
	('3-korns mel', 16.25, 4);

INSERT INTO dbo.Vare VALUES 
	('Sodavand - 30cl', 3.00, 5),
	('Sodavand - 50cl', 5.00, 5),
	('Sodavand - 1 liter', 9.00, 5),
	('�blejuice', 5.00, 5),
	('Appelsinjuice', 4.50, 5),
	('Gulerodsjuice', 7.50, 5),
	('�kologisk �blejuice', 7.00, 5),
	('�kologisk Appelsinjuice', 6.50, 5),
	('Blandet juice', 7.75, 5);

INSERT INTO dbo.Vare VALUES 
	('�l', 4.00, 6),
	('R�dvin', 65.00, 6),
	('Hvidvin', 45.00, 6),
	('Rose', 39.75, 6);

INSERT INTO dbo.Vare VALUES 
	('Toiletpapir', 40.00, 7),
	('Papirslommet�rkl�de', 2.50, 7),
	('Vatpinde', 12.25, 7),
	('Vat', 10.00, 7),
	('S�be', 8.00, 7),
	('H�rshampoo', 29.75, 7),
	('Badesalt', 35.50, 7);

INSERT INTO dbo.Vare VALUES 
	('Opvaskemiddel', 12.00, 8),
	('WC-rens', 23.50, 8),
	('Brun s�be', 6.50, 8),
	('S�besp�ner', 8.75, 8),
	('Reng�ringssvamp', 9.50, 8),
	('Karklud - bomuld', 19.50, 8),
	('Karklud - fiber', 14.50, 8),
	('Gulvklud', 19.50, 8);

INSERT INTO dbo.Vare VALUES 
	('Affaldsposer - alm.', 6.00, 9),
	('Affaldsposer - store', 8.00, 9),
	('Sorte Affaldss�kke', 13.00, 9),
	('Klare Affaldss�kke', 13.00, 9),
	('Frostposer - 1 liter', 9.00, 9),
	('Frostposer - 2 liter', 14.00, 9),
	('Frostposer - 5 liter', 19.00, 9),
	('Frostposer - 8 liter', 29.00, 9);

INSERT INTO dbo.Maanedsnavn VALUES 
	(1, 'Januar'),
	(2, 'Februar'),
	(3, 'Marts'),
	(4, 'April'),
	(5, 'Maj'),
	(6, 'Juni'),
	(7, 'Juli'),
	(8, 'August'),
	(9, 'September'),
	(10, 'Oktober'),
	(11, 'November'),
	(12, 'December');

INSERT INTO dbo.Ugedagsnavn VALUES 
	(1, 'Mandag'),
	(2, 'Tirsdag'),
	(3, 'Onsdag'),
	(4, 'Torsdag'),
	(5, 'Fredag'),
	(6, 'L�rdag'),
	(7, 'S�ndag');

SET NOCOUNT OFF;
GO
SET NOCOUNT ON;
INSERT INTO dbo.KundeSalg(KundeID, VareID, SalgskanalID, MedarbejderID, BestillingsDato, SalgsDato, AntalEnheder, EnhedsPris)
	SELECT	Kunde.KundeID, 
			Vare.VareID, 
			3 AS SalgskanalID, 
			Medarbejder.MedarbejderID,
			NULL,
			DATEADD(DAY, -4, SYSDATETIME()) AS Salgsdato, 
			2 AS AntalEnheder,
			VejledendePris
		FROM dbo.Kunde, dbo.Vare, dbo.Medarbejder
		WHERE	Kunde.KundeID % 2017 = 37 AND
				Vare.vareID % 6 = 2 AND
				Medarbejder.MedarbejderID % 5 = 1;

INSERT INTO dbo.KundeSalg (KundeID, VareID, SalgskanalID, MedarbejderID, BestillingsDato, SalgsDato, AntalEnheder, EnhedsPris)
	SELECT	Kunde.KundeID, 
			Vare.VareID, 
			2 AS SalgskanalID, 
			Medarbejder.MedarbejderID,
			NULL,
			DATEADD(DAY, -12, SYSDATETIME()) AS Salgsdato, 
			1 AS AntalEnheder,
			VejledendePris
		FROM dbo.Kunde, dbo.Vare, dbo.Medarbejder
		WHERE	Kunde.KundeID % 436 = 11 AND
				Vare.vareID % 9 = 1 AND
				Medarbejder.MedarbejderID % 7 = 1;
GO
DECLARE @i	INT
SET @i = 23
WHILE @i < 1000
BEGIN
	INSERT INTO dbo.KundeSalg (KundeID, VareID, SalgskanalID, MedarbejderID, BestillingsDato, SalgsDato, AntalEnheder, EnhedsPris)
		SELECT	Kunde.KundeID, 
			Vare.VareID, 
			1 AS SalgskanalID, 
			Medarbejder.MedarbejderID,
			NULL,
			DATEADD(DAY, @i, SYSDATETIME()) AS Salgsdato, 
			1 AS AntalEnheder,
			VejledendePris
		FROM dbo.Kunde, dbo.Vare, dbo.Medarbejder
		WHERE	Kunde.KundeID % @i = 6 AND
				Vare.VareID IN (@i % 33, @i % 18, @i % 12) AND
				Medarbejder.MedarbejderID IN (9 % 2, 9 % 4, 9 % 6, 9 % 8)
		SET @i = @i + 7;
END
GO
INSERT INTO KundeSalg (KundeID, VareID, SalgskanalID, MedarbejderID, BestillingsDato, SalgsDato, AntalEnheder, EnhedsPris)
	SELECT	Kunde.KundeID, 
			Vare.VareID, 
			2 AS SalgskanalID, 
			Medarbejder.MedarbejderID,
			NULL,
			DATEADD(DAY, -27, SYSDATETIME()) AS Salgsdato, 
			3 AS AntalEnheder,
			CAST(VejledendePris AS DECIMAL(7,0))
		FROM dbo.Kunde, dbo.Vare, dbo.Medarbejder
		WHERE	Kunde.KundeID % 43600 = 234 AND
				Vare.vareID % 11 = 4 AND
				Medarbejder.MedarbejderID % 9 = 5;

INSERT INTO dbo.KundeSalg (KundeID, VareID, SalgskanalID, MedarbejderID, BestillingsDato,SalgsDato, AntalEnheder, EnhedsPris)
	SELECT	Kunde.KundeID, 
			Vare.VareID, 
			3 AS SalgskanalID, 
			Medarbejder.MedarbejderID,
			NULL,
			DATEADD(DAY, -21, SYSDATETIME()) AS Salgsdato, 
			5 AS AntalEnheder,
			CAST(VejledendePris AS DECIMAL(7,0)) - 0.5
		FROM dbo.Kunde, dbo.Vare, dbo.Medarbejder
		WHERE	Kunde.KundeID % 57500 = 6890 AND
				Vare.vareID % 16 = 3 AND
				Medarbejder.MedarbejderID % 8 = 2;
GO
UPDATE dbo.KundeSalg
	SET BestillingsDato = DATEADD(DAY, -1, SalgsDato)
	WHERE SalgskanalID = 2;
	
UPDATE dbo.KundeSalg
	SET BestillingsDato = DATEADD(DAY, -2, SalgsDato)
	WHERE SalgskanalID = 3;
GO
UPDATE dbo.KundeSalg
	SET EnhedsPris = EnhedsPris * 0.95
	WHERE AntalEnheder = 3;
GO
UPDATE dbo.KundeSalg
	SET EnhedsPris = EnhedsPris * 0.9
	WHERE AntalEnheder = 4;
GO
DELETE TOP (80) PERCENT 
	FROM dbo.Kunde
	WHERE KundeId NOT IN (SELECT Kundeid 
							FROM dbo.KundeSalg);

SET NOCOUNT OFF;
GO
SET NOCOUNT ON
DECLARE @StartDato		DATE;
DECLARE @SlutDato		DATE;
DECLARE @Maanedsnr		SMALLINT;
DECLARE @DagnrUge		SMALLINT;
DECLARE @Maanedsnavn	VARCHAR(12);
DECLARE @Dagnavn		VARCHAR(12);

SET DATEFIRST 1;

SET @StartDato = (SELECT MIN(Salgsdato) 
						FROM KundeSalg);
SET @SlutDato =  (SELECT MAX(Salgsdato) 
						FROM KundeSalg);
SET @SlutDato = DATEADD(yy, 1, @SlutDato);

WHILE @StartDato <= @SlutDato
BEGIN
	SET @Maanedsnr = MONTH(@StartDato);
	SET @Maanedsnavn = (SELECT Maanedsnavn_da FROM Maanedsnavn WHERE Maanedsnr = @Maanedsnr);

	SET @DagnrUge = DATEPART(WEEKDAY, @Startdato);
	SET @Dagnavn = (SELECT Ugedagsnavn_da FROM Ugedagsnavn WHERE Ugedagsnr = @DagnrUge);

	INSERT INTO Tid(Dato, Aar, KvartalsNr, MaanedsNr, MaanedsNavn, 
					 DagNrIMaaned, DagNrIUge, DagNavn)
		VALUES (@Startdato, 
				YEAR(@Startdato),
				DATEPART(QUARTER, @Startdato),
				@Maanedsnr, 
				@Maanedsnavn,
				DAY(@Startdato), 
				@DagnrUge, 
				@Dagnavn);

	SET @Startdato = DATEADD(DAY, 1, @Startdato);
END;
SET NOCOUNT OFF;
GO
DECLARE @time	DATE = SYSDATETIME();

SELECT	IDENTITY(INT) AS OrdreId, 
		KundeID, 
		VareID, 
		DATEADD(DAY, - KundeID % 200, @time)  AS BestillingsDato,
		DATEADD(DAY, - KundeID % 200 + 14, @time)  AS LeveringsDato,
		DATEADD(DAY, - KundeID % 200 + 14, @time)  AS FaktureringsDato,
		DATEADD(DAY, - KundeID % 200, @time)  AS BetalingsDato,
		NULL AS RykkerDato, 
		AntalEnheder
	INTO Ordre
	FROM (SELECT	KundeID, 
					VareID, 
					SUM(AntalEnheder) AS AntalEnheder
				FROM (SELECT TOP 100000 *  FROM KundeSalg) AS ks
				GROUP BY KundeID, VareID) AS Salg
	ORDER BY KundeID, VareID;
GO
-- vis alle tabeller og antal forekomster
USE ColumnStoreDB;
GO
SET NOCOUNT ON
DECLARE @TableName		SYSNAME;
DECLARE @SchemaName		SYSNAME;
DECLARE @Antal			INT;
DECLARE @SQLString		NVARCHAR(500);

DECLARE @t TABLE
(
	ID					INT			NOT NULL IDENTITY,
	Object_id			INT			NOT NULL,
	TableName			SYSNAME		NOT NULL, 
	SchemaName			SYSNAME		NOT NULL,
	AntalForkomster		INT			NULL,
	Brugt				CHAR(1)		NOT NULL DEFAULT('N')
);

INSERT INTO @t (Object_id, TableName, SchemaName)
	SELECT	t.object_id, 
			t.name, 
			s.name 
		FROM sys.tables as t INNER JOIN sys.schemas as s 
			ON t.schema_id = s.schema_id
		ORDER BY t.name;

WHILE EXISTS (SELECT * FROM @t WHERE Brugt = 'N')
BEGIN
	SELECT @TableName = TableName, 
			@SchemaName = SchemaName
		FROM @t
		WHERE ID = (SELECT MIN(ID) 
						FROM @t 
						WHERE Brugt = 'N');
		
	SET @SQLString = 'SET @Antal = (SELECT COUNT(*) FROM ' + @SchemaName + '.' + @TableName + ')';
	EXECUTE sp_executesql @SqlString, N'@Antal INT OUTPUT', @Antal OUTPUT;

	UPDATE @t
		SET		AntalForkomster = @Antal, 
				Brugt = 'Y'
		WHERE	TableName = @TableName AND 
				SchemaName = @SchemaName;
END
SELECT	TableName, 
		SchemaName, 
		AntalForkomster 
	FROM @t
	ORDER BY TableName, SchemaName;
GO
------------------------------------------------------------------------------------------
SELECT i.name,  ps.* 
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('Kundesalg'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
GO
-- Clustered ColumnStore Index
CREATE CLUSTERED COLUMNSTORE INDEX cci_Kundesalg
	ON dbo.Kundesalg;
GO
SELECT i.name,  ps.*				-- Viser ikke Columnstore Index
	FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('Kundesalg'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
GO
SELECT *
	FROM sys.indexes
	WHERE object_id = OBJECT_ID('dbo.Kundesalg');

SELECT *
	FROM sys.column_store_segments;

SELECT *
	FROM sys.column_store_dictionaries;
	 
SELECT *
	FROM sys.column_store_row_groups;
GO
SELECT object_id, index_id, size_in_bytes
	FROM sys.column_store_row_groups;

DROP INDEX cci_Kundesalg ON dbo.Kundesalg;

SELECT i.name,  ps.page_Count * 8192 AS size_in_bytes
	FROM sys.dm_db_index_physical_stats(DB_ID(), object_id('Kundesalg'), NULL, NULL , 'DETAILED') AS ps INNER JOIN sys.indexes AS i
				ON ps.object_id = i.object_id AND ps.index_id = i.index_id;
GO
-- �ndring af data
INSERT INTO KundeSalg (KundeID, VareID, SalgskanalID, MedarbejderID, BestillingsDato,SalgsDato, AntalEnheder, EnhedsPris)
	SELECT	Kunde.KundeID, 
			Vare.VareID, 
			2 AS SalgskanalID, 
			Medarbejder.MedarbejderID,
			NULL,
			DATEADD(DAY, -17, SYSDATETIME()) AS Salgsdato, 
			5 AS AntalEnheder,
			CAST(VejledendePris AS DECIMAL(7,0)) - 0.5
		FROM Kunde, Vare, Medarbejder
		WHERE	Kunde.KundeID % 34567 = 2345 AND
				Vare.vareID % 12 = 8 AND
				Medarbejder.MedarbejderID % 6 = 3;

UPDATE KundeSalg
	SET EnhedsPris = EnhedsPris * 0.9
	WHERE AntalEnheder = 2;
GO
-- Performance
PRINT '----------------------';
PRINT '----- Uden index -----';
PRINT '----------------------';
SET STATISTICS TIME ON;
GO
SELECT	KundeID,
		VareID,
		AntalEnheder,
		EnhedsPris
	FROM dbo.Kundesalg;
GO
SELECT	KundeID,
		AntalEnheder,
		EnhedsPris
	FROM dbo.Kundesalg
	WHERE KundeId > 300000;
GO
SELECT DISTINCT BestillingsDato
	FROM dbo.Kundesalg;
GO
SET STATISTICS TIME OFF;
GO
CREATE NONCLUSTERED INDEX nc_Kundesalg_2_3_8_9 
	ON Kundesalg (KundeID, VareID, AntalEnheder, EnhedsPris);

CREATE NONCLUSTERED INDEX nc_Kundesalg_Bestillingsdato
	ON Kundesalg (Bestillingsdato);
GO
-- Performance
PRINT '----------------------------------------';
PRINT '----- Relevante nonclustered index -----';
PRINT '----------------------------------------';
SET STATISTICS TIME ON;
GO
SELECT	KundeID,
		VareID,
		AntalEnheder,
		EnhedsPris
	FROM dbo.Kundesalg;
GO
SELECT	KundeID,
		AntalEnheder,
		EnhedsPris
	FROM dbo.Kundesalg
	WHERE KundeId > 300000;
GO
SELECT DISTINCT BestillingsDato
	FROM dbo.Kundesalg;
GO
SET STATISTICS TIME OFF;
GO
DROP INDEX nc_Kundesalg_2_3_8_9 ON Kundesalg;
DROP INDEX nc_Kundesalg_Bestillingsdato ON Kundesalg;
GO
CREATE CLUSTERED COLUMNSTORE INDEX cci_Kundesalg
	ON dbo.Kundesalg;
GO
PRINT '---------------------------------------';
PRINT '----- Columnstore Clustered Index -----';
PRINT '---------------------------------------';
SET STATISTICS TIME ON;
GO
SELECT	KundeID,
		VareID,
		AntalEnheder,
		EnhedsPris
	FROM dbo.Kundesalg;
GO
SELECT	KundeID,
		AntalEnheder,
		EnhedsPris
	FROM dbo.Kundesalg
	WHERE KundeId > 300000;
GO
SELECT DISTINCT BestillingsDato
	FROM dbo.Kundesalg;
GO
SET STATISTICS TIME OFF;
GO
DROP INDEX cci_Kundesalg ON dbo.Kundesalg;
GO