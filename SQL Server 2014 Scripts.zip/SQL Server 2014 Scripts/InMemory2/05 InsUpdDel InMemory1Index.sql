USE master;
GO
DROP DATABASE HashDB;
GO
CREATE DATABASE HashDB
ON PRIMARY
(
	NAME = HashDB_sys,
	FILENAME = N'C:\Databaser\HashDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP HashDB_filegroup  
(
	NAME = HashDB_filegroup_1,
	FILENAME = N'C:\Databaser\HashDB_filegroup.ndf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
)
LOG ON
( 
	NAME = HashDB_log_file_1,
	FILENAME = N'C:\Databaser\HashDB_log.ldf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 10%
);
GO
USE HashDB;
CREATE TABLE dbo.HashTable
(
	HashValue			SMALLINT NOT NULL PRIMARY KEY,
	FirstID				INT NULL
) ON HashDB_filegroup;

CREATE TABLE dbo.Data
(
	DataID					INT NOT NULL PRIMARY KEY IDENTITY,
	StartTransactionID		INT NOT NULL,
	EndTransactionID		INT NULL,
	Indexcount				SMALLINT NOT NULL DEFAULT(1),
	NextID					INT NULL,

-- Data i tabellen

	ID						INT NOT NULL,			--PRIMARY KEY
	Navn					VARCHAR(20) NOT NULL,
) ON HashDB_filegroup;
GO
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'BucketSizeTable')
BEGIN
	DROP TABLE BucketSizeTable;
	TRUNCATE TABLE dbo.HashTable;
	TRUNCATE TABLE dbo.Data;
END;
SELECT BucketCount
	INTO dbo.BucketSizeTable
	FROM (VALUES (20)) AS bz(BucketCount);
GO
-- Initialisering af Bucket-tabel
DECLARE @BucketCount	SMALLINT = (SELECT BucketCount FROM dbo.BucketSizeTable);
 
WITH BucketCount
AS
(
SELECT	0 AS HashValue,
		NULL AS ID
UNION ALL
SELECT	HashValue + 1,
		ID
	FROM BucketCount
	WHERE HashValue < @BucketCount - 1
)
INSERT INTO dbo.HashTable
	SELECT *
		FROM BucketCount
		OPTION (MAXRECURSION 0);
GO
SELECT *
	FROM dbo.HashTable;
GO
CREATE SEQUENCE TransactionsID
    AS INT
    START WITH 1
    INCREMENT BY 1;
GO
CREATE PROCEDURE dbo.usp_Insert
(
	@ID						INT,
	@Navn					VARCHAR(20),
	@TrannsactionsID		INT	
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @BucketCount	SMALLINT = ABS(CAST(HASHBYTES('SHA', @Navn) AS SMALLINT) % (SELECT BucketCount FROM dbo.BucketSizeTable));
	DECLARE @DataID			INT;
	DECLARE @GlDataID		INT;

	IF EXISTS(SELECT *							-- F�rste forekomst for Bucketcount
				FROM dbo.HashTable
				WHERE	HashValue = @BucketCount AND
						FirstID IS NULL)
	BEGIN
		INSERT 
			INTO dbo.Data (StartTransactionID, EndTransactionID, Indexcount, NextID, Id, Navn) VALUES
			(@TrannsactionsID, NULL, 1, NULL, @ID, @Navn);

		UPDATE dbo.HashTable
			SET FirstID = SCOPE_IDENTITY()
			WHERE HashValue = @BucketCount;
	END
	ELSE
	BEGIN
		SELECT @DataID = FirstID
			FROM dbo.HashTable
			WHERE HashValue = @BucketCount;

		WHILE EXISTS (SELECT *
						FROM dbo.Data
						WHERE	DataID = @DataID AND
								NextID IS NOT NULL)
		BEGIN
			SELECT	@DataID = NextID,
					@GlDataID = ID
				FROM dbo.Data
				WHERE DataId = @DataID;

			IF @GlDataID = @ID					-- Samme ID findes 'midt' i k�den
				THROW 88765, 'ID findes i forvejen', 1;
		END;

		IF @ID = (SELECT ID FROM dbo.Data WHERE DataID = @DataID)
			THROW 88765, 'ID findes i forvejen', 1;

		INSERT 
			INTO dbo.Data (StartTransactionID, EndTransactionID, Indexcount, NextID, Id, Navn) VALUES
			(@TrannsactionsID, NULL, 1, NULL, @ID, @Navn);

		UPDATE dbo.Data
			SET NextId = SCOPE_IDENTITY()
			WHERE Dataid = @DataID;
	END;
END;
GO
CREATE PROCEDURE dbo.usp_Delete
(
	@ID						INT,
	@TrannsactionsID		INT	
)
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE dbo.Data
		SET EndTransactionID = @TrannsactionsID
		WHERE	ID = @ID AND
				EndTransactionID IS NULL;

	RETURN @@ROWCOUNT;
END;
GO
CREATE PROCEDURE dbo.usp_Update_Navn
(
	@ID						INT,
	@Navn					VARCHAR(20),		
	@TrannsactionsID		INT	
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @AntalSlettet		INT;

	EXEC @AntalSlettet = dbo.usp_Delete @ID, @TrannsactionsID;

	IF @AntalSlettet > 0
		EXEC dbo.usp_Insert @ID, @Navn, @TrannsactionsID;
END;
GO
-- BEGIN TRANSACTION 
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Insert 7, 'Ole', @TransactionID;

SELECT *
	FROM dbo.Data;

SELECT *
	FROM dbo.HashTable
	WHERE FirstID IS NOT NULL;
GO
-- BEGIN TRANSACTION 
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Insert 10, 'Ole', @TransactionID;

SELECT *
	FROM dbo.Data;

SELECT *
	FROM dbo.HashTable
	WHERE FirstID IS NOT NULL;
GO
SET NOCOUNT ON;
-- BEGIN TRANSACTION 
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Insert 33, 'Ole', @TransactionID;
EXEC dbo.usp_Insert 37, 'Ole', @TransactionID;
EXEC dbo.usp_Insert 39, 'Ole', @TransactionID;
-- END TRANSACTION 

SELECT *
	FROM dbo.Data;

SELECT *
	FROM dbo.HashTable
	WHERE FirstID IS NOT NULL;
GO
-- BEGIN TRANSACTION
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Insert 13, 'Ane', @TransactionID;
-- BEGIN TRANSACTION

SELECT *
	FROM dbo.Data;

SELECT *
	FROM dbo.HashTable
	WHERE FirstID IS NOT NULL;
GO
-- BEGIN TRANSACTION 
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Insert 11, 'Per', @TransactionID;
EXEC dbo.usp_Insert 14, 'Lars', @TransactionID;
EXEC dbo.usp_Insert 15, 'Hanne', @TransactionID;
EXEC dbo.usp_Insert 21, 'Knud', @TransactionID;
EXEC dbo.usp_Insert 22, 'Hanne', @TransactionID;
EXEC dbo.usp_Insert 32, 'Maren', @TransactionID;
-- END TRANSACTION

SELECT *
	FROM dbo.Data
	ORDER BY DataID;

SELECT *
	FROM dbo.HashTable
	WHERE FirstID IS NOT NULL
	ORDER BY HashValue;
GO
-- BEGIN TRANSACTION
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Insert 67, 'Ole', @TransactionID;
EXEC dbo.usp_Insert 78, 'Ole', @TransactionID;
EXEC dbo.usp_Insert 87, 'Ole', @TransactionID;
-- END TRANSACTION

SELECT *
	FROM dbo.Data
	ORDER BY DataID;

SELECT *
	FROM dbo.HashTable
	WHERE FirstID IS NOT NULL
	ORDER BY HashValue;
GO
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Delete 33, @TransactionID;

SELECT *
	FROM dbo.Data
	ORDER BY DataID;

SELECT *
	FROM dbo.HashTable
	WHERE FirstID IS NOT NULL
	ORDER BY HashValue;
GO
-- BEGIN TRANSACTION
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Delete 67, @TransactionID;
EXEC dbo.usp_Delete 78, @TransactionID;
-- END TRANSACTION

SELECT *
	FROM dbo.Data
	ORDER BY DataID;

SELECT *
	FROM dbo.HashTable
	WHERE FirstID IS NOT NULL
	ORDER BY HashValue;
GO
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Update_Navn 37, 'Ole Erik', @TransactionID;
EXEC dbo.usp_Update_Navn 14, 'Lars Emil', @TransactionID;

EXEC dbo.usp_Update_Navn 33, 'Ole Viggo', @TransactionID;

SELECT *
	FROM dbo.Data
	ORDER BY DataID;

SELECT *
	FROM dbo.HashTable
	WHERE FirstID IS NOT NULL
	ORDER BY HashValue;
GO
CREATE PROCEDURE dbo.usp_Select_Alle
(
	@TransactionID			INT
)
AS
BEGIN
	SELECT	ID,
			Navn
		FROM dbo.Data
		WHERE EndTransactionID IS NULL AND
			  StartTransactionID <= @TransactionID
	UNION ALL
	SELECT	ID,
			Navn
		FROM dbo.Data
		WHERE @TransactionID BETWEEN StartTransactionID AND EndTransactionID
	ORDER BY ID;
END;
GO
DECLARE @TransactionID		INT = (NEXT VALUE FOR TransactionsID);

EXEC dbo.usp_Select_Alle @TransactionID;

SELECT *
	FROM dbo.Data
	ORDER BY ID;

GO
DECLARE @TransactionID		INT = 4;

EXEC dbo.usp_Select_Alle @TransactionID;

SELECT *
	FROM dbo.Data
	ORDER BY ID;
GO
CREATE PROCEDURE dbo.Garbage
(
	@TransactionID			INT
)
AS
BEGIN
	DECLARE @BucketCount	INT = 0;
	DECLARE @DataID			INT;
	DECLARE @NextDataID		INT;
	DECLARE @PrevDataID		INT;

	WHILE @BucketCount < (SELECT BucketCount
								FROM dbo.BucketSizeTable)
	BEGIN
		SET @DataID = (SELECT FirstId
							FROM dbo.HashTable
							WHERE HashValue = @BucketCount);
		SET @PrevDataID = NULL;

		WHILE @DataID IS NOT NULL
		BEGIN
			IF EXISTS (SELECT *
							FROM dbo.Data
							WHERE	DataID = @DataID AND
									EndTransactionID < @TransactionID)
			BEGIN
				SET @NextDataID = (SELECT NextID 
										FROM dbo.Data 
										WHERE DataID = @DataID);

				IF @PrevDataID IS NULL
				BEGIN
					UPDATE dbo.HashTable
						SET FirstID = @NextDataID
						WHERE HashValue = @BucketCount;
				END
				ELSE
				BEGIN											-- Ikke f�rste i k�den slettes
					UPDATE dbo.Data
						SET NextID = @NextDataID
						WHERE DataId = @PrevDataID;
				END;

				DELETE
					FROM dbo.Data
					WHERE DataID = @DataID;
			

				SET @DataID = (SELECT FirstId
									FROM dbo.HashTable
									WHERE HashValue = @BucketCount);
				SET @PrevDataID = NULL;
			END
			ELSE
			BEGIN
				SET @PrevDataID = @DataID;
				SET @DataId = (SELECT NextID	
								FROM dbo.Data
								WHERE DataID = @DataID);
			END;
		END;
	
		SET @BucketCount += 1;
	END;
END;
GO
SELECT *
	FROM dbo.Data
	ORDER BY DataID;

EXEC dbo.Garbage 8

SELECT *
	FROM dbo.Data
	ORDER BY DataID;

