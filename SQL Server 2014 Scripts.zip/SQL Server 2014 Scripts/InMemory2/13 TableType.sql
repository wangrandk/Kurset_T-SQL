USE master;
GO
DROP DATABASE InMemDB;
GO
CREATE DATABASE InMemDB
ON PRIMARY
(
	NAME = InMemDB_sys,
	FILENAME = N'C:\Databaser\InMemDB_sys.mdf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_NotInMem_filegroup  
(
	NAME = InMemDB_NotInMem_filegroup_1,
	FILENAME = N'C:\Databaser\InMemDB_InMemDB_NotInMem_filegroup.ndf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
),
FILEGROUP InMemDB_InMem_filegroup CONTAINS MEMORY_OPTIMIZED_DATA
( 
	NAME = InMemDB_InMem_filegroup_1,
    FILENAME = N'C:\Databaser\InMem_Data_InMemDB'
)
LOG ON
( 
	NAME = InMemDB_log_file_1,
	FILENAME = N'C:\Databaser\InMemDB_log.ldf',
	SIZE = 10MB,
	MAXSIZE = 50MB,
	FILEGROWTH = 10%
);
GO
USE InMemDB
SET NOCOUNT ON
GO
CREATE TYPE dbo.KundeInMem_Type
AS TABLE
(
	KundeID			INT NOT NULL PRIMARY KEY NONCLUSTERED,
	Fornavn			VARCHAR(20) NOT NULL,
	Efternavn		VARCHAR(20) NOT NULL,
	INDEX hash_index_Person_Navn HASH (Fornavn) WITH (BUCKET_COUNT = 1000000)
)
WITH (MEMORY_OPTIMIZED = ON);

CREATE TYPE dbo.KundeNotInMem_Type
AS TABLE
(
	KundeID			INT NOT NULL PRIMARY KEY NONCLUSTERED,
	Fornavn			VARCHAR(20) NOT NULL INDEX nc_Kunde_Fornavn,
	Efternavn		VARCHAR(20) NOT NULL
);

BEGIN TRY
	CREATE TABLE #Tider
	(
		ID			INT NOT NULL PRIMARY KEY IDENTITY,
		Type		VARCHAR(20) NOT NULL,
		Tid			BIGINT NOT NULL
	);
END TRY
BEGIN CATCH
	TRUNCATE TABLE #Tider;
END CATCH
GO
DECLARE @Kunde		dbo.KundeInMem_Type;
DECLARE @i			INT = 1;
DECLARE @Starttid	DATETIME2 = SYSDATETIME();

WHILE @i <= 100000
BEGIN
	INSERT INTO @Kunde VALUES 
		(@i, 'Ole', 'Hansen')
	SET @i += 1;
END;

INSERT INTO #Tider(Type, Tid) VALUES
	('InMem', DATEDIFF(MICROSECOND, @Starttid, SYSDATETIME()));
GO 10
DECLARE @Kunde		dbo.KundeNotInMem_Type;
DECLARE @i			INT = 1;
DECLARE @Starttid	DATETIME2 = SYSDATETIME();

WHILE @i <= 100000
BEGIN
	INSERT INTO @Kunde VALUES 
		(@i, 'Ida', 'Larsen')
	SET @i += 1;
END;

INSERT INTO #Tider(Type, Tid) VALUES
	('NotInMem', DATEDIFF(MICROSECOND, @Starttid, SYSDATETIME()));
GO 10
SELECT	Type, 
		AVG(Tid) AS Gennemsnitstid,
		COUNT(*) AS AntalForsoeg,
		MIN(Tid) AS MindsteTid,
		MAX(Tid) AS StoersteTid
	FROM #Tider
	GROUP BY Type;
