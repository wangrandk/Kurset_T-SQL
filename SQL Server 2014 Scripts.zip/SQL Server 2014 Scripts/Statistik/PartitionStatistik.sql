USE master;
GO
DROP DATABASE StatsDemoDB;
GO
CREATE DATABASE StatsDemoDB;
GO 
USE StatsDemoDB;
GO 
CREATE PARTITION FUNCTION pf_Data (INT) 
	AS RANGE LEFT FOR VALUES (10000, 20000, 30000, 40000); 
GO 
CREATE PARTITION SCHEME ps_Data 
	AS PARTITION pf_Data ALL TO ([Primary]);
GO
CREATE TABLE dbo.Data
( 
	Id			INT NOT NULL,
	Balance		INT NOT NULL,
	Name		VARCHAR(50)
) ON ps_Data (Id);
GO 
CREATE CLUSTERED INDEX cl_Data__Id 
	ON dbo.Data (Id)
	WITH (STATISTICS_INCREMENTAL = ON)
	ON ps_Data (Id);
GO 
SELECT * 
	FROM sys.partitions 
	WHERE object_id = OBJECT_ID('dbo.Data');
GO 
SET NOCOUNT ON
DECLARE @i INT = 1;
DECLARE @Balance INT = 1;

WHILE @i <= 50000
BEGIN 
    IF @i % 3 = 0 
		INSERT INTO dbo.Data VALUES(@i, @Balance, CONCAT(@i, 'xxxxxxxxxx', 100000 - @i))
	ELSE
		IF @i % 3 = 1 
			INSERT INTO dbo.Data VALUES(@i, @Balance, CONCAT(@i, 'yyyyyyyyyy', 100000 - @i))
		ELSE 
			INSERT INTO dbo.Data VALUES(@i, @Balance, CONCAT(@i, 'zzzzzzzzzz', 100000 - @i));

	SET @i += 1; 
	SET @Balance += 1; 
END;

INSERT INTO dbo.Data
	SELECT	Id + (SELECT MAX(Id) FROM dbo.Data),
			Balance,
			CONCAT(ID, Name) AS Name
		FROM dbo.Data
		WHERE Id % 17 > 8

INSERT INTO dbo.Data
	SELECT	Id + (SELECT MAX(Id) FROM dbo.Data),
			Balance,
			CONCAT(ID, Name) AS Name
		FROM dbo.Data
		WHERE Id % 23 < 13
GO
SELECT COUNT(*)
	FROM dbo.Data; 
GO 
CREATE NONCLUSTERED INDEX nc_Data__Name 
	ON dbo.Data (Name) 
	WITH (STATISTICS_INCREMENTAL = ON)
	ON ps_Data (Id);
GO
DBCC SHOW_STATISTICS('dbo.Data','nc_Data__Name') 
GO
