USE IndexFilegrpDB
GO
CREATE NONCLUSTERED INDEX nc_Person__Navn__Gade_Postnr 
	ON dbo.Person (Navn) INCLUDE(Gade, Postnr)
	WITH (STATISTICS_INCREMENTAL = ON) 
	ON partition_schema_index (PersonId);
GO
DBCC SHOW_STATISTICS (Person, nc_Person__Navn__Gade_Postnr);
GO
UPDATE STATISTICS dbo.Person 
	WITH FULLSCAN, INCREMENTAL = ON;
GO
INSERT INTO dbo.Person
	(
	Fornavn,
	Efternavn,
	Gade,
	Postnr,
	Koenkode,
	Landekode,
	Tlfnr,
	Persontype
	)
	SELECT TOP 200000
		  Fornavn,
		  Efternavn,
		  Gade,
		  Postnr,
		  Koenkode,
		  Landekode,
		  Tlfnr,
		  Persontype
	  FROM dbo.Person
GO
DBCC SHOW_STATISTICS (Person, nc_Person__Navn__Gade_Postnr);
GO
UPDATE STATISTICS dbo.Person  WITH RESAMPLE ON PARTITIONS (5), INCREMENTAL = ON;
GO
DBCC SHOW_STATISTICS (Person, nc_Person__Navn__Gade_Postnr);
GO
UPDATE STATISTICS dbo.Person  WITH RESAMPLE ON PARTITIONS (6), INCREMENTAL = ON;
GO
DBCC SHOW_STATISTICS (Person, nc_Person__Navn__Gade_Postnr);
GO
SELECT *
	FROM sys.dm_db_incremental_stats_properties(OBJECT_ID('dbo.Person'), 1);
