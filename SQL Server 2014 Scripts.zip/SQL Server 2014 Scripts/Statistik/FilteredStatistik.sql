USE master;
GO
DROP DATABASE StatsDemoDB;
GO
CREATE DATABASE StatsDemoDB;
GO 
USE StatsDemoDB;
GO 
CREATE PARTITION FUNCTION pf_Data (INT) 
	AS RANGE LEFT FOR VALUES (10000, 20000); 
GO 
CREATE PARTITION SCHEME ps_Data 
	AS PARTITION pf_Data ALL TO ([Primary]);
GO
CREATE TABLE dbo.Data
( 
	Id			INT NOT NULL,
	Balance		INT NOT NULL,
	Name		VARCHAR(25)
) ON ps_Data (Id);
GO 
CREATE CLUSTERED INDEX cl_Data__Id 
	ON dbo.Data (Id); 
GO 
SELECT * 
	FROM sys.partitions 
	WHERE object_id = OBJECT_ID('dbo.Data');
GO 
SET NOCOUNT ON
DECLARE @Counter INT = 1;
DECLARE @Balance INT = 1;

WHILE (@Counter <= 30000) 
BEGIN 
    IF @Counter % 3 = 0 
		INSERT INTO dbo.Data VALUES(@Counter, @Balance, 'xxxxxxxxxx')
	ELSE
		IF @Counter % 3 = 1 
			INSERT INTO dbo.Data VALUES(@Counter, @Balance, 'yyyyyyyyyy')
		ELSE 
			INSERT INTO dbo.Data VALUES(@Counter, @Balance, 'zzzzzzzzzz');

	SET @Counter += 1; 
	SET @Balance += 1; 
END;
GO
SELECT COUNT(*) 
	FROM dbo.Data; 
GO 
CREATE NONCLUSTERED INDEX nc_Data__Id_Name 
	ON dbo.Data (Id, Name) 
	WHERE Balance > 20000;
GO
SELECT	Id,
		Name 
	FROM dbo.Data 
	WHERE balance > 20000 
GO 
DBCC SHOW_STATISTICS('dbo.Data','nc_Data__Id_Name') 
GO
DELETE 
	FROM dbo.Data 
	WHERE Id > 25000;
GO
SELECT	Id,
		Name 
	FROM dbo.Data 
	WHERE	Balance > 20000 AND
			Id > 20000 
GO 
DBCC SHOW_STATISTICS('dbo.Data','nc_Data__Id_Name') 
GO
DELETE 
	FROM dbo.Data 
	WHERE Id BETWEEN 15000 AND 20000;
GO
SELECT	Id,
		Name 
	FROM dbo.Data 
	WHERE	Balance > 20000 AND
			Id > 20000 
GO 
DBCC SHOW_STATISTICS('dbo.Data','nc_Data__Id_Name') 
GO
