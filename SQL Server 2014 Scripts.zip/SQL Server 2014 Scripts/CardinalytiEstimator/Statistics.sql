USE IndexDB
GO
CREATE STATISTICS st_Person__Fornavn ON dbo.Person(Fornavn);
CREATE STATISTICS st_Person__Efternavn ON dbo.Person(Efternavn);
GO
DBCC SHOW_STATISTICS ('dbo.Person', st_Person__Fornavn);
DBCC SHOW_STATISTICS ('dbo.Person', st_Person__Efternavn);
GO
CREATE TABLE dbo.HistogramFornavn
(
	ID						INT NOT NULL IDENTITY,
	Range_Hi_Key			VARCHAR(255),
	Range_Rows				BIGINT,
	Eq_Rows					FLOAT,
	Distinct_Range_Rows		BIGINT,
	Avg_Range_Rows			FLOAT
);
GO
INSERT INTO dbo.HistogramFornavn (Range_Hi_Key, Range_Rows, Eq_Rows, Distinct_Range_Rows, Avg_Range_Rows)
	EXEC('DBCC SHOW_STATISTICS (''dbo.Person'', st_Person__Fornavn) WITH HISTOGRAM');
GO
CREATE TABLE dbo.HistogramEfternavn
(
	ID						INT NOT NULL IDENTITY,
	Range_Hi_Key			VARCHAR(255),
	Range_Rows				BIGINT,
	Eq_Rows					FLOAT,
	Distinct_Range_Rows		BIGINT,
	Avg_Range_Rows			FLOAT
);
GO
INSERT INTO dbo.HistogramEfternavn (Range_Hi_Key, Range_Rows, Eq_Rows, Distinct_Range_Rows, Avg_Range_Rows)
	EXEC('DBCC SHOW_STATISTICS (''dbo.Person'' , st_Person__Efternavn) WITH HISTOGRAM');
GO
CREATE TABLE dbo.HeaderFornavn
(
	Name					SYSNAME NOT NULL,
	Updated					DATETIME NOT NULL,
	Rows					BIGINT NOT NULL,
	RowsSampled				BIGINT NOT NULL,
	Steps					INT NOT NULL,
	Density					FLOAT NOT NULL,
	AverageKeyLength		FLOAT NOT NULL,
	StringIndex				VARCHAR(255) NOT NULL,
	FilterExpression		VARCHAR(8000) NULL,
	UnfilterdRows			BIGINT NOT NULL
);
GO
INSERT INTO dbo.HeaderFornavn (Name, Updated, Rows, RowsSampled, Steps, Density,AverageKeyLength, StringIndex,FilterExpression, UnfilterdRows)
	EXEC('DBCC SHOW_STATISTICS (''dbo.Person'', st_Person__Fornavn) WITH STAT_HEADER');
GO
CREATE TABLE dbo.HeaderEfternavn
(
	Name					SYSNAME NOT NULL,
	Updated					DATETIME NOT NULL,
	Rows					BIGINT NOT NULL,
	RowsSampled				BIGINT NOT NULL,
	Steps					INT NOT NULL,
	Density					FLOAT NOT NULL,
	AverageKeyLength		FLOAT NOT NULL,
	StringIndex				VARCHAR(255) NOT NULL,
	FilterExpression		VARCHAR(8000) NULL,
	UnfilterdRows			BIGINT NOT NULL
);
GO
INSERT INTO dbo.HeaderEfternavn (Name, Updated, Rows, RowsSampled, Steps, Density,AverageKeyLength, StringIndex,FilterExpression, UnfilterdRows)
	EXEC('DBCC SHOW_STATISTICS (''dbo.Person'', st_Person__Efternavn) WITH STAT_HEADER');
GO
SELECT *
	FROM dbo.HeaderFornavn;

SELECT *
	FROM HistogramFornavn;
GO
SELECT *
	FROM dbo.HeaderEfternavn;

SELECT *
	FROM HistogramEfternavn;
GO
DROP STATISTICS dbo.Person.st_Person__Fornavn;
DROP STATISTICS dbo.Person.st_Person__Efternavn;
GO
CREATE NONCLUSTERED INDEX mc_Person__Fornavn ON dbo.Person(Fornavn);
CREATE NONCLUSTERED INDEX mc_Person__Efternavn ON dbo.Person(Efternavn);
GO
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT *
	FROM dbo.Person
	WHERE	Fornavn = 'Ole' OR 
			Efternavn = 'Hansen';

SELECT *
	FROM dbo.Person
	WHERE	NOT
			(NOT Fornavn = 'Ole' AND 
			 NOT Efternavn = 'Hansen');

SELECT *
	FROM dbo.Person
	WHERE	NOT
			(Fornavn <> 'Ole' AND 
			 Efternavn <> 'Hansen');

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
DELETE TOP (90) PERCENT
	FROM dbo.Person
	WHERE Fornavn = 'Ole';

DELETE TOP (90) PERCENT
	FROM dbo.Person
	WHERE Efternavn = 'Hansen';
GO
UPDATE STATISTICS dbo.Person WITH FULLSCAN;
GO
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT COUNT(*)
	FROM dbo.Person
	WHERE	Fornavn = 'Ole' OR 
			Efternavn = 'Hansen';

SELECT COUNT(*)
	FROM dbo.Person
	WHERE	NOT
			(NOT Fornavn = 'Ole' AND 
			 NOT Efternavn = 'Hansen');

SELECT COUNT(*)
	FROM dbo.Person
	WHERE	NOT
			(Fornavn <> 'Ole' AND 
			 Efternavn <> 'Hansen');
GO
DBCC FREEPROCCACHE;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT	Fornavn,
		Efternavn
	FROM dbo.Person
	WHERE	Fornavn BETWEEN 'Ole' AND 'Per' OR 
			Efternavn BETWEEN 'Hansen' AND 'Iversen'
	OPTION (
			RECOMPILE,
			QUERYTRACEON 3604,
			QUERYTRACEON 9204
			);

DBCC FREEPROCCACHE;

SELECT	Fornavn,
		Efternavn
	FROM dbo.Person
	WHERE	NOT
			( Fornavn NOT BETWEEN 'Ole' AND 'Per' AND 
			  Efternavn NOT BETWEEN 'Hansen' AND 'Iversen')
	OPTION (
			RECOMPILE,
			QUERYTRACEON 3604,
			QUERYTRACEON 9204
			);