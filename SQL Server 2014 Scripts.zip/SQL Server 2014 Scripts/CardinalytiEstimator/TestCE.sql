USE IndexDB;
GO
--DROP INDEX nc_Person_Persontype ON dbo.Person;
--DROP INDEX nc_Person_Koen ON dbo.Person;
GO
CREATE NONCLUSTERED INDEX nc_Person_Persontype ON dbo.Person (Persontype);
CREATE NONCLUSTERED INDEX nc_Person_Koen ON dbo.Person (Koenkode);
GO
SELECT Persontype, COUNT(*) AS Antal
	FROM dbo.Person
	GROUP BY Persontype;

SELECT Koenkode, COUNT(*) AS Antal
	FROM dbo.Person
	GROUP BY Koenkode;
GO
SET STATISTICS XML ON;

SELECT		Persontype, 
			Koenkode
	FROM dbo.Person
	WHERE	Persontype = 'D' AND
			Koenkode IS NULL;

SELECT		Persontype, 
			Koenkode
	FROM dbo.Person
	WHERE	Persontype = 'D' OR
			Koenkode IS NULL;
SET STATISTICS XML OFF;
GO
SET STATISTICS XML ON;

SELECT		Persontype, 
			Koenkode
	FROM dbo.Person
	WHERE	Persontype = 'C' OR
			Koenkode IS NULL
	OPTION (QUERYTRACEON 9481);		-- version 7.0

SELECT		Persontype, 
			Koenkode
	FROM dbo.Person
	WHERE	Persontype = 'C' OR
			Koenkode IS NULL
	OPTION (QUERYTRACEON 2312);		-- version 2014

SET STATISTICS XML OFF;
GO
SELECT TOP 90 PERCENT *
	INTO dbo.SletPersonKoenkodeNULL
	FROM dbo.Person
	WHERE Koenkode IS NULL;
GO
DELETE 
	FROM dbo.Person
	WHERE PersonId IN (SELECT PersonId FROM dbo.SletPersonKoenkodeNULL);
GO
UPDATE STATISTICS dbo.Person
	WITH FULLSCAN;
GO
SET IDENTITY_INSERT dbo.Person ON;
INSERT INTO dbo.Person(PersonID, Fornavn, Efternavn, Gade, Postnr, Koenkode, Landekode, Tlfnr, Persontype)
	SELECT	PersonID, 
			Fornavn, 
			Efternavn, 
			Gade, 
			Postnr, 
			Koenkode, 
			Landekode, 
			Tlfnr, 
			Persontype
		FROM dbo.SletPersonKoenkodeNULL;
SET IDENTITY_INSERT dbo.Person OFF;
GO
SELECT MAX(PersonId)
	FROM dbo.Person;
GO
INSERT INTO dbo.Person(Fornavn, Efternavn, Gade, Postnr, Koenkode, Landekode, Tlfnr, Persontype)
	SELECT	TOP 1000000
			Fornavn, 
			Efternavn, 
			Gade, 
			Postnr, 
			Koenkode, 
			Landekode, 
			Tlfnr, 
			Persontype
		FROM dbo.Person;
GO
SET STATISTICS XML ON;

SELECT		Persontype, 
			Koenkode
	FROM dbo.Person
	WHERE	PersonId BETWEEN 5200000 AND 5300000
	OPTION (QUERYTRACEON 9481);		-- version 7.0

SELECT		Persontype, 
			Koenkode
	FROM dbo.Person
	WHERE	PersonId BETWEEN 5200000 AND 5300000
	OPTION (QUERYTRACEON 2312);		-- version 2014

SET STATISTICS XML OFF;
GO
INSERT INTO dbo.Persontype (Persontype, PersontypeTxt)
	VALUES ('F', 'f-kode');
GO
UPDATE dbo.Person
	SET Persontype = 'F'
	WHERE PersonId BETWEEN 5200001 AND 5200500;
GO
SET STATISTICS XML ON;

SELECT		Persontype, 
			Koenkode
	FROM dbo.Person
	WHERE	Persontype = 'F'
	OPTION (QUERYTRACEON 9481);		-- version 7.0

SELECT		Persontype, 
			Koenkode
	FROM dbo.Person
	WHERE	Persontype = 'F'
	OPTION (QUERYTRACEON 2312);		-- version 2014

SET STATISTICS XML OFF;
GO
SET STATISTICS XML ON
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT		p1.Persontype,
			p2.Persontype, 
			p1.Koenkode
	FROM dbo.Person AS p1 INNER JOIN dbo.Person AS p2 ON p1.Persontype = p2.Persontype
	WHERE	p1.Persontype = 'F'
	OPTION (QUERYTRACEON 9481);		-- version 7.0

SELECT		p1.Persontype,
			p2.Persontype, 
			p1.Koenkode
	FROM dbo.Person AS p1 INNER JOIN dbo.Person AS p2 ON p1.Persontype = p2.Persontype
	WHERE	p1.Persontype = 'F'
	OPTION (QUERYTRACEON 2312);		-- version 2014

SET STATISTICS XML OFF;
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
UPDATE STATISTICS dbo.Person
	WITH FULLSCAN;
