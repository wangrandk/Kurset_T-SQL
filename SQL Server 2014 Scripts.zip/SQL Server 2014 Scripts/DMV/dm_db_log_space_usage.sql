-- ny info : log_space_in_bytes_since_last_backup

SELECT *
	FROM sys.dm_db_log_space_usage;
